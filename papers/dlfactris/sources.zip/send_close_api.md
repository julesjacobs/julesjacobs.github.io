The send_close API could look like this:

* fork
* c.send(b, v) where b indicates whether we want to close
* c.recv() -> (b, v) where b indicates whether the other side wants to close