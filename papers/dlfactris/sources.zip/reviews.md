# POPL 2024 Paper #234 Reviews and Comments

Paper #234 Deadlock-Free Separation Logic: Linearity Yields Progress for
Dependent Higher-Order Message Passing

# Review #234A

## Overall merit

A. Strong accept: I will argue for acceptance.

## Reviewer expertise

X. Expert: I am an expert on the topic of the paper (or at least key
aspects of it).

## Summary of the paper

This paper integrates linear session types, which can be used to prove deadlock-freedom of channel-based communicating programs, into the Actris line of work that combines separation logic and session types. The result is a linear separation logic for channel-based programs, LinearActris, that guarantees deadlock-freedom of any program that can be verified. While the paper draws heavily on prior work, it also addresses new challenges that have not appeared in any of the prior work. Most significantly, while Actris was able to use the generic weakest preconditions and adequacy proof of the Iris framework, LinearActris requires a more complicated adequacy proof that maintains a well-formed connectivity graph throughout the execution of the program.

## Assessment of the paper

This appears to be a problem where a relatively small advance in the state of the art requires a large amount of technical work, on both the theoretical and the practical side. The use of connectivity graphs as an invariant on execution is a neat idea that has been executed carefully and explained well. The material is well-presented and admirably self-contained for work that relies on so many different strands of prior work. The paper suffers a bit from the absence of evaluation and discussion sections, making it hard to get a top-level picture of what has been accomplished and how much of the technical work might be reused in future developments.

## Detailed comments for authors

## Major comments:

The only comprehensive evaluation appears to be in the introduction, where it is mentioned in passing that you verified various examples from Actris 2.0. There is also no discussion or conclusion. Maybe the intro and related work say everything you want to say, but it would be nice to see both a recap of what you accomplished, and some hints at where else all this work could be put to use. Two things in particular stand out to me. First, LinearActris clearly can't use general Iris invariants, and I wonder whether you know of channel-communicating programs where such invariants would be useful. Second, the paper ends with a tantalizing comment about applying your approach to general Iris invariants, and I'd love to see either more explanation or other examples of more limited invariants that your approach might apply to.

There are a few things I'm confused about with regard to the example in section 5.2, page 16, used to demonstrate the problem with leaks. First, this is the only example in the section to be written with multi-shot channels -- is there no one-shot analogue? Second, the undesirable behavior described appears to be ruled out by weak channel acyclicity, since it only arises when $c_1$ and $c_2$ are two endpoints of the same channel owned by a single thread. Finally, I found it harder than in the other examples to see how the rules of LinearActris rule out this behavior; it would help to give a short explanation of why the example program would be impossible to verify.

## Minor comments:

Line 825/826 contains the phrase "ownership of the channel ownership", which is at least confusing and probably an error.

On line 914, $\mathsf{WP}_0$ is used before it is defined. The mutual recursion is addressed later, but it's worth at least giving a brief intuition for it at this point.

## Line edits:

8: "program" -> "programs"

146: "used in to" -> "used to"

467/468, etc.: "used verify" -> "used to verify"

847: "strongly acyclic" -> "strong acyclicity"

976-977: "weakest preconditions rules" -> "weakest precondition rules"

1033: "$!A.\ S$ and $!A.\ S$" -> "$!A.\ S$ and $?A.\ S$"

1153/1154: "constructs" -> "construct"

1195-1196: "invariants mechanisms" -> "invariant mechanisms"

## Questions to be addressed by author response

Do you expect that the restrictions on invariants required by the linear logic will prevent you from verifying any real programs of interest? Do you know of any examples where they're needed?

Does the leak example actually illustrate the need for strong acyclicity? Is there anything special about the rules of LinearActris that take strong acyclicity into account, or does it just fall out from the linear handling of channels and separation logic?

# Review #234B

## Overall merit

B. Weak accept: I lean towards acceptance.

## Reviewer expertise

Y. Knowledgeable: I am knowledgeable about the topic of the paper (or at
least key aspects of it).

## Summary of the paper

This paper presents a linear concurrent separation logic, LinearActris. It shows that LinearActris guarantees deadlock- and leak-freedom. Moreover, it shows how LinearActris can be used to provide a logical-relations model for a higher-order GV-like calculus. All of the results are proven in Coq.

## Assessment of the paper

The goal of deadlock-free concurrent programming is an important one, and a separation-logic approach seems natural, especially when dealing with programs that mix message-passing and shared-memory concurrency. While I'm not an expert in separation logic, this paper did a very good job of explaining where previous work failed to achieve deadlock freedom, and why their solution works better. There are several parts in the paper where I felt like things were a bit vague---the definition of the connectivity graph, for instance---but I appreciate that this was previous work, and space is limited. Even there, the intuitive explanation was enough for me to believe that the result works as intended, and that a precise definition of the terms involved was not difficult.

However, I had one major concern: how does LinearActris reason about shared-memory concurrency? It certainly has it; see the example on lines 283-284. However, it seems like any locks would have to be encoded via busy waiting, which keeps your definition of deadlock-freedom from recognizing deadlock. This is exactly the complaint you made about Idris! It seems to me that this seriously weakens the story, since you only get deadlock freedom for the message-passing component of your program.

Even with this major issue, I think that the insights in this paper are enough to warrant a publication. However, it keeps me from enthusiastically supporting it, leading to my rating.

## Detailed comments for authors

There were very few typos or grammatical errors in the paper. Well done!

L 146: Extra "in"

L 862: In what sense is "$\ell \mapsto v \in \text{Prot}$"? $\ell \mapsto v$ is a proposition, $v$ is a value, and $\ell$ is a location---none of these are protocols!

L 951: Where does $\Phi$ come from?

L 1013: "different" should be "difference"

Figure 7: Shouldn't one of the $S$s in the fork rule be dualized?

L1154: "constructs" should be "construct"

# Review #234C

## Overall merit

B. Weak accept: I lean towards acceptance.

## Reviewer expertise

Y. Knowledgeable: I am knowledgeable about the topic of the paper (or at
least key aspects of it).

## Summary of the paper

This paper proposes a linear concurrent separation logic for channel-based message-passing concurrency. The logic follows the idea of session types and uses dependent separation protocols to reason about channels. It supports higher-order functions, mutable states, and channels as first-class citizen. Soundness of the logic is proved using the step-indexed model. The soundness ensures not only safety, but also deadlock-freedom and leak-freedom. In particular, the deadlock-freedom is guaranteed by the linear channel assertions of the program logic, so that there's no need of explicit ordering of blocking channel operations.

## Assessment of the paper

**Strength:**

- The use of linear separation logic to ensure deadlock-freedom is elegant.
- The paper is well written and easy to follow.

**Weakness:**

- Key ideas of this work are not totally new. This logic is an extension of Actris. The use of connectivity graph to prove deadlock-freedom follows Jacobs et al. [2022a]. The key idea of using linear separation logic assertions to ensure deadlock-freedom seems to be a natural extension.

## Detailed comments for authors

In general I like the paper, which is well written. The idea to ensure deadlock-freedom is elegant.

The paper takes the narrower sense of deadlock-freedom, which is still a safety property and ensures there's no circular waiting of threads. This relies on having blocking primitives in the language. Correspondingly, the key ideas are developed around logic rules for the blocking primitives. This makes the approach a bit ad-hoc. For instance, it's unclear how it scales to languages with multiple sets of blocking primitives (e.g., having both channels and locks). Also, does it work for channels that allow for multiple senders and receivers?

A more challenging problem is to verify the deadlock-freedom following a more general definition, as given in the classic textbook "The art of multiprocessor programming" by Herlihy and Shavit. There deadlock-freedom is a liveness property, and the definition doesn't rely on blocking primitives. It’s unclear how the ideas in this paper can be applied for the more general problem. But I agree that this seems to be a totally different problem and may be out of the scope of this paper.

The paper shows the encoding of multi-shot channels using the single-shot ones. Then how are the channel rules in Fig. 3 (for multi-shot channels) related to those one-shot channel rules in Fig. 4? Are those in Fig. 3 derivable from those in Fig. 4?

I don't understand the point of having Sec. 7. How is it related to the program logic in Sec. 3?

About the presentation, I find the explanation of connectivity graph and (strong) channel acyclicity is too terse. To help people to understand the key ideas, it would be nice to give examples showing how bad programs generate cyclic connectivity graphs.

For related work, I'm not sure whether TaDA Live really needs to enforce lock orders. The work does not rely on built-in blocking lock primitives. Also, Liang and Feng [2016] proves deadlock-freedom of concurrent objects as a liveness property, without relying on lock orders.
