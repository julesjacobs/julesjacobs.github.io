We thank the reviewers for their effort and thoughtful feedback. We respond to the high level points raised by more than one reviewer next, and we give detailed in-line responses to each individual reviewer further below.

# Expressiveness and future applicability (reviewers A and C)

Reviewer A points out that the paper is missing an evaluation/discussion to evaluate the expressiveness of the logic. We agree with this and have made a plan for this below.
The reviewers also ask about more examples of invariants (other than session channels) that our approach might apply to in the future.

Connectivity graphs have been used to verify the deadlock freedom for a type system that supports a form of linearly typed locks [Jacobs and Balzer, 2023], and a type system that supports multiparty session types [Jacobs et al. 2022b].
We conjecture that our approach can be adapted to program logic analogues of these type systems.
However, doing so in an _interesting way_ requires new research in orthogonal directions.
For example, how to adapt the Actris dependent protocols to the multiparty setting? -- We conjecture that a multiparty program logic _without_ dependent protocols is in closer reach, but would also be rather weak in terms of expressivity.

**We describe a more general situation for which we conjecture that our approach works in the detailed response to reviewer A below.**

# Liveness versus deadlock freedom (reviewers B and C)

The reviewers point out that LinearActris does not guarantee the absence of infinite (busy) loops, i.e., the adequacy statement does not show liveness.
Indeed, the LinearActris proof rules do not guarantee liveness, or even termination for sequential programs.
We agree with Reviewer B's assessments and find that LinearActris should be viewed as a "message passing logic" where deadlock freedom specifically applies to the primitive blocking operations, and is guaranteed as a safety property.
We justify this as follows:

1. Our deadlock freedom property is the same as the standard deadlock freedom property guaranteed by session types: global progress, i.e., the property that a non-empty configuration can always step.
   This is non-trivial in the presence of primitive blocking operations, and stronger than the usual adequacy result of Iris and Actris and of the soundness result of type systems verified using Iris (e.g., RustBelt).
2. We agree that it _would_ be neat to have a logic that proves liveness for fine-grained concurrency _and_ can encode (a restricted form of) the Actris proof rules for message passing _and_ has (a restricted form of) Iris invariants _and_ is mechanized.
   However, as the state of the art currently stands, this goal is still out of reach.
3. A liveness logic would not be _strictly_ superior, because proving termination of all subroutines can be challenging for the user of the logic.
   The advantage of LinearActris is that its guarantees come more or less for free within its area of applicability, as Actris existing proofs already tend to use channels linearly (which is the reason why we could port examples from the original Actris papers).
4. We do expect it to be **true** that **if** all operations in between two message passing operations terminate, then a LinearActris program (with spinning `recv` operation) is live under fair scheduling.
   However, whether ideas from our adequacy proof can be adapted is unclear.
   Therefore, we consider liveness to be out of scope for this paper.

We will add these points to the new discussion/evaluation section in the revised paper.

# Plan for the revision

We propose to add a new discussion/evaluation (& future work) section with the following points:

1. Describe the Actris examples and new examples we have verified, to better explain what our logic can do.
2. Add negative examples to better explain what our logic cannot do.
3. Discuss in more detail the difference between deadlock freedom and liveness, as adequacy theorems.
4. Explain why naively adding Iris invariants would violate our adequacy theorem.
5. Describe previous connectivity graph based concurrency constructs to which we believe our approach might apply as future work and the orthogonal challenges they involve (e.g., dependencies in the multiparty setting as mentioned above).
   This will give a more general idea about the types of invariants for which we might expect a LinearActris-like methodology to work.

In addition, we will also:

1. Improve the presentation of the invariant in our adequacy proof (§ 5).
   See the response to Reviewer A below.
   We will also add pictures as suggested by Reviewer C.
2. Clarify the significance of semantic typing (§ 7).
   See the response to Reviewer C below.
3. Clarify what sets us apart from prior work on Actris and connectivity graphs (in introduction and/or related work).
   See response to Reviewer C below.

We will also implement other changes discussed in the detailed responses below.

> # POPL 2024 Paper #234 Reviews and Comments
>
> Paper #234 Deadlock-Free Separation Logic: Linearity Yields Progress for
> Dependent Higher-Order Message Passing
>
> # Review #234A
>
> ## Overall merit
>
> A. Strong accept: I will argue for acceptance.
>
> ## Reviewer expertise
>
> X. Expert: I am an expert on the topic of the paper (or at least key
> aspects of it).
>
> ## Summary of the paper
>
> This paper integrates linear session types, which can be used to prove deadlock-freedom of channel-based communicating programs, into the Actris line of work that combines separation logic and session types. The result is a linear separation logic for channel-based programs, LinearActris, that guarantees deadlock-freedom of any program that can be verified. While the paper draws heavily on prior work, it also addresses new challenges that have not appeared in any of the prior work. Most significantly, while Actris was able to use the generic weakest preconditions and adequacy proof of the Iris framework, LinearActris requires a more complicated adequacy proof that maintains a well-formed connectivity graph throughout the execution of the program.
>
> ## Assessment of the paper
>
> This appears to be a problem where a relatively small advance in the state of the art requires a large amount of technical work, on both the theoretical and the practical side. The use of connectivity graphs as an invariant on execution is a neat idea that has been executed carefully and explained well. The material is well-presented and admirably self-contained for work that relies on so many different strands of prior work. The paper suffers a bit from the absence of evaluation and discussion sections, making it hard to get a top-level picture of what has been accomplished and how much of the technical work might be reused in future developments.

We agree that a discussion/evaluation section is a good idea.
Above we list a plan for adding this section.

> ## Detailed comments for authors
>
> ## Major comments:
>
> The only comprehensive evaluation appears to be in the introduction, where it is mentioned in passing that you verified various examples from Actris 2.0. There is also no discussion or conclusion. Maybe the intro and related work say everything you want to say, but it would be nice to see both a recap of what you accomplished, and some hints at where else all this work could be put to use. Two things in particular stand out to me. First, LinearActris clearly can't use general Iris invariants, and I wonder whether you know of channel-communicating programs where such invariants would be useful. Second, the paper ends with a tantalizing comment about applying your approach to general Iris invariants, and I'd love to see either more explanation or other examples of more limited invariants that your approach might apply to.

Indeed, LinearActris cannot use general Iris invariants, as our adequacy theorem would become false if we were to add the rules for Iris invariants to our logic.
They would certainly be useful: with Iris invariants one could share channels with multiple producers/consumers.

It is a good question which other instances of Iris invariants maintain the deadlock freedom guarantee.
We conjecture that our approach works in the following setting:

- We have a type of 'synchronization object' `c` (like a channel or lock) corresponding to a node in the connectivity graph, which stores physical values as well as logical resources.
- We have ownership assertions `c >-> p` where `p` is some kind of protocol, corresponding to a `p`-labeled edge in the graph from the owner of `c >-> p` to `c`.
- Upon doing an operation on `c`, the thread exchanges some values and resources with `c`, and gets a new protocol state `c >-> p'`.
- The `c >-> p` is linear, but upon `fork` we may duplicate precisely 1 such ownership assertion into the forked thread, splitting `p=p1+p2` in some way.
  Other resources must be divided up linearly between the forking and forked thread.
  This maintains acyclicity of the graph.

The system is now deadlock free, provided that each synchronization object is 'locally deadlock free', i.e., the protocols restrict the allowed operations so that at least 1 owner can make progress.
For instance, session protocols guarantee this because if both sides were blocked on the channel then both would be receivers, which is ruled out by the protocols.
In our Coq development, mutable references are also modeled as a (trivial) example of the above, giving us some hope that combinations of multiple types of 'synchronization objects' work too.

We think this direction is exciting, but also speculative.
For instance, our Coq development is not abstracted out like the description above -- we do not know how to do this, so session channels and mutable references are hard coded for now.
A logic with general invariants is (even) more speculative, and designing the right rules for such a logic is a problem that we have not solved, but is the next big challenge.

Circling back from speculative further work to LinearActris, we believe that even though LinearActris only has one specific kind of channel invariant, this particular invariant still has interesting features:

1. They can be nested, i.e., a channel ownership assertion `c >-> p` can be stored inside a channel invariant.
2. Channel ownership is therefore not pinned to a particular thread, but can be sent to other threads dynamically.
3. Deadlock freedom is maintained even though every channel ownership assertion that we own automatically gives us the right to do a blocking operation with the channel, without any additional (well-founded/partial) orders between channels.

Therefore, we think that LinearActris is interesting not just as a step towards a more general logic, but also as a self-contained logic for deadlock-free message passing.

> There are a few things I'm confused about with regard to the example in section 5.2, page 16, used to demonstrate the problem with leaks. First, this is the only example in the section to be written with multi-shot channels -- is there no one-shot analogue? Second, the undesirable behavior described appears to be ruled out by weak channel acyclicity, since it only arises when $c_1$ and $c_2$ are two endpoints of the same channel owned by a single thread. Finally, I found it harder than in the other examples to see how the rules of LinearActris rule out this behavior; it would help to give a short explanation of why the example program would be impossible to verify.

You are right.
There is a one-shot analogue, namely `send1 c1 c2` where `c1` and `c2` are the two endpoints of the same one-shot channel.
This stores the `c2` endpoint in the channel itself, causing a leak.
We will replace the example with this (simpler) one-shot example.

You are correct about the reason why the logical rules of LinearActris rule out this behavior: the two endpoints can never be owned by the same thread.
Note that the original Actris had a `new_chan` construct, which returns both endpoints to the same thread. This immediately violates acyclicity, and thus deadlock and leaks can occur (e.g., `let (c1,c2) = new_chan() in c1.receive(); c2.send(3)` deadlocks).
Our `fork` rule creates a channel and gives the two ownership assertions to separate threads, thus making this simple deadlock impossible.
It may be less immediately obvious from the rules that this cannot be subsequently circumvented by transmitting channel endpoints over other channels or mutable references, but that is nevertheless true, and guaranteed by the linearity of the separation logic. For instance, attempts to verify programs such as `my_new_chan() := let c2 = fork(λc1, c1.send(c1)) in (c2,c2.receive())` or `my_new_chan() := let r = ref(0) in let c2 = fork(λc1, r <- c1; c1.send(())); c2.receive(); return (c2,!r)` will fail to prove a spec that gives both ownership assertions, even though sending channel ownership of one channel over another channel _can_ be done.

We can generalize the `send1 c1 c2` example slightly to `send c1 d2 || send c2 d1`, with two channels and two threads, so that **weak** channel acyclicity is not violated.
However, the other reason that _(weak) channel acyclicity_ is not good enough, is that it is not maintained by steps of the operational semantics.
If the channels in the heap already refer to each other cyclically, then threads can often receive messages from such channels and subsequently violate weak channel acyclicity.
For example, if a (multi-shot) channel endpoint `c1` is stored in the channel's own buffer, then receiving that message via the other endpoint `c2`, obtains both `c1` and `c2` in the same thread (thus violating weak channel acyclicity, even though it was not violated a moment ago).

The key is that _strong channel acyclicity_ (when combined with `WP`s for all threads and channel invariants for all channels), _is_ maintained under steps of the operational semantics.
Therefore, the strengthening of weak channel acyclicity → channel acyclicity → strong channel acyclicity, is not just to rule out more and more counterexamples, but primarily to obtain a property that is maintained by the step relation of the operational semantics.
This is akin to strengthening an induction hypothesis, to make the induction go through.
This was not made clear in the text, as the text made it seem that the point of the strengthening was to exclude more and more examples.

In the revision, we will make the following changes to § 5:

1. We will change the example use the one-shot channels.
2. We will explain why the rules of LinearActris rule out this behavior: we will present examples showing various ways in which one might attempt to create a deadlock or leak.
3. As Reviewer C suggests, we will add pictures showing why the examples violate acyclicity.
4. For each example, we will explain why the LinearActris proof rules will rule those out.
5. We will better explain why we need to generalize the acyclicity condition (it is akin to strengthening an induction hypothesis).

> ## Minor comments:
>
> Line 825/826 contains the phrase "ownership of the channel ownership", which is at least confusing and probably an error.
>
> On line 914, $\mathsf{WP}_0$ is used before it is defined. The mutual recursion is addressed later, but it's worth at least giving a brief intuition for it at this point.
>
> ## Line edits:
>
> 8: "program" -> "programs"
>
> 146: "used in to" -> "used to"
>
> 467/468, etc.: "used verify" -> "used to verify"
>
> 847: "strongly acyclic" -> "strong acyclicity"
>
> 976-977: "weakest preconditions rules" -> "weakest precondition rules"
>
> 1033: "$!A.\ S$ and $!A.\ S$" -> "$!A.\ S$ and $?A.\ S$"
>
> 1153/1154: "constructs" -> "construct"
>
> 1195-1196: "invariants mechanisms" -> "invariant mechanisms"

Thanks for these corrections. We will address these in the revision.

> ## Questions to be addressed by author response
>
> Do you expect that the restrictions on invariants required by the linear logic will prevent you from verifying any real programs of interest? Do you know of any examples where they're needed?
> Does the leak example actually illustrate the need for strong acyclicity? Is there anything special about the rules of LinearActris that take strong acyclicity into account, or does it just fall out from the linear handling of channels and separation logic?

These questions have been discussed above.
For the last question, see the discussion of `new_chan` in the response to Reviewer A.

> # Review #234B
>
> ## Overall merit
>
> B. Weak accept: I lean towards acceptance.
>
> ## Reviewer expertise
>
> Y. Knowledgeable: I am knowledgeable about the topic of the paper (or at
> least key aspects of it).
>
> ## Summary of the paper
>
> This paper presents a linear concurrent separation logic, LinearActris. It shows that LinearActris guarantees deadlock- and leak-freedom. Moreover, it shows how LinearActris can be used to provide a logical-relations model for a higher-order GV-like calculus. All of the results are proven in Coq.
>
> ## Assessment of the paper
>
> The goal of deadlock-free concurrent programming is an important one, and a separation-logic approach seems natural, especially when dealing with programs that mix message-passing and shared-memory concurrency. While I'm not an expert in separation logic, this paper did a very good job of explaining where prior work failed to achieve deadlock freedom, and why their solution works better. There are several parts in the paper where I felt like things were a bit vague---the definition of the connectivity graph, for instance---but I appreciate that this was prior work, and space is limited. Even there, the intuitive explanation was enough for me to believe that the result works as intended, and that a precise definition of the terms involved was not difficult.
>
> However, I had one major concern: how does LinearActris reason about shared-memory concurrency? It certainly has it; see the example on lines 283-284. However, it seems like any locks would have to be encoded via busy waiting, which keeps your definition of deadlock-freedom from recognizing deadlock. This is exactly the complaint you made about Idris! It seems to me that this seriously weakens the story, since you only get deadlock freedom for the message-passing component of your program.

Note that the example on lines 283-284 works because the ownership assertion for the mutable reference is transmitted via the `close`/`wait` pair of message passing operations. In LinearActris, two threads cannot race on one memory location, as heap ownership is unique (albeit transmittable via message passing). However, LinearActris does not require proving termination of sequential loops, and as such does not rule out livelocks.
We distinguish deadlock freedom as a safety property ("global progress", i.e., the configuration can always step / the program isn't stuck on blocking operations) from liveness/termination properties (eventual completion of some goal is assured, often by going down a well-founded order, or using a decreasing ordinal). LinearActris is in the former category.

Proving deadlock freedom of busy-waiting programs (such as the mentioned locks) pertains to liveness properties,
which is a very different problem than the global progress we prove.
However, obtaining global progress for such locks may be possible if they are treated as primitively blocking.
This would be an interesting potential for future work, although we find it is beyond the scope of the paper.
See the main concerns above for more details regarding deadlock freedom versus liveness.

> Even with this major issue, I think that the insights in this paper are enough to warrant a publication. However, it keeps me from enthusiastically supporting it, leading to my rating.
>
> ## Detailed comments for authors
>
> There were very few typos or grammatical errors in the paper. Well done!
>
> L 146: Extra "in"
>
> L 862: In what sense is "$\ell \mapsto v \in \text{Prot}$"? $\ell \mapsto v$ is a proposition, $v$ is a value, and $\ell$ is a location---none of these are protocols!
>
> L 951: Where does $\Phi$ come from?
>
> L 1013: "different" should be "difference"
>
> Figure 7: Shouldn't one of the $S$s in the fork rule be dualized?
>
> L1154: "constructs" should be "construct"

Thank you for these corrections. We will address these in the revision.

> # Review #234C
>
> ## Overall merit
>
> B. Weak accept: I lean towards acceptance.
>
> ## Reviewer expertise
>
> Y. Knowledgeable: I am knowledgeable about the topic of the paper (or at
> least key aspects of it).
>
> ## Summary of the paper
>
> This paper proposes a linear concurrent separation logic for channel-based message-passing concurrency. The logic follows the idea of session types and uses dependent separation protocols to reason about channels. It supports higher-order functions, mutable states, and channels as first-class citizen. Soundness of the logic is proved using the step-indexed model. The soundness ensures not only safety, but also deadlock-freedom and leak-freedom. In particular, the deadlock-freedom is guaranteed by the linear channel assertions of the program logic, so that there's no need of explicit ordering of blocking channel operations.
>
> ## Assessment of the paper
>
> **Strength:**
>
> - The use of linear separation logic to ensure deadlock-freedom is elegant.
> - The paper is well written and easy to follow.
>
> **Weakness:**
>
> - Key ideas of this work are not totally new. This logic is an extension of Actris. The use of connectivity graph to prove deadlock-freedom follows Jacobs et al. [2022a]. The key idea of using linear separation logic assertions to ensure deadlock-freedom seems to be a natural extension.

We do indeed heavily rely on this prior work, and agree that the research question underlying our work is a natural extension: can we develop a deadlock free version of Actris.
The key difference is that Jacobs et al. [2022a] only applies to progress/preservation style proofs for syntactic type systems, and in contrast to our work, has no notion of weakest precondition or Hoare triple.

Our key technical contribution is the adequacy proof and step-indexed semantic model of our weakest precondition logic (§ 6).
The result is the first session protocol based program logic with a semantic model for deadlock freedom, and is in a different category than prior work on type systems.
Our deadlock freedom result indeed relies on linearity of the separation logic, just like deadlock freedom of session types relies on the linearity of the type system.
We argue that it is non-obvious that deadlock freedom via linearity transfers from type systems to program logics: when we started our work, it was unclear to us whether this was even possible.
The key mutually recursive construction of the WP and the graph invariant (§ 6) is quite different than how Iris's WP and `state_interp` work.

To draw an analogy, the jump from _deadlock & leak freedom for syntactic session types_ to _LinearActris_, is analogous to the jump from _progress and preservation for STLC+references_ to _semantic models of step-indexed separation logic_.
Type safety using progress and preservation for STLC+references (as in the text books by Pierce and Harper) are often taught in an undergraduate course, whereas semantic models for step-indexed separation logic are considerably more difficult.
Our work is in the latter category, and the technical results are not a matter of taking prior work and putting 1+1 together.

In quantitative terms, our Coq mechanization consists of approximately 12.000 lines, of which only 10% are acyclic graph helper lemmas re-used from Jacobs et al. (such as "if you delete an edge from an acyclic graph, then the resulting graph is also acyclic"), modified to work in the step-indexed setting.
In particular, the key parts of our mechanization are new.

Therefore, we believe that both the high-level contribution (the deadlock free program logic) and the technical contribution (the Coq mechanized adequacy proof) set us apart from prior work.
We will explain this more clearly in the revision, and we can also add information about our Coq mechanization.

> ## Detailed comments for authors
>
> In general I like the paper, which is well written. The idea to ensure deadlock-freedom is elegant.
>
> The paper takes the narrower sense of deadlock-freedom, which is still a safety property and ensures there's no circular waiting of threads. This relies on having blocking primitives in the language. Correspondingly, the key ideas are developed around logic rules for the blocking primitives. This makes the approach a bit ad-hoc. For instance, it's unclear how it scales to languages with multiple sets of blocking primitives (e.g., having both channels and locks). Also, does it work for channels that allow for multiple senders and receivers?

See the main concerns above.

> A more challenging problem is to verify the deadlock-freedom following a more general definition, as given in the classic textbook "The art of multiprocessor programming" by Herlihy and Shavit. There deadlock-freedom is a liveness property, and the definition doesn't rely on blocking primitives. It’s unclear how the ideas in this paper can be applied for the more general problem. But I agree that this seems to be a totally different problem and may be out of the scope of this paper.

See the main concerns above.

> The paper shows the encoding of multi-shot channels using the single-shot ones. Then how are the channel rules in Fig. 3 (for multi-shot channels) related to those one-shot channel rules in Fig. 4? Are those in Fig. 3 derivable from those in Fig. 4?

That is correct, the rules in Fig 3 are derivable from those in Fig 4. We will clarify this in the revision.

> I don't understand the point of having Sec. 7. How is it related to the program logic in Sec. 3?

The significance of this result is that it shows the strength of the logic, i.e., it verifies an infinite class of programs.
It shows every program that can be shown to be deadlock free using the session type system, can also be shown to be deadlock free using our logic.

In short, the semantic type system translates a typing derivation of `e : T` from a syntactic session type system into a proof of `WP e {v. [T] v}` in the logic, where `[T]` is the semantic interpretation of the syntactic type `[T]`.
Due to our adequacy theorem for `WP`, we obtain the corollary that all well-typed programs `e : T` in the syntactic session type system are deadlock and leak free when executed.
This theorem is quite easy to prove, as our program logic does all the heavy lifting.

We will clarify this in the revision.

> About the presentation, I find the explanation of connectivity graph and (strong) channel acyclicity is too terse. To help people to understand the key ideas, it would be nice to give examples showing how bad programs generate cyclic connectivity graphs.

This is a good idea.
We will add such pictures to show how the negative examples result in cyclic connectivity graphs.

> For related work, I'm not sure whether TaDA Live really needs to enforce lock orders. The work does not rely on built-in blocking lock
> primitives. Also, Liang and Feng [2016] proves deadlock-freedom of concurrent objects as a liveness property, without relying on lock orders.

You are right, the terminology was incorrect.
TaDa Live does not rely on built-in blocking primitives, and it does not use lock orders.
Instead, it relies on a well-founded partial order, elements of which TaDa Live calls _layers_ (see https://arxiv.org/pdf/1901.05750.pdf, page 7, second to last paragraph).
These layers form conditions on the order of use of multiple (encoded) blocking operations, similar to lock orders, but not the same.

Thanks for pointing out Liang and Feng [2016].
This was an oversight; we will add and discuss this in the related work.
LiLi indeed does not use orders, and instead specifies _definite actions_, which also control the order in which operations can depend on each other.

In LinearActris, the deadlock-freedom is guaranteed by the linear channel assertions of the program logic, so that there is no need of explicit ordering of blocking channel operations.

That is, if one has a `c >-> p` channel ownership assertion where `p` is a receive protocol, then one automatically has the right to do the blocking receive on `c`, regardless of which other channels you or others may own.
This is what makes it possible easily use dynamically created channels, and easily use channels received from other threads, and it is also precisely what makes it possible for us to carry out the semantic typing proof for session types, as session types have the same feature.

It is important to note that it is _not_ the case that any two channels in a LinearActris run-time configuration could be used in any order.
If a thread in the program does an operation such as `c1.send (c2.recv ())` then there _is_ a dependency: the person responsible for sending us the message on `c2` must not be waiting for us to send that message on `c1`, or else that would deadlock.
It is not the case that any two channels can be used in either order; that is _only_ the case for the thread that _simultaneously_ holds both their channel ownership assertions.
If a thread owns multiple channels, then it is indeed free to use them in any order it wishes, because due to acyclicity, the other ends of those channels will not be waiting for each other.
