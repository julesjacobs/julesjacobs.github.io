This is an archived artifact for the paper [Deadlock-Free Separation Logic: Linearity Yields Progress for Dependent Higher-Order Message Passing](https://apndx.org/pub/icnp/miniactris.pdf)
by Jules Jacobs, Jonas Kastberg Hinrichsen, and Robbert Krebbers.
The most recent version of the Coq code is available at [https://github.com/julesjacobs/dlf-actris](https://github.com/julesjacobs/dlf-actris).


This artifact website is bidirectionally hyperlinked with the [PDF of the paper](https://apndx.org/pub/icnp/dlfactris.pdf):

* Definitions, theorems, and examples in the Coq code are hyperlinked to the corresponding location in the paper.
* Definitions, theorems, and examples in the paper are hyperlinked to the corresponding location in the Coq code.
