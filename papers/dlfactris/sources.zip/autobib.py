# AutoBib
# -------
# This script searches your .tex files for \cite{foo_bar_baz} commands.
# It then searches DBLP for query "foo bar baz", and adds the resulting paper to your .bib file.
# If no results or multiple results are returned by DBLP, it gives an error.
# The script only looks at DBLP if the citekey foo_bar_baz is not already present in the .bib file.
#
# bug reports: mail@julesjacobs.com

# TeX files to search for cite keys
texfiles = "**/*.tex"

# Bib file to store the bibtex into
bibfile = "refs.bib"

# Regex to find \cite{...} commands
cite_regex = r"\\cite(?:p|t|){([A-Za-z0-9_, ]*)}"

# Regex to find the key of a bibtex entry
bib_regex = r"@[A-Za-z]*{([A-Za-z0-9_]*),"


import pathlib
import re
import urllib.request
import json

def get_tex_citekeys(texfiles):
  """Find all citekeys in \cite{citekeys} in the texfiles."""
  files = pathlib.Path('.').glob(texfiles)
  return [cite for file in files
               for line in open(file)
               for citelist in re.findall(cite_regex,line)
               for cite in citelist.split(',')]

def get_bib_citekeys(bibfile):
  """Find all citekeys in bibtex file"""
  return [cite for line in open(bibfile)
               for cite in re.findall(bib_regex, line)]

def search_dblp(query):
  """Search DBLP for the cite key, replacing _ with space."""
  query = query.replace("_","%20").replace(" ","%20")
  url = f"https://dblp.org/search/publ/api?q={query}&h=10&format=json"
  result = urllib.request.urlopen(url)
  js = json.loads(result.read().decode('utf-8'))
  try:
    return js['result']['hits']['hit']
  except KeyError:
    return []

def get_bibtex(dblpkey,replacementkey=None):
  """Given a DBLP key, find the bibtex record.
     Optionally, replace the cite key with replacementkey."""
  url = f"https://dblp.org/rec/{dblpkey}.bib"
  result = urllib.request.urlopen(url)
  bib = result.read().decode('utf-8')
  if replacementkey:
    bib = bib.replace(f"DBLP:{dblpkey}", replacementkey)
  return bib

def search_bib(query):
  """Find the bibtex record for a search query string.
     Gives an error if none or multiple results exist."""
  papers = search_dblp(query)
  if len(papers) == 0:
    print(f"No DBLP results for query: {query}")
    exit()
  if len(papers) > 1:
    print(f"Ambiguous DBLP results for query: {query}")
    print("---------------------------------")
    bibs = [get_bibtex(paper['info']['key'], replacementkey=None) for paper in papers]
    for bib in bibs:
      print(bib)
    exit()
  return get_bibtex(papers[0]['info']['key'], replacementkey=query)


tex_cites = get_tex_citekeys(texfiles)
bib_cites = get_bib_citekeys(bibfile)
new_cites = set(tex_cites) - set(bib_cites)

if not new_cites:
  print(f"No new citekeys found.\nAll citekeys in your {texfiles} files are already in {bibfile}:")
  for cite in tex_cites: print(f"- {cite}")

unused_cites = set(bib_cites) - set(tex_cites)
if unused_cites:
  print(f"\nUnused citekeys (found in {bibfile} but not in {texfiles} files):")
  for cite in unused_cites: print(f"  {cite}")

f = open(bibfile,"a")
for cite in new_cites:
  print(f"Adding entry {cite} to {bibfile}.\n")
  bib = search_bib(cite)
  print(bib)
  f.write(bib)
