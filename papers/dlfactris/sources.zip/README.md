# Linear Actris

A version of Actris where Hoare triples prove deadlock and leak freedom.

Version of Iris to use: https://gitlab.mpi-sws.org/iris/iris/-/commits/robbert/sbi

## Compilation

The project maintains compatibility with Coq 8.17 and relies on `coqc` being
available in your shell. 

Run `make -jN` to run the makefiles, where `N` is the number of your CPU cores.

## File structure

- [`prelude/`](theories/prelude): Miscellaneous lemmas and definitions that could be upstreamed to std++ and Iris.

- [`algebra/`](theories/algebra): Algebraic structures, including step-indexed multisets for modeling the incoming edges of the connectivity graph.

- [`lang/`](theories/lang): The syntax and operational semantics of our language ChanLang, including some meta theory and notations.

- [`base_logic/`](theories/base_logic): The model, WP rules, and adequacy one-shot LinearActris logic.

- [`session_logic/`](theories/session_logic): The multi-shot LinearActris logic, derived in multiple layers from the one-shot LinearActris logic.

- [`examples/`](theories/examples): Examples
  * [`tour.v`](theories/examples/tour.v): Examples from this paper, Section 2
  * [`basics.v`](theories/examples/basics.v): Examples from the Actris 2.0 paper, Section 1 and 10
  * [`sort.v`](theories/examples/sort.v): Example from Actris 2.0 paper, Section 5
  * [`sort_br_del.v`](theories/examples/sort_br_del.v): Example from Actris 2.0 paper, Section 5
  * [`sort_fg.v`](theories/examples/sort_fg.v): Example from Actris 2.0 paper, Section 5
  * [`list_rev.v`](theories/examples/list_rev.v): Example from Actris 2.0 paper, Section 6.3

- [`logrel/`](theories/logrel): The semantic session type system
  * [`theories/logrel/examples`](theories/logrel/examples): Examples of using the semantic type system to type check sample programs.

