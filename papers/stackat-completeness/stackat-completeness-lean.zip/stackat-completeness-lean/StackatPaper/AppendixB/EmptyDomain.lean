import StackatPaper.Section5.Spec

/-!
# Appendix B: an empty field domain

If some field domain `V_i` is empty, the partition law of field `i` is `0 = 1`, so every pair of
expressions is derivably equal (`empty_domain_derives`); there are no configurations, so every
pair is also semantically equal (`empty_domain_denote`).
-/

namespace Stackat.Fields

/-! ## Appendix B: an empty field domain -/

section EmptyDomain

variable {A : Type} {n : Nat} {V : Fin n → Type} [∀ i, Fintype (V i)]

/-- If some field domain is empty, the partition law is `0 = 1` and every pair of expressions is
derivably equal. -/
theorem empty_domain_derives (i : Fin n) [IsEmpty (V i)] (e f : Expr A V) :
    Derives e f := by
  have h01 : Derives (0 : Expr A V) 1 := by
    have h := Derives.test_complete (A := A) (V := V) i
    have hl : (Finset.univ : Finset (V i)).toList = [] := by simp
    rwa [hl] at h
  have hz : ∀ x : Expr A V, Derives x 0 := fun x =>
    (Derives.mul_one x).symm.trans
      ((Derives.mul_congr (.refl x) h01.symm).trans (Derives.mul_zero x))
  exact (hz e).trans (hz f).symm

omit [∀ i, Fintype (V i)] in
/-- … and semantically equal: there are no configurations. -/
theorem empty_domain_denote (i : Fin n) [IsEmpty (V i)] (e f : Expr A V) :
    ∀ s t, e.denote s t ↔ f.denote s t :=
  fun s _ => (IsEmpty.false (s.1 i)).elim

/-- **Appendix B.** With an empty field domain, all expressions are derivably and semantically
equal. -/
theorem empty_domain (i : Fin n) [IsEmpty (V i)] (e f : Expr A V) :
    (⊢ e ≈ f) ∧ R e = R f :=
  ⟨empty_domain_derives i e f,
    funext fun s => funext fun t => propext (empty_domain_denote i e f s t)⟩

end EmptyDomain

end Stackat.Fields
