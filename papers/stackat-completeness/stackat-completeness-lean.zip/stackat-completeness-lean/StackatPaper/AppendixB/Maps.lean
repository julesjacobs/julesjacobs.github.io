import StackatPaper.AppendixB.Translation

/-!
Appendix B: the maps from pure-stack expressions into the algebra with fields and into relations
preserve the Kleene algebra operations, including matrix star (`Fields.Headers.stackHom`,
`Fields.Headers.stackHom_star`, `Fields.Headers.map_matrix_star`).
-/

namespace Stackat.Fields.Headers

open scoped Computability

variable {A H K L : Type} [Fintype H] [DecidableEq H]
  [KleeneAlgebra K] [KleeneAlgebra L]

omit [Fintype H] [DecidableEq H] in
private theorem map_close (f : K →+* L) (hs : ∀ x, f x∗ = (f x)∗)
    (ks : List H) (M : Matrix H H K) :
    MatrixStar.close ks (fun i j => f (M i j)) =
      fun i j => f (MatrixStar.close ks M i j) := by
  induction ks with
  | nil => rfl
  | cons k ks ih =>
    simp only [MatrixStar.close, ih, MatrixStar.eliminate]
    ext i j
    simp only [MatrixStar.eliminate, map_add, map_mul, hs]

theorem map_matrix_star (f : K →+* L) (hs : ∀ x, f x∗ = (f x)∗)
    (M : Matrix H H K) :
    (M.map f)∗ = fun i j => f (M∗ i j) := by
  change 1 + MatrixStar.close Finset.univ.toList (fun i j => f (M i j)) = _
  rw [map_close f hs]
  ext i j
  change (1 : Matrix H H L) i j + f _ = f ((1 : Matrix H H K) i j + _)
  simp only [map_add, Matrix.one_apply, apply_ite f, map_one, map_zero]

theorem matrices_map (f : K →+* L) (hs : ∀ x, f x∗ = (f x)∗)
    (p q : A → K) (e : Expr A H) :
    matrices (fun a => f (p a)) (fun a => f (q a)) e =
      fun i j => f (matrices p q e i j) := by
  induction e with
  | zero => ext i j; simp [matrices, eval]
  | one => ext i j; simp [matrices, eval, Matrix.one_apply, apply_ite f]
  | push a => ext i j; simp [matrices, eval, Matrix.diagonal_apply, apply_ite f]
  | pop a => ext i j; simp [matrices, eval, Matrix.diagonal_apply, apply_ite f]
  | test h => ext i j; simp [matrices, eval, apply_ite f]
  | assign h => ext i j; simp [matrices, eval, apply_ite f]
  | add e g he hg =>
    change matrices _ _ e + matrices _ _ g = _
    rw [he, hg]
    ext i j
    exact (map_add f _ _).symm
  | mul e g he hg =>
    change matrices _ _ e * matrices _ _ g = _
    rw [he, hg]
    ext i j
    simp [matrices, eval, Matrix.mul_apply, map_sum]
  | star e he =>
    change (matrices _ _ e)∗ = _
    rw [he]
    exact map_matrix_star f hs (matrices p q e)

def embedStack : Stackat.Expr A → Expr A H
  | .zero => 0
  | .one => 1
  | .push a => .push a
  | .pop a => .pop a
  | .add e f => embedStack e + embedStack f
  | .mul e f => embedStack e * embedStack f
  | .star e => (embedStack e).star

omit [DecidableEq H] in
theorem embedStack_derives {e f : Stackat.Expr A} (h : Stackat.Derives e f) :
    Derives (embedStack (H := H) e) (embedStack f) := by
  induction h with
  | refl => exact .refl _
  | symm _ ih => exact .symm ih
  | trans _ _ ih ih' => exact .trans ih ih'
  | add_congr _ _ ih ih' => exact .add_congr ih ih'
  | mul_congr _ _ ih ih' => exact .mul_congr ih ih'
  | star_congr _ ih => exact .star_congr ih
  | add_assoc => exact .add_assoc _ _ _
  | add_comm => exact .add_comm _ _
  | add_zero => exact .add_zero _
  | add_idem => exact .add_idem _
  | mul_assoc => exact .mul_assoc _ _ _
  | one_mul => exact .one_mul _
  | mul_one => exact .mul_one _
  | zero_mul => exact .zero_mul _
  | mul_zero => exact .mul_zero _
  | mul_add => exact .mul_add _ _ _
  | add_mul => exact .add_mul _ _ _
  | star_unfold_left => exact .star_unfold_left _
  | star_unfold_right => exact .star_unfold_right _
  | star_induct_left _ ih => exact .star_induct_left ih
  | star_induct_right _ ih => exact .star_induct_right ih
  | push_pop => exact .push_pop _
  | push_pop_ne h => exact .push_pop_ne _ _ h
  | pop_push => exact .pop_push _

noncomputable def stackHom : Stackat.FreeAlgebra A →+* FreeAlgebra A H where
  toFun := Quotient.lift (fun e => FreeAlgebra.of (embedStack e))
    (fun _ _ h => Quotient.sound (embedStack_derives (Stackat.derives_iff.mpr h)))
  map_zero' := rfl
  map_one' := rfl
  map_add' x y := Quotient.inductionOn₂ x y (fun _ _ => rfl)
  map_mul' x y := Quotient.inductionOn₂ x y (fun _ _ => rfl)

omit [DecidableEq H] in
theorem stackHom_star (x : Stackat.FreeAlgebra A) :
    stackHom (H := H) x∗ = (stackHom x)∗ :=
  Quotient.inductionOn x (fun _ => rfl)

/-- **Appendix B.** The map into the algebra with fields preserves addition, multiplication and
star, and finite matrix star. -/
theorem stackHom_preserves :
    (∀ x y : Stackat.FreeAlgebra A,
        stackHom (H := H) (x + y) = stackHom x + stackHom y) ∧
      (∀ x y : Stackat.FreeAlgebra A,
        stackHom (H := H) (x * y) = stackHom x * stackHom y) ∧
      (∀ x : Stackat.FreeAlgebra A, stackHom (H := H) x∗ = (stackHom x)∗) ∧
      ∀ M : Matrix H H (Stackat.FreeAlgebra A),
        (M.map (stackHom (H := H)))∗ = fun i j => stackHom (M∗ i j) :=
  ⟨map_add stackHom, map_mul stackHom, stackHom_star, map_matrix_star stackHom stackHom_star⟩

noncomputable def stackRelHom : Stackat.FreeAlgebra A →+* Rel (List A) where
  toFun := Quotient.lift (fun e => (Stackat.R e : Rel (List A)))
    (fun _ _ h => Stackat.soundness (Stackat.derives_iff.mpr h))
  map_zero' := rfl
  map_one' := rfl
  map_add' x y := Quotient.inductionOn₂ x y (fun _ _ => rfl)
  map_mul' x y := Quotient.inductionOn₂ x y (fun _ _ => rfl)

theorem stackRelHom_star (x : Stackat.FreeAlgebra A) :
    stackRelHom x∗ = (stackRelHom x)∗ :=
  Quotient.inductionOn x (fun e => Stackat.R_star e)

theorem stackRelHom_injective [Finite A] : Function.Injective (stackRelHom (A := A)) := by
  intro x y
  induction x, y using Quotient.inductionOn₂ with
  | _ e f =>
    intro h
    apply Quotient.sound
    apply Stackat.derives_iff.mp
    exact Stackat.completeness A e f h

end Stackat.Fields.Headers
