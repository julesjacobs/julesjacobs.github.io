import StackatPaper.AppendixB.FieldAlgebra
import StackatPaper.AppendixB.Translation

/-!
Appendix B: the whole-header laws (15) from the per-field laws (`Fields.whole_model`), the field
expansions (16) (`Fields.expand_test`, `Fields.expand_assign`), and whole-header assignments
followed by field operations.
-/

namespace Stackat.Fields

attribute [local instance] Classical.propDecidable

variable {n : Nat} {V : Fin n → Type} [∀ i, Fintype (V i)]
  {K : Type} [KleeneAlgebra K]

structure FieldModel (t u : ∀ i, V i → K) : Prop where
  complete : ∀ i, ∑ v, t i v = 1
  test_assign : ∀ i v, t i v * u i v = t i v
  assign_test : ∀ i v, u i v * t i v = u i v
  assign_test_ne : ∀ i v w, v ≠ w → u i v * t i w = 0
  assign_assign : ∀ i v w, u i v * u i w = u i w
  assign_comm : ∀ i j v w, i ≠ j → Commute (u i v) (u j w)
  assign_test_comm : ∀ i j v w, i ≠ j → Commute (u i v) (t j w)

variable (t u : ∀ i, V i → K) (hm : FieldModel t u)

def wholeTest (h : Header V) : K := prod (fun i => t i (h i))
def wholeAssign (h : Header V) : K := prod (fun i => u i (h i))

include hm

theorem whole_test_assign (h : Header V) : wholeTest t h * wholeAssign u h = wholeTest t h := by
  rw [wholeTest, wholeAssign, prod_mul _ _
    (fun i j hij => (hm.assign_test_comm j i _ _ hij.symm).symm)]
  exact prod_congr (fun i => hm.test_assign i (h i))

theorem whole_assign_assign (h k : Header V) :
    wholeAssign u h * wholeAssign u k = wholeAssign u k := by
  rw [wholeAssign, wholeAssign, prod_mul _ _ (fun i j hij => hm.assign_comm i j _ _ hij)]
  exact prod_congr (fun i => hm.assign_assign i (h i) (k i))

theorem whole_assign_test (h k : Header V) :
    wholeAssign u h * wholeTest t k = if h = k then wholeAssign u h else 0 := by
  classical
  rw [wholeAssign, wholeTest, prod_mul _ _ (fun i j hij => hm.assign_test_comm i j _ _ hij)]
  split
  · subst k
    exact prod_congr (fun i => hm.assign_test i (h i))
  · rename_i hne
    obtain ⟨i,hi⟩ : ∃ i, h i ≠ k i := by
      by_contra hh
      apply hne
      funext i
      exact Classical.byContradiction (fun hn => hh ⟨i,hn⟩)
    exact prod_eq_zero _ i (hm.assign_test_ne i _ _ hi)

/-- **The whole-header laws** (15): in a Kleene algebra satisfying the per-field laws, the
whole-header tests `t_h` and assignments `u_h` satisfy the whole-header laws. -/
theorem whole_model : Headers.HeaderModel (wholeTest t) (wholeAssign u) := by
  classical
  exact ⟨sum_prod V t hm.complete, whole_test_assign t u hm,
    whole_assign_test t u hm, whole_assign_assign t u hm⟩

theorem whole_assign_field (h : Header V) (i : Fin n) (v : V i) :
    wholeAssign u h * u i v = wholeAssign u (Function.update h i v) := by
  classical
  rw [wholeAssign, ← prod_single i (u i v)]
  rw [prod_mul _ _ (by
    intro j k hjk
    split
    · subst k
      exact hm.assign_comm j i _ _ hjk
    · exact Commute.one_right _)]
  apply prod_congr
  intro j
  by_cases hj : j = i
  · subst j
    simp only [ite_true, Function.update_self]
    exact hm.assign_assign i _ _
  · simp [hj]

theorem whole_assign_fieldTest (h : Header V) (i : Fin n) (v : V i) :
    wholeAssign u h * t i v = if h i = v then wholeAssign u h else 0 := by
  classical
  rw [wholeAssign, ← prod_single i (t i v)]
  rw [prod_mul _ _ (by
    intro j k hjk
    split
    · subst k
      exact hm.assign_test_comm j i _ _ hjk
    · exact Commute.one_right _)]
  split
  · rename_i hv
    apply prod_congr
    intro j
    by_cases hj : j = i
    · subst j
      simpa only [ite_true, ← hv] using hm.assign_test i (h i)
    · simp [hj]
  · rename_i hv
    apply prod_eq_zero _ i
    simpa only [ite_true] using hm.assign_test_ne i (h i) v hv

theorem expand_test (i : Fin n) (v : V i) :
    t i v = ∑ h : Header V, if h i = v then wholeTest t h else 0 := by
  classical
  calc
    t i v = (∑ h : Header V, wholeTest t h) * t i v := by rw [(whole_model t u hm).complete, one_mul]
    _ = ∑ h : Header V, wholeTest t h * (wholeAssign u h * t i v) := by
      simp_rw [← mul_assoc, whole_test_assign t u hm]
      rw [Finset.sum_mul]
    _ = _ := by
      apply Finset.sum_congr rfl
      intro h _
      rw [whole_assign_fieldTest t u hm]
      split <;> simp_all [whole_test_assign t u hm]

theorem expand_assign (i : Fin n) (v : V i) :
    u i v = ∑ h : Header V, wholeTest t h * wholeAssign u (Function.update h i v) := by
  calc
    u i v = (∑ h : Header V, wholeTest t h) * u i v := by rw [(whole_model t u hm).complete, one_mul]
    _ = ∑ h : Header V, wholeTest t h * (wholeAssign u h * u i v) := by
      simp_rw [← mul_assoc, whole_test_assign t u hm]
      rw [Finset.sum_mul]
    _ = _ := by simp_rw [whole_assign_field t u hm]

/-- **The field expansions** (16): `t_{i,v} = ∑_{h : h_i = v} t_h` and
`u_{i,v} = ∑_h t_h u_{h[i:=v]}`. -/
theorem field_expansions (i : Fin n) (v : V i) :
    t i v = (∑ h : Header V, if h i = v then wholeTest t h else 0) ∧
      u i v =
        ∑ h : Header V, wholeTest t h * wholeAssign u (Function.update h i v) :=
  ⟨expand_test t u hm i v, expand_assign t u hm i v⟩

/-- **Appendix B.** A whole-header assignment followed by a primitive field operation:
`u_h t_{i,v} = u_h` when `h_i = v` and `0` otherwise, and `u_h u_{i,v} = u_{h[i:=v]}`. -/
theorem whole_assign_field_operations (h : Header V) (i : Fin n) (v : V i) :
    wholeAssign u h * t i v = (if h i = v then wholeAssign u h else 0) ∧
      wholeAssign u h * u i v = wholeAssign u (Function.update h i v) :=
  ⟨whole_assign_fieldTest t u hm h i v, whole_assign_field t u hm h i v⟩

end Stackat.Fields
