import StackatPaper.AppendixB.Semantics

/-!
Appendix B: completeness for whole-header expressions
(`Fields.Headers.whole_header_completeness`): pure-stack completeness entrywise, then
reconstruction.
-/

namespace Stackat.Fields.Headers

open scoped Computability

variable {A H : Type} [Fintype H] [DecidableEq H]

private abbrev p (a : A) : FreeAlgebra A H := FreeAlgebra.of (.push a)
private abbrev q (a : A) : FreeAlgebra A H := FreeAlgebra.of (.pop a)
private abbrev t (h : H) : FreeAlgebra A H := FreeAlgebra.of (.test h)
private abbrev u (h : H) : FreeAlgebra A H := FreeAlgebra.of (.assign h)

omit [DecidableEq H] in
private theorem of_sum (xs : List H) (f : H → Expr A H) :
    FreeAlgebra.of (Expr.sum xs f) = (xs.map (fun h => FreeAlgebra.of (f h))).sum := by
  induction xs with
  | nil => rfl
  | cons h xs ih =>
    simp only [Expr.sum, List.foldr_cons, FreeAlgebra.of_add, List.map_cons, List.sum_cons] at *
    rw [ih]

private theorem free_headerModel : HeaderModel (t (A := A) (H := H)) u where
  complete := by
    have h : FreeAlgebra.of (A := A) (H := H) (Expr.sum Finset.univ.toList Expr.test) = 1 :=
      Quotient.sound Derives.test_complete
    rwa [of_sum, Finset.sum_map_toList] at h
  test_assign h := Quotient.sound (.test_assign h)
  assign_test h k := by
    by_cases hh : h = k
    · subst k
      simpa only [ite_true] using (Quotient.sound (Derives.assign_test (A := A) h) :
        u h * t h = (u h : FreeAlgebra A H))
    · simpa [hh] using (Quotient.sound (.assign_test_ne (A := A) h k hh) :
        u h * t k = (0 : FreeAlgebra A H))
  assign_assign h k := Quotient.sound (.assign_assign h k)

omit [DecidableEq H] in
private theorem eval_free (e : Expr A H) : eval p q t u e = FreeAlgebra.of e := by
  induction e with
  | zero => exact FreeAlgebra.of_zero.symm
  | one => exact FreeAlgebra.of_one.symm
  | push a => rfl
  | pop a => rfl
  | test h => rfl
  | assign h => rfl
  | add e f he hf => exact (congrArg₂ (· + ·) he hf).trans (FreeAlgebra.of_add e f).symm
  | mul e f he hf => exact (congrArg₂ (· * ·) he hf).trans (FreeAlgebra.of_mul e f).symm
  | star e he => exact (congrArg KStar.kstar he).trans (FreeAlgebra.of_star e).symm

private theorem free_reconstruction (e : Expr A H) :
    FreeAlgebra.of e = ∑ i, t i * (∑ j, matrices p q e i j * u j) := by
  rw [← eval_free]
  exact reconstruction p q t u free_headerModel
    (fun h a => Quotient.sound (.assign_push h a))
    (fun h a => Quotient.sound (.assign_pop h a)) e

omit [DecidableEq H] in
/-- **Completeness for whole-header expressions.** Every equation valid on headers and stacks
has a finite derivation in the whole-header system. -/
theorem whole_header_completeness [Finite A] (e f : Expr A H) :
    R e = R f → ⊢ e ≈ f := by
  intro hef'
  have hef : ∀ s t, e.denote s t ↔ f.denote s t := fun s t => by
    change R e s t ↔ R f s t; rw [hef']
  classical
  let sp : A → Stackat.FreeAlgebra A := fun a => Stackat.FreeAlgebra.of (.push a)
  let sq : A → Stackat.FreeAlgebra A := fun a => Stackat.FreeAlgebra.of (.pop a)
  have hm : matrices sp sq e = matrices sp sq f := by
    ext i j
    apply stackRelHom_injective
    have he := congrArg (fun m : Matrix H H (Rel (List A)) => m i j)
      (matrices_map stackRelHom stackRelHom_star sp sq e)
    have hf := congrArg (fun m : Matrix H H (Rel (List A)) => m i j)
      (matrices_map stackRelHom stackRelHom_star sp sq f)
    dsimp only at he hf
    rw [← he, ← hf]
    apply Rel.ext
    intro s t
    exact (semantic_entries e i j s t).symm.trans ((hef (i,s) (j,t)).trans
      (semantic_entries f i j s t))
  have hm' : matrices (p (H := H)) q e = matrices p q f := by
    have he := matrices_map (stackHom (H := H)) stackHom_star sp sq e
    have hf := matrices_map (stackHom (H := H)) stackHom_star sp sq f
    change matrices p q e = _ at he
    change matrices p q f = _ at hf
    rw [he, hf, hm]
  apply FreeAlgebra.of_eq_iff.mp
  rw [free_reconstruction e, free_reconstruction f, hm']

end Stackat.Fields.Headers
