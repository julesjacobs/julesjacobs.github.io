import StackatPaper.Section5.Spec
import Mathlib.Algebra.Order.Kleene
import Mathlib.Algebra.BigOperators.Group.Finset.Pi
import Mathlib.Data.Fintype.Prod
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.BigOperators.Group.Finset.Basic

/-!
Appendix B: header expressions modulo the field laws form a Kleene algebra; products over the
fields.
-/

namespace Stackat.Fields

instance derivesSetoid (A : Type) {n : Nat} (V : Fin n → Type) [∀ i, Fintype (V i)] : Setoid (Expr A V) where
  r := Derives
  iseqv := ⟨Derives.refl, Derives.symm, Derives.trans⟩

abbrev FreeAlgebra (A : Type) {n : Nat} (V : Fin n → Type) [∀ i, Fintype (V i)] := Quotient (derivesSetoid A V)

namespace FreeAlgebra

variable {A : Type} {n : Nat} {V : Fin n → Type} [∀ i, Fintype (V i)]

def of (e : Expr A V) : FreeAlgebra A V := Quotient.mk _ e

instance : Zero (FreeAlgebra A V) := ⟨of 0⟩
instance : One (FreeAlgebra A V) := ⟨of 1⟩
instance : Add (FreeAlgebra A V) := ⟨Quotient.map₂ (· + ·)
  (fun _ _ h₁ _ _ h₂ => Derives.add_congr h₁ h₂)⟩
instance : Mul (FreeAlgebra A V) := ⟨Quotient.map₂ (· * ·)
  (fun _ _ h₁ _ _ h₂ => Derives.mul_congr h₁ h₂)⟩
instance : KStar (FreeAlgebra A V) := ⟨Quotient.map Expr.star
  (fun _ _ h => Derives.star_congr h)⟩

@[simp] theorem of_zero : of (0 : Expr A V) = 0 := rfl
@[simp] theorem of_one : of (1 : Expr A V) = 1 := rfl
@[simp] theorem of_add (e f : Expr A V) : of (e + f) = of e + of f := rfl
@[simp] theorem of_mul (e f : Expr A V) : of (e * f) = of e * of f := rfl
@[simp] theorem of_star (e : Expr A V) : of e.star = KStar.kstar (of e) := rfl

theorem of_eq_iff {e f : Expr A V} : of e = of f ↔ Derives e f :=
  ⟨Quotient.exact, fun h => Quotient.sound h⟩

instance : Semiring (FreeAlgebra A V) where
  add_assoc := fun a b c => Quotient.inductionOn₃ a b c
    (fun e f g => Quotient.sound (.add_assoc e f g))
  add_comm := fun a b => Quotient.inductionOn₂ a b
    (fun e f => Quotient.sound (.add_comm e f))
  add_zero := fun a => Quotient.inductionOn a
    (fun e => Quotient.sound (.add_zero e))
  zero_add := fun a => Quotient.inductionOn a
    (fun e => Quotient.sound (.trans (.add_comm 0 e) (.add_zero e)))
  mul_assoc := fun a b c => Quotient.inductionOn₃ a b c
    (fun e f g => Quotient.sound (.mul_assoc e f g))
  one_mul := fun a => Quotient.inductionOn a
    (fun e => Quotient.sound (.one_mul e))
  mul_one := fun a => Quotient.inductionOn a
    (fun e => Quotient.sound (.mul_one e))
  zero_mul := fun a => Quotient.inductionOn a
    (fun e => Quotient.sound (.zero_mul e))
  mul_zero := fun a => Quotient.inductionOn a
    (fun e => Quotient.sound (.mul_zero e))
  left_distrib := fun a b c => Quotient.inductionOn₃ a b c
    (fun e f g => Quotient.sound (.mul_add e f g))
  right_distrib := fun a b c => Quotient.inductionOn₃ a b c
    (fun e f g => Quotient.sound (.add_mul e f g))
  nsmul := nsmulRec
  natCast := Nat.unaryCast
  natCast_zero := rfl
  natCast_succ := fun _ => rfl

instance : IdemSemiring (FreeAlgebra A V) :=
  IdemSemiring.ofSemiring (fun a => Quotient.inductionOn a
    (fun e => Quotient.sound (.add_idem e)))

open scoped Computability

instance : KleeneAlgebra (FreeAlgebra A V) where
  one_le_kstar := by
    intro a
    induction a using Quotient.inductionOn with
    | _ e =>
      have h : (1 : FreeAlgebra A V) + of e * (of e)∗ = (of e)∗ :=
        Quotient.sound (.star_unfold_left e)
      exact le_trans (le_add_right le_rfl) (le_of_eq h)
  mul_kstar_le_kstar := by
    intro a
    induction a using Quotient.inductionOn with
    | _ e =>
      have h : (1 : FreeAlgebra A V) + of e * (of e)∗ = (of e)∗ :=
        Quotient.sound (.star_unfold_left e)
      exact le_trans (le_add_left le_rfl) (le_of_eq h)
  kstar_mul_le_kstar := by
    intro a
    induction a using Quotient.inductionOn with
    | _ e =>
      have h : (1 : FreeAlgebra A V) + (of e)∗ * of e = (of e)∗ :=
        Quotient.sound (.star_unfold_right e)
      exact le_trans (le_add_left le_rfl) (le_of_eq h)
  kstar_mul_le_self := by
    intro a b
    induction a, b using Quotient.inductionOn₂ with
    | _ e f =>
      intro h
      exact of_eq_iff.mp h |>.star_induct_left |> Quotient.sound
  mul_kstar_le_self := by
    intro a b
    induction a, b using Quotient.inductionOn₂ with
    | _ e f =>
      intro h
      exact of_eq_iff.mp h |>.star_induct_right |> Quotient.sound

@[simp] theorem push_pop (a : A) : of (V := V) (.push a) * of (V := V) (.pop a) = 1 :=
  Quotient.sound (.push_pop a)

@[simp] theorem push_pop_ne {a b : A} (h : a ≠ b) :
    of (V := V) (.push a) * of (V := V) (.pop b) = 0 := Quotient.sound (.push_pop_ne a b h)

theorem pop_push (a : A) : of (V := V) (.pop a) * of (V := V) (.push a) ≤ 1 :=
  Quotient.sound (.pop_push a)

end FreeAlgebra

end Stackat.Fields

namespace Stackat.Fields

variable {K : Type} [KleeneAlgebra K]

def prod : {n : Nat} → (Fin n → K) → K
  | 0, _ => 1
  | _ + 1, f => f 0 * prod (fun i => f i.succ)

@[simp] theorem prod_zero (f : Fin 0 → K) : prod f = 1 := rfl
@[simp] theorem prod_succ (f : Fin (n+1) → K) : prod f = f 0 * prod (fun i => f i.succ) := rfl

theorem prod_congr {f g : Fin n → K} (h : ∀ i, f i = g i) : prod f = prod g :=
  congrArg prod (funext h)

theorem prod_commute (f : Fin n → K) (x : K) (h : ∀ i, Commute (f i) x) :
    Commute (prod f) x := by
  induction n with
  | zero => exact Commute.one_left x
  | succ n ih => exact (h 0).mul_left (ih _ (fun i => h i.succ))

theorem prod_mul (f g : Fin n → K) (h : ∀ i j, i ≠ j → Commute (f i) (g j)) :
    prod f * prod g = prod (fun i => f i * g i) := by
  induction n with
  | zero => simp
  | succ n ih =>
    simp only [prod_succ]
    have hc := prod_commute (fun i : Fin n => f i.succ) (g 0)
      (fun i => h i.succ 0 (Fin.succ_ne_zero i))
    rw [← mul_assoc, mul_assoc (f 0), hc.eq, ← mul_assoc, mul_assoc]
    rw [ih _ _ (fun i j hij => h i.succ j.succ (by simpa using hij))]

theorem prod_one : prod (fun _ : Fin n => (1 : K)) = 1 := by
  induction n with
  | zero => rfl
  | succ n ih => simp [ih]

theorem prod_single (i : Fin n) (x : K) :
    prod (fun j => if j = i then x else 1) = x := by
  induction n with
  | zero => exact i.elim0
  | succ n ih =>
    refine Fin.cases ?_ (fun i => ?_) i
    · simp [Fin.succ_ne_zero, prod_one]
    · simp [Ne.symm (Fin.succ_ne_zero i), ih]

theorem prod_eq_zero (f : Fin n → K) (i : Fin n) (h : f i = 0) : prod f = 0 := by
  induction n with
  | zero => exact i.elim0
  | succ n ih =>
    refine Fin.cases ?_ (fun i => ?_) i h
    · intro h
      simp [h]
    · intro h
      simp [ih (fun j => f j.succ) i h]

def splitHeader {V : Fin (n+1) → Type} : (∀ i, V i) ≃ (V 0 × (∀ i : Fin n, V i.succ)) where
  toFun h := (h 0, fun i => h i.succ)
  invFun h := Fin.cases h.1 h.2
  left_inv h := by funext i; exact Fin.cases rfl (fun _ => rfl) i
  right_inv h := rfl

theorem sum_prod {n : Nat} (V : Fin n → Type) [∀ i, Fintype (V i)]
    (f : ∀ i, V i → K) (h : ∀ i, ∑ v, f i v = 1) :
    ∑ v : Header V, prod (fun i => f i (v i)) = 1 := by
  induction n with
  | zero =>
    simp only [Finset.univ_unique, Finset.sum_singleton, prod_zero]
  | succ n ih =>
    rw [Fintype.sum_equiv (splitHeader (V := V)) (fun v : Header V => prod (fun i => f i (v i)))
      (fun v => f 0 v.1 * prod (fun i => f i.succ (v.2 i))) (fun _ => rfl)]
    rw [Fintype.sum_prod_type]
    simp_rw [← Finset.mul_sum, ih (fun i => V i.succ) (fun i => f i.succ) (fun i => h i.succ), mul_one]
    exact h 0

end Stackat.Fields
