import StackatPaper.AppendixB.HeaderSpec
import StackatPaper.AppendixB.HeaderCompleteness

/-!
Appendix B: the semantics of finite sums, header filters and header updates of whole-header
expressions.
-/

namespace Stackat.Fields.Headers

variable {A H : Type}

@[simp] theorem denote_sum (xs : List H) (f : H → Expr A H) (s t : H × List A) :
    (Expr.sum xs f).denote s t ↔ ∃ h ∈ xs, (f h).denote s t := by
  induction xs with
  | nil => simp [Expr.sum, Expr.denote]
  | cons h xs ih => simpa [Expr.sum, Expr.denote] using or_congr Iff.rfl ih

@[simp] theorem denote_filter [Fintype H] (b : H → Bool) (s t : H × List A) :
    (Expr.filter b).denote s t ↔ b s.1 = true ∧ s = t := by
  simp only [Expr.filter, denote_sum, Finset.mem_toList, Finset.mem_univ, true_and]
  constructor
  · rintro ⟨h,hh⟩
    split at hh
    · obtain ⟨rfl,rfl⟩ := hh
      exact ⟨by assumption, rfl⟩
    · exact False.elim hh
  · rintro ⟨hb,rfl⟩
    exact ⟨s.1, by simp [hb, Expr.denote]⟩

@[simp] theorem denote_update [Fintype H] (f : H → H) (s t : H × List A) :
    (Expr.update f).denote s t ↔ t.1 = f s.1 ∧ t.2 = s.2 := by
  rcases s with ⟨i,s⟩
  rcases t with ⟨j,t⟩
  simp [Expr.update, Expr.denote, and_comm, eq_comm]

end Stackat.Fields.Headers
