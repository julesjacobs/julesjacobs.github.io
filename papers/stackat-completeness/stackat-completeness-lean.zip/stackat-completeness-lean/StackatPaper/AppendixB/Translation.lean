import StackatPaper.AppendixB.HeaderAlgebra
import StackatPaper.Background.MatrixSimulation
import StackatPaper.Section4.Derivation

/-!
Appendix B: the matrix interpretation `M_e` (`Fields.Headers.matrices`), the simulation (17) `M_e
U = U e` (`Fields.Headers.simulation`) and the reconstruction (12)
(`Fields.Headers.reconstruction`).
-/

namespace Stackat.Fields.Headers

open scoped Computability

variable {A H K : Type} [KleeneAlgebra K]

noncomputable def eval (p q : A → K) (t u : H → K) : Expr A H → K
  | .zero => 0
  | .one => 1
  | .push a => p a
  | .pop a => q a
  | .test h => t h
  | .assign h => u h
  | .add e f => eval p q t u e + eval p q t u f
  | .mul e f => eval p q t u e * eval p q t u f
  | .star e => (eval p q t u e)∗

@[simp] theorem eval_sum (p q : A → K) (t u : H → K) (xs : List H) (f : H → Expr A H) :
    eval p q t u (Expr.sum xs f) = (xs.map (fun h => eval p q t u (f h))).sum := by
  induction xs with
  | nil => rfl
  | cons h xs ih => simpa [Expr.sum, eval] using congrArg (eval p q t u (f h) + ·) ih

variable [Fintype H] [DecidableEq H]

noncomputable def matrices (p q : A → K) : Expr A H → Matrix H H K :=
  eval (fun a => Matrix.diagonal (fun _ => p a))
    (fun a => Matrix.diagonal (fun _ => q a))
    (fun h i j => if i = h ∧ i = j then 1 else 0)
    (fun h _ j => if j = h then 1 else 0)

structure HeaderModel (t u : H → K) : Prop where
  complete : ∑ h, t h = 1
  test_assign : ∀ h, t h * u h = t h
  assign_test : ∀ h k, u h * t k = if h = k then u h else 0
  assign_assign : ∀ h k, u h * u k = u k

private theorem unit_star (M : Matrix Unit Unit K) :
    M∗ () () = (M () ())∗ := by
  change (1 + MatrixStar.close Finset.univ.toList M) () () = _
  simp only [Finset.univ_unique, Finset.toList_singleton, MatrixStar.close,
    MatrixStar.eliminate, Matrix.add_apply, Matrix.one_apply_eq]
  change 1 + (M () () + M () () * (M () ())∗ * M () ()) = _
  conv_lhs => arg 2; arg 1; rw [← mul_one (M () ())]
  rw [mul_assoc, ← mul_add, one_add_kstar_mul, one_add_mul_kstar]

private theorem scalar_simulation (M : Matrix H H K) (u : H → K) (x : K)
    (h : ∀ i, ∑ j, M i j * u j = u i * x) :
    ∀ i, ∑ j, M∗ i j * u j = u i * x∗ := by
  let R : Matrix H Unit K := fun i _ => u i
  let N : Matrix Unit Unit K := fun _ _ => x
  have hs : M * R = R * N := by
    ext i j
    simpa [Matrix.mul_apply, R, N] using h i
  have hstar := matrix_star_simulation M N R hs
  intro i
  have hi := congrArg (fun m : Matrix H Unit K => m i ()) hstar
  simpa [Matrix.mul_apply, R, unit_star, N] using hi

/-- **The simulation equation** (17): `M_e U = U e` entrywise, `∑_j (M_e)_{ij} u_j = u_i e`. -/
theorem simulation (p q : A → K) (t u : H → K) (hm : HeaderModel t u)
    (hp : ∀ h a, u h * p a = p a * u h)
    (hq : ∀ h a, u h * q a = q a * u h) (e : Expr A H) :
    ∀ i, ∑ j, matrices p q e i j * u j = u i * eval p q t u e := by
  induction e with
  | zero => intro i; simp [matrices, eval]
  | one => intro i; simp [matrices, eval, Matrix.one_apply]
  | push a => intro i; simpa [matrices, eval, Matrix.diagonal_apply] using (hp i a).symm
  | pop a => intro i; simpa [matrices, eval, Matrix.diagonal_apply] using (hq i a).symm
  | test h =>
    intro i
    by_cases hi : i = h
    · subst i
      simp [matrices, eval, hm.assign_test]
    · simp [matrices, eval, hi, hm.assign_test]
  | assign h => intro i; simp [matrices, eval, hm.assign_assign]
  | add e f he hf =>
    intro i
    change (∑ j, (matrices p q e i j + matrices p q f i j) * u j) =
      u i * (eval p q t u e + eval p q t u f)
    simp only [add_mul, Finset.sum_add_distrib, he, hf, mul_add]
  | mul e f he hf =>
    intro i
    change (∑ j, (matrices p q e * matrices p q f) i j * u j) = _
    simp only [Matrix.mul_apply, Finset.sum_mul, mul_assoc]
    rw [Finset.sum_comm]
    simp_rw [← Finset.mul_sum, hf, ← mul_assoc]
    rw [← Finset.sum_mul, he]
    exact mul_assoc _ _ _
  | star e he => exact scalar_simulation _ _ _ he

/-- **The reconstruction identity** (12): `e = ∑_i t_i (∑_j (M_e)_{ij} u_j)`. -/
theorem reconstruction (p q : A → K) (t u : H → K) (hm : HeaderModel t u)
    (hp : ∀ h a, u h * p a = p a * u h)
    (hq : ∀ h a, u h * q a = q a * u h) (e : Expr A H) :
    eval p q t u e = ∑ i, t i * (∑ j, matrices p q e i j * u j) := by
  simp_rw [simulation p q t u hm hp hq e, ← mul_assoc, hm.test_assign]
  rw [← Finset.sum_mul, hm.complete, one_mul]

end Stackat.Fields.Headers
