import Mathlib.Logic.Relation
import Mathlib.Data.Fintype.Basic

/-!
Appendix B: expressions over whole headers (tests `t_h`, assignments `u_h`), their semantics and
derivation system.
-/

namespace Stackat.Fields.Headers

/-- Stack expressions extended with tests and assignments of complete header valuations. -/
inductive Expr (A H : Type) where
  | zero
  | one
  | push (a : A)
  | pop (a : A)
  | test (h : H)
  | assign (h : H)
  | add (e f : Expr A H)
  | mul (e f : Expr A H)
  | star (e : Expr A H)
  deriving DecidableEq

namespace Expr

instance : Zero (Expr A H) := ⟨zero⟩
instance : One (Expr A H) := ⟨one⟩
instance : Add (Expr A H) := ⟨add⟩
instance : Mul (Expr A H) := ⟨mul⟩

def sum (xs : List H) (f : H → Expr A H) : Expr A H :=
  xs.foldr (fun h e => f h + e) 0

/-- Headers are finite control; multiplication executes its left operand first. -/
def denote : Expr A H → (H × List A) → (H × List A) → Prop
  | .zero => fun _ _ => False
  | .one => Eq
  | .push a => fun s t => t.1 = s.1 ∧ t.2 = a :: s.2
  | .pop a => fun s t => t.1 = s.1 ∧ s.2 = a :: t.2
  | .test h => fun s t => s.1 = h ∧ s = t
  | .assign h => fun s t => t.1 = h ∧ t.2 = s.2
  | .add e f => fun s t => denote e s t ∨ denote f s t
  | .mul e f => fun s t => ∃ m, denote e s m ∧ denote f m t
  | .star e => Relation.ReflTransGen (denote e)

/-- Test a predicate on complete header valuations. -/
noncomputable def filter [Fintype H] (b : H → Bool) : Expr A H :=
  sum Finset.univ.toList (fun h => if b h then .test h else 0)

/-- Update the header by a total function, including an individual field assignment. -/
noncomputable def update [Fintype H] (f : H → H) : Expr A H :=
  sum Finset.univ.toList (fun h => .test h * .assign (f h))

end Expr

/-- The relation of `e` on `H × A*`. -/
abbrev R (e : Expr A H) : H × List A → H × List A → Prop := e.denote

/-- Equational derivability from ordinary Kleene algebra, the three stack laws,
finite-header laws, and commutation.
The two induction rules express `a ≤ b` as `a + b = b`. -/
inductive Derives {A H : Type} [Fintype H] : Expr A H → Expr A H → Prop where
  -- Equational reasoning.
  | refl (e) : Derives e e
  | symm : Derives e f → Derives f e
  | trans : Derives e f → Derives f g → Derives e g
  | add_congr : Derives e e' → Derives f f' → Derives (e + f) (e' + f')
  | mul_congr : Derives e e' → Derives f f' → Derives (e * f) (e' * f')
  | star_congr : Derives e f → Derives e.star f.star

  -- Idempotent semiring laws.
  | add_assoc (e f g) : Derives ((e + f) + g) (e + (f + g))
  | add_comm (e f) : Derives (e + f) (f + e)
  | add_zero (e) : Derives (e + 0) e
  | add_idem (e) : Derives (e + e) e
  | mul_assoc (e f g) : Derives ((e * f) * g) (e * (f * g))
  | one_mul (e) : Derives (1 * e) e
  | mul_one (e) : Derives (e * 1) e
  | zero_mul (e) : Derives (0 * e) 0
  | mul_zero (e) : Derives (e * 0) 0
  | mul_add (e f g) : Derives (e * (f + g)) (e * f + e * g)
  | add_mul (e f g) : Derives ((e + f) * g) (e * g + f * g)

  -- Kleene star laws.
  | star_unfold_left (e) : Derives (1 + e * e.star) e.star
  | star_unfold_right (e) : Derives (1 + e.star * e) e.star
  | star_induct_left : Derives (e * f + f) f → Derives (e.star * f + f) f
  | star_induct_right : Derives (f * e + f) f → Derives (f * e.star + f) f

  -- Stack laws.
  | push_pop (a : A) : Derives (.push a * .pop a) 1
  | push_pop_ne (a b : A) : a ≠ b → Derives (.push a * .pop b) 0
  | pop_push (a : A) : Derives (.pop a * .push a + 1) 1

  -- Finite-header laws for complete valuation tests and assignments.
  | test_complete : Derives (Expr.sum Finset.univ.toList Expr.test) 1
  | test_assign (h : H) : Derives (.test h * .assign h) (.test h)
  | assign_test (h : H) : Derives (.assign h * .test h) (.assign h)
  | assign_test_ne (h k : H) : h ≠ k → Derives (.assign h * .test k) 0
  | assign_assign (h k : H) : Derives (.assign h * .assign k) (.assign k)
  | assign_push (h : H) (a : A) :
      Derives (.assign h * .push a) (.push a * .assign h)
  | assign_pop (h : H) (a : A) :
      Derives (.assign h * .pop a) (.pop a * .assign h)

/-- `⊢ e ≈ f`: the equation `e = f` is derivable in the whole-header system. -/
scoped notation:25 "⊢ " e:51 " ≈ " f:51 => Headers.Derives e f

end Stackat.Fields.Headers
