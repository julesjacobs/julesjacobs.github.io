import StackatPaper.AppendixB.HeaderSpec
import Mathlib.Algebra.Order.Kleene

/-!
Appendix B: whole-header expressions modulo derivability form a Kleene algebra.
-/

namespace Stackat.Fields.Headers

instance derivesSetoid (A H : Type) [Fintype H] : Setoid (Expr A H) where
  r := Derives
  iseqv := ⟨Derives.refl, Derives.symm, Derives.trans⟩

abbrev FreeAlgebra (A H : Type) [Fintype H] := Quotient (derivesSetoid A H)

namespace FreeAlgebra

variable {A H : Type} [Fintype H]

def of (e : Expr A H) : FreeAlgebra A H := Quotient.mk _ e

instance : Zero (FreeAlgebra A H) := ⟨of 0⟩
instance : One (FreeAlgebra A H) := ⟨of 1⟩
instance : Add (FreeAlgebra A H) := ⟨Quotient.map₂ (· + ·)
  (fun _ _ h₁ _ _ h₂ => Derives.add_congr h₁ h₂)⟩
instance : Mul (FreeAlgebra A H) := ⟨Quotient.map₂ (· * ·)
  (fun _ _ h₁ _ _ h₂ => Derives.mul_congr h₁ h₂)⟩
instance : KStar (FreeAlgebra A H) := ⟨Quotient.map Expr.star
  (fun _ _ h => Derives.star_congr h)⟩

@[simp] theorem of_zero : of (0 : Expr A H) = 0 := rfl
@[simp] theorem of_one : of (1 : Expr A H) = 1 := rfl
@[simp] theorem of_add (e f : Expr A H) : of (e + f) = of e + of f := rfl
@[simp] theorem of_mul (e f : Expr A H) : of (e * f) = of e * of f := rfl
@[simp] theorem of_star (e : Expr A H) : of e.star = KStar.kstar (of e) := rfl

theorem of_eq_iff {e f : Expr A H} : of e = of f ↔ Derives e f :=
  ⟨Quotient.exact, fun h => Quotient.sound h⟩

instance : Semiring (FreeAlgebra A H) where
  add_assoc := fun a b c => Quotient.inductionOn₃ a b c
    (fun e f g => Quotient.sound (.add_assoc e f g))
  add_comm := fun a b => Quotient.inductionOn₂ a b
    (fun e f => Quotient.sound (.add_comm e f))
  add_zero := fun a => Quotient.inductionOn a
    (fun e => Quotient.sound (.add_zero e))
  zero_add := fun a => Quotient.inductionOn a
    (fun e => Quotient.sound (.trans (.add_comm 0 e) (.add_zero e)))
  mul_assoc := fun a b c => Quotient.inductionOn₃ a b c
    (fun e f g => Quotient.sound (.mul_assoc e f g))
  one_mul := fun a => Quotient.inductionOn a
    (fun e => Quotient.sound (.one_mul e))
  mul_one := fun a => Quotient.inductionOn a
    (fun e => Quotient.sound (.mul_one e))
  zero_mul := fun a => Quotient.inductionOn a
    (fun e => Quotient.sound (.zero_mul e))
  mul_zero := fun a => Quotient.inductionOn a
    (fun e => Quotient.sound (.mul_zero e))
  left_distrib := fun a b c => Quotient.inductionOn₃ a b c
    (fun e f g => Quotient.sound (.mul_add e f g))
  right_distrib := fun a b c => Quotient.inductionOn₃ a b c
    (fun e f g => Quotient.sound (.add_mul e f g))
  nsmul := nsmulRec
  natCast := Nat.unaryCast
  natCast_zero := rfl
  natCast_succ := fun _ => rfl

instance : IdemSemiring (FreeAlgebra A H) :=
  IdemSemiring.ofSemiring (fun a => Quotient.inductionOn a
    (fun e => Quotient.sound (.add_idem e)))

open scoped Computability

instance : KleeneAlgebra (FreeAlgebra A H) where
  one_le_kstar := by
    intro a
    induction a using Quotient.inductionOn with
    | _ e =>
      have h : (1 : FreeAlgebra A H) + of e * (of e)∗ = (of e)∗ :=
        Quotient.sound (.star_unfold_left e)
      exact le_trans (le_add_right le_rfl) (le_of_eq h)
  mul_kstar_le_kstar := by
    intro a
    induction a using Quotient.inductionOn with
    | _ e =>
      have h : (1 : FreeAlgebra A H) + of e * (of e)∗ = (of e)∗ :=
        Quotient.sound (.star_unfold_left e)
      exact le_trans (le_add_left le_rfl) (le_of_eq h)
  kstar_mul_le_kstar := by
    intro a
    induction a using Quotient.inductionOn with
    | _ e =>
      have h : (1 : FreeAlgebra A H) + (of e)∗ * of e = (of e)∗ :=
        Quotient.sound (.star_unfold_right e)
      exact le_trans (le_add_left le_rfl) (le_of_eq h)
  kstar_mul_le_self := by
    intro a b
    induction a, b using Quotient.inductionOn₂ with
    | _ e f =>
      intro h
      exact of_eq_iff.mp h |>.star_induct_left |> Quotient.sound
  mul_kstar_le_self := by
    intro a b
    induction a, b using Quotient.inductionOn₂ with
    | _ e f =>
      intro h
      exact of_eq_iff.mp h |>.star_induct_right |> Quotient.sound

end FreeAlgebra

end Stackat.Fields.Headers
