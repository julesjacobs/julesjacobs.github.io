import StackatPaper.AppendixB.Maps

/-!
Appendix B: the entries of `M_e` in the relational model are the stack relations with fixed
headers (`Fields.Headers.semantic_entries`).
-/

namespace Stackat.Fields.Headers

open scoped Computability

variable {A H X : Type}

def onStacks (r : Rel X) : Rel (H × X) := fun s t => s.1 = t.1 ∧ r s.2 t.2

def relTest (h : H) : Rel (H × X) := fun s t => s.1 = h ∧ s = t

def relAssign (h : H) : Rel (H × X) := fun s t => t.1 = h ∧ t.2 = s.2

noncomputable def onStacksHom : Rel X →+* Rel (H × X) where
  toFun := onStacks
  map_zero' := by apply Rel.ext; intro s t; simp [onStacks]
  map_one' := by
    apply Rel.ext
    rintro ⟨i,s⟩ ⟨j,t⟩
    simp [onStacks, Prod.mk.injEq]
  map_add' r r' := by apply Rel.ext; intro s t; simp [onStacks, and_or_left]
  map_mul' r r' := by
    apply Rel.ext
    rintro ⟨i,s⟩ ⟨j,t⟩
    change (i = j ∧ ∃ m, r s m ∧ r' m t) ↔
      ∃ m : H × X, (i = m.1 ∧ r s m.2) ∧ m.1 = j ∧ r' m.2 t
    constructor
    · rintro ⟨rfl, m, hr, hr'⟩
      exact ⟨(i,m), ⟨rfl,hr⟩, rfl, hr'⟩
    · rintro ⟨⟨k,m⟩, ⟨rfl,hr⟩, rfl,hr'⟩
      exact ⟨rfl,m,hr,hr'⟩

theorem onStacks_star (r : Rel X) : onStacksHom (H := H) r∗ = (onStacksHom r)∗ := by
  apply Rel.ext
  rintro ⟨i,s⟩ ⟨j,t⟩
  change (i = j ∧ Relation.ReflTransGen r s t) ↔
    Relation.ReflTransGen (onStacks r) (i,s) (j,t)
  constructor
  · rintro ⟨rfl,h⟩
    induction h with
    | refl => exact .refl
    | tail _ h ih => exact ih.tail ⟨rfl,h⟩
  · intro h
    have aux : ∀ {s t : H × X}, Relation.ReflTransGen (onStacks r) s t →
        s.1 = t.1 ∧ Relation.ReflTransGen r s.2 t.2 := by
      intro s t h
      induction h with
      | refl => exact ⟨rfl,.refl⟩
      | tail _ h ih => exact ⟨ih.1.trans h.1, ih.2.tail h.2⟩
    exact aux h

variable [Fintype H] [DecidableEq H]

theorem rel_headerModel : HeaderModel (relTest (H := H) (X := X)) relAssign where
  complete := by
    apply Rel.ext
    intro s t
    rw [Rel.sum_apply]
    simp [relTest]
  test_assign := by
    intro h
    apply Rel.ext
    rintro ⟨i,s⟩ ⟨j,t⟩
    simp [Rel.mul_apply, relTest, relAssign, Prod.mk.injEq]
    aesop
  assign_test := by
    intro h k
    apply Rel.ext
    rintro ⟨i,s⟩ ⟨j,t⟩
    by_cases hh : h = k
    · subst k
      simp [Rel.mul_apply, relTest, relAssign]
      aesop
    · simp [Rel.mul_apply, relTest, relAssign, hh]
      aesop
  assign_assign := by
    intro h k
    apply Rel.ext
    rintro ⟨i,s⟩ ⟨j,t⟩
    simp [Rel.mul_apply, relAssign, and_comm]

omit [Fintype H] [DecidableEq H] in
theorem assign_onStacks (h : H) (r : Rel X) :
    relAssign h * onStacks r = onStacks r * relAssign h := by
  apply Rel.ext
  rintro ⟨i,s⟩ ⟨j,t⟩
  simp [Rel.mul_apply, relAssign, onStacks, and_comm, eq_comm]

omit [Fintype H] [DecidableEq H] in
@[simp] theorem eval_denote (e : Expr A H) :
    eval (fun a => onStacks (Rel.push a)) (fun a => onStacks (Rel.pop a))
      relTest relAssign e = (e.denote : Rel (H × List A)) := by
  induction e with
  | zero => rfl
  | one => rfl
  | push a => apply Rel.ext; intro s t; simp [eval, onStacks, Rel.push, Expr.denote, eq_comm]
  | pop a => apply Rel.ext; intro s t; simp [eval, onStacks, Rel.pop, Expr.denote, eq_comm]
  | test h => rfl
  | assign h => rfl
  | add e f he hf => change _ + _ = _; rw [he, hf]; rfl
  | mul e f he hf => change _ * _ = _; rw [he, hf]; rfl
  | star e he => change _∗ = _; rw [he]; rfl

omit [DecidableEq H] in
theorem reconstructed_entry (M : Matrix H H (Rel X)) (i j : H) (s t : X) :
    (∑ h, relTest h * (∑ k, onStacks (M h k) * relAssign k)) (i,s) (j,t) ↔ M i j s t := by
  simp only [Rel.sum_apply, Finset.mem_univ, true_and, Rel.mul_apply,
    relTest, onStacks, relAssign]
  constructor
  · rintro ⟨h, m, ⟨hh, rfl⟩, k, n, ⟨hn, hr⟩, hk, ht⟩
    subst h
    subst k
    simpa [← hn, ht] using hr
  · intro hr
    exact ⟨i, (i,s), ⟨rfl,rfl⟩, j, (i,t), ⟨rfl,hr⟩, rfl,rfl⟩

/-- **The entries of `M_e` in the relational model:** `e` relates `(i, s)` to `(j, t)` exactly when
the `(i, j)` entry of `M_e` relates `s` to `t`. -/
theorem semantic_entries (e : Expr A H) (i j : H) (s t : List A) :
    R e (i, s) (j, t) ↔ matrices Rel.push Rel.pop e i j s t := by
  have hr := reconstruction (fun a => onStacks (Rel.push a)) (fun a => onStacks (Rel.pop a))
    relTest relAssign rel_headerModel
    (fun h a => assign_onStacks h (Rel.push a))
    (fun h a => assign_onStacks h (Rel.pop a)) e
  rw [eval_denote] at hr
  have hm := matrices_map (onStacksHom (H := H)) onStacks_star Rel.push Rel.pop e
  change matrices (fun a => onStacks (Rel.push a)) (fun a => onStacks (Rel.pop a)) e = _ at hm
  rw [hm] at hr
  exact (Iff.of_eq (congrArg (fun r : Rel (H × List A) => r (i,s) (j,t)) hr)).trans
    (reconstructed_entry _ i j s t)

end Stackat.Fields.Headers
