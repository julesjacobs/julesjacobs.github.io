import StackatPaper.Section2
import Mathlib.Computability.MyhillNerode

/-!
# Section 7: Related Work

## The NetKAT hypotheses fail for pushes and pops

The hypotheses `bb ≤ b` and `a ≤ 1` of Pous, Rot and Wagemaker's NetKAT instance do not hold in
the relational model for `b`, `a` a push or a pop (`netkat_hypotheses_fail`).

## The hypothesis closure of `1` is not regular

Section 7, on Chung and Kappé: "For any stack symbol `a`, the closure of `1` under all three schemes
intersects `q_a* p_a*` in `{q_a^n p_a^n : n ≥ 0}`: inserting `q_a p_a` gives the diagonal words, and
unequal exponents change stack height, so cannot occur in a sound closure of `1`. This nonregular
intersection excludes `1` from the domain of such a reduction."

Words are over the operation alphabet `Op A = {p_a, q_a}`. The closure of a language `L` under
hypotheses `e ≤ f` (Doumane et al.) is the least language containing `L` such that
`u [f] v ⊆ cl ⟹ u [e] v ⊆ cl`. For the three schemes, as the hypotheses `p_a q_a ≤ 1`,
`1 ≤ p_a q_a`, `p_a q_b ≤ 0`, `0 ≤ p_a q_b` and `q_a p_a ≤ 1`, this is `InClosure` (the hypothesis
`0 ≤ p_a q_b` adds nothing, because `[0] = ∅`).

* `closure_sound`: every word of the closure of `1` denotes a relation inside the identity;
* `closure_inter`: the closure meets `q_a* p_a*` exactly in `{q_a^n p_a^n}`;
* `diagonal_not_regular`: `{q_a^n p_a^n}` is not regular (Myhill–Nerode);
* `closure_inter_not_regular`: the two together.
-/

namespace Stackat

/-! ## Related work: the NetKAT hypotheses fail for pushes and pops -/

section NetKAT

variable {A : Type} (a : A)

/-- `x x ≤ x` fails for `x = p_a`: `p_a p_a` relates `ε` to `aa`, `p_a` does not. -/
theorem push_not_idem : ¬ R (.push a * .push a) ≤ R (.push a) := by
  intro h
  have := h [] [a, a] ⟨[a], rfl, rfl⟩
  simp [R] at this

/-- `x x ≤ x` fails for `x = q_a`. -/
theorem pop_not_idem : ¬ R (.pop a * .pop a) ≤ R (.pop a) := by
  intro h
  have := h [a, a] [] ⟨[a], rfl, rfl⟩
  simp [R] at this

/-- `x ≤ 1` fails for `x = p_a`. -/
theorem push_not_le_one : ¬ R (.push a) ≤ R 1 := by
  intro h
  have := h [] [a] rfl
  simp [R] at this

/-- `x ≤ 1` fails for `x = q_a`. -/
theorem pop_not_le_one : ¬ R (.pop a) ≤ R 1 := by
  intro h
  have := h [a] [] rfl
  simp [R] at this

/-- **Section 7.** The NetKAT hypotheses `bb ≤ b` and `a ≤ 1` do not hold for pushes and pops in
the relational model. -/
theorem netkat_hypotheses_fail :
    ¬ R (.push a * .push a) ≤ R (.push a) ∧ ¬ R (.pop a * .pop a) ≤ R (.pop a) ∧
      ¬ R (.push a) ≤ R 1 ∧ ¬ R (.pop a) ≤ R 1 :=
  ⟨push_not_idem a, pop_not_idem a, push_not_le_one a, pop_not_le_one a⟩

end NetKAT

end Stackat

namespace Stackat.Closure

open Stackat

/-- The operation alphabet: pushes and pops. -/
inductive Op (A : Type)
  | push (a : A)
  | pop (a : A)

variable {A : Type}

def Op.expr : Op A → Expr A
  | .push a => .push a
  | .pop a => .pop a

/-- The program of a word of operations. -/
def word : List (Op A) → Expr A
  | [] => 1
  | o :: w => o.expr * word w

theorem word_append (u v : List (Op A)) (s t : List A) :
    R (word (u ++ v)) s t ↔ ∃ m, R (word u) s m ∧ R (word v) m t := by
  induction u generalizing s with
  | nil =>
    change R (word v) s t ↔ ∃ m, s = m ∧ R (word v) m t
    exact ⟨fun h => ⟨s, rfl, h⟩, fun ⟨_, h1, h2⟩ => h1 ▸ h2⟩
  | cons o u ih =>
    change (∃ m, R o.expr s m ∧ R (word (u ++ v)) m t) ↔
      ∃ m, (∃ x, R o.expr s x ∧ R (word u) x m) ∧ R (word v) m t
    simp only [ih]
    constructor
    · rintro ⟨x, hx, m, hm, hv⟩; exact ⟨m, ⟨x, hx, hm⟩, hv⟩
    · rintro ⟨m, ⟨x, hx, hm⟩, hv⟩; exact ⟨x, hx, m, hm, hv⟩

/-- The closure of `1` (the language `{ε}`) under the three stack schemes. -/
inductive InClosure : List (Op A) → Prop
  | one : InClosure []
  -- p_a q_a ≤ 1
  | push_pop_le {u v : List (Op A)} {a : A} :
      InClosure (u ++ v) → InClosure (u ++ [.push a, .pop a] ++ v)
  -- 1 ≤ p_a q_a
  | push_pop_ge {u v : List (Op A)} {a : A} :
      InClosure (u ++ [.push a, .pop a] ++ v) → InClosure (u ++ v)
  -- p_a q_b ≤ 0 ([0] = ∅, so the premise holds vacuously)
  | push_pop_ne {u v : List (Op A)} {a b : A} :
      a ≠ b → InClosure (u ++ [.push a, .pop b] ++ v)
  -- q_a p_a ≤ 1
  | pop_push {u v : List (Op A)} {a : A} :
      InClosure (u ++ v) → InClosure (u ++ [.pop a, .push a] ++ v)

theorem word_three (u v : List (Op A)) (x y : Op A) (s t : List A) :
    R (word (u ++ [x, y] ++ v)) s t ↔
      ∃ m n, R (word u) s m ∧ R (x.expr * y.expr) m n ∧ R (word v) n t := by
  rw [List.append_assoc, word_append]
  change (∃ m, _ ∧ ∃ k, R x.expr m k ∧ ∃ n, R y.expr k n ∧ R (word v) n t) ↔ _
  constructor
  · rintro ⟨m, hu, k, hk, n, hn, hv⟩
    exact ⟨m, n, hu, ⟨k, hk, hn⟩, hv⟩
  · rintro ⟨m, n, hu, ⟨k, hk, hn⟩, hv⟩
    exact ⟨m, hu, k, hk, n, hn, hv⟩

/-- **The closure is sound**: every word in the closure of `1` denotes a relation inside the
identity. -/
theorem closure_sound {w : List (Op A)} (h : InClosure w) :
    ∀ s t, R (word w) s t → s = t := by
  induction h with
  | one => intro s t h; exact h
  | @push_pop_le u v a _ ih =>
    intro s t h
    obtain ⟨m, n, hu, hpq, hv⟩ := (word_three u v _ _ s t).mp h
    have hmn : m = n := (push_pop_denote a m n).mp hpq
    subst hmn
    exact ih s t ((word_append u v s t).mpr ⟨m, hu, hv⟩)
  | @push_pop_ge u v a _ ih =>
    intro s t h
    obtain ⟨m, hu, hv⟩ := (word_append u v s t).mp h
    exact ih s t ((word_three u v _ _ s t).mpr ⟨m, m, hu, (push_pop_denote a m m).mpr rfl, hv⟩)
  | @push_pop_ne u v a b hab =>
    intro s t h
    obtain ⟨m, n, _, hpq, _⟩ := (word_three u v _ _ s t).mp h
    exact (push_pop_ne_denote hab m n hpq).elim
  | @pop_push u v a _ ih =>
    intro s t h
    obtain ⟨m, n, hu, hqp, hv⟩ := (word_three u v _ _ s t).mp h
    have hmn : m = n := ((pop_push_denote a m n).mp hqp).1
    subst hmn
    exact ih s t ((word_append u v s t).mpr ⟨m, hu, hv⟩)

/-- `q_a^m`. -/
def pops (a : A) (m : ℕ) : List (Op A) := List.replicate m (.pop a)
/-- `p_a^n`. -/
def pushes (a : A) (n : ℕ) : List (Op A) := List.replicate n (.push a)

theorem pops_denote (a : A) (m : ℕ) (s : List A) :
    R (word (pops a m)) (List.replicate m a ++ s) s := by
  induction m with
  | zero => exact rfl
  | succ m ih => exact ⟨_, rfl, ih⟩

theorem pushes_denote (a : A) (n : ℕ) (s : List A) :
    R (word (pushes a n)) s (List.replicate n a ++ s) := by
  induction n generalizing s with
  | zero => exact rfl
  | succ n ih =>
    refine ⟨a :: s, rfl, ?_⟩
    have := ih (a :: s)
    rwa [List.replicate_succ', List.append_assoc]

theorem diagonal_mem_closure (a : A) (n : ℕ) : InClosure (pops a n ++ pushes a n) := by
  induction n with
  | zero => exact .one
  | succ n ih =>
    have h := InClosure.pop_push (u := pops a n) (v := pushes a n) (a := a) ih
    have e : pops a n ++ [.pop a, .push a] ++ pushes a n = pops a (n + 1) ++ pushes a (n + 1) := by
      rw [show pops a (n + 1) = pops a n ++ [.pop a] from List.replicate_succ' ..,
        show pushes a (n + 1) = .push a :: pushes a n from List.replicate_succ ..]
      simp
    rwa [e] at h

/-- **The closure of `1` meets `q_a* p_a*` exactly in `{q_a^n p_a^n : n ≥ 0}`.** -/
theorem closure_inter (a : A) (w : List (Op A)) :
    (InClosure w ∧ ∃ m n, w = pops a m ++ pushes a n) ↔ ∃ n, w = pops a n ++ pushes a n := by
  constructor
  · rintro ⟨hc, m, n, rfl⟩
    refine ⟨m, ?_⟩
    have h := closure_sound hc (List.replicate m a) (List.replicate n a)
      ((word_append _ _ _ _).mpr ⟨[], by simpa using pops_denote a m [],
        by simpa using pushes_denote a n []⟩)
    have := congrArg List.length h
    simp only [List.length_replicate] at this
    rw [this]
  · rintro ⟨n, rfl⟩
    exact ⟨diagonal_mem_closure a n, n, n, rfl⟩

theorem pops_pushes_inj (a : A) {j k m n : ℕ}
    (h : pops a j ++ pushes a k = pops a m ++ pushes a n) : j = m ∧ k = n := by
  induction j generalizing m with
  | zero =>
    cases m with
    | zero =>
      simp only [pops, pushes, List.replicate_zero, List.nil_append] at h
      exact ⟨rfl, by simpa using congrArg List.length h⟩
    | succ m =>
      cases k with
      | zero => simp [pops, pushes, List.replicate_succ] at h
      | succ k => simp [pops, pushes, List.replicate_succ] at h
  | succ j ih =>
    cases m with
    | zero =>
      cases n with
      | zero => simp [pops, pushes, List.replicate_succ] at h
      | succ n => simp [pops, pushes, List.replicate_succ] at h
    | succ m =>
      simp only [pops, List.replicate_succ, List.cons_append, List.cons.injEq, true_and] at h
      have := ih (m := m) h
      exact ⟨by omega, this.2⟩

/-- The diagonal language `{q_a^n p_a^n}`. -/
def diagonal (a : A) : Language (Op A) := {w | ∃ n, w = pops a n ++ pushes a n}

/-- **The intersection is not regular** (Myhill–Nerode: the left quotients by `q_a^k` differ). -/
theorem diagonal_not_regular (a : A) : ¬ (diagonal a).IsRegular := by
  intro hreg
  have hfin := hreg.finite_range_leftQuotient
  have hinj : Function.Injective fun k => (diagonal a).leftQuotient (pops a k) := by
    intro j k hjk
    have hk : pushes a k ∈ (diagonal a).leftQuotient (pops a k) := ⟨k, rfl⟩
    simp only at hjk
    rw [← hjk] at hk
    obtain ⟨n, hn⟩ := hk
    obtain ⟨h1, h2⟩ := pops_pushes_inj a hn
    omega
  exact Set.infinite_range_of_injective hinj
    (hfin.subset (by rintro _ ⟨k, rfl⟩; exact ⟨pops a k, rfl⟩))

/-- **Section 7.** The closure of `1` under the three schemes meets `q_a* p_a*` exactly in
`{q_a^n p_a^n : n ≥ 0}`, and this intersection is not regular. -/
theorem closure_inter_not_regular (a : A) :
    (∀ w : List (Op A), (InClosure w ∧ ∃ m n, w = pops a m ++ pushes a n) ↔
        ∃ n, w = pops a n ++ pushes a n) ∧ ¬ (diagonal a).IsRegular :=
  ⟨closure_inter a, diagonal_not_regular a⟩

end Stackat.Closure
