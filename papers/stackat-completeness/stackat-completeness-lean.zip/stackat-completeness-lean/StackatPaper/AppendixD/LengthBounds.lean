import StackatPaper.AppendixD.Marking

/-!
# Appendix D.3: Counterexample Length, the upper bound

Proposition 12 (short counterexamples): with `n = |S|` and `b = |S² ∖ F|`, if `𝓡_E ⊈ 𝓡_F`
there is a counterexample `(u, v)` with `max(|u|, |v|) ≤ n + b - 1 ≤ n² + n - 1`
(`short_counterexamples`; the two bounds separately: `short_counterexample`,
`short_counterexample_sq`). The proof follows the paper:

* removing the preserved suffix keeps a pair outside `𝓡_F` (`accepted_suffix`), so the source
  cell of `E` is marked (`marked_of_not_accepted`, `AppendixD/Marking.lean`);
* every marked cell is marked within `b - 1` propagation steps (`markedWithin_bound`). Where the
  paper takes a shortest propagation path, this proof counts layers (`layers_stabilize`): the
  cells marked within `k` steps grow strictly until they stop growing, and all lie outside `F`;
* every state has a representative of length at most `n - 1` (`exists_short_representative`);
* the witness grows by one letter per propagation step (`MarkedWithin.exists_short`).
-/

namespace Stackat

/-! ## Layers that stop growing -/

/-- **Layers in a finite set stop growing in time.** If a monotone sequence of sets `D k` lies
inside `P`, starts nonempty, and stays put from the first `k` with `D (k + 1) ⊆ D k`, then every
layer is inside `D (|P| - 1)`. -/
theorem layers_stabilize {α : Type*} [Finite α] (P : Set α) (D : ℕ → Set α)
    (mono : ∀ k, D k ⊆ D (k + 1)) (sub : ∀ k, D k ⊆ P) (ne : (D 0).Nonempty)
    (stab : ∀ k, D (k + 1) ⊆ D k → D (k + 2) ⊆ D (k + 1)) :
    ∀ m, D m ⊆ D (P.ncard - 1) := by
  have hmono : Monotone D := monotone_nat_of_le_succ mono
  -- some layer `k < |P|` does not grow
  have hex : ∃ k, k < P.ncard ∧ D (k + 1) ⊆ D k := by
    by_contra hno
    push Not at hno
    have hgrow : ∀ k, k ≤ P.ncard → k + 1 ≤ (D k).ncard := by
      intro k
      induction k with
      | zero =>
        intro _
        exact Nat.one_le_iff_ne_zero.mpr
          ((Set.ncard_pos (Set.toFinite _)).mpr ne).ne'
      | succ k ih =>
        intro hk
        have hlt : (D k).ncard < (D (k + 1)).ncard :=
          Set.ncard_lt_ncard (HasSubset.Subset.ssubset_of_not_subset (mono k) (hno k hk))
            (Set.toFinite _)
        have := ih (by omega)
        omega
    have h1 := hgrow P.ncard le_rfl
    have h2 : (D P.ncard).ncard ≤ P.ncard := Set.ncard_le_ncard (sub _) (Set.toFinite _)
    omega
  obtain ⟨k, hk, hstop⟩ := hex
  -- from `k` on, the layers stay inside `D k`
  have hstep : ∀ j, D (k + j + 1) ⊆ D (k + j) := by
    intro j
    induction j with
    | zero => simpa using hstop
    | succ j ih => exact stab (k + j) ih
  have hall : ∀ j, D (k + j) ⊆ D k := by
    intro j
    induction j with
    | zero => exact le_rfl
    | succ j ih => exact (hstep j).trans ih
  intro m
  rcases le_or_gt m k with hm | hm
  · exact (hmono hm).trans (hmono (by omega))
  · have := hall (m - k)
    rw [Nat.add_sub_cancel' hm.le] at this
    exact this.trans (hmono (by omega))

variable {A S : Type*}

/-! ## Short representatives -/

/-- **Short representatives.** Every state of a reachable automaton with `n` states has a word
reaching it of length at most `n - 1`. -/
theorem exists_short_representative [Fintype S] (M : DFA A S) (s : S) :
    ∃ u : List A, M.h u = s ∧ u.length ≤ Fintype.card S - 1 := by
  let D : ℕ → Set S := fun k => {t | ∃ u : List A, M.h u = t ∧ u.length ≤ k}
  have hD := layers_stabilize Set.univ D
    (fun k t ⟨u, hu, hl⟩ => ⟨u, hu, by omega⟩) (fun _ _ _ => trivial)
    ⟨M.initial, [], rfl, by simp⟩
    (by
      intro k hstop t ⟨u, hu, hl⟩
      induction u using List.reverseRecOn with
      | nil => exact ⟨[], hu, by simp⟩
      | append_singleton u a _ =>
        simp only [List.length_append, List.length_singleton] at hl
        obtain ⟨u', hu', hl'⟩ := hstop ⟨u, rfl, by omega⟩
        exact ⟨u' ++ [a], by rw [DFA.h_append_singleton, hu', ← hu, DFA.h_append_singleton],
          by simp; omega⟩)
  obtain ⟨u, hu⟩ := M.reachable s
  obtain ⟨u', hu', hl⟩ := hD u.length ⟨u, hu, le_rfl⟩
  exact ⟨u', hu', by simpa [Set.ncard_univ, Nat.card_eq_fintype_card] using hl⟩

/-! ## Propagation within `k` steps -/

variable (M : DFA A S) (F : S → S → Prop)

/-- The cells marked within `k` propagation steps: the initially marked cells at every depth,
and one more step per application of the marking rule. -/
inductive MarkedWithin : ℕ → S → S → Prop
  | initial {k : ℕ} {i j : S} : InitiallyMarked M F i j → MarkedWithin k i j
  | propagate {k : ℕ} {i j : S} {a : A} :
      MarkedWithin k i j → ¬ F (M.step i a) (M.step j a) →
        MarkedWithin (k + 1) (M.step i a) (M.step j a)

variable {M F}

theorem MarkedWithin.not_target {k : ℕ} {i j : S} (h : MarkedWithin M F k i j) : ¬ F i j := by
  cases h with
  | initial h => exact h.1
  | propagate _ h => exact h

theorem MarkedWithin.succ {k : ℕ} {i j : S} (h : MarkedWithin M F k i j) :
    MarkedWithin M F (k + 1) i j := by
  induction h with
  | initial h => exact .initial h
  | propagate _ h ih => exact .propagate ih h

/-- If depth `k + 1` adds nothing to depth `k`, depth `k + 2` adds nothing to depth `k + 1`. -/
theorem MarkedWithin.stable {k : ℕ}
    (hstop : ∀ i j, MarkedWithin M F (k + 1) i j → MarkedWithin M F k i j) {i j : S}
    (h : MarkedWithin M F (k + 2) i j) : MarkedWithin M F (k + 1) i j := by
  cases h with
  | initial h => exact .initial h
  | propagate h' h => exact .propagate (hstop _ _ h') h

/-- Every propagation starts at an initially bad cell, so depth `0` is nonempty. -/
theorem MarkedWithin.exists_zero {k : ℕ} {i j : S} (h : MarkedWithin M F k i j) :
    ∃ i' j', MarkedWithin M F 0 i' j' := by
  induction h with
  | initial h => exact ⟨_, _, .initial h⟩
  | propagate _ _ ih => exact ih

theorem Marked.exists_within {i j : S} (h : Marked M F i j) : ∃ k, MarkedWithin M F k i j := by
  induction h with
  | initial h => exact ⟨0, .initial h⟩
  | propagate _ h ih =>
    obtain ⟨k, hk⟩ := ih
    exact ⟨k + 1, .propagate hk h⟩

/-- **Short propagation paths.** A cell marked within some number of steps is marked within
`b - 1` steps, where `b = |S² ∖ F|`. -/
theorem markedWithin_bound [Finite S] {k : ℕ} {i j : S}
    (h : MarkedWithin M F k i j) :
    MarkedWithin M F ({p : S × S | ¬ F p.1 p.2}.ncard - 1) i j := by
  obtain ⟨i', j', h0⟩ := h.exists_zero
  exact layers_stabilize {p : S × S | ¬ F p.1 p.2} (fun k => {p | MarkedWithin M F k p.1 p.2})
    (fun _ _ hp => MarkedWithin.succ hp) (fun _ _ hp => MarkedWithin.not_target hp)
    ⟨(i', j'), h0⟩
    (fun _ hstop p hp => MarkedWithin.stable (fun i j h => hstop (a := (i, j)) h) (i := p.1) (j := p.2) hp) k
    (show (i, j) ∈ {p : S × S | MarkedWithin M F k p.1 p.2} from h)

/-- **The witness grows by one letter per propagation step.** A cell marked within `k` steps
contains a move that `F` does not cover with both words of length at most `n + k`: the initial
witness has length at most `n - 1` (boundary) or `n` (mismatched letters). -/
theorem MarkedWithin.exists_short [Fintype S] {k : ℕ} {i j : S}
    (h : MarkedWithin M F k i j) :
    ∃ u v, M.h u = i ∧ M.h v = j ∧ ¬ Accepted M F u v ∧
      u.length ≤ Fintype.card S + k ∧ v.length ≤ Fintype.card S + k := by
  induction h with
  | @initial k i j h =>
    obtain ⟨hF, hi | hj | ⟨k', l, a, b, hab, rfl, rfl⟩⟩ := h
    · subst hi
      obtain ⟨v, hv, hl⟩ := exists_short_representative M j
      refine ⟨[], v, rfl, hv, fun hc => hF ?_, by simp, by omega⟩
      have := (accepted_nil_left M F v).mp hc
      rwa [hv] at this
    · subst hj
      obtain ⟨u, hu, hl⟩ := exists_short_representative M i
      refine ⟨u, [], hu, rfl, fun hc => hF ?_, by omega, by simp⟩
      have := (accepted_nil_right M F u).mp hc
      rwa [hu] at this
    · obtain ⟨x, hx, hlx⟩ := exists_short_representative M k'
      obtain ⟨y, hy, hly⟩ := exists_short_representative M l
      have hpos : 0 < Fintype.card S := Fintype.card_pos_iff.mpr ⟨M.initial⟩
      refine ⟨x ++ [a], y ++ [b], by rw [DFA.h_append_singleton, hx],
        by rw [DFA.h_append_singleton, hy], fun hc => ?_, by simp; omega, by simp; omega⟩
      rcases (accepted_append_iff M F x y a b).mp hc with hF' | ⟨hab', _⟩
      · exact hF (by rwa [hx, hy] at hF')
      · exact hab hab'
  | @propagate k i j a _ hF ih =>
    obtain ⟨u, v, hu, hv, hn, hlu, hlv⟩ := ih
    refine ⟨u ++ [a], v ++ [a], by rw [DFA.h_append_singleton, hu],
      by rw [DFA.h_append_singleton, hv], fun hc => ?_, by simp; omega, by simp; omega⟩
    rcases (accepted_append_iff M F u v a a).mp hc with hF' | ⟨_, hc'⟩
    · exact hF (by rwa [hu, hv] at hF')
    · exact hn hc'

/-! ## The bound -/

/-- **Short counterexamples** (Proposition 12). Let `n = |S|` and `b = |S² ∖ F|`. If
`𝓡_E ⊈ 𝓡_F`, there is a counterexample `(u, v)`: directly accepted by `E` (so in `𝓡_E`), not in
`𝓡_F`, with `max(|u|, |v|) ≤ n + b - 1`. -/
theorem short_counterexample [Fintype S] (M : DFA A S) (E F : S → S → Prop)
    (h : ¬ Accepted M E ≤ Accepted M F) :
    ∃ u v, E (M.h u) (M.h v) ∧ ¬ Accepted M F u v ∧
      max u.length v.length ≤ Fintype.card S + Nat.card {p : S × S // ¬ F p.1 p.2} - 1 := by
  simp only [Pi.le_def, le_Prop_eq, not_forall] at h
  obtain ⟨u, v, ⟨x, y, w, rfl, rfl, hxy⟩, hn⟩ := h
  -- remove the preserved suffix `w`
  have hn' : ¬ Accepted M F x y := fun hc => hn (accepted_suffix hc w)
  obtain ⟨k, hk⟩ := (marked_of_not_accepted M F hn').exists_within
  have hb := markedWithin_bound hk
  obtain ⟨u', v', hu', hv', hc, hlu, hlv⟩ := hb.exists_short
  have hcard : Nat.card {p : S × S // ¬ F p.1 p.2} = {p : S × S | ¬ F p.1 p.2}.ncard :=
    (Nat.card_coe_set_eq _)
  -- `b ≥ 1`: the source cell lies outside `F`
  have hpos : 0 < {p : S × S | ¬ F p.1 p.2}.ncard :=
    (Set.ncard_pos (Set.toFinite _)).mpr ⟨(M.h x, M.h y), hk.not_target⟩
  refine ⟨u', v', by rw [hu', hv']; exact hxy, hc, ?_⟩
  rw [hcard]
  omega

/-- The second inequality of the proposition: `n + b - 1 ≤ n² + n - 1`. -/
theorem short_counterexample_sq [Fintype S] (M : DFA A S) (E F : S → S → Prop)
    (h : ¬ Accepted M E ≤ Accepted M F) :
    ∃ u v, E (M.h u) (M.h v) ∧ ¬ Accepted M F u v ∧
      max u.length v.length ≤ Fintype.card S ^ 2 + Fintype.card S - 1 := by
  obtain ⟨u, v, he, hn, hl⟩ := short_counterexample M E F h
  refine ⟨u, v, he, hn, hl.trans ?_⟩
  have : Nat.card {p : S × S // ¬ F p.1 p.2} ≤ Fintype.card S ^ 2 := by
    calc Nat.card {p : S × S // ¬ F p.1 p.2} ≤ Nat.card (S × S) := Finite.card_subtype_le _
      _ = Fintype.card S ^ 2 := by rw [Nat.card_eq_fintype_card, Fintype.card_prod, sq]
  omega

/-- **Proposition 12 (short counterexamples).** Let `n = |S|` and `b = |S² ∖ F|`. If
`𝓡_E ⊈ 𝓡_F`, there is a counterexample `(u, v)`, directly accepted by `E` (so in `𝓡_E`) and not
in `𝓡_F`, with `max(|u|, |v|) ≤ n + b - 1 ≤ n² + n - 1`. -/
theorem short_counterexamples [Fintype S] (M : DFA A S) (E F : S → S → Prop)
    (h : ¬ Accepted M E ≤ Accepted M F) :
    ∃ u v, E (M.h u) (M.h v) ∧ ¬ Accepted M F u v ∧
      max u.length v.length ≤
        Fintype.card S + Nat.card {p : S × S // ¬ F p.1 p.2} - 1 ∧
      Fintype.card S + Nat.card {p : S × S // ¬ F p.1 p.2} - 1 ≤
        Fintype.card S ^ 2 + Fintype.card S - 1 := by
  obtain ⟨u, v, he, hn, hl⟩ := short_counterexample M E F h
  refine ⟨u, v, he, hn, hl, ?_⟩
  have : Nat.card {p : S × S // ¬ F p.1 p.2} ≤ Fintype.card S ^ 2 := by
    calc Nat.card {p : S × S // ¬ F p.1 p.2} ≤ Nat.card (S × S) := Finite.card_subtype_le _
      _ = Fintype.card S ^ 2 := by rw [Nat.card_eq_fintype_card, Fintype.card_prod, sq]
  omega

end Stackat
