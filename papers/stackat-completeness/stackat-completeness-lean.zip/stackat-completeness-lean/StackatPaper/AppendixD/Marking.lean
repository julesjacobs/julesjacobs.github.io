import StackatPaper.Section3.TargetTable
import Mathlib.Data.Set.Card
import Mathlib.Data.Finite.Card

/-!
# Appendix D.1: Computing the Good Cells

Fix the shared reachable DFA `M` and the target table `F`. The complement `B` of the good table
is computed by marking cells:

* the initial marking `Z_F` (`InitiallyMarked`): the cells outside `F` with an initial
  coordinate or of the form `(δ(i,a), δ(j,b))` with `a ≠ b`;
* the marked cells `B` (`Marked`): the least set containing `Z_F` and closed under the marking
  rule (18) `(i,j) ∈ B, (δ(i,a), δ(j,a)) ∉ F ⟹ (δ(i,a), δ(j,a)) ∈ B` (`Marked.propagate`);
* the marking stops after at most `|S|²` insertions of previously unmarked cells, in any order
  (`MarkingRun.length_le_sq`), and then has marked exactly `B` (`MarkingRun.terminates`,
  `MarkingRun.mem_iff_marked`); the three together are `marking_runs`;
* every marked cell contains a pair outside `𝓡_F` (`marked_not_good`);
* `B` is exactly the complement of `G` (`marked_iff_not_good`), and `𝓡_E ⊆ 𝓡_F` iff
  `E ∩ B = ∅` (`inclusion_iff_disjoint`); both together are `marked_complement_and_inclusion`.
-/

namespace Stackat

variable {A S : Type*} (M : DFA A S) (F : S → S → Prop)

/-- `Z_F`: the cells outside `F` that have an initial coordinate or have the form
`(δ(k,a), δ(l,b))` with `a ≠ b`. -/
def InitiallyMarked (i j : S) : Prop :=
  ¬ F i j ∧ (i = M.initial ∨ j = M.initial ∨
    ∃ k l a b, a ≠ b ∧ M.step k a = i ∧ M.step l b = j)

/-- The marked cells `B`: the initial marking, closed under the marking rule (18). -/
inductive Marked : S → S → Prop
  | initial {i j : S} : InitiallyMarked M F i j → Marked i j
  | propagate {i j : S} {a : A} : Marked i j → ¬ F (M.step i a) (M.step j a) →
      Marked (M.step i a) (M.step j a)

variable {M F}

/-- A marked cell lies outside `F`. -/
theorem Marked.not_target {i j : S} (h : Marked M F i j) : ¬ F i j := by
  cases h with
  | initial h => exact h.1
  | propagate _ h => exact h

/-- **Every marked cell contains a pair outside `𝓡_F`**: at an initial coordinate the empty word
and a word reaching the other state; at a mismatched-letter cell `(ua, vb)`; along a propagation
step, the pair extended by the common letter. -/
theorem marked_not_good {i j : S} (h : Marked M F i j) :
    ∃ u ∈ M.L i, ∃ v ∈ M.L j, ¬ Accepted M F u v := by
  induction h with
  | @initial i j h =>
    obtain ⟨hF, hi | hj | ⟨k, l, a, b, hab, rfl, rfl⟩⟩ := h
    · subst hi
      obtain ⟨v, hv⟩ := M.L_nonempty j
      refine ⟨[], rfl, v, hv, fun hc => hF ?_⟩
      simpa [DFA.mem_L.mp hv] using (accepted_nil_left M F v).mp hc
    · subst hj
      obtain ⟨u, hu⟩ := M.L_nonempty i
      refine ⟨u, hu, [], rfl, fun hc => hF ?_⟩
      simpa [DFA.mem_L.mp hu] using (accepted_nil_right M F u).mp hc
    · obtain ⟨x, hx⟩ := M.L_nonempty k
      obtain ⟨y, hy⟩ := M.L_nonempty l
      rw [DFA.mem_L] at hx hy
      refine ⟨x ++ [a], by simp [hx], y ++ [b], by simp [hy], fun hc => ?_⟩
      rcases (accepted_append_iff M F x y a b).mp hc with hF' | ⟨hab', _⟩
      · exact hF (by rwa [hx, hy] at hF')
      · exact hab hab'
  | @propagate i j a _ hF ih =>
    obtain ⟨u, hu, v, hv, hn⟩ := ih
    rw [DFA.mem_L] at hu hv
    refine ⟨u ++ [a], by simp [hu], v ++ [a], by simp [hv], fun hc => ?_⟩
    rcases (accepted_append_iff M F u v a a).mp hc with hF' | ⟨_, hc'⟩
    · exact hF (by rwa [hu, hv] at hF')
    · exact hn hc'

variable (M F)

/-- The unmarked cells satisfy the certificate conditions: each condition is a marking rule read
backwards. -/
theorem unmarked_certificate : CertificateConditions M F (fun i j => ¬ Marked M F i j) where
  boundary_left := fun _ ⟨hn, hF⟩ => hn (.initial ⟨hF, Or.inl rfl⟩)
  boundary_right := fun _ ⟨hn, hF⟩ => hn (.initial ⟨hF, Or.inr (Or.inl rfl)⟩)
  mismatch := fun i j a b hab ⟨hn, hF⟩ =>
    hn (.initial ⟨hF, Or.inr (Or.inr ⟨i, j, a, b, hab, rfl, rfl⟩)⟩)
  matching := fun _ _ _ ⟨hn, hF⟩ hm => hn (.propagate hm hF)

/-- **The marked cells are exactly the cells that are not good**: `B` is the complement of `G`. -/
theorem marked_iff_not_good (i j : S) : Marked M F i j ↔ ¬ Good M F i j := by
  constructor
  · intro hm hg
    obtain ⟨u, hu, v, hv, hn⟩ := marked_not_good hm
    exact hn (hg u hu v hv)
  · intro hg
    by_contra hm
    exact hg (le_good_of_certificate M F (unmarked_certificate M F) i j hm)

/-- A pair outside `𝓡_F` lies in a marked cell. -/
theorem marked_of_not_accepted {u v : List A} (h : ¬ Accepted M F u v) :
    Marked M F (M.h u) (M.h v) :=
  (marked_iff_not_good M F _ _).mpr fun hg => h (hg u rfl v rfl)

/-- **Inclusion is `E ∩ B = ∅`.** -/
theorem inclusion_iff_disjoint (E : S → S → Prop) :
    Accepted M E ≤ Accepted M F ↔ E ⊓ Marked M F = ⊥ := by
  rw [certificate_iff]
  constructor
  · rintro ⟨G, hE, -, hG⟩
    funext i j
    refine propext ⟨fun ⟨he, hm⟩ => ?_, False.elim⟩
    exact (marked_iff_not_good M F i j).mp hm (le_good_of_certificate M F hG i j (hE i j he))
  · intro h
    refine ⟨Good M F, fun i j he => ?_, target_le_good M F, good_certificate M F⟩
    by_contra hg
    have := congrFun (congrFun h i) j
    exact this.mp ⟨he, (marked_iff_not_good M F i j).mpr hg⟩

/-- **Appendix D.1.** `B` is exactly the complement of `G`, and `𝓡_E ⊆ 𝓡_F` iff `E ∩ B = ∅`. -/
theorem marked_complement_and_inclusion (E : S → S → Prop) :
    (∀ i j, Marked M F i j ↔ ¬ Good M F i j) ∧
      (Accepted M E ≤ Accepted M F ↔ E ⊓ Marked M F = ⊥) :=
  ⟨marked_iff_not_good M F, inclusion_iff_disjoint M F E⟩

/-! ## The cost of the marking -/

/-- A cell the marking may insert into the marked set `B`: previously unmarked, and either
initially marked or the conclusion of rule (18) from a cell of `B`. -/
def CanInsert (B : Set (S × S)) (c : S × S) : Prop :=
  c ∉ B ∧ (InitiallyMarked M F c.1 c.2 ∨
    ∃ p ∈ B, ∃ a, c = (M.step p.1 a, M.step p.2 a) ∧ ¬ F c.1 c.2)

/-- A run of the marking: `MarkingRun B k` says that `k` insertions of previously unmarked
cells, in some order, produce the marked set `B`. -/
inductive MarkingRun : Set (S × S) → ℕ → Prop
  | nil : MarkingRun ∅ 0
  | insert {B : Set (S × S)} {k : ℕ} {c : S × S} :
      MarkingRun B k → CanInsert M F B c → MarkingRun (insert c B) (k + 1)

/-- The marking stops when no unmarked cell can be added. -/
def Stuck (B : Set (S × S)) : Prop := ∀ c, ¬ CanInsert M F B c

variable {M F}

theorem MarkingRun.sub_marked {B : Set (S × S)} {k : ℕ} (h : MarkingRun M F B k) :
    ∀ c ∈ B, Marked M F c.1 c.2 := by
  induction h with
  | nil => intro c hc; exact hc.elim
  | @insert B k c _ hc ih =>
    intro d hd
    rcases hd with rfl | hd
    · rcases hc.2 with h0 | ⟨p, hp, a, rfl, hF⟩
      · exact .initial h0
      · exact .propagate (ih p hp) hF
    · exact ih d hd

theorem MarkingRun.ncard_eq [Finite S] {B : Set (S × S)} {k : ℕ} (h : MarkingRun M F B k) :
    B.ncard = k := by
  induction h with
  | nil => simp
  | insert _ hc ih => rw [Set.ncard_insert_of_notMem hc.1 (Set.toFinite _), ih]

/-- At most `|S² ∖ F|` insertions. -/
theorem MarkingRun.length_le_outside [Finite S] {B : Set (S × S)} {k : ℕ}
    (h : MarkingRun M F B k) : k ≤ {p : S × S | ¬ F p.1 p.2}.ncard := by
  rw [← h.ncard_eq]
  exact Set.ncard_le_ncard (fun c hc => (h.sub_marked c hc).not_target) (Set.toFinite _)

/-- **At most `|S|²` insertions of previously unmarked cells**, in any order. -/
theorem MarkingRun.length_le_sq [Fintype S] {B : Set (S × S)} {k : ℕ} (h : MarkingRun M F B k) :
    k ≤ Fintype.card S ^ 2 := by
  have h1 := h.length_le_outside
  have h2 : {p : S × S | ¬ F p.1 p.2}.ncard ≤ Fintype.card S ^ 2 := by
    calc {p : S × S | ¬ F p.1 p.2}.ncard ≤ (Set.univ : Set (S × S)).ncard :=
          Set.ncard_le_ncard (Set.subset_univ _) (Set.toFinite _)
      _ = Fintype.card S ^ 2 := by
        rw [Set.ncard_univ, Nat.card_eq_fintype_card, Fintype.card_prod, sq]
  omega

/-- The marking terminates: some run reaches a marked set to which no cell can be added. (The
proof extends the given run, but the statement does not record that.) -/
theorem MarkingRun.terminates [Finite S] {B : Set (S × S)} {k : ℕ} (h : MarkingRun M F B k) :
    ∃ B' k', MarkingRun M F B' k' ∧ Stuck M F B' := by
  classical
  suffices ∀ n, ∀ B k, MarkingRun M F B k → {p : S × S | ¬ F p.1 p.2}.ncard - k = n →
      ∃ B' k', MarkingRun M F B' k' ∧ Stuck M F B' from this _ B k h rfl
  intro n
  induction n using Nat.strong_induction_on with
  | _ n ih =>
    intro B k hB hn
    by_cases hs : Stuck M F B
    · exact ⟨B, k, hB, hs⟩
    · simp only [Stuck, not_forall, not_not] at hs
      obtain ⟨c, hc⟩ := hs
      have hB' := hB.insert hc
      have hle := hB'.length_le_outside
      exact ih _ (by omega) _ _ hB' rfl

/-- When the marking stops, it has marked exactly the cells of `B`. -/
theorem MarkingRun.mem_iff_marked {B : Set (S × S)} {k : ℕ} (h : MarkingRun M F B k)
    (hs : Stuck M F B) (i j : S) : (i, j) ∈ B ↔ Marked M F i j := by
  constructor
  · exact h.sub_marked (i, j)
  · intro hm
    induction hm with
    | @initial i j h0 =>
      by_contra hb
      exact hs _ ⟨hb, Or.inl h0⟩
    | @propagate i j a _ hF ih =>
      by_contra hb
      exact hs _ ⟨hb, Or.inr ⟨(i, j), ih, a, rfl, hF⟩⟩

/-- **The cost of the marking** (Appendix D.1). Every run of the marking, in any order, makes at
most `|S|²` insertions of previously unmarked cells; some run stops, with no unmarked cell left
to add; and a stopped run has marked exactly the cells of `B`. -/
theorem marking_runs [Fintype S] :
    (∀ B k, MarkingRun M F B k → k ≤ Fintype.card S ^ 2) ∧
      (∃ B k, MarkingRun M F B k ∧ Stuck M F B) ∧
      ∀ B k, MarkingRun M F B k → Stuck M F B →
        ∀ i j, (i, j) ∈ B ↔ Marked M F i j :=
  ⟨fun _ _ h => h.length_le_sq, MarkingRun.nil.terminates, fun _ _ h hs => h.mem_iff_marked hs⟩

end Stackat
