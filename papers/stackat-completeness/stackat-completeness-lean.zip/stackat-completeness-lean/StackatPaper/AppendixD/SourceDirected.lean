import StackatPaper.AppendixD.Counterexample
import StackatPaper.Section6.Executable.FiniteTable

/-! ## Proposition 11: the source-directed residual search -/

namespace Stackat

section SourceDirected

variable {A S : Type*} (M : DFA A S) (E F : S → S → Prop)

/-- `C_min`: the least set containing `E ∖ F` and closed under matching predecessors outside `F`:
`(δ(i,a), δ(j,a)) ∈ C_min`, `(i,j) ∉ F ⟹ (i,j) ∈ C_min`. -/
inductive CMin : S → S → Prop
  | source {i j : S} : E i j → ¬ F i j → CMin i j
  | pred {i j : S} {a : A} : CMin (M.step i a) (M.step j a) → ¬ F i j → CMin i j

variable {M E F}

theorem CMin.not_target {i j : S} (h : CMin M E F i j) : ¬ F i j := by
  cases h <;> assumption

/-- **Every certificate for these fixed tables contains `C_min`**: a table `G ≥ E` satisfying
the certificate conditions. -/
theorem certificate_contains_cmin {G : S → S → Prop} (hE : E ≤ G)
    (hG : CertificateConditions M F G) : CMin M E F ≤ G := by
  intro i j h
  induction h with
  | source he _ => exact hE _ _ he
  | pred h' _ ih => exact (hG.step ih h'.not_target).2

/-- **If `C_min ∩ Z_F = ∅`, then `G = F ∪ C_min` is a certificate**: `G ≥ E, F` and `G`
satisfies the certificate conditions. -/
theorem source_directed_certificate (h : CMin M E F ⊓ InitiallyMarked M F = ⊥) :
    E ≤ F ⊔ CMin M E F ∧ F ≤ F ⊔ CMin M E F ∧ CertificateConditions M F (F ⊔ CMin M E F) := by
  classical
  have hz : ∀ i j, CMin M E F i j → ¬ InitiallyMarked M F i j := fun i j hc hz =>
    (congrFun (congrFun h i) j).mp ⟨hc, hz⟩
  refine ⟨fun i j he => ?_, fun _ _ => Or.inl, CertificateConditions.of_step M F ?_ ?_ ?_⟩
  · by_cases hf : F i j
    · exact Or.inl hf
    · exact Or.inr (.source he hf)
  · rintro j (hf | hc)
    · exact hf
    · by_contra hF; exact hz _ _ hc ⟨hF, Or.inl rfl⟩
  · rintro i (hf | hc)
    · exact hf
    · by_contra hF; exact hz _ _ hc ⟨hF, Or.inr (Or.inl rfl)⟩
  · intro i j a b hg hF
    have hc := hg.resolve_left hF
    by_cases hab : a = b
    · subst hab
      refine ⟨rfl, ?_⟩
      by_cases hf : F i j
      · exact Or.inl hf
      · exact Or.inr (.pred hc hf)
    · exact absurd ⟨hF, Or.inr (Or.inr ⟨i, j, a, b, hab, rfl, rfl⟩)⟩ (hz _ _ hc)

/-- **Proposition 11.** `𝓡_E ⊆ 𝓡_F` iff `C_min ∩ Z_F = ∅`. -/
theorem source_directed :
    Accepted M E ≤ Accepted M F ↔ CMin M E F ⊓ InitiallyMarked M F = ⊥ := by
  constructor
  · intro hEF
    funext i j
    refine propext ⟨fun ⟨hc, hs⟩ => ?_, False.elim⟩
    have hg : Good M F i j :=
      certificate_contains_cmin (source_le_good M F hEF) (good_certificate M F) i j hc
    exact (marked_iff_not_good M F i j).mp (.initial hs) hg
  · intro h
    obtain ⟨hE, hF, hG⟩ := source_directed_certificate h
    exact (certificate_iff M F E).mpr ⟨_, hE, hF, hG⟩

variable (M E F) in
/-- **Proposition 11 (source-directed residual search).** `𝓡_E ⊆ 𝓡_F` iff `C_min ∩ Z_F = ∅`; in
that case `G = F ∪ C_min` is a certificate; and every certificate for these fixed tables
contains `C_min`. -/
theorem source_directed_search :
    (Accepted M E ≤ Accepted M F ↔ CMin M E F ⊓ InitiallyMarked M F = ⊥) ∧
      (CMin M E F ⊓ InitiallyMarked M F = ⊥ →
        E ≤ F ⊔ CMin M E F ∧ F ≤ F ⊔ CMin M E F ∧
          CertificateConditions M F (F ⊔ CMin M E F)) ∧
      ∀ G : S → S → Prop, E ≤ G → F ≤ G → CertificateConditions M F G →
        CMin M E F ≤ G :=
  ⟨source_directed, source_directed_certificate, fun _ hE _ hG => certificate_contains_cmin hE hG⟩

end SourceDirected

end Stackat

namespace Stackat.Executable.SourceDirected
open BadCells (Direct)
variable {A S : Type} [FinEnum A] [FinEnum S]
variable (M : DFA A S) (F E : S → S → Bool)

class Prepared where
  incoming : Table S (fun _ => List (A × S))
  correct : ∀ i j a, (a,i) ∈ incoming.get j ↔ M.step i a = j

@[noinline, nospecialize] opaque prepare : Prepared M :=
  let steps := Table.ofFn fun (i,a) => M.step i a
  { incoming := Table.ofFn fun j => (FinEnum.toList A).flatMap fun a =>
      ((FinEnum.toList S).filter fun i => steps.get (i,a) == j).map fun i => (a, i)
    correct := by intros; simp [steps] }

variable [Prepared M]

abbrev incoming := (inferInstance : Prepared M).incoming

omit [FinEnum A] in
@[simp] theorem mem_incoming (i j : S) (a : A) :
    (a, i) ∈ (incoming M).get j ↔ M.step i a = j :=
  Prepared.correct i j a

/-- Edges point from a residual obligation to its matching predecessors. -/
def predecessors (p : S × S) : List (A × (S × S)) :=
  ((incoming M).get p.1).flatMap fun (a, i) =>
    (((incoming M).get p.2).filter fun (b, j) => a == b && !F i j).map
      fun (_, j) => (a, (i, j))

@[simp] theorem mem_predecessors (p : S × S) (a : A) (i j : S) :
    (a, (i,j)) ∈ predecessors M F p ↔
      M.step i a = p.1 ∧ M.step j a = p.2 ∧ ¬ Direct F i j := by
  simp [predecessors, Direct]

def roots : List (S × S) :=
  (FinEnum.toList (S × S)).filter fun (i,j) => E i j && !F i j

@[simp] theorem mem_roots (p : S × S) :
    p ∈ roots F E ↔ Direct E p.1 p.2 ∧ ¬ Direct F p.1 p.2 := by
  simp [roots, Direct]

def support : Finset (S × S) :=
  reachable (fun p => (predecessors M F p).map Prod.snd) (roots F E)

theorem support_closed {p : S × S} (hp : p ∈ support M F E)
    {a : A} {i j : S} (hi : M.step i a = p.1) (hj : M.step j a = p.2)
    (hf : ¬ Direct F i j) : (i,j) ∈ support M F E := by
  obtain ⟨r, hr, hp⟩ := (mem_reachable_iff _ _ _).mp hp
  apply (mem_reachable_iff _ _ _).mpr
  exact ⟨r, hr, hp.tail (List.mem_map.mpr ⟨(a,(i,j)),
    (mem_predecessors M F p a i j).mpr ⟨hi,hj,hf⟩, rfl⟩)⟩

theorem support_source {p : S × S} (he : Direct E p.1 p.2)
    (hf : ¬ Direct F p.1 p.2) : p ∈ support M F E :=
  (mem_reachable_iff _ _ _).mpr ⟨p, (mem_roots F E p).mpr ⟨he,hf⟩, .refl⟩

/-- The labels already have the order in which they are appended to a seed witness. -/
def traces : List ((S × S) × List A) :=
  exploreTraces (predecessors M F) ∅ ((roots F E).map fun p => (p, []))

theorem traces_states : ((traces M F E).map Prod.fst).toFinset = support M F E := by
  have h := exploreTraces_states (predecessors M F) ∅ ((roots F E).map fun p => (p, []))
  simpa [traces, support, reachable, List.map_map, Function.comp_def] using h

variable (repr : S → List A)

/-- At most one witness is needed at a forbidden cell. -/
def seed (p : S × S) : Option (List A × List A) :=
  if p.1 = M.initial then some ([], repr p.2)
  else if p.2 = M.initial then some (repr p.1, [])
  else
    (((incoming M).get p.1).findSome? fun (a,i) =>
      (((incoming M).get p.2).find? fun (b,_) => a != b).map
        fun (b,j) => (repr i ++ [a], repr j ++ [b]))

theorem seed_none {p : S × S} (h : seed M repr p = none) :
    p.1 ≠ M.initial ∧ p.2 ≠ M.initial ∧
      ∀ i j a b, M.step i a = p.1 → M.step j b = p.2 → a = b := by
  simp only [seed] at h
  split at h
  · contradiction
  · rename_i hi
    split at h
    · contradiction
    · rename_i hj
      refine ⟨hi,hj,?_⟩
      intro i j a b hai hbj
      have hh := (List.findSome?_eq_none_iff.mp h) (a,i) ((mem_incoming M i _ a).mpr hai)
      have hb := List.find?_eq_none.mp (Option.map_eq_none_iff.mp hh)
        (b,j) ((mem_incoming M j _ b).mpr hbj)
      simpa using hb

variable (repr_ok : ∀ i, M.h (repr i) = i)
include repr_ok

theorem seed_sound {p : S × S} {u v : List A} (hf : ¬ Direct F p.1 p.2)
    (h : seed M repr p = some (u,v)) :
    M.h u = p.1 ∧ M.h v = p.2 ∧ ¬ Accepted M (Direct F) u v := by
  unfold seed at h
  split at h
  · rename_i hi
    cases h
    simpa [hi, repr_ok, accepted_nil_left] using hf
  · split at h
    · rename_i hj
      cases h
      simpa [hj, repr_ok, accepted_nil_right] using hf
    · obtain ⟨⟨a,i⟩, hi, h⟩ := List.exists_of_findSome?_eq_some h
      obtain ⟨⟨b,j⟩, hj, h⟩ := Option.map_eq_some_iff.mp h
      have hab : a ≠ b := by simpa using List.find?_some hj
      have hi := (mem_incoming M i _ a).mp hi
      have hj := (mem_incoming M j _ b).mp (List.mem_of_find?_eq_some hj)
      cases h
      simpa [repr_ok, hi, hj, accepted_append_iff, hab] using hf

omit repr_ok in
def Valid (p : (S × S) × List A) : Prop :=
  ¬ Direct F p.1.1 p.1.2 ∧
    ∀ u v, M.h u = p.1.1 → M.h v = p.1.2 →
      ¬ Accepted M (Direct F) u v →
      Accepted M (Direct E) (u ++ p.2) (v ++ p.2) ∧
      ¬ Accepted M (Direct F) (u ++ p.2) (v ++ p.2)

omit repr_ok in
theorem traces_valid : ∀ p ∈ traces M F E, Valid M F E p := by
  refine exploreTraces_preserves (predecessors M F) (Valid M F E) ?_ ∅
    ((roots F E).map fun p => (p, [])) ?_
  · intro p hp q hq
    obtain ⟨⟨a,⟨i,j⟩⟩, ha, rfl⟩ := List.mem_map.mp hq
    obtain ⟨hi,hj,hf⟩ := (mem_predecessors M F p.1 a i j).mp ha
    refine ⟨hf, ?_⟩
    intro u v hu hv hn
    have hfail : ¬ Accepted M (Direct F) (u ++ [a]) (v ++ [a]) := by
      rw [accepted_append_iff]
      simpa [hu,hv,hi,hj] using And.intro hp.1 hn
    have h := hp.2 (u ++ [a]) (v ++ [a]) (by simp [hu,hi]) (by simp [hv,hj]) hfail
    simpa [List.append_assoc] using h
  · intro p hp
    obtain ⟨p, hroot, rfl⟩ := List.mem_map.mp hp
    obtain ⟨he,hf⟩ := (mem_roots F E p).mp hroot
    refine ⟨hf, ?_⟩
    intro u v hu hv hn
    simpa using And.intro (DirectlyAccepted.accepted (M := M) (D := Direct E)
      (by simpa [DirectlyAccepted, hu, hv] using he)) hn

omit repr_ok in
def counterexample : Option (List A × List A) :=
  (traces M F E).findSome? fun p =>
    (seed M repr p.1).map fun (u,v) => (u ++ p.2, v ++ p.2)

theorem counterexample_sound {u v : List A} (h : counterexample M F E repr = some (u,v)) :
    Accepted M (Direct E) u v ∧ ¬ Accepted M (Direct F) u v := by
  obtain ⟨p, hp, h⟩ := List.exists_of_findSome?_eq_some h
  obtain ⟨⟨x,y⟩, hs, h⟩ := Option.map_eq_some_iff.mp h
  have hv := traces_valid M F E p hp
  obtain ⟨hx,hy,hn⟩ := seed_sound M F repr repr_ok hv.1 hs
  cases h
  exact hv.2 x y hx hy hn

theorem counterexample_none_iff : counterexample M F E repr = none ↔
    ∀ u v, Accepted M (Direct E) u v → Accepted M (Direct F) u v := by
  constructor
  · intro h
    have hn : ∀ p ∈ support M F E, seed M repr p = none := by
      intro p hp
      rw [← traces_states M F E] at hp
      obtain ⟨q,hq,rfl⟩ := List.mem_map.mp (List.mem_toFinset.mp hp)
      exact Option.map_eq_none_iff.mp ((List.findSome?_eq_none_iff.mp h) q hq)
    apply (certificate_iff M (Direct F) (Direct E)).mpr
    refine ⟨fun i j => Direct F i j ∨ (i,j) ∈ support M F E, ?_, fun _ _ => Or.inl, ?_⟩
    · intro i j he
      by_cases hf : Direct F i j
      · exact Or.inl hf
      · exact Or.inr (support_source M F E he hf)
    · refine CertificateConditions.of_step M _ ?_ ?_ ?_
      · intro j hg
        rcases hg with hf | hc
        · exact hf
        · exact False.elim ((seed_none M repr (hn _ hc)).1 rfl)
      · intro i hg
        rcases hg with hf | hc
        · exact hf
        · exact False.elim ((seed_none M repr (hn _ hc)).2.1 rfl)
      · intro i j a b hg hf
        have hc := hg.resolve_left hf
        have hab := (seed_none M repr (hn _ hc)).2.2 i j a b rfl rfl
        refine ⟨hab, ?_⟩
        by_cases hf' : Direct F i j
        · exact Or.inl hf'
        · exact Or.inr (support_closed M F E hc rfl (by rw [hab]) hf')
  · intro h
    cases hc : counterexample M F E repr with
    | none => rfl
    | some p =>
      obtain ⟨he,hf⟩ := counterexample_sound M F E repr repr_ok hc
      exact False.elim (hf (h p.1 p.2 he))

/-- **The source-directed inclusion test** (Appendix D.2): every returned pair is a
counterexample (witness soundness), and none is returned exactly when `𝓡_E ⊆ 𝓡_F`
(completeness). -/
theorem counterexample_correct :
    (∀ u v, counterexample M F E repr = some (u, v) →
      Accepted M (Direct E) u v ∧ ¬ Accepted M (Direct F) u v) ∧
      (counterexample M F E repr = none ↔
        ∀ u v, Accepted M (Direct E) u v → Accepted M (Direct F) u v) :=
  ⟨fun _ _ h => counterexample_sound M F E repr repr_ok h, counterexample_none_iff M F E repr repr_ok⟩

end Stackat.Executable.SourceDirected
