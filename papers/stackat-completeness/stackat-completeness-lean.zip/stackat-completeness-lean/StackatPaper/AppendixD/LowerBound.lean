import StackatPaper.AppendixD.Marking
import StackatPaper.AppendixD.LengthBounds
import Mathlib.Data.ZMod.Basic
import Mathlib.Tactic.Ring
import Mathlib.Data.Fintype.Option

/-!
# Counterexample length: quadratic is necessary

The family after Proposition 12 of the completeness paper (Appendix
"Certificate Computation and Extended Example", subsection "Counterexample Length"). Over the
alphabet `{a, b}`, for coprime `r, s ≥ 2`: initial state `o`, a state `β` for the word `b`, a dead
state `d`, and cycles `U_0 … U_{r-1}` and `V_0 … V_{s-1}`, with transitions

| state | `a`                | `b` |
|-------|--------------------|-----|
| `o`   | `V_1`              | `β` |
| `β`   | `U_1`              | `d` |
| `U_i` | `U_{i+1 mod r}`    | `d` |
| `V_j` | `V_{j+1 mod s}`    | `d` |
| `d`   | `d`                | `d` |

The cycle indices are `ZMod r` and `ZMod s`. With `E = {(U_{r-1}, V_{s-1})}` and
`S² ∖ F = {(β, o)} ∪ {(U_i, V_j)}`:

* `card_state`: `n = r + s + 3` states;
* `not_accepted_iff`: `F` fails to cover exactly the pairs `(b a^t, a^t)`;
* `card_state_reachable`, `classes`: the states, all reachable, and the classes of `U_i` and `V_j`;
* `quadratic_lower_bound`: inclusion fails, `(b a^{rs-1}, a^{rs-1})` is a counterexample of maximum
  length `r s`, and every counterexample has maximum length at least `r s`;
* `consecutive_and_two_three`: consecutive `r`, `s` give `r s = Ω(n²)`, and the witness for
  `r = 2`, `s = 3`;
* `Stackat.length_bounds`: the upper bound of Proposition 12 and the quadratic lower bound together.
-/

namespace Stackat.LowerBound



/-- The alphabet `{a, b}`. -/
inductive Letter
  | a
  | b

/-- The states `o`, `β`, `d`, `U_i` (`i : ZMod r`) and `V_j` (`j : ZMod s`). -/
inductive State (r s : ℕ)
  | o
  | β
  | d
  | U (i : ZMod r)
  | V (j : ZMod s)

variable {r s : ℕ}

/-- The transition table of the paper. -/
def step : State r s → Letter → State r s
  | .o, .a => .V 1
  | .o, .b => .β
  | .β, .a => .U 1
  | .β, .b => .d
  | .U i, .a => .U (i + 1)
  | .U _, .b => .d
  | .V j, .a => .V (j + 1)
  | .V _, .b => .d
  | .d, _ => .d

/-- `a^m`. -/
abbrev aw (m : ℕ) : List Letter := List.replicate m .a

theorem foldl_U (i : ZMod r) (m : ℕ) :
    (aw m).foldl (step (s := s)) (.U i) = .U (i + m) := by
  induction m generalizing i with
  | zero => simp
  | succ m ih =>
    rw [aw, List.replicate_succ, List.foldl_cons]
    change (aw m).foldl step (.U (i + 1)) = _
    rw [ih]
    push_cast
    ring_nf

theorem foldl_V (j : ZMod s) (m : ℕ) :
    (aw m).foldl (step (r := r)) (.V j) = .V (j + m) := by
  induction m generalizing j with
  | zero => simp
  | succ m ih =>
    rw [aw, List.replicate_succ, List.foldl_cons]
    change (aw m).foldl step (.V (j + 1)) = _
    rw [ih]
    push_cast
    ring_nf

theorem foldl_b_aw (m : ℕ) (hm : 1 ≤ m) :
    (Letter.b :: aw m).foldl (step (r := r) (s := s)) .o = .U m := by
  obtain ⟨m, rfl⟩ := Nat.exists_eq_add_of_le' hm
  rw [List.foldl_cons, aw, List.replicate_succ, List.foldl_cons]
  change (aw m).foldl step (.U 1) = _
  rw [foldl_U]
  push_cast
  ring_nf

theorem foldl_aw (k : ℕ) (hk : 1 ≤ k) :
    (aw k).foldl (step (r := r) (s := s)) .o = .V k := by
  obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le' hk
  rw [aw, List.replicate_succ, List.foldl_cons]
  change (aw k).foldl step (.V 1) = _
  rw [foldl_V]
  push_cast
  ring_nf

variable (r s) [NeZero r] [NeZero s]

/-- The automaton of the paper; all `r + s + 3` states are reachable. -/
def aut : DFA Letter (State r s) where
  initial := .o
  step := step
  reachable
    | .o => ⟨[], rfl⟩
    | .β => ⟨[.b], rfl⟩
    | .d => ⟨[.b, .b], rfl⟩
    | .U i => ⟨.b :: aw (i.val + r), by
        rw [foldl_b_aw _ (by have := NeZero.pos r; omega)]
        push_cast
        rw [ZMod.natCast_self, add_zero, ZMod.natCast_zmod_val]⟩
    | .V j => ⟨aw (j.val + s), by
        rw [foldl_aw _ (by have := NeZero.pos s; omega)]
        push_cast
        rw [ZMod.natCast_self, add_zero, ZMod.natCast_zmod_val]⟩

/-- The source table `E = {(U_{r-1}, V_{s-1})}`. -/
def E : State r s → State r s → Prop :=
  fun p q => p = .U ((r - 1 : ℕ) : ZMod r) ∧ q = .V ((s - 1 : ℕ) : ZMod s)

/-- The cells outside the target: `S² ∖ F = {(β, o)} ∪ {(U_i, V_j)}`. -/
def Outside : State r s → State r s → Prop :=
  fun p q => (p = .β ∧ q = .o) ∨ ∃ i j, p = .U i ∧ q = .V j

/-- The target table `F`, the complement of `Outside`. -/
def F : State r s → State r s → Prop := fun p q => ¬ Outside r s p q

/-! ## The counts `n = r + s + 3` and `b = r s + 1` -/

/-- The states as `Option (Option (Option (ZMod r ⊕ ZMod s)))`. -/
def stateEquiv : State r s ≃ Option (Option (Option (ZMod r ⊕ ZMod s))) where
  toFun
    | .o => none
    | .β => some none
    | .d => some (some none)
    | .U i => some (some (some (.inl i)))
    | .V j => some (some (some (.inr j)))
  invFun
    | none => .o
    | some none => .β
    | some (some none) => .d
    | some (some (some (.inl i))) => .U i
    | some (some (some (.inr j))) => .V j
  left_inv := by rintro (_ | _ | _ | _ | _) <;> rfl
  right_inv := by rintro (_ | (_ | (_ | (i | j)))) <;> rfl

instance : Fintype (State r s) := Fintype.ofEquiv _ (stateEquiv r s).symm

/-- `n = r + s + 3`. -/
theorem card_state : Fintype.card (State r s) = r + s + 3 := by
  rw [Fintype.card_congr (stateEquiv r s)]
  simp only [Fintype.card_option, Fintype.card_sum, ZMod.card]

/-- **Appendix D.3.** The automaton of the family has `n = r + s + 3` states, all reachable. -/
theorem card_state_reachable :
    Fintype.card (State r s) = r + s + 3 ∧
      ∀ i : State r s, ∃ u, (aut r s).h u = i :=
  ⟨card_state r s, (aut r s).reachable⟩

/-! ## The words reaching each state -/

theorem run_b_aw (m : ℕ) (hm : 1 ≤ m) : (aut r s).h (.b :: aw m) = .U m :=
  foldl_b_aw m hm

theorem run_aw (k : ℕ) (hk : 1 ≤ k) : (aut r s).h (aw k) = .V k :=
  foldl_aw k hk

/-- Every word is `ε` (in `o`), `b` (in `β`), `b a^m` with `m ≥ 1` (in `U_m`), `a^k` with `k ≥ 1`
(in `V_k`), or in `d`. -/
theorem run_cases (x : List Letter) :
    (x = [] ∧ (aut r s).h x = .o) ∨ (x = [.b] ∧ (aut r s).h x = .β) ∨
      (∃ m, 1 ≤ m ∧ x = .b :: aw m ∧ (aut r s).h x = .U m) ∨
      (∃ k, 1 ≤ k ∧ x = aw k ∧ (aut r s).h x = .V k) ∨ (aut r s).h x = .d := by
  induction x using List.reverseRecOn with
  | nil => exact Or.inl ⟨rfl, rfl⟩
  | append_singleton x c ih =>
    rw [DFA.h_append_singleton]
    change _ ∨ _ ∨ _ ∨ _ ∨ step ((aut r s).h x) c = .d
    rcases ih with ⟨rfl, h⟩ | ⟨rfl, h⟩ | ⟨m, hm, rfl, h⟩ | ⟨k, hk, rfl, h⟩ | h <;>
      rw [show (aut r s).step = step from rfl, h] <;> cases c
    · exact Or.inr (Or.inr (Or.inr (Or.inl ⟨1, le_rfl, rfl, by simp [step]⟩)))
    · exact Or.inr (Or.inl ⟨rfl, rfl⟩)
    · exact Or.inr (Or.inr (Or.inl ⟨1, le_rfl, rfl, by simp [step]⟩))
    · exact Or.inr (Or.inr (Or.inr (Or.inr rfl)))
    · refine Or.inr (Or.inr (Or.inl ⟨m + 1, by omega, ?_, by simp [step]⟩))
      simp [aw, List.replicate_succ']
    · exact Or.inr (Or.inr (Or.inr (Or.inr rfl)))
    · refine Or.inr (Or.inr (Or.inr (Or.inl ⟨k + 1, by omega, ?_, by simp [step]⟩)))
      simp [aw, List.replicate_succ']
    · exact Or.inr (Or.inr (Or.inr (Or.inr rfl)))
    · exact Or.inr (Or.inr (Or.inr (Or.inr rfl)))
    · exact Or.inr (Or.inr (Or.inr (Or.inr rfl)))

theorem eq_of_run_eq_o {x : List Letter} (h : (aut r s).h x = .o) : x = [] := by
  rcases run_cases r s x with ⟨hx, _⟩ | ⟨_, h'⟩ | ⟨_, _, _, h'⟩ | ⟨_, _, _, h'⟩ | h' <;>
    first | exact hx | (rw [h'] at h; cases h)

theorem eq_of_run_eq_β {x : List Letter} (h : (aut r s).h x = .β) : x = [.b] := by
  rcases run_cases r s x with ⟨_, h'⟩ | ⟨hx, _⟩ | ⟨_, _, _, h'⟩ | ⟨_, _, _, h'⟩ | h' <;>
    first | exact hx | (rw [h'] at h; cases h)

theorem eq_of_run_eq_U {x : List Letter} {i : ZMod r} (h : (aut r s).h x = .U i) :
    ∃ m, 1 ≤ m ∧ x = .b :: aw m ∧ (m : ZMod r) = i := by
  rcases run_cases r s x with ⟨_, h'⟩ | ⟨_, h'⟩ | ⟨m, hm, hx, h'⟩ | ⟨_, _, _, h'⟩ | h' <;>
    rw [h'] at h <;> cases h
  exact ⟨m, hm, hx, rfl⟩

theorem eq_of_run_eq_V {x : List Letter} {j : ZMod s} (h : (aut r s).h x = .V j) :
    ∃ k, 1 ≤ k ∧ x = aw k ∧ (k : ZMod s) = j := by
  rcases run_cases r s x with ⟨_, h'⟩ | ⟨_, h'⟩ | ⟨_, _, _, h'⟩ | ⟨k, hk, hx, h'⟩ | h' <;>
    rw [h'] at h <;> cases h
  exact ⟨k, hk, hx, rfl⟩

/-- **Appendix D.3.** The class of `U_i` consists of the words `b a^m` with `m ≥ 1` and
`m ≡ i (mod r)`, and the class of `V_j` of the words `a^k` with `k ≥ 1` and `k ≡ j (mod s)`. -/
theorem classes :
    (∀ (x : List Letter) (i : ZMod r),
      (aut r s).h x = .U i ↔ ∃ m, 1 ≤ m ∧ x = .b :: aw m ∧ (m : ZMod r) = i) ∧
      ∀ (x : List Letter) (j : ZMod s),
        (aut r s).h x = .V j ↔ ∃ k, 1 ≤ k ∧ x = aw k ∧ (k : ZMod s) = j := by
  refine ⟨fun x i => ⟨eq_of_run_eq_U r s, ?_⟩, fun x j => ⟨eq_of_run_eq_V r s, ?_⟩⟩
  · rintro ⟨m, hm, rfl, rfl⟩; exact run_b_aw r s m hm
  · rintro ⟨k, hk, rfl, rfl⟩; exact run_aw r s k hk

/-! ## What the target rejects -/

/-- **The target rejects exactly the pairs `(b a^t, a^t)`**, `t ≥ 0`. -/
theorem not_accepted_iff (u v : List Letter) :
    ¬ Accepted (aut r s) (F r s) u v ↔ ∃ t, u = .b :: aw t ∧ v = aw t := by
  constructor
  · intro hn
    have hout : Outside r s ((aut r s).h u) ((aut r s).h v) := by
      by_contra ho
      exact hn (DirectlyAccepted.accepted ho)
    rcases hout with ⟨hu, hv⟩ | ⟨i, j, hu, hv⟩
    · exact ⟨0, eq_of_run_eq_β r s hu, eq_of_run_eq_o r s hv⟩
    · obtain ⟨m, hm, rfl, -⟩ := eq_of_run_eq_U r s hu
      obtain ⟨k, hk, rfl, -⟩ := eq_of_run_eq_V r s hv
      rcases lt_trichotomy m k with hmk | rfl | hmk
      · -- `(b a^m, a^k)` slides to `(b, a^{k-m})`, a cell of `F`
        refine absurd ⟨[.b], aw (k - m), aw m, ?_, ?_, ?_⟩ hn
        · simp
        · rw [aw, aw, aw, ← List.replicate_add, Nat.sub_add_cancel hmk.le]
        · rw [show (aut r s).h [.b] = .β from rfl, run_aw r s _ (by omega)]
          rintro (⟨_, h⟩ | ⟨_, _, h, _⟩) <;> cases h
      · exact ⟨m, rfl, rfl⟩
      · -- `(b a^m, a^k)` slides to `(b a^{m-k}, ε)`, a cell of `F`
        refine absurd ⟨.b :: aw (m - k), [], aw k, ?_, ?_, ?_⟩ hn
        · rw [List.cons_append, aw, aw, aw, ← List.replicate_add, Nat.sub_add_cancel hmk.le]
        · simp
        · rw [run_b_aw r s _ (by omega), DFA.h_nil]
          rintro (⟨h, _⟩ | ⟨_, _, _, h⟩) <;> cases h
  · rintro ⟨t, rfl, rfl⟩
    induction t with
    | zero =>
      rw [aw, List.replicate_zero, accepted_nil_right]
      exact fun hF => hF (Or.inl ⟨rfl, rfl⟩)
    | succ t ih =>
      rw [aw, List.replicate_succ', ← List.cons_append, accepted_append_iff]
      rintro (hF | ⟨_, hc⟩)
      · have h1 := run_b_aw r s (t + 1) (by omega)
        have h2 := run_aw r s (t + 1) (by omega)
        simp only [aw] at h1 h2
        rw [← DFA.h_append_singleton, ← DFA.h_append_singleton] at hF
        rw [List.cons_append, ← List.replicate_succ', h1, h2] at hF
        exact hF (Or.inr ⟨_, _, rfl, rfl⟩)
      · exact ih hc

/-! ## The lower bound -/

theorem dvd_of_cast_eq {n t : ℕ} (hn : 1 ≤ n) (h : (t : ZMod n) = ((n - 1 : ℕ) : ZMod n)) :
    n ∣ t + 1 := by
  rw [← ZMod.natCast_eq_zero_iff, Nat.cast_add_one, h, ← Nat.cast_add_one, Nat.sub_add_cancel hn,
    ZMod.natCast_self]

/-- **Quadratic is necessary.** For coprime `r, s ≥ 2`: `(b a^{rs-1}, a^{rs-1})` is a move of `E`
(directly, in the cell `(U_{r-1}, V_{s-1})`) that `F` does not cover, of maximum length `r s`; and
every move of `E` that `F` does not cover has maximum length at least `r s`. -/
theorem quadratic_lower_bound (hr : 2 ≤ r) (hs : 2 ≤ s)
    (hrs : Nat.Coprime r s) :
    (E r s ((aut r s).h (.b :: aw (r * s - 1))) ((aut r s).h (aw (r * s - 1))) ∧
      ¬ Accepted (aut r s) (F r s) (.b :: aw (r * s - 1)) (aw (r * s - 1)) ∧
      max (.b :: aw (r * s - 1)).length (aw (r * s - 1)).length = r * s) ∧
    ∀ u v, Accepted (aut r s) (E r s) u v → ¬ Accepted (aut r s) (F r s) u v →
      r * s ≤ max u.length v.length := by
  have hrs4 : 4 ≤ r * s := Nat.mul_le_mul hr hs
  refine ⟨⟨⟨?_, ?_⟩, (not_accepted_iff r s _ _).mpr ⟨_, rfl, rfl⟩, ?_⟩, ?_⟩
  · rw [run_b_aw r s _ (by omega)]
    congr 1
    rw [ZMod.natCast_eq_natCast_iff' _ _ r]
    have : r * s - 1 = (r - 1) + r * (s - 1) := by
      rw [Nat.mul_sub_one]
      have : r ≤ r * s := Nat.le_mul_of_pos_right r (by omega)
      omega
    rw [this, Nat.add_mul_mod_self_left]
  · rw [run_aw r s _ (by omega)]
    congr 1
    rw [ZMod.natCast_eq_natCast_iff' _ _ s]
    have : r * s - 1 = (s - 1) + s * (r - 1) := by
      rw [Nat.mul_sub_one, Nat.mul_comm s r]
      have : s ≤ r * s := Nat.le_mul_of_pos_left s (by omega)
      omega
    rw [this, Nat.add_mul_mod_self_left]
  · simp only [aw, List.length_cons, List.length_replicate]
    omega
  · rintro u v ⟨x, y, w, rfl, rfl, ⟨hx, hy⟩⟩ hn
    -- remove the preserved suffix `w`
    have hn' : ¬ Accepted (aut r s) (F r s) x y := fun hc => hn (accepted_suffix hc w)
    obtain ⟨t, rfl, rfl⟩ := (not_accepted_iff r s x y).mp hn'
    obtain ⟨m, -, hm, hmr⟩ := eq_of_run_eq_U r s hx
    obtain ⟨k, -, hk, hks⟩ := eq_of_run_eq_V r s hy
    have hmt : m = t := by simpa [aw] using (congrArg List.length hm).symm
    have hkt : k = t := by simpa [aw] using (congrArg List.length hk).symm
    rw [hmt] at hmr
    rw [hkt] at hks
    have hdvd : r * s ∣ t + 1 :=
      hrs.mul_dvd_of_dvd_of_dvd (dvd_of_cast_eq (by omega) hmr) (dvd_of_cast_eq (by omega) hks)
    have hle := Nat.le_of_dvd (by omega) hdvd
    simp only [List.length_append, List.length_cons, aw, List.length_replicate]
    omega

/-- For coprime `r, s ≥ 2` the inclusion fails, witnessed by `(b a^{rs-1}, a^{rs-1})`. -/
theorem inclusion_fails (hr : 2 ≤ r) (hs : 2 ≤ s) (hrs : Nat.Coprime r s) :
    ¬ Accepted (aut r s) (E r s) ≤ Accepted (aut r s) (F r s) := by
  obtain ⟨⟨he, hn, -⟩, -⟩ := quadratic_lower_bound r s hr hs hrs
  exact fun hle => hn (hle _ _ (DirectlyAccepted.accepted he))

/-- **Quadratic in the number of states.** With consecutive `r = k`, `s = k + 1` (`k ≥ 2`), the
automaton has `n = 2k + 4` states and every counterexample has maximum length `L ≥ k (k + 1)`, so
`(n - 4)² ≤ 4 L`. -/
theorem consecutive_lower_bound (k : ℕ) [NeZero k] (hk : 2 ≤ k) :
    Fintype.card (State k (k + 1)) = 2 * k + 4 ∧
    ∀ u v, Accepted (aut k (k + 1)) (E k (k + 1)) u v → ¬ Accepted (aut k (k + 1)) (F k (k + 1)) u v →
      (Fintype.card (State k (k + 1)) - 4) ^ 2 ≤ 4 * max u.length v.length := by
  have hcard : Fintype.card (State k (k + 1)) = 2 * k + 4 := by rw [card_state]; ring
  refine ⟨hcard, fun u v he hn => ?_⟩
  have := (quadratic_lower_bound k (k + 1) hk (by omega)
    (Nat.coprime_self_add_right.mpr (Nat.coprime_one_right k))).2 u v he hn
  rw [hcard, show 2 * k + 4 - 4 = 2 * k by omega]
  have hsq : k ^ 2 ≤ k * (k + 1) := by rw [sq]; exact Nat.mul_le_mul_left k (Nat.le_succ k)
  calc (2 * k) ^ 2 = 4 * k ^ 2 := by ring
    _ ≤ 4 * (k * (k + 1)) := Nat.mul_le_mul_left 4 hsq
    _ ≤ 4 * max u.length v.length := Nat.mul_le_mul_left 4 this

/-- **For `r = 2`, `s = 3`, the shortest witness is `(ba⁵, a⁵)`**: it is a counterexample, and every
counterexample has maximum length at least `6`. -/
theorem shortest_witness_two_three :
    (E 2 3 ((aut 2 3).h (.b :: aw 5)) ((aut 2 3).h (aw 5)) ∧
      ¬ Accepted (aut 2 3) (F 2 3) (.b :: aw 5) (aw 5)) ∧
    ∀ u v, Accepted (aut 2 3) (E 2 3) u v → ¬ Accepted (aut 2 3) (F 2 3) u v →
      6 ≤ max u.length v.length := by
  obtain ⟨⟨he, hn, -⟩, hmin⟩ := quadratic_lower_bound 2 3 le_rfl (by omega) (by decide)
  exact ⟨⟨he, hn⟩, hmin⟩

/-- **Appendix D.3.** Consecutive `r = k`, `s = k + 1` give `r s = Ω(n²)`: the automaton has
`n = 2k + 4` states, the inclusion fails, and every counterexample has maximum length `L` with
`(n - 4)² ≤ 4 L`; for
`r = 2`, `s = 3`, `(b a⁵, a⁵)` is a counterexample, and every counterexample has maximum length at
least `6`. -/
theorem consecutive_and_two_three :
    (∀ (k : ℕ) [NeZero k], 2 ≤ k →
      Fintype.card (State k (k + 1)) = 2 * k + 4 ∧
      ¬ Accepted (aut k (k + 1)) (E k (k + 1)) ≤
        Accepted (aut k (k + 1)) (F k (k + 1)) ∧
      ∀ u v, Accepted (aut k (k + 1)) (E k (k + 1)) u v →
        ¬ Accepted (aut k (k + 1)) (F k (k + 1)) u v →
        (Fintype.card (State k (k + 1)) - 4) ^ 2 ≤ 4 * max u.length v.length) ∧
    (E 2 3 ((aut 2 3).h (.b :: aw 5)) ((aut 2 3).h (aw 5)) ∧
      ¬ Accepted (aut 2 3) (F 2 3) (.b :: aw 5) (aw 5)) ∧
    ∀ u v, Accepted (aut 2 3) (E 2 3) u v → ¬ Accepted (aut 2 3) (F 2 3) u v →
      6 ≤ max u.length v.length :=
  ⟨fun k _ hk => ⟨(consecutive_lower_bound k hk).1,
    inclusion_fails k (k + 1) hk (by omega) (Nat.coprime_self_add_right.mpr (Nat.coprime_one_right k)),
    (consecutive_lower_bound k hk).2⟩, shortest_witness_two_three⟩

end Stackat.LowerBound

namespace Stackat

/-- **The two length bounds** (Section 4, Appendix D.3). Failed inclusion has a witness `(u, v)`
with `max(|u|, |v|) ≤ n² + n - 1` for an `n`-state shared DFA, and quadratic dependence is
necessary: for the family with `r = k`, `s = k + 1`, the inclusion fails and every counterexample
has maximum length `L` with `(n - 4)² ≤ 4 L`. -/
theorem length_bounds :
    (∀ {A S : Type} [Fintype S] (M : DFA A S) (E F : S → S → Prop),
      ¬ Accepted M E ≤ Accepted M F →
      ∃ u v, E (M.h u) (M.h v) ∧ ¬ Accepted M F u v ∧
        max u.length v.length ≤ Fintype.card S ^ 2 + Fintype.card S - 1) ∧
    ∀ (k : ℕ) [NeZero k], 2 ≤ k →
      Fintype.card (LowerBound.State k (k + 1)) = 2 * k + 4 ∧
      ¬ Accepted (LowerBound.aut k (k + 1)) (LowerBound.E k (k + 1)) ≤
        Accepted (LowerBound.aut k (k + 1)) (LowerBound.F k (k + 1)) ∧
      ∀ u v, Accepted (LowerBound.aut k (k + 1)) (LowerBound.E k (k + 1)) u v →
        ¬ Accepted (LowerBound.aut k (k + 1)) (LowerBound.F k (k + 1)) u v →
        (Fintype.card (LowerBound.State k (k + 1)) - 4) ^ 2 ≤
          4 * max u.length v.length :=
  ⟨fun M E F h => short_counterexample_sq M E F h,
    fun k _ hk => (LowerBound.consecutive_and_two_three.1 k hk)⟩

end Stackat
