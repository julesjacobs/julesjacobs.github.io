import StackatPaper.AppendixD.BadCells
import StackatPaper.Section6.Executable.Traces
import StackatPaper.Section3.TargetTable

/-!
Appendix D.1: witness recovery from the marked cells (`Executable.BadCells.counterexample`); every
returned pair is a counterexample (`counterexample_sound`), and none is returned iff `𝓡_E ⊆ 𝓡_F`
(`counterexample_none_iff`).
-/

namespace Stackat.Executable.BadCells

variable {A S : Type} [FinEnum A] [FinEnum S]
variable (M : DFA A S) (F : S → S → Bool)

abbrev WitnessPath (A : Type) := (List A × List A) × List A

def words (w : WitnessPath A) : List A × List A :=
  (w.1.1 ++ w.2.reverse, w.1.2 ++ w.2.reverse)

def extend (a : A) (w : WitnessPath A) : WitnessPath A := (w.1, a :: w.2)

omit [FinEnum A] [FinEnum S] in
@[simp] theorem words_extend (a : A) (w : WitnessPath A) :
    words (extend a w) = ((words w).1 ++ [a], (words w).2 ++ [a]) := by
  simp [words, extend, List.reverse_cons, List.append_assoc]

variable (repr : S → List A)

def boundaryRoots : List ((S × S) × WitnessPath A) :=
  (FinEnum.toList S).flatMap fun i =>
    [((M.initial, i), (([], repr i), [])), ((i, M.initial), ((repr i, []), []))]

def mismatchRoots : List ((S × S) × WitnessPath A) :=
  (FinEnum.toList S).flatMap fun i =>
    (FinEnum.toList S).flatMap fun j =>
      (FinEnum.toList A).flatMap fun a =>
        ((FinEnum.toList A).filter fun b => a != b).map fun b =>
          ((M.step i a, M.step j b), ((repr i ++ [a], repr j ++ [b]), []))

def roots : List ((S × S) × WitnessPath A) :=
  (boundaryRoots M repr ++ mismatchRoots M repr).filter fun p => !F p.1.1 p.1.2

def nextWith (p : (S × S) × WitnessPath A) : List ((S × S) × WitnessPath A) :=
  ((FinEnum.toList A).map fun a =>
    ((M.step p.1.1 a, M.step p.1.2 a), extend a p.2)).filter
      fun q => !F q.1.1 q.1.2

omit [FinEnum S] in
theorem nextWith_states (p : (S × S) × WitnessPath A) :
    (nextWith M F p).map Prod.fst = next M F p.1 := by
  simp [nextWith, next, List.filter_map, Function.comp_def, List.map_map]

theorem roots_states : (roots M F repr).map Prod.fst = seeds M F := by
  unfold roots
  trans (((boundaryRoots M repr ++ mismatchRoots M repr).map Prod.fst).filter
    fun q : S × S => !F q.1 q.2)
  · exact (List.filter_map (f := (Prod.fst : ((S × S) × WitnessPath A) → S × S))
      (p := fun q : S × S => !F q.1 q.2)).symm
  · simp only [List.map_append, boundaryRoots, mismatchRoots, List.map_flatMap,
      List.map_cons, List.map_nil, List.map_map]
    rfl

def traces : List ((S × S) × WitnessPath A) :=
  exploreWith (nextWith M F) ∅ (roots M F repr)

theorem traces_states : ((traces M F repr).map Prod.fst).toFinset = bad M F := by
  have h := exploreWith_states (nextWith M F) (next M F) (nextWith_states M F)
    ∅ (roots M F repr)
  simpa only [Finset.union_empty, roots_states, traces, bad, reachable] using h

omit [FinEnum A] [FinEnum S] in
def Valid (p : (S × S) × WitnessPath A) : Prop :=
  M.h (words p.2).1 = p.1.1 ∧ M.h (words p.2).2 = p.1.2 ∧
    ¬ Accepted M (Direct F) (words p.2).1 (words p.2).2

omit [FinEnum S] in
theorem nextWith_valid {p q : (S × S) × WitnessPath A}
    (hp : Valid M F p) (hq : q ∈ nextWith M F p) : Valid M F q := by
  simp only [nextWith, List.mem_filter, List.mem_map] at hq
  obtain ⟨⟨a, _, rfl⟩, hf⟩ := hq
  obtain ⟨hu, hv, hn⟩ := hp
  simp only [Valid, words_extend, DFA.h_append_singleton, hu, hv,
    true_and]
  rw [accepted_append_iff]
  simpa [Direct, hu, hv] using And.intro hf hn

variable (repr_ok : ∀ i, M.h (repr i) = i)
include repr_ok

theorem roots_valid : ∀ p ∈ roots M F repr, Valid M F p := by
  intro p hp
  simp only [roots, List.mem_filter, List.mem_append] at hp
  obtain ⟨hb | hm, hf⟩ := hp
  · obtain ⟨i, _, hp⟩ := List.mem_flatMap.mp hb
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hp
    rcases hp with rfl | rfl
    · simpa [Valid, words, repr_ok, accepted_nil_left, Direct] using hf
    · simpa [Valid, words, repr_ok, accepted_nil_right, Direct] using hf
  · obtain ⟨i, _, hm⟩ := List.mem_flatMap.mp hm
    obtain ⟨j, _, hm⟩ := List.mem_flatMap.mp hm
    obtain ⟨a, _, hm⟩ := List.mem_flatMap.mp hm
    obtain ⟨b, hb, rfl⟩ := List.mem_map.mp hm
    have hab : a ≠ b := by simpa using (List.mem_filter.mp hb).2
    simpa [Valid, words, repr_ok, accepted_append_iff, hab, Direct] using hf

theorem traces_valid : ∀ p ∈ traces M F repr, Valid M F p :=
  exploreWith_preserves (nextWith M F) (Valid M F)
    (fun _ h _ hq => nextWith_valid M F h hq) ∅ (roots M F repr)
      (roots_valid M F repr repr_ok)

def counterexample (E : S → S → Bool) : Option (List A × List A) :=
  ((traces M F repr).find? fun p => E p.1.1 p.1.2).map fun p => words p.2

theorem counterexample_sound (E : S → S → Bool) {u v : List A}
    (h : counterexample M F repr E = some (u, v)) :
    Accepted M (Direct E) u v ∧ ¬ Accepted M (Direct F) u v := by
  obtain ⟨p, hp, hw⟩ := Option.map_eq_some_iff.mp h
  have hm := List.mem_of_find?_eq_some hp
  have he := List.find?_some hp
  obtain ⟨hu, hv, hn⟩ := traces_valid M F repr repr_ok p hm
  cases hw
  refine ⟨DirectlyAccepted.accepted ?_, hn⟩
  change Direct E (M.h (words p.2).1) (M.h (words p.2).2)
  rw [hu, hv]
  exact he

theorem counterexample_none_iff (E : S → S → Bool) :
    counterexample M F repr E = none ↔
      ∀ u v, Accepted M (Direct E) u v → Accepted M (Direct F) u v := by
  constructor
  · intro h
    have hn := List.find?_eq_none.mp (Option.map_eq_none_iff.mp h)
    apply (certificate_iff M (Direct F) (Direct E)).mpr
    refine ⟨fun i j => (i, j) ∉ bad M F, ?_, (certificate M F).1, (certificate M F).2⟩
    intro i j he hb
    rw [← traces_states M F repr] at hb
    obtain ⟨p, hp, heq⟩ := List.mem_map.mp (List.mem_toFinset.mp hb)
    have hfalse := hn p hp
    rw [heq] at hfalse
    exact hfalse he
  · intro h
    cases hc : counterexample M F repr E with
    | none => rfl
    | some p =>
      obtain ⟨he, hf⟩ := counterexample_sound M F repr repr_ok E hc
      exact False.elim (hf (h p.1 p.2 he))

/-- **Witness recovery** (Appendix D.1): every pair recovered from the marked cells is a
counterexample, and none is recovered exactly when `𝓡_E ⊆ 𝓡_F`. -/
theorem counterexample_correct (E : S → S → Bool) :
    (∀ u v, counterexample M F repr E = some (u, v) →
      Accepted M (Direct E) u v ∧ ¬ Accepted M (Direct F) u v) ∧
      (counterexample M F repr E = none ↔
        ∀ u v, Accepted M (Direct E) u v → Accepted M (Direct F) u v) :=
  ⟨fun _ _ h => counterexample_sound M F repr repr_ok E h, counterexample_none_iff M F repr repr_ok E⟩

end Stackat.Executable.BadCells
