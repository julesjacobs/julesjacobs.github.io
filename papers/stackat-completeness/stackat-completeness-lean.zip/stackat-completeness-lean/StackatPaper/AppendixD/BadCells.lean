import StackatPaper.Section6.Executable.Reachability
import StackatPaper.AppendixD.Marking
import Mathlib.Data.FinEnum

/-!
# Appendix D.1: the executable marking

The executable module `BadCells` computes the marked cells `B` of `AppendixD/Marking.lean` as
finite reachability: the initial marking (`seeds`, `mem_seeds`), the marking rule (`next`,
`propagate`), and the marked set `bad`, which is `Marked` (`mem_bad_iff`). Its complement is the
good table (`good_iff`). The inclusion test `includes` is used by the executable tests.
-/

namespace Stackat.Executable.BadCells

variable {A S : Type} [FinEnum A] [FinEnum S]
variable (M : DFA A S) (F : S → S → Bool)

abbrev Direct (i j : S) : Prop := F i j = true

def boundaries : List (S × S) :=
  (FinEnum.toList S).flatMap fun i => [(M.initial, i), (i, M.initial)]

def mismatches : List (S × S) :=
  (FinEnum.toList S).flatMap fun i =>
    (FinEnum.toList S).flatMap fun j =>
      (FinEnum.toList A).flatMap fun a =>
        ((FinEnum.toList A).filter fun b => a != b).map fun b => (M.step i a, M.step j b)

def seeds : List (S × S) :=
  (boundaries M ++ mismatches M).filter fun p => !F p.1 p.2

omit [FinEnum A] in
@[simp] theorem mem_boundaries (i j : S) :
    (i, j) ∈ boundaries M ↔ i = M.initial ∨ j = M.initial := by
  simp [boundaries, Prod.mk.injEq, exists_or]

@[simp] theorem mem_mismatches (i j : S) :
    (i, j) ∈ mismatches M ↔ ∃ k l a b, a ≠ b ∧ M.step k a = i ∧ M.step l b = j := by
  simp [mismatches, Prod.mk.injEq]

/-- The executable initial marking is `Z_F`. -/
@[simp] theorem mem_seeds (i j : S) :
    (i, j) ∈ seeds M F ↔ InitiallyMarked M (Direct F) i j := by
  simp [seeds, Direct, InitiallyMarked]
  tauto

def next (p : S × S) : List (S × S) :=
  ((FinEnum.toList A).map fun a => (M.step p.1 a, M.step p.2 a)).filter
    fun q => !F q.1 q.2

omit [FinEnum S] in
@[simp] theorem mem_next (p q : S × S) :
    q ∈ next M F p ↔
      (∃ a, M.step p.1 a = q.1 ∧ M.step p.2 a = q.2) ∧ ¬ Direct F q.1 q.2 := by
  simp [next, Prod.ext_iff, Direct]

def bad : Finset (S × S) := reachable (next M F) (seeds M F)

theorem seed_bad {i j : S} (h : (i, j) ∈ seeds M F) : (i, j) ∈ bad M F :=
  (mem_reachable_iff _ _ _).mpr ⟨(i, j), h, .refl⟩

theorem propagate {p q : S × S} (hp : p ∈ bad M F) (hq : q ∈ next M F p) :
    q ∈ bad M F := by
  obtain ⟨r, hr, hp⟩ := (mem_reachable_iff _ _ _).mp hp
  exact (mem_reachable_iff _ _ _).mpr ⟨r, hr, hp.tail hq⟩

/-- The executable marked set is `B`. -/
theorem mem_bad_iff (i j : S) : (i, j) ∈ bad M F ↔ Marked M (Direct F) i j := by
  constructor
  · intro h
    apply explore_preserves (next M F) (fun p => Marked M (Direct F) p.1 p.2) _ ∅ (seeds M F)
        (by simp) _ (i, j) h
    · rintro p hp q hq
      obtain ⟨⟨a, h1, h2⟩, hf⟩ := (mem_next M F p q).mp hq
      obtain ⟨q1, q2⟩ := q
      simp only at h1 h2
      subst h1 h2
      exact .propagate hp hf
    · rintro ⟨i, j⟩ h
      exact .initial ((mem_seeds M F i j).mp h)
  · intro h
    induction h with
    | initial h => exact seed_bad M F ((mem_seeds M F _ _).mpr h)
    | propagate _ hf ih => exact propagate M F ih ((mem_next M F _ _).mpr ⟨⟨_, rfl, rfl⟩, hf⟩)

/-- The cells outside `bad` form a certificate. -/
theorem certificate :
    Direct F ≤ (fun i j => (i, j) ∉ bad M F) ∧
      CertificateConditions M (Direct F) (fun i j => (i, j) ∉ bad M F) := by
  have h : (fun i j => (i, j) ∉ bad M F) = fun i j => ¬ Marked M (Direct F) i j := by
    funext i j; rw [mem_bad_iff]
  rw [h]
  exact ⟨fun i j hf hm => hm.not_target hf, unmarked_certificate M (Direct F)⟩

/-- The computed bad cells are the complement of the good table. -/
theorem good_iff (i j : S) :
    Good M (Direct F) i j ↔ (i, j) ∉ bad M F := by
  rw [mem_bad_iff, marked_iff_not_good, not_not]

def includes (E : S → S → Bool) : Bool :=
  let d := bad M F
  (FinEnum.toList S).all fun i =>
    (FinEnum.toList S).all fun j => !E i j || decide ((i, j) ∉ d)

end Stackat.Executable.BadCells
