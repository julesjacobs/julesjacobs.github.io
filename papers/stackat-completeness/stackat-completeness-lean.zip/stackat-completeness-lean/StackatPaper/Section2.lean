import StackatPaper.Background.Relations

/-!
# Section 2: Stack Expressions and the Completeness Theorem

The syntax `Expr`, the semantics `R` (written `R e`), the derivation system `Derives`
(written `⊢ e ≈ f`, with `⊢ e ≤ f` for `⊢ e + f ≈ f`) and the statement of Theorem 1,
`SoundnessAndCompleteness`, are in `StackatPaper/Spec.lean`. This file has the semantic facts of
Section 2, the statements `Soundness`, `Completeness` and `InequationalCompleteness`, and soundness. Completeness is proved at the end of Section 3
(`StackatPaper/Section4/Derivation.lean`).

* `p_a q_a` restores every stack, `q_a p_a` exactly those beginning with `a`
  (`push_pop_and_pop_push_R`); `q_a p_b` replaces `a` by `b` (`pop_push_ne_R`);
* soundness: every derivable equation holds in the relational model (`soundness`);
* the two formulations of completeness defined in `Spec.lean` are equivalent
  (`completeness_iff_inequational`).
-/

namespace Stackat

open scoped Computability


section StackLaws

variable {A : Type} (a b : A)

/-- `p_a q_a` restores every stack. -/
theorem push_pop_denote (s t : List A) : R (.push a * .pop a) s t ↔ s = t := by
  simp [R]

/-- `q_a p_a` restores exactly the stacks beginning with `a`. -/
theorem pop_push_denote (s t : List A) :
    R (.pop a * .push a) s t ↔ s = t ∧ ∃ w, s = a :: w := by
  simp only [R]
  constructor
  · rintro ⟨m, rfl, rfl⟩; exact ⟨rfl, m, rfl⟩
  · rintro ⟨rfl, w, rfl⟩; exact ⟨w, rfl, rfl⟩

/-- **Section 2.** `p_a q_a` restores every stack, and `q_a p_a` restores exactly the stacks
beginning with `a`. -/
theorem push_pop_and_pop_push_R :
    (∀ s t : List A, R (.push a * .pop a) s t ↔ s = t) ∧
      ∀ s t : List A, R (.pop a * .push a) s t ↔ s = t ∧ ∃ w, s = a :: w :=
  ⟨push_pop_denote a, pop_push_denote a⟩

/-- `p_a q_b` fails for `a ≠ b`. -/
theorem push_pop_ne_denote {a b : A} (h : a ≠ b) (s t : List A) :
    ¬ R (.push a * .pop b) s t := by
  change ¬ ∃ m, m = a :: s ∧ m = b :: t
  rintro ⟨m, rfl, hm⟩
  exact h (List.cons.inj hm).1

/-- `q_a p_b` replaces the top symbol `a` by `b`. The paper states it for `a ≠ b`; it holds for
all `a`, `b`. -/
theorem pop_push_ne_R (s t : List A) :
    R (.pop a * .push b) s t ↔ ∃ w, s = a :: w ∧ t = b :: w :=
  Iff.rfl

end StackLaws

/-! ## Soundness -/

/-- The relational model satisfies the three stack schemes. -/
theorem Rel.holds (x : StackLaw) : x.Holds (Rel.push (A := A)) Rel.pop := by
  cases x with
  | push_pop => exact Rel.push_pop
  | push_pop_ne => exact fun _ _ h => Rel.push_pop_ne h
  | pop_push =>
    intro a s t ⟨m, hs, ht⟩
    exact hs.trans ht.symm

/-! ## The statements of soundness and of the two forms of completeness

`Spec.lean` states Theorem 1 as one proposition, `SoundnessAndCompleteness`. The development also
uses its parts: soundness over any alphabet, and completeness in the equation form and in the
inclusion form. -/

/-- Every derivable equation is valid in the relational semantics. -/
def Soundness : Prop :=
  ∀ {A : Type} {e f : Expr A}, (⊢ e ≈ f) → R e = R f

/-- Every equation valid on finite stacks over a finite alphabet is derivable. -/
def Completeness : Prop :=
  ∀ (A : Type) [Finite A] (e f : Expr A), R e = R f → ⊢ e ≈ f

/-- The stronger inclusion form of completeness. -/
def InequationalCompleteness : Prop :=
  ∀ (A : Type) [Finite A] (e f : Expr A), R e ≤ R f → ⊢ e ≤ f

/-- **Soundness** (Theorem 1, `⟸`): every derivable equation holds in the relational model,
over any alphabet. -/
theorem soundness : Soundness := by
  intro A e f h
  have he := (derives_iff.mp h).sound (fun x _ => Rel.holds x)
  rw [Rel.eval_denote, Rel.eval_denote] at he
  exact he

/-- Soundness, pointwise: a derivable equation relates the same pairs of stacks. -/
theorem soundness_iff {e f : Expr A} (h : ⊢ e ≈ f) (s t : List A) : R e s t ↔ R f s t := by
  rw [soundness h]

/-! ## The two formulations of completeness -/

theorem completeness_of_inequational (h : InequationalCompleteness) : Completeness := by
  intro A _ e f hef
  have he := h A e f hef.le
  have hf := h A f e hef.ge
  exact .trans (.symm hf) (.trans (.add_comm (e := f) (f := e)) he)

theorem inequational_of_completeness (h : Completeness) : InequationalCompleteness := by
  intro A _ e f hef
  exact h A (e + f) f
    (funext fun s => funext fun t => propext ⟨fun h' => h'.elim (hef s t) id, Or.inr⟩)

/-- The equation form and the inclusion form of completeness are equivalent. -/
theorem completeness_iff_inequational : Completeness ↔ InequationalCompleteness :=
  ⟨inequational_of_completeness, completeness_of_inequational⟩

end Stackat
