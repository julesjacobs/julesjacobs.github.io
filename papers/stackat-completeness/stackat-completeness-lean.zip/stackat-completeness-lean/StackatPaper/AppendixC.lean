import StackatPaper.Background.Relations

/-!
# Appendix C: Countermodels for Scheme Independence

* the reduced derivation system for an omitted scheme `x`: the Kleene algebra laws and the other
  two schemes, `⊢[(· ≠ x)] e ≈ f` (`DerivesWith (· ≠ x)`, `Background/FreeAlgebra.lean`);
* soundness: a Kleene algebra satisfying the retained schemes validates every reduced derivation
  (`DerivesWith.sound`), so a valid-looking equation that fails there is not derivable
  (`not_derivable_of_countermodel`);
* the three relational countermodels: all pushes and pops `0` on a singleton carrier
  (`push_pop_countermodel`), all `1` on a singleton carrier (`mismatch_countermodel`), and
  bit-tagged stacks (`pop_push_countermodel`); together, each omitted scheme fails in a model of
  KA and the retained schemes (`scheme_countermodels`);
* Proposition 10 (`scheme_independence`, from `push_pop_independent`, `mismatch_independent`,
  `pop_push_independent`).

No alphabet is assumed finite.
-/

namespace Stackat

open scoped Computability


namespace Independence

variable {A : Type}

/-- **Soundness gives nonderivability.** If a Kleene algebra satisfies the retained schemes and
`e`, `f` have different values there, `e = f` is not derivable in the reduced system. -/
theorem not_derivable_of_countermodel {K : Type*} [KleeneAlgebra K]
    {p q : A → K} {x : StackLaw} (hL : ∀ y : StackLaw, y ≠ x → y.Holds p q)
    {e f : Expr A} (hn : e.eval p q ≠ f.eval p q) : ⊬[(· ≠ x)] e ≈ f :=
  fun h => hn (h.sound hL)

/-! ## The three countermodels -/

/-- Every push and pop is `0`, on a singleton carrier. -/
def zeroOp (_ : A) : Rel Unit := 0

/-- Every push and pop is `1`, on a singleton carrier. -/
def oneOp (_ : A) : Rel Unit := 1

/-- `p_a` on bit-tagged stacks: push `(a, c)` for either bit `c`. -/
def bitPush (a : A) : Rel (List (A × Bool)) := fun s t => ∃ c, t = (a, c) :: s

/-- `q_a` on bit-tagged stacks: pop `(a, c)` for either bit `c`. -/
def bitPop (a : A) : Rel (List (A × Bool)) := fun s t => ∃ c, s = (a, c) :: t

/-- **The countermodel for matching cancellation.** With every push and pop `0` on a singleton
carrier, mismatch and partial identity hold, whereas `p_a q_a = 0 ≠ 1` for every symbol `a`. -/
theorem push_pop_countermodel :
    (∀ y : StackLaw, y ≠ .push_pop → y.Holds (zeroOp (A := A)) zeroOp) ∧
      ∀ a : A, zeroOp a * zeroOp a ≠ (1 : Rel Unit) := by
  refine ⟨fun y hy => ?_, fun a h => ?_⟩
  · cases y with
    | push_pop => exact (hy rfl).elim
    | push_pop_ne => exact fun _ _ _ => zero_mul _
    | pop_push => exact fun _ => by simp [zeroOp]
  · have h' := congrArg (fun r : Rel Unit => r () ()) h
    simp [zeroOp] at h'

/-- **The countermodel for mismatch.** With every push and pop `1` on a singleton carrier,
matching cancellation and partial identity hold, whereas `p_a q_b = 1 ≠ 0` for distinct `a`, `b`. -/
theorem mismatch_countermodel :
    (∀ y : StackLaw, y ≠ .push_pop_ne → y.Holds (oneOp (A := A)) oneOp) ∧
      ∀ a b : A, a ≠ b → oneOp a * oneOp b ≠ (0 : Rel Unit) := by
  refine ⟨fun y hy => ?_, fun a b _ h => ?_⟩
  · cases y with
    | push_pop => exact fun _ => one_mul _
    | push_pop_ne => exact (hy rfl).elim
    | pop_push => exact fun _ => by simp [oneOp]
  · have h' := congrArg (fun r : Rel Unit => r () ()) h
    simp [oneOp] at h'

/-- **The countermodel for partial identity.** On bit-tagged stacks, matching cancellation and
mismatch hold, whereas `q_a p_a` relates `(a,0)w` to `(a,1)w`, so `q_a p_a ≰ 1`. One symbol
suffices. -/
theorem pop_push_countermodel :
    (∀ y : StackLaw, y ≠ .pop_push → y.Holds (bitPush (A := A)) bitPop) ∧
      ∀ (a : A) (w : List (A × Bool)),
        (bitPop a * bitPush a) ((a, false) :: w) ((a, true) :: w) ∧
          ¬ (bitPop a * bitPush a ≤ 1) := by
  refine ⟨fun y hy => ?_, fun a w => ?_⟩
  · cases y with
    | push_pop =>
      intro a
      apply Rel.ext
      intro s t
      change (∃ m, (∃ c, m = (a, c) :: s) ∧ ∃ c, m = (a, c) :: t) ↔ s = t
      constructor
      · rintro ⟨m, ⟨c, rfl⟩, d, h⟩
        exact (List.cons.inj h).2
      · rintro rfl
        exact ⟨(a, false) :: s, ⟨false, rfl⟩, false, rfl⟩
    | push_pop_ne =>
      intro a b hab
      apply Rel.ext
      intro s t
      change (∃ m, (∃ c, m = (a, c) :: s) ∧ ∃ c, m = (b, c) :: t) ↔ False
      constructor
      · rintro ⟨m, ⟨c, rfl⟩, d, h⟩
        exact hab (congrArg Prod.fst (List.cons.inj h).1)
      · exact False.elim
    | pop_push => exact (hy rfl).elim
  · have hr : (bitPop a * bitPush a) ((a, false) :: w) ((a, true) :: w) :=
      ⟨w, ⟨false, rfl⟩, true, rfl⟩
    refine ⟨hr, fun h => ?_⟩
    have := h _ _ hr
    change (a, false) :: w = (a, true) :: w at this
    simp at this

/-- **Appendix C.** Each omitted scheme fails in a relational model of KA and the retained
schemes: matching cancellation and partial identity over a nonempty alphabet, mismatch over an
alphabet with at least two symbols. -/
theorem scheme_countermodels :
    (Nonempty A → ∃ (X : Type) (p q : A → Rel X),
      (∀ y : StackLaw, y ≠ .push_pop → y.Holds p q) ∧
        ¬ StackLaw.push_pop.Holds p q) ∧
    (Nontrivial A → ∃ (X : Type) (p q : A → Rel X),
      (∀ y : StackLaw, y ≠ .push_pop_ne → y.Holds p q) ∧
        ¬ StackLaw.push_pop_ne.Holds p q) ∧
    (Nonempty A → ∃ (X : Type) (p q : A → Rel X),
      (∀ y : StackLaw, y ≠ .pop_push → y.Holds p q) ∧
        ¬ StackLaw.pop_push.Holds p q) := by
  refine ⟨fun ⟨a⟩ => ⟨Unit, zeroOp, zeroOp, push_pop_countermodel.1,
      fun h => push_pop_countermodel.2 a (h a)⟩,
    fun _ => ?_, fun ⟨a⟩ => ⟨_, bitPush, bitPop, pop_push_countermodel.1,
      fun h => (pop_push_countermodel.2 a []).2 (h a)⟩⟩
  obtain ⟨a, b, hab⟩ := exists_pair_ne A
  exact ⟨Unit, oneOp, oneOp, mismatch_countermodel.1,
    fun h => mismatch_countermodel.2 a b hab (h a b hab)⟩

/-! ## Proposition 10 -/

/-- **Matching cancellation is independent** (Proposition 10): over a nonempty alphabet,
`p_a q_a = 1` does not follow from KA and the other two schemes. -/
theorem push_pop_independent [Nonempty A] :
    ¬ ∀ a : A, ⊢[(· ≠ .push_pop)] .push a * .pop a ≈ 1 := by
  intro h
  obtain ⟨a⟩ := ‹Nonempty A›
  exact not_derivable_of_countermodel (e := Expr.push a * Expr.pop a) (f := 1)
    push_pop_countermodel.1 (push_pop_countermodel.2 a) (h a)

/-- **Mismatch is independent** (Proposition 10): over an alphabet with at least two symbols,
`p_a q_b = 0` for `a ≠ b` does not follow from KA and the other two schemes. -/
theorem mismatch_independent [Nontrivial A] :
    ¬ ∀ a b : A, a ≠ b → ⊢[(· ≠ .push_pop_ne)] .push a * .pop b ≈ 0 := by
  intro h
  obtain ⟨a, b, hab⟩ := exists_pair_ne A
  exact not_derivable_of_countermodel (e := Expr.push a * Expr.pop b) (f := 0)
    mismatch_countermodel.1 (mismatch_countermodel.2 a b hab) (h a b hab)

/-- **Partial identity is independent** (Proposition 10): over a nonempty alphabet,
`q_a p_a ≤ 1` does not follow from KA and the other two schemes. -/
theorem pop_push_independent [Nonempty A] :
    ¬ ∀ a : A, ⊢[(· ≠ .pop_push)] .pop a * .push a ≤ 1 := by
  intro h
  obtain ⟨a⟩ := ‹Nonempty A›
  refine not_derivable_of_countermodel (e := Expr.pop a * Expr.push a + 1) (f := 1)
    pop_push_countermodel.1 (fun he => ?_) (h a)
  exact (pop_push_countermodel.2 a []).2 (add_eq_right_iff_le.mp he)

/-- **Proposition 10 (scheme independence).** For a nonempty alphabet, neither matching push–pop
cancellation nor the pop–push partial-identity scheme follows from KA and the other two schemes;
for an alphabet with at least two symbols, the mismatch scheme does not either. -/
theorem scheme_independence :
    (Nonempty A → ¬ ∀ a : A, ⊢[(· ≠ .push_pop)] .push a * .pop a ≈ 1) ∧
      (Nonempty A → ¬ ∀ a : A, ⊢[(· ≠ .pop_push)] .pop a * .push a ≤ 1) ∧
      (Nontrivial A →
        ¬ ∀ a b : A, a ≠ b → ⊢[(· ≠ .push_pop_ne)] .push a * .pop b ≈ 0) :=
  ⟨fun _ => push_pop_independent, fun _ => pop_push_independent, fun _ => mismatch_independent⟩

end Independence

end Stackat
