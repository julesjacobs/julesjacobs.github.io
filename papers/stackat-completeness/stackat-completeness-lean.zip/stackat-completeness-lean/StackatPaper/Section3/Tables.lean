import StackatPaper.Section3.DFA
import StackatPaper.Background.BooleanMatrix
import StackatPaper.Background.Relations
import Mathlib.Data.Matrix.Mul

/-!
# Section 3.2: the program `Φ(D)` of a table and its relation

* the matrices `X = Σ_a q_a T_a` (`popMatrix`) and `Y = Σ_a p_a T_aᵀ` (`pushMatrix`) of
  Section 4 (Step 1), in any Kleene algebra;
* the program of a table `D`, defined in the matrix form (9) `Φ(D) = ℓ X* D Y* r`
  (`tableProgram M p q D`, in any Kleene algebra with letters `p`, `q`; `Φ M D` in the algebra of
  expressions modulo derivability);
* its relation (3): `R_{Φ(D)} = 𝓡_D` (`table_semantics`).
-/

namespace Stackat

open scoped Computability

variable {A S K : Type*} [Fintype A] [Fintype S] [DecidableEq S] [KleeneAlgebra K]

/-- `X = Σ_a q_a T_a`: `X_{ij}` sums `q_a` over the letters with `δ(i, a) = j`. -/
def popMatrix (M : DFA A S) (q : A → K) : Matrix S S K :=
  fun i j => ∑ a, if M.step i a = j then q a else 0

/-- `Y = Σ_a p_a T_aᵀ`: `Y_{ij}` sums `p_a` over the letters with `δ(j, a) = i`. -/
def pushMatrix (M : DFA A S) (p : A → K) : Matrix S S K :=
  fun i j => ∑ a, if M.step j a = i then p a else 0

/-- The program of a table `D` in a Kleene algebra with pushes `p` and pops `q`:
`ℓ X* D Y* r`, the `(s, s)` entry of `X* D Y*`. -/
noncomputable def tableProgram (M : DFA A S) (p q : A → K) (D : S → S → Prop) :
    K :=
  ((popMatrix M q)∗ * boolMatrix (K := K) D * (pushMatrix M p)∗)
    M.initial M.initial

/-- `Φ(D)`: the program of a table in the algebra of expressions modulo derivability. -/
noncomputable abbrev Φ {A : Type} [Fintype A] (M : DFA A S) (D : S → S → Prop) :
    FreeAlgebra A :=
  tableProgram M (p := fun a => FreeAlgebra.of (.push a))
    (q := fun a => FreeAlgebra.of (.pop a)) D

theorem pop_mul {T : Type*} (M : DFA A S) (q : A → K) (B : Matrix S T K) (i j) :
    (popMatrix M q * B) i j = ∑ a, q a * B (M.step i a) j := by
  classical
  simp only [Matrix.mul_apply, popMatrix, Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro a _
  simp [ite_mul, eq_comm]

theorem mul_push {T : Type*} (M : DFA A S) (p : A → K) (B : Matrix T S K) (i j) :
    (B * pushMatrix M p) i j = ∑ a, B i (M.step j a) * p a := by
  classical
  simp only [Matrix.mul_apply, pushMatrix, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro a _
  simp [mul_ite, eq_comm]

end Stackat

namespace Stackat

open scoped Computability

variable {A : Type} {S : Type*} [Fintype A] [Fintype S] [DecidableEq S]

omit [Fintype S] in
private theorem pop_matrix_apply (M : DFA A S) (i j : S) (s t : List A) :
    popMatrix M Rel.pop i j s t ↔ ∃ a, M.step i a = j ∧ s = a :: t := by
  classical
  simp only [popMatrix, Rel.sum_apply, Finset.mem_univ, true_and]
  apply exists_congr
  intro a
  by_cases h : M.step i a = j <;> simp [h, Rel.pop]

omit [Fintype S] in
private theorem push_matrix_apply (M : DFA A S) (i j : S) (s t : List A) :
    pushMatrix M Rel.push i j s t ↔ ∃ a, M.step j a = i ∧ t = a :: s := by
  classical
  simp only [pushMatrix, Rel.sum_apply, Finset.mem_univ, true_and]
  apply exists_congr
  intro a
  by_cases h : M.step j a = i <;> simp [h, Rel.push]

private def PopPaths (M : DFA A S) : Matrix S S (Rel (List A)) :=
  fun i j s t => ∃ w : List A, w.foldl M.step i = j ∧ s = w ++ t

private def PushPaths (M : DFA A S) : Matrix S S (Rel (List A)) :=
  fun i j s t => ∃ w : List A, w.foldl M.step j = i ∧ t = w ++ s

private theorem pop_star_upper (M : DFA A S) : (popMatrix M Rel.pop)∗ ≤ PopPaths M := by
  apply kstar_le_of_mul_le_right
  · intro i j s t h
    by_cases hij : i = j
    · subst j
      simp only [Matrix.one_apply_eq, Rel.one_apply] at h
      exact ⟨[], rfl, h⟩
    · simp only [Matrix.one_apply_ne hij, Rel.zero_apply] at h
  · intro i j s t h
    obtain ⟨k, _, v, hp, hw⟩ := (Rel.sum_apply _ _ s t).mp h
    obtain ⟨a, hstep, hs⟩ := (pop_matrix_apply M i k s v).mp hp
    obtain ⟨w, hw, ht⟩ := hw
    exact ⟨a :: w, by simpa only [List.foldl, hstep] using hw,
      by simp only [List.cons_append, hs, ht]⟩

private theorem push_star_upper (M : DFA A S) : (pushMatrix M Rel.push)∗ ≤ PushPaths M := by
  apply kstar_le_of_mul_le_right
  · intro i j s t h
    by_cases hij : i = j
    · subst j
      simp only [Matrix.one_apply_eq, Rel.one_apply] at h
      exact ⟨[], rfl, h.symm⟩
    · simp only [Matrix.one_apply_ne hij, Rel.zero_apply] at h
  · intro i j s t h
    obtain ⟨k, _, v, hp, hw⟩ := (Rel.sum_apply _ _ s t).mp h
    obtain ⟨a, hstep, hv⟩ := (push_matrix_apply M i k s v).mp hp
    obtain ⟨w, hw, ht⟩ := hw
    exact ⟨w ++ [a], by simpa only [List.foldl_append, List.foldl, hw] using hstep,
      by simpa only [List.append_assoc, List.cons_append, List.nil_append, hv] using ht⟩

private theorem pop_word_lower (M : DFA A S) (w : List A) (i : S) (t : List A) :
    (popMatrix M Rel.pop)∗ i (w.foldl M.step i) (w ++ t) t := by
  induction w generalizing i with
  | nil => exact matrix_star_diagonal (popMatrix M Rel.pop) i t t rfl
  | cons a w ih =>
    have he := (pop_matrix_apply M i (M.step i a) (a :: (w ++ t)) (w ++ t)).mpr ⟨a, rfl, rfl⟩
    have hes := le_kstar (a := popMatrix M Rel.pop) i (M.step i a) _ _ he
    exact matrix_star_entry_mul_le (popMatrix M Rel.pop) i _ (M.step i a) _ _
      ⟨w ++ t, hes, ih (M.step i a)⟩

private theorem push_word_lower (M : DFA A S) (w : List A) (j : S) (s : List A) :
    (pushMatrix M Rel.push)∗ (w.foldl M.step j) j s (w ++ s) := by
  induction w generalizing j with
  | nil => exact matrix_star_diagonal (pushMatrix M Rel.push) j s s rfl
  | cons a w ih =>
    have he := (push_matrix_apply M (M.step j a) j (w ++ s) (a :: (w ++ s))).mpr ⟨a, rfl, rfl⟩
    have hes := le_kstar (a := pushMatrix M Rel.push) (M.step j a) j _ _ he
    exact matrix_star_entry_mul_le (pushMatrix M Rel.push) _ j (M.step j a) _ _
      ⟨w ++ s, ih (M.step j a), hes⟩

theorem pop_star_apply (M : DFA A S) (i j : S) (s t : List A) :
    (popMatrix M Rel.pop)∗ i j s t ↔ ∃ w : List A, w.foldl M.step i = j ∧ s = w ++ t := by
  constructor
  · exact pop_star_upper M i j s t
  · rintro ⟨w, rfl, rfl⟩
    exact pop_word_lower M w i t

theorem push_star_apply (M : DFA A S) (i j : S) (s t : List A) :
    (pushMatrix M Rel.push)∗ i j s t ↔ ∃ w : List A, w.foldl M.step j = i ∧ t = w ++ s := by
  constructor
  · exact push_star_upper M i j s t
  · rintro ⟨w, rfl, rfl⟩
    exact push_word_lower M w j s

/-- **The relation of a table** (3): `R_{Φ(D)} = 𝓡_D = {(uw, vw) : D_{h(u),h(v)} = 1}`, in the
relational model. -/
theorem table_semantics (M : DFA A S) (D : S → S → Prop) (s t : List A) :
    tableProgram M Rel.push Rel.pop D s t ↔ Accepted M D s t := by
  simp only [tableProgram, Matrix.mul_apply, Rel.sum_apply, Finset.mem_univ, true_and,
    Rel.mul_apply, boolMatrix, Rel.bit_apply, pop_star_apply, push_star_apply]
  constructor
  · rintro ⟨j, v, ⟨i, u, ⟨x, hx, hs⟩, he, huv⟩, y, hy, ht⟩
    subst v
    exact ⟨x, y, u, hs, ht, by simpa only [DFA.h, hx, hy] using he⟩
  · rintro ⟨x, y, u, hs, ht, he⟩
    exact ⟨M.h y, u, ⟨M.h x, u, ⟨x, rfl, hs⟩, he, rfl⟩, y, rfl, ht⟩

end Stackat
