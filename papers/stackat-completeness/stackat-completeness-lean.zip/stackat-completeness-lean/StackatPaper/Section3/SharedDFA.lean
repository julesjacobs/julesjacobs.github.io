import StackatPaper.AppendixA.Saturation
import StackatPaper.Background.BooleanMatrix
import StackatPaper.Background.MatrixSimulation
import Mathlib.Data.Fintype.Sets
import Mathlib.Data.Fintype.Pi
import StackatPaper.Section3.DFA
import StackatPaper.AppendixA.Automaton
import StackatPaper.AppendixA.NormalForm
import StackatPaper.Section3.Tables
import StackatPaper.Section2
import Mathlib.Data.Fintype.EquivFin

/-!
Section 3.2: one reachable DFA for all pop and push languages (`SharedDFA.dfa`), over which each
automaton of a finite family is the program of a table (`SharedDFA.accepts`,
`SharedDFA.representation`), and the shared normal forms (2) `e = Φ(E)`, `f = Φ(F)`
(`shared_normal_forms`).
-/

namespace Stackat

open scoped Computability


variable {A S D K : Type*} [Fintype A] [Fintype S] [DecidableEq S]
  [Fintype D] [DecidableEq D] [KleeneAlgebra K]

omit [DecidableEq S] in
/-- A Boolean simulation from a DFA to a letter-labeled NFA. -/
theorem deterministic_simulation (M : DFA A D)
    (L : A → S → S → Prop) (R : D → S → Prop) (w : A → K)
    (hstep : ∀ d a j, R (M.step d a) j ↔ ∃ k, R d k ∧ L a k j) :
    popMatrix M w * boolMatrix (K := K) R = boolMatrix R * StackGraph.labelMatrix L w := by
  classical
  ext d j
  rw [pop_mul]
  simp only [Matrix.mul_apply, boolMatrix, StackGraph.labelMatrix, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro a _
  rw [propext (hstep d a j), bit_exists, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro k _
  by_cases hr : R d k <;> by_cases hl : L a k j <;> simp [bit, hr, hl]

theorem deterministic_star_simulation (M : DFA A D)
    (L : A → S → S → Prop) (R : D → S → Prop) (w : A → K)
    (hstep : ∀ d a j, R (M.step d a) j ↔ ∃ k, R d k ∧ L a k j) :
    (popMatrix M w)∗ * boolMatrix (K := K) R =
      boolMatrix R * (StackGraph.labelMatrix L w)∗ :=
  matrix_star_simulation _ _ _ (deterministic_simulation M L R w hstep)

omit [DecidableEq S] in
theorem reverse_deterministic_simulation (M : DFA A D)
    (L : A → S → S → Prop) (R : D → S → Prop) (w : A → K)
    (hstep : ∀ d a j, R (M.step d a) j ↔ ∃ k, R d k ∧ L a k j) :
    StackGraph.labelMatrix (fun a i j => L a j i) w * boolMatrix (K := K) (fun i d => R d i) =
      boolMatrix (fun i d => R d i) * pushMatrix M w := by
  classical
  ext j d
  rw [mul_push]
  simp only [Matrix.mul_apply, boolMatrix, StackGraph.labelMatrix, Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro a _
  rw [propext (hstep d a j), bit_exists, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro k _
  by_cases hr : R d k <;> by_cases hl : L a k j <;> simp [bit, hr, hl]

theorem reverse_deterministic_star_simulation (M : DFA A D)
    (L : A → S → S → Prop) (R : D → S → Prop) (w : A → K)
    (hstep : ∀ d a j, R (M.step d a) j ↔ ∃ k, R d k ∧ L a k j) :
    (StackGraph.labelMatrix (fun a i j => L a j i) w)∗ * boolMatrix (K := K) (fun i d => R d i) =
      boolMatrix (fun i d => R d i) * (pushMatrix M w)∗ :=
  matrix_star_simulation _ _ _ (reverse_deterministic_simulation M L R w hstep)

end Stackat

namespace Stackat.DeterminizedFamily

open scoped Computability


variable {A I : Type*} (S : I → Type*)

def RawState := ∀ i, S i → S i → Prop

def step (L : ∀ i, A → S i → S i → Prop) (R : RawState S) (a : A) : RawState S :=
  fun i x y => ∃ z, R i x z ∧ L i a z y

abbrev State (Z : RawState S) (L : ∀ i, A → S i → S i → Prop) :=
  ReachableDFA.State Z (step S L)

def automaton (Z : RawState S) (L : ∀ i, A → S i → S i → Prop) :
    DFA A (State S Z L) := ReachableDFA.automaton Z (step S L)

variable [Fintype I] [∀ i, Fintype (S i)]

noncomputable instance : Fintype (RawState S) := by
  classical
  unfold RawState
  infer_instance

variable {K : Type*} [KleeneAlgebra K] [Fintype A] [∀ i, DecidableEq (S i)]

/-- One reachable DFA simultaneously represents every row language of a finite family of NFAs. -/
theorem row_eq (Z : RawState S) (L : ∀ i, A → S i → S i → Prop)
    (w : A → K) (i : I) (x y : S i) :
    ∑ d, (popMatrix (automaton S Z L) w)∗ (automaton S Z L).initial d * bit (d.val i x y) =
      (boolMatrix (K := K) (Z i) * (StackGraph.labelMatrix (L i) w)∗) x y := by
  classical
  have h := deterministic_star_simulation (automaton S Z L) (L i)
    (fun d j => d.val i x j) w (fun _ _ _ => Iff.rfl)
  have he := congrArg (fun m => m (automaton S Z L).initial y) h
  exact he

theorem reverse_row_eq (Z : RawState S) (L : ∀ i, A → S i → S i → Prop)
    (w : A → K) (i : I) (x y : S i) :
    ∑ d, bit (d.val i x y) * (pushMatrix (automaton S Z L) w)∗ d (automaton S Z L).initial =
      ((StackGraph.labelMatrix (fun a u v => L i a v u) w)∗ *
        boolMatrix (K := K) (fun u v => Z i v u)) y x := by
  classical
  have h := reverse_deterministic_star_simulation (automaton S Z L) (L i)
    (fun d j => d.val i x j) w (fun _ _ _ => Iff.rfl)
  have he := congrArg (fun m => m y (automaton S Z L).initial) h
  exact he.symm

end Stackat.DeterminizedFamily

namespace Stackat

open scoped Computability


variable {A D J K : Type*} [Fintype A] [Fintype D] [DecidableEq D] [Fintype J] [KleeneAlgebra K]

theorem tableProgram_product (M : DFA A D) (p q : A → K)
    (R P : D → J → Prop) :
    tableProgram M p q (fun d e => ∃ j, R d j ∧ P e j) =
      ∑ j, (∑ d, (popMatrix M q)∗ M.initial d * bit (R d j)) *
        (∑ e, bit (P e j) * (pushMatrix M p)∗ e M.initial) := by
  classical
  let X := (popMatrix M q)∗
  let Y := (pushMatrix M p)∗
  calc
    tableProgram M p q (fun d e => ∃ j, R d j ∧ P e j) =
        ∑ e, ∑ d, ∑ j, X M.initial d * (bit (R d j) * bit (P e j)) * Y e M.initial := by
      simp only [tableProgram, Matrix.mul_apply, boolMatrix, bit_exists, bit_and,
        Finset.sum_mul, Finset.mul_sum, X, Y]
    _ = ∑ d, ∑ j, ∑ e, X M.initial d * (bit (R d j) * bit (P e j)) * Y e M.initial := by
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro d _
      exact Finset.sum_comm
    _ = ∑ j, ∑ d, ∑ e, X M.initial d * (bit (R d j) * bit (P e j)) * Y e M.initial := Finset.sum_comm
    _ = _ := by
      simp only [Finset.sum_mul, Finset.mul_sum, mul_assoc, X, Y]
      apply Finset.sum_congr rfl
      intro j _
      exact Finset.sum_comm

end Stackat

namespace Stackat.SharedDFA

open scoped Computability


variable {A I : Type} (F : I → StackAutomaton A)

abbrev CoordinateState (ib : I × Bool) := (F ib.1).State

def initial : DeterminizedFamily.RawState (CoordinateState F)
  | (i, false), x, y => (F i).graph.Balanced x y
  | (i, true), x, y => (F i).graph.Balanced y x

def letter : ∀ ib : I × Bool, A → CoordinateState F ib → CoordinateState F ib → Prop
  | (i, false), a, x, y => (F i).graph.surround (F i).graph.pop a x y
  | (i, true), a, x, y => (F i).graph.surround (F i).graph.push a y x

abbrev State :=
  DeterminizedFamily.State (CoordinateState F) (initial F) (letter F)

def dfa : DFA A (State F) :=
  DeterminizedFamily.automaton (CoordinateState F) (initial F) (letter F)

def accepts (i : I) (d e : State F) : Prop :=
  ∃ k : (F i).State,
    d.val (i, false) (F i).initial k ∧ e.val (i, true) (F i).final k

variable [Fintype I] [Fintype A] {K : Type*} [KleeneAlgebra K]

theorem pop_component (q : A → K) (i : I) (k : (F i).State) :
    ((F i).graph.saturation (K := K) + (F i).graph.saturatedPop q)∗ (F i).initial k =
      ∑ d, (popMatrix (dfa F) q)∗ (dfa F).initial d * bit (d.val (i, false) (F i).initial k) := by
  classical
  rw [StackGraph.saturated_pop_factor]
  exact (DeterminizedFamily.row_eq (CoordinateState F) (initial F) (letter F) q
    (i, false) (F i).initial k).symm

theorem push_component (p : A → K) (i : I) (k : (F i).State) :
    ((F i).graph.saturation (K := K) + (F i).graph.saturatedPush p)∗ k (F i).final =
      ∑ e, bit (e.val (i, true) (F i).final k) * (pushMatrix (dfa F) p)∗ e (dfa F).initial := by
  classical
  rw [StackGraph.saturated_push_factor]
  exact (DeterminizedFamily.reverse_row_eq (CoordinateState F) (initial F) (letter F) p
    (i, true) (F i).final k).symm

/-- **The shared reachable DFA** (Section 3.2). For a finite family `F` of stack automata, one
complete reachable DFA `dfa F` serves every member: in every Kleene algebra with `p_a q_a = 1` and
`p_a q_b = 0` (`a ≠ b`), each `F i` is the program of a table `accepts F i` on `dfa F`. -/
theorem representation (p q : A → K) (hpq : ∀ a, p a * q a = 1)
    (hne : ∀ a b, a ≠ b → p a * q b = 0) (i : I) :
    (F i).eval p q = tableProgram (dfa F) p q (accepts F i) := by
  classical
  change ((F i).graph.transition p q)∗ (F i).initial (F i).final = _
  rw [(F i).graph.factorization p q hpq hne]
  change (∑ k, ((F i).graph.saturation (K := K) + (F i).graph.saturatedPop q)∗ (F i).initial k *
    ((F i).graph.saturation (K := K) + (F i).graph.saturatedPush p)∗ k (F i).final) = _
  simp_rw [pop_component F q i, push_component F p i]
  exact (tableProgram_product (dfa F) p q _ _).symm

end Stackat.SharedDFA

namespace Stackat

open scoped Computability


variable {A S T : Type*}

private theorem foldl_reindex (δ : S → A → S) (e : S ≃ T) (w : List A) (s : S) :
    w.foldl (fun t a => e (δ (e.symm t) a)) (e s) = e (w.foldl δ s) := by
  induction w generalizing s with
  | nil => rfl
  | cons a w ih => simpa only [List.foldl, Equiv.symm_apply_apply] using ih (δ s a)

def DFA.reindex (M : DFA A S) (e : S ≃ T) :
    DFA A T where
  initial := e M.initial
  step t a := e (M.step (e.symm t) a)
  reachable := by
    intro t
    obtain ⟨w, hw⟩ := M.reachable (e.symm t)
    exact ⟨w, by rw [foldl_reindex, hw, Equiv.apply_symm_apply]⟩

@[simp] theorem DFA.h_reindex (M : DFA A S) (e : S ≃ T) (w : List A) :
    (M.reindex e).h w = e (M.h w) := foldl_reindex M.step e w M.initial

theorem accepted_reindex (M : DFA A S) (e : S ≃ T) (F : S → S → Prop)
    (s t : List A) :
    Accepted (M.reindex e) (fun i j => F (e.symm i) (e.symm j)) s t ↔ Accepted M F s t := by
  simp only [Accepted, DFA.h_reindex, Equiv.symm_apply_apply]

variable {K : Type*} [KleeneAlgebra K] [Fintype S] [Fintype T] [DecidableEq S] [DecidableEq T]

theorem matrix_star_submatrix (e : S ≃ T) (N : Matrix T T K) :
    N∗.submatrix e e = (N.submatrix e e)∗ := by
  ext i j
  apply le_antisymm
  · have h := matrix_star_map_le N (N.submatrix e e) e.symm
      (fun u v => by simp only [Matrix.submatrix_apply, Equiv.apply_symm_apply, le_refl]) (e i) (e j)
    simpa only [Matrix.submatrix_apply, Equiv.symm_apply_apply] using h
  · exact matrix_star_map_le (N.submatrix e e) N e (fun _ _ => le_rfl) i j

variable [Fintype A]

theorem tableProgram_reindex (M : DFA A S) (e : S ≃ T) (p q : A → K) (F : S → S → Prop) :
    tableProgram (M.reindex e) p q (fun i j => F (e.symm i) (e.symm j)) = tableProgram M p q F := by
  have hx : (popMatrix (M.reindex e) q).submatrix e e = popMatrix M q := by
    ext i j
    simp only [Matrix.submatrix_apply, popMatrix, DFA.reindex,
      Equiv.symm_apply_apply, Equiv.apply_eq_iff_eq]
  have hy : (pushMatrix (M.reindex e) p).submatrix e e = pushMatrix M p := by
    ext i j
    simp only [Matrix.submatrix_apply, pushMatrix, DFA.reindex,
      Equiv.symm_apply_apply, Equiv.apply_eq_iff_eq]
  have hf : (boolMatrix (K := K) (fun i j => F (e.symm i) (e.symm j))).submatrix e e = boolMatrix F := by
    ext i j
    simp only [Matrix.submatrix_apply, boolMatrix, Equiv.symm_apply_apply]
  have h : (((popMatrix (M.reindex e) q)∗ * boolMatrix (K := K) (fun i j => F (e.symm i) (e.symm j))) *
      (pushMatrix (M.reindex e) p)∗).submatrix e e =
        (popMatrix M q)∗ * boolMatrix (K := K) F * (pushMatrix M p)∗ := by
    rw [Matrix.submatrix_mul _ _ e e e e.bijective,
      Matrix.submatrix_mul _ _ e e e e.bijective,
      matrix_star_submatrix, matrix_star_submatrix, hx, hy, hf]
  exact congrArg (fun m => m M.initial M.initial) h

end Stackat

namespace Stackat

open FreeAlgebra

variable {A : Type} [Fintype A]

private theorem expression_family_normalForm {I : Type} [Fintype I] (es : I → Expr A) :
    let F := fun i => StackAutomaton.ofExpr (es i)
    ∀ i,
      of (es i) = tableProgram (SharedDFA.dfa F)
        (fun a => of (.push a)) (fun a => of (.pop a)) (SharedDFA.accepts F i) ∧
      ∀ s t, R (es i) s t ↔
        Accepted (SharedDFA.dfa F) (SharedDFA.accepts F i) s t := by
  classical
  intro F i
  constructor
  · simpa only [F, StackAutomaton.eval_ofExpr_free] using
      SharedDFA.representation F (fun a => of (.push a)) (fun a => of (.pop a))
        FreeAlgebra.push_pop (fun _ _ h => FreeAlgebra.push_pop_ne h) i
  · have h := SharedDFA.representation F Rel.push Rel.pop
      Rel.push_pop (fun _ _ h => Rel.push_pop_ne h) i
    change (StackAutomaton.ofExpr (es i)).eval _ _ = _ at h
    rw [StackAutomaton.eval_ofExpr, Rel.eval_denote] at h
    exact fun s t => (Iff.of_eq (congrArg (fun r => r s t) h)).trans
      (table_semantics (SharedDFA.dfa F) (SharedDFA.accepts F i) s t)

/-- **Shared normal forms** (2). Any two expressions are the programs `e = Φ(E)`, `f = Φ(F)` of
two tables on one finite reachable DFA, and their relations are `R_e = 𝓡_E`, `R_f = 𝓡_F`. -/
theorem shared_normal_forms (e f : Expr A) :
    ∃ (n : ℕ) (M : DFA A (Fin n)) (E F : Fin n → Fin n → Prop),
      FreeAlgebra.of e = Φ M E ∧ FreeAlgebra.of f = Φ M F ∧
        R e = Accepted M E ∧ R f = Accepted M F := by
  classical
  let es : Bool → Expr A := fun b => if b then f else e
  let F := fun b => StackAutomaton.ofExpr (es b)
  let M := SharedDFA.dfa F
  let E := SharedDFA.accepts F false
  let G := SharedDFA.accepts F true
  obtain ⟨he, hse⟩ := expression_family_normalForm es false
  obtain ⟨hf, hsf⟩ := expression_family_normalForm es true
  let index := Fintype.equivFin (SharedDFA.State F)
  refine ⟨Fintype.card (SharedDFA.State F), M.reindex index,
    (fun i j => E (index.symm i) (index.symm j)),
    (fun i j => G (index.symm i) (index.symm j)), ?_, ?_, ?_, ?_⟩
  · exact he.trans (tableProgram_reindex M index _ _ E).symm
  · exact hf.trans (tableProgram_reindex M index _ _ G).symm
  · exact funext fun s => funext fun t => propext ((hse s t).trans (accepted_reindex M index E s t).symm)
  · exact funext fun s => funext fun t => propext ((hsf s t).trans (accepted_reindex M index G s t).symm)

end Stackat
