import Mathlib.Data.List.Induction
import Mathlib.Data.Fintype.Sets
import Mathlib.Data.Fintype.Pi

/-!
# Section 3.2: the shared reachable DFA and the relation of a table

* `DFA A S`: a complete DFA `M = (S, s, δ)` in which every state is reachable;
* `M.h u = δ(s, u)`, the state reached by `u`, and the classes `M.L i = {u | h(u) = i}`;
  `h(ua) = δ(h(u), a)` and every class is nonempty (`DFA.h_append_singleton_and_L_nonempty`);
* `Accepted M D u v`: the pair `(u, v)` is in the relation `𝓡_D` of a table `D`, that is
  `(u, v) = (xw, yw)` with `D_{h(x),h(y)} = 1`; `DirectlyAccepted M D u v`: `D_{h(u),h(v)} = 1`;
* `ReachableDFA.automaton`: the restriction of a complete DFA to its reachable states.
-/

namespace Stackat

variable {A S : Type*}

/-- A complete DFA with initial state `initial` and transition function `step`, every state of
which is reachable. It has no accepting states: tables of state pairs take their place. -/
structure DFA (A S : Type*) where
  initial : S
  step : S → A → S
  reachable : ∀ i, ∃ u : List A, u.foldl step initial = i

namespace DFA

/-- `h(u) = δ(s, u)`, the state reached by `u`. -/
def h (M : DFA A S) (u : List A) : S :=
  u.foldl M.step M.initial

/-- The class `L_i = {u ∈ A* : h(u) = i}`. -/
def L (M : DFA A S) (i : S) : Set (List A) := {u | M.h u = i}

@[simp] theorem mem_L {M : DFA A S} {u : List A} {i : S} : u ∈ M.L i ↔ M.h u = i := Iff.rfl

@[simp] theorem h_nil (M : DFA A S) : M.h [] = M.initial := rfl

/-- `h(ua) = δ(h(u), a)`. -/
@[simp] theorem h_append_singleton (M : DFA A S) (u : List A) (a : A) :
    M.h (u ++ [a]) = M.step (M.h u) a := by
  simp [DFA.h, List.foldl_append]

/-- Every class is nonempty. -/
theorem L_nonempty (M : DFA A S) (i : S) : (M.L i).Nonempty := M.reachable i

/-- **Section 3.2.** `h(ua) = δ(h(u), a)`, and every set `L_i` is nonempty. -/
theorem h_append_singleton_and_L_nonempty (M : DFA A S) :
    (∀ (u : List A) (a : A), M.h (u ++ [a]) = M.step (M.h u) a) ∧
      ∀ i, (M.L i).Nonempty :=
  ⟨M.h_append_singleton, M.L_nonempty⟩

end DFA

/-- `(u, v) ∈ 𝓡_D`: the pair is `(xw, yw)` for a prefix pair `(x, y)` in a cell selected by `D`,
with an unchanged suffix `w`. -/
def Accepted (M : DFA A S) (D : S → S → Prop) (u v : List A) : Prop :=
  ∃ x y w, u = x ++ w ∧ v = y ++ w ∧ D (M.h x) (M.h y)

/-- `(u, v)` is directly accepted by `D`: `D_{h(u),h(v)} = 1`. -/
def DirectlyAccepted (M : DFA A S) (D : S → S → Prop) (u v : List A) : Prop :=
  D (M.h u) (M.h v)

/-- A directly accepted pair is accepted, with empty unchanged suffix. -/
theorem DirectlyAccepted.accepted {M : DFA A S} {D : S → S → Prop} {u v : List A}
    (h : DirectlyAccepted M D u v) : Accepted M D u v :=
  ⟨u, v, [], by simp, by simp, h⟩

/-- `𝓡_D` is closed under appending a common suffix. -/
theorem accepted_suffix {M : DFA A S} {D : S → S → Prop} {u v : List A}
    (h : Accepted M D u v) (w : List A) : Accepted M D (u ++ w) (v ++ w) := by
  obtain ⟨x, y, z, rfl, rfl, hxy⟩ := h
  exact ⟨x, y, z ++ w, List.append_assoc .., List.append_assoc .., hxy⟩

end Stackat

namespace Stackat.ReachableDFA

variable {A Q : Type*}

/-- The states reachable from `initial`. -/
def State (initial : Q) (step : Q → A → Q) :=
  { q : Q // ∃ w : List A, w.foldl step initial = q }

def initial (q : Q) (step : Q → A → Q) : State q step := ⟨q, [], rfl⟩

def step {q : Q} {δ : Q → A → Q} (s : State q δ) (a : A) : State q δ :=
  ⟨δ s.val a, by
    obtain ⟨w, hw⟩ := s.property
    exact ⟨w ++ [a], by simp only [List.foldl_append, List.foldl, hw]⟩⟩

theorem foldl_val {q : Q} {δ : Q → A → Q} (w : List A) (s : State q δ) :
    (w.foldl step s).val = w.foldl δ s.val := by
  induction w generalizing s with
  | nil => rfl
  | cons a w ih => exact ih (step s a)

/-- Restricting a complete DFA to its reachable states. -/
def automaton (q : Q) (δ : Q → A → Q) : DFA A (State q δ) where
  initial := initial q δ
  step := step
  reachable := by
    intro s
    obtain ⟨w, hw⟩ := s.property
    exact ⟨w, Subtype.ext ((foldl_val w (initial q δ)).trans hw)⟩

noncomputable instance [Finite Q] (q : Q) (δ : Q → A → Q) : Fintype (State q δ) := by
  unfold State
  exact Fintype.ofFinite _

noncomputable instance (q : Q) (δ : Q → A → Q) : DecidableEq (State q δ) := Classical.decEq _

end Stackat.ReachableDFA
