import StackatPaper.Section2
import StackatPaper.Background.FreeAlgebra

/-!
# Section 3.1: words

* `q(u) = q_{a_1} ⋯ q_{a_k}` and `p(u) = p_{a_k} ⋯ p_{a_1}` for `u = a_1 ⋯ a_k` (`q`, `p`);
* `q(u)p(v)` relates `uw` to `vw` for every unchanged suffix `w` (`qp_R`);
* `q(xw)p(yw) = q(x)q(w)p(w)p(y) ≤ q(x)p(y)` (`qp_append_eq_le`);
* `q(w)p(w) ≤ 1`, by induction on `w` (`qp_le_one`).
-/

namespace Stackat

open FreeAlgebra

variable {A : Type}

/-! ## Words -/

/-- `q(u) = q_{a_1} ⋯ q_{a_k}`. -/
def q : List A → Expr A
  | [] => 1
  | c :: u => .pop c * q u

/-- `p(u) = p_{a_k} ⋯ p_{a_1}`. -/
def p : List A → Expr A
  | [] => 1
  | c :: u => p u * .push c

theorem q_denote (u s t : List A) : R (q u) s t ↔ s = u ++ t := by
  induction u generalizing s with
  | nil => simp [q, R, OfNat.ofNat, One.one]
  | cons c u ih =>
    simp only [q, R] at ih ⊢
    constructor
    · rintro ⟨m, rfl, hm⟩; rw [(ih m).mp hm]; rfl
    · rintro rfl; exact ⟨u ++ t, rfl, (ih _).mpr rfl⟩

theorem p_denote (u s t : List A) : R (p u) s t ↔ t = u ++ s := by
  induction u generalizing t with
  | nil => simp [p, R, OfNat.ofNat, One.one, eq_comm]
  | cons c u ih =>
    simp only [p, R] at ih ⊢
    constructor
    · rintro ⟨m, hm, rfl⟩; rw [(ih m).mp hm]; rfl
    · rintro rfl; exact ⟨u ++ s, (ih _).mpr rfl, rfl⟩

/-- `q(u)p(v)` relates `uw` to `vw` for every unchanged suffix `w`. -/
theorem qp_R (u v s t : List A) :
    R (q u * p v) s t ↔ ∃ w, s = u ++ w ∧ t = v ++ w := by
  change (∃ m, R (q u) s m ∧ R (p v) m t) ↔ _
  simp only [q_denote, p_denote]

private theorem of_q_append (x w : List A) : of (q (x ++ w)) = of (q x) * of (q w) := by
  induction x with
  | nil => simp [q]
  | cons c x ih => simp only [List.cons_append, q, of_mul, ih, mul_assoc]

private theorem of_p_append (y w : List A) : of (p (y ++ w)) = of (p w) * of (p y) := by
  induction y with
  | nil => simp [p]
  | cons c y ih => simp only [List.cons_append, p, of_mul, ih, mul_assoc]

private theorem qp_le_one_of (w : List A) : of (q w) * of (p w) ≤ 1 := by
  induction w with
  | nil => simp [q, p]
  | cons c w ih =>
    simp only [q, p, of_mul]
    calc of (.pop c) * of (q w) * (of (p w) * of (.push c)) =
        of (.pop c) * (of (q w) * of (p w)) * of (.push c) := by simp only [mul_assoc]
      _ ≤ of (.pop c) * 1 * of (.push c) :=
        mul_le_mul_left (mul_le_mul_right ih _) _
      _ = of (.pop c) * of (.push c) := by rw [mul_one]
      _ ≤ 1 := FreeAlgebra.pop_push c

/-- `q(xw)p(yw) = q(x)q(w)p(w)p(y)`. -/
theorem qp_append (x y w : List A) :
    ⊢ q (x ++ w) * p (y ++ w) ≈ q x * (q w * p w) * p y := by
  apply of_eq_iff.mp
  simp only [of_mul, of_q_append, of_p_append, mul_assoc]

/-- **Section 3.1.** `q(xw)p(yw) = q(x)q(w)p(w)p(y) ≤ q(x)p(y)`. -/
theorem qp_append_eq_le (x y w : List A) :
    (⊢ q (x ++ w) * p (y ++ w) ≈ q x * (q w * p w) * p y) ∧
      (⊢ q x * (q w * p w) * p y ≤ q x * p y) := by
  refine ⟨qp_append x y w, ?_⟩
  apply of_eq_iff.mp
  rw [of_add]
  apply add_eq_right_iff_le.mpr
  simp only [of_mul]
  calc of (q x) * (of (q w) * of (p w)) * of (p y) ≤
      of (q x) * 1 * of (p y) :=
        mul_le_mul_left (mul_le_mul_right (qp_le_one_of w) _) _
    _ = _ := by rw [mul_one]

/-- `q(w)p(w) ≤ 1`, by induction on `w`: appending `a` gives `q(w)q_a p_a p(w) ≤ q(w)p(w)`. -/
theorem qp_le_one (w : List A) : ⊢ q w * p w ≤ 1 := by
  apply of_eq_iff.mp
  simpa using (qp_le_one_of w).add_eq_right

end Stackat
