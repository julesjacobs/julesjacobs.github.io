import StackatPaper.Section3.DFA

/-!
# Section 3.3: Inclusion Reduces to Finding the Good Cells

Fix the shared reachable DFA `M` and the target table `F`.

* good cells (4): `Good M F i j` iff every `(u, v) ∈ L_i × L_j` is in `𝓡_F`;
  `F ≤ G`, and `𝓡_E ⊆ 𝓡_F` iff `E ≤ G` (`target_and_source_le_good`);
* the residual cells `C = G ∖ F` (`Residual`);
* the suffix alternative (5) (`suffix_alternative`), with its cases by the shape of the words
  (`accepted_nil_left`, `accepted_nil_right`, `accepted_append_iff`);
* the three conditions on the residual cells: empty-prefix boundaries
  (`residual_boundaries`), mismatched final symbols
  (`residual_mismatch`) and matching final symbols (`residual_match`);
* fact 3: a cell outside `F` with no initial coordinate, not entered by two different letters,
  is good iff all its predecessors are good (`good_iff_predecessors_good`);
* the certificate conditions (6)–(8) (`CertificateConditions`) and Proposition 8, first
  sentence (`certificate_iff`). The whole of Proposition 8, with `Φ(G) = Φ(F)`, is
  `finite_certificate` in `Section4/Derivation.lean`.
-/

namespace Stackat

variable {A S : Type*} (M : DFA A S) (F : S → S → Prop)

/-- The good table (4): `G_{ij} = 1` iff `(u, v) ∈ 𝓡_F` for all `u ∈ L_i`, `v ∈ L_j`. -/
def Good (i j : S) : Prop :=
  ∀ u ∈ M.L i, ∀ v ∈ M.L j, Accepted M F u v

/-- The residual cells `C = G ∖ F` of the good table. -/
def Residual : S → S → Prop := Good M F \ F

theorem residual_iff {i j : S} : Residual M F i j ↔ Good M F i j ∧ ¬ F i j := Iff.rfl

/-- Every cell selected by `F` is good: `F ≤ G`. -/
theorem target_le_good : F ≤ Good M F := by
  intro i j h u hu v hv
  rw [DFA.mem_L] at hu hv
  subst hu hv
  exact DirectlyAccepted.accepted h

/-- If `𝓡_E ⊆ 𝓡_F`, every cell selected by `E` is good: `E ≤ G`. -/
theorem source_le_good {E : S → S → Prop} (h : Accepted M E ≤ Accepted M F) :
    E ≤ Good M F := by
  intro i j he u hu v hv
  exact h u v (target_le_good M E i j he u hu v hv)

/-- If every cell selected by `E` is good, `𝓡_E ⊆ 𝓡_F`. -/
theorem accepted_le_of_le_good {E : S → S → Prop} (h : E ≤ Good M F) :
    Accepted M E ≤ Accepted M F := by
  rintro u v ⟨x, y, w, rfl, rfl, he⟩
  exact accepted_suffix (h _ _ he x rfl y rfl) w

/-- **Section 3.3.** `F ≤ G`, and `𝓡_E ⊆ 𝓡_F` iff `E ≤ G`. -/
theorem target_and_source_le_good (E : S → S → Prop) :
    F ≤ Good M F ∧ (Accepted M E ≤ Accepted M F ↔ E ≤ Good M F) :=
  ⟨target_le_good M F, source_le_good M F, accepted_le_of_le_good M F⟩

/-! ## The suffix alternative -/

/-- **The suffix alternative (5).** A pair is accepted iff it is directly accepted, or both words
end in the same symbol `c` and deleting it leaves an accepted pair. -/
theorem suffix_alternative (u v : List A) :
    Accepted M F u v ↔ F (M.h u) (M.h v) ∨
      ∃ x y : List A, ∃ c : A, u = x ++ [c] ∧ v = y ++ [c] ∧ Accepted M F x y := by
  constructor
  · rintro ⟨x, y, w, rfl, rfl, hf⟩
    induction w using List.reverseRecOn with
    | nil => exact Or.inl (by simpa using hf)
    | append_singleton w c _ =>
      exact Or.inr ⟨x ++ w, y ++ w, c, by simp, by simp, x, y, w, rfl, rfl, hf⟩
  · rintro (hf | ⟨x, y, c, rfl, rfl, h⟩)
    · exact DirectlyAccepted.accepted hf
    · exact accepted_suffix h [c]

variable {M F} in
private theorem accepted_nil_left_iff {v : List A} :
    Accepted M F [] v ↔ F M.initial (M.h v) := by
  rw [suffix_alternative]
  simp

/-- The suffix alternative when the input prefix is empty. -/
theorem accepted_nil_left (v : List A) : Accepted M F [] v ↔ F M.initial (M.h v) :=
  accepted_nil_left_iff

/-- The suffix alternative when the output prefix is empty. -/
theorem accepted_nil_right (u : List A) : Accepted M F u [] ↔ F (M.h u) M.initial := by
  rw [suffix_alternative]
  simp

/-- The suffix alternative for two nonempty words with final symbols `a` and `b`. -/
theorem accepted_append_iff (u v : List A) (a b : A) :
    Accepted M F (u ++ [a]) (v ++ [b]) ↔
      F (M.step (M.h u) a) (M.step (M.h v) b) ∨ (a = b ∧ Accepted M F u v) := by
  rw [suffix_alternative]
  simp only [DFA.h_append_singleton]
  constructor
  · rintro (h | ⟨x, y, c, hx, hy, h⟩)
    · exact Or.inl h
    · obtain ⟨rfl, rfl⟩ := List.append_singleton_inj.mp hx
      obtain ⟨rfl, rfl⟩ := List.append_singleton_inj.mp hy
      exact Or.inr ⟨rfl, h⟩
  · rintro (h | ⟨rfl, h⟩)
    · exact Or.inl h
    · exact Or.inr ⟨u, v, a, rfl, rfl, h⟩

/-! ## The three conditions on residual cells -/

/-- **Empty-prefix boundary.** `C_{sj} = 0`. -/
theorem residual_boundary_left (j : S) : ¬ Residual M F M.initial j := by
  rintro ⟨hg, hn⟩
  obtain ⟨v, hv⟩ := M.L_nonempty j
  exact hn (by simpa [DFA.mem_L.mp hv] using (accepted_nil_left M F v).mp (hg [] rfl v hv))

/-- **Empty-prefix boundary.** `C_{is} = 0`. -/
theorem residual_boundary_right (i : S) : ¬ Residual M F i M.initial := by
  rintro ⟨hg, hn⟩
  obtain ⟨u, hu⟩ := M.L_nonempty i
  exact hn (by simpa [DFA.mem_L.mp hu] using (accepted_nil_right M F u).mp (hg u hu [] rfl))

/-- **Empty-prefix boundaries.** No residual cell has an initial coordinate. -/
theorem residual_boundaries :
    (∀ j, ¬ Residual M F M.initial j) ∧ ∀ i, ¬ Residual M F i M.initial :=
  ⟨residual_boundary_left M F, residual_boundary_right M F⟩

private theorem residual_step_words {i j : S} {a b : A}
    (hc : Residual M F (M.step i a) (M.step j b))
    {u v : List A} (hu : M.h u = i) (hv : M.h v = j) :
    a = b ∧ Accepted M F u v := by
  have h := hc.1 (u ++ [a]) (by simp [hu]) (v ++ [b]) (by simp [hv])
  rcases (accepted_append_iff M F u v a b).mp h with hf | h
  · exact (hc.2 (by simpa [hu, hv] using hf)).elim
  · exact h

/-- **Mismatched final symbols.** `C_{δ(i,a),δ(j,b)} = 0` for `a ≠ b`. -/
theorem residual_mismatch {i j : S} {a b : A} (hab : a ≠ b) :
    ¬ Residual M F (M.step i a) (M.step j b) := by
  intro hc
  obtain ⟨u, hu⟩ := M.L_nonempty i
  obtain ⟨v, hv⟩ := M.L_nonempty j
  exact hab (residual_step_words M F hc hu hv).1

/-- **Matching final symbols.** If `C_{δ(i,a),δ(j,a)} = 1`, the predecessor cell is good. -/
theorem residual_match {i j : S} {a : A}
    (hc : Residual M F (M.step i a) (M.step j a)) : Good M F i j := by
  intro u hu v hv
  exact (residual_step_words M F hc hu hv).2

/-- **Fact 3.** A cell outside `F` that has no initial coordinate and is not entered by two
different letters is good iff all its predecessors are good. -/
theorem good_iff_predecessors_good {k l : S} (hF : ¬ F k l)
    (hk : k ≠ M.initial) (hl : l ≠ M.initial)
    (hne : ∀ i j a b, M.step i a = k → M.step j b = l → a = b) :
    Good M F k l ↔ ∀ i j a, M.step i a = k → M.step j a = l → Good M F i j := by
  constructor
  · rintro hg i j a rfl rfl
    exact residual_match M F ⟨hg, hF⟩
  · intro hp u hu v hv
    rw [DFA.mem_L] at hu hv
    rcases List.eq_nil_or_concat u with rfl | ⟨u, a, rfl⟩
    · exact (hk hu.symm).elim
    rcases List.eq_nil_or_concat v with rfl | ⟨v, b, rfl⟩
    · exact (hl hv.symm).elim
    simp only [List.concat_eq_append, DFA.h_append_singleton] at hu hv ⊢
    obtain rfl := hne _ _ a b hu hv
    exact accepted_suffix (hp _ _ a hu hv u rfl v rfl) [a]

/-! ## The finite certificate -/

/-- **The certificate conditions** (6)–(8) on a table `G`, for `C = G ∖ F`:
`C_{sj} = C_{is} = 0`, `C_{δ(i,a),δ(j,b)} = 0` for `a ≠ b`, and
`C_{δ(i,a),δ(j,a)} ≤ G_{ij}`. -/
structure CertificateConditions (G : S → S → Prop) : Prop where
  boundary_left : ∀ j, ¬ (G \ F) M.initial j
  boundary_right : ∀ i, ¬ (G \ F) i M.initial
  mismatch : ∀ i j (a b : A), a ≠ b → ¬ (G \ F) (M.step i a) (M.step j b)
  matching : ∀ i j (a : A), (G \ F) (M.step i a) (M.step j a) → G i j

variable {M F} in
/-- The mismatch and match conditions together: a residual cell entered by letters `a`, `b`
forces `a = b` and a predecessor in `G`. -/
theorem CertificateConditions.step {G : S → S → Prop} (hG : CertificateConditions M F G)
    {i j : S} {a b : A} (hg : G (M.step i a) (M.step j b)) (hf : ¬ F (M.step i a) (M.step j b)) :
    a = b ∧ G i j := by
  by_cases hab : a = b
  · subst hab
    exact ⟨rfl, hG.matching i j a ⟨hg, hf⟩⟩
  · exact (hG.mismatch i j a b hab ⟨hg, hf⟩).elim

/-- The certificate conditions from the boundary conditions and the combined step condition. -/
theorem CertificateConditions.of_step {G : S → S → Prop}
    (hl : ∀ j, G M.initial j → F M.initial j) (hr : ∀ i, G i M.initial → F i M.initial)
    (hs : ∀ i j a b, G (M.step i a) (M.step j b) → ¬ F (M.step i a) (M.step j b) →
      a = b ∧ G i j) : CertificateConditions M F G where
  boundary_left := fun j ⟨hg, hf⟩ => hf (hl j hg)
  boundary_right := fun i ⟨hg, hf⟩ => hf (hr i hg)
  mismatch := fun i j a b hab ⟨hg, hf⟩ => hab (hs i j a b hg hf).1
  matching := fun i j a ⟨hg, hf⟩ => (hs i j a a hg hf).2

/-- The good table satisfies the certificate conditions. -/
theorem good_certificate : CertificateConditions M F (Good M F) where
  boundary_left := residual_boundary_left M F
  boundary_right := residual_boundary_right M F
  mismatch := fun _ _ _ _ hab => residual_mismatch M F hab
  matching := fun _ _ _ hc => residual_match M F hc

/-- A table satisfying the certificate conditions contains only good cells. -/
theorem le_good_of_certificate {G : S → S → Prop}
    (hG : CertificateConditions M F G) : G ≤ Good M F := by
  classical
  intro i j hg u hu v hv
  rw [DFA.mem_L] at hu hv
  subst i
  subst j
  induction u using List.reverseRecOn generalizing v with
  | nil =>
    refine (accepted_nil_left M F v).mpr ?_
    by_contra hf
    exact hG.boundary_left _ ⟨hg, hf⟩
  | append_singleton u a ih =>
    induction v using List.reverseRecOn with
    | nil =>
      refine (accepted_nil_right M F _).mpr ?_
      by_contra hf
      exact hG.boundary_right _ ⟨hg, hf⟩
    | append_singleton v b _ =>
      rw [accepted_append_iff]
      by_cases hf : F (M.step (M.h u) a) (M.step (M.h v) b)
      · exact Or.inl hf
      · rw [DFA.h_append_singleton, DFA.h_append_singleton] at hg
        by_cases hab : a = b
        · subst hab
          exact Or.inr ⟨rfl, ih v (hG.matching _ _ _ ⟨hg, hf⟩)⟩
        · exact (hG.mismatch _ _ _ _ hab ⟨hg, hf⟩).elim

/-- **Proposition 8 (finite certificate), first sentence.** `𝓡_E ⊆ 𝓡_F` iff some table
`G ≥ E, F` satisfies the certificate conditions. -/
theorem certificate_iff (E : S → S → Prop) :
    Accepted M E ≤ Accepted M F ↔
      ∃ G, E ≤ G ∧ F ≤ G ∧ CertificateConditions M F G := by
  constructor
  · intro h
    exact ⟨Good M F, source_le_good M F h, target_le_good M F, good_certificate M F⟩
  · rintro ⟨G, hE, hF, hG⟩ u v ⟨x, y, w, rfl, rfl, hxy⟩
    exact accepted_suffix (le_good_of_certificate M F hG _ _ (hE _ _ hxy) x rfl y rfl) w

end Stackat
