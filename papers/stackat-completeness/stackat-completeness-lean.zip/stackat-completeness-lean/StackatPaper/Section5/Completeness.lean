import StackatPaper.AppendixB.WholeHeaderLaws
import StackatPaper.AppendixB.HeaderCompleteness
import StackatPaper.AppendixB.HeaderFieldOperations
import StackatPaper.Section5.Soundness

/-!
Section 5: Corollary 9 (completeness with fields), from the whole-header completeness of
Appendix B by expanding the primitive field operations (`Fields.finite_header_completeness`,
`Fields.finite_header_inequational_completeness`, `Fields.finite_header_equality_iff_derivable`).
-/

namespace Stackat.Fields

open scoped Computability

variable {A H K : Type} [Fintype H] [DecidableEq H] [KleeneAlgebra K]

private theorem header_derives_eval (p q : A → K) (t u : H → K)
    (hm : Headers.HeaderModel t u)
    (hpush : ∀ a, p a * q a = 1)
    (hne : ∀ a b, a ≠ b → p a * q b = 0)
    (hpop : ∀ a, q a * p a ≤ 1)
    (hp : ∀ h a, u h * p a = p a * u h)
    (hq : ∀ h a, u h * q a = q a * u h)
    {e f : Headers.Expr A H} (hd : Headers.Derives e f) :
    Headers.eval p q t u e = Headers.eval p q t u f := by
  induction hd with
  | refl => rfl
  | symm _ ih => exact ih.symm
  | trans _ _ ih ih' => exact ih.trans ih'
  | add_congr _ _ ih ih' => exact congrArg₂ (· + ·) ih ih'
  | mul_congr _ _ ih ih' => exact congrArg₂ (· * ·) ih ih'
  | star_congr _ ih => exact congrArg KStar.kstar ih
  | add_assoc => exact add_assoc _ _ _
  | add_comm => exact add_comm _ _
  | add_zero => exact add_zero _
  | add_idem => exact add_idem _
  | mul_assoc => exact mul_assoc _ _ _
  | one_mul => exact one_mul _
  | mul_one => exact mul_one _
  | zero_mul => exact zero_mul _
  | mul_zero => exact mul_zero _
  | mul_add => exact mul_add _ _ _
  | add_mul => exact add_mul _ _ _
  | star_unfold_left => exact one_add_mul_kstar
  | star_unfold_right => exact one_add_kstar_mul
  | star_induct_left _ ih =>
    apply le_antisymm
    · exact add_le (kstar_mul_le_self ((le_add_right le_rfl).trans (le_of_eq ih))) le_rfl
    · exact le_add_left le_rfl
  | star_induct_right _ ih =>
    apply le_antisymm
    · exact add_le (mul_kstar_le_self ((le_add_right le_rfl).trans (le_of_eq ih))) le_rfl
    · exact le_add_left le_rfl
  | push_pop a => exact hpush a
  | push_pop_ne a b h => exact hne a b h
  | pop_push a => exact le_antisymm (add_le (hpop a) le_rfl) (le_add_left le_rfl)
  | test_complete =>
    rw [Headers.eval_sum, Finset.sum_map_toList]
    exact hm.complete
  | test_assign h => exact hm.test_assign h
  | assign_test h => simpa using hm.assign_test h h
  | assign_test_ne h k hne => simpa [hne] using hm.assign_test h k
  | assign_assign h k => exact hm.assign_assign h k
  | assign_push h a => exact hp h a
  | assign_pop h a => exact hq h a

variable {n : Nat} {V : Fin n → Type} [∀ i, Fintype (V i)]

noncomputable def compile : Expr A V → Headers.Expr A (Header V)
  | .zero => 0
  | .one => 1
  | .push a => .push a
  | .pop a => .pop a
  | .test i v => by
      classical
      exact Headers.Expr.filter (fun h => decide (h i = v))
  | .assign i v => Headers.Expr.update (fun h => Function.update h i v)
  | .add e f => compile e + compile f
  | .mul e f => compile e * compile f
  | .star e => (compile e).star

theorem compile_denote (e : Expr A V) :
    ∀ s t, (compile e).denote s t ↔ e.denote s t := by
  induction e with
  | zero => exact fun _ _ => Iff.rfl
  | one => exact fun _ _ => Iff.rfl
  | push a => exact fun _ _ => Iff.rfl
  | pop a => exact fun _ _ => Iff.rfl
  | test i v => intro s t; simp [compile, Expr.denote]
  | assign i v => intro s t; simp [compile, Expr.denote]
  | add e f he hf => intro s t; exact or_congr (he s t) (hf s t)
  | mul e f he hf => intro s t; exact exists_congr fun m => and_congr (he s m) (hf m t)
  | star e he =>
    intro s t
    exact ⟨Relation.ReflTransGen.mono (fun s t => (he s t).mp),
      Relation.ReflTransGen.mono (fun s t => (he s t).mpr)⟩

private abbrev test (i : Fin n) (v : V i) : FreeAlgebra A V := FreeAlgebra.of (.test i v)
private abbrev assign (i : Fin n) (v : V i) : FreeAlgebra A V := FreeAlgebra.of (.assign i v)
private abbrev push (a : A) : FreeAlgebra A V := FreeAlgebra.of (.push a)
private abbrev pop (a : A) : FreeAlgebra A V := FreeAlgebra.of (.pop a)

private theorem of_sum (xs : List I) (f : I → Expr A V) :
    FreeAlgebra.of (Expr.sum xs f) = (xs.map (fun i => FreeAlgebra.of (f i))).sum := by
  induction xs with
  | nil => rfl
  | cons i xs ih =>
    simp only [Expr.sum, List.foldr_cons, FreeAlgebra.of_add, List.map_cons, List.sum_cons] at *
    rw [ih]

private theorem free_model : FieldModel (test (A := A) (V := V)) assign where
  complete i := by
    have h : FreeAlgebra.of (A := A) (V := V) (Expr.sum Finset.univ.toList (.test i)) = 1 :=
      Quotient.sound (Derives.test_complete i)
    rwa [of_sum, Finset.sum_map_toList] at h
  test_assign i v := Quotient.sound (.test_assign i v)
  assign_test i v := Quotient.sound (.assign_test i v)
  assign_test_ne i v w h := Quotient.sound (.assign_test_ne i v w h)
  assign_assign i v w := Quotient.sound (.assign_assign i v w)
  assign_comm i j v w h := Quotient.sound (.assign_comm i j v w h)
  assign_test_comm i j v w h := Quotient.sound (.assign_test_comm i j v w h)

private theorem compile_eval (e : Expr A V) :
    Headers.eval push pop (wholeTest test) (wholeAssign assign) (compile e) = FreeAlgebra.of e := by
  classical
  induction e with
  | zero => exact FreeAlgebra.of_zero.symm
  | one => exact FreeAlgebra.of_one.symm
  | push a => rfl
  | pop a => rfl
  | test i v =>
    simp only [compile, Headers.Expr.filter, Headers.eval_sum, Finset.sum_map_toList]
    have hx := expand_test test assign (free_model (A := A)) i v
    change _ = test (A := A) i v
    rw [hx]
    apply Finset.sum_congr rfl
    intro h _
    split <;> simp_all [Headers.eval]
  | assign i v =>
    simp only [compile, Headers.Expr.update, Headers.eval_sum, Finset.sum_map_toList]
    exact (expand_assign test assign (free_model (A := A)) i v).symm
  | add e f he hf => exact (congrArg₂ (· + ·) he hf).trans (FreeAlgebra.of_add e f).symm
  | mul e f he hf => exact (congrArg₂ (· * ·) he hf).trans (FreeAlgebra.of_mul e f).symm
  | star e he => exact (congrArg KStar.kstar he).trans (FreeAlgebra.of_star e).symm

/-- **Completeness with fields** (Corollary 9, equation form): every equation between expressions
with fields valid on `H × A*` is derivable in the per-field system. -/
theorem finite_header_completeness : Fields.Completeness := by
  intro A n V _ _ e f hef
  classical
  have hd := Headers.whole_header_completeness (compile e) (compile f)
    (funext fun s => funext fun t => propext ((compile_denote e s t).trans
      ((Eq.to_iff (congrFun (congrFun hef s) t)).trans (compile_denote f s t).symm)))
  have hx := header_derives_eval (push (A := A) (V := V)) pop
    (wholeTest test) (wholeAssign assign) (whole_model test assign free_model)
    FreeAlgebra.push_pop (fun a b h => FreeAlgebra.push_pop_ne h) FreeAlgebra.pop_push
    (fun h a => (prod_commute (fun i => assign i (h i)) (push a)
      (fun i => Quotient.sound (Derives.assign_push i (h i) a))).eq)
    (fun h a => (prod_commute (fun i => assign i (h i)) (pop a)
      (fun i => Quotient.sound (Derives.assign_pop i (h i) a))).eq) hd
  rw [compile_eval, compile_eval] at hx
  exact FreeAlgebra.of_eq_iff.mp hx

theorem finite_header_inequational_completeness : InequationalCompleteness := by
  intro A n V _ _ e f hef
  apply finite_header_completeness A n V (e + f) f
  exact funext fun s => funext fun t => propext ⟨fun h => h.elim (hef s t) id, Or.inr⟩

end Stackat.Fields

namespace Stackat.Fields

/-- **Corollary 9 (completeness with fields).** For a finite alphabet and finite field
domains, equality of the relations denoted by two expressions on `H × A*` is equivalent to
derivability. -/
theorem finite_header_equality_iff_derivable {A : Type} {n : ℕ} {V : Fin n → Type}
    [Finite A] [∀ i, Fintype (V i)] (e f : Expr A V) : R e = R f ↔ ⊢ e ≈ f :=
  ⟨finite_header_completeness A n V e f, fun h => finite_header_soundness h⟩

/-- **Corollary 9 (completeness with fields).** For a finite alphabet and finite field
domains, equality of the relations denoted by two expressions on `H × A*` is equivalent to
derivability; equivalently, semantic inclusion implies derivability of `e + f = f`. -/
theorem finite_header_completeness_both_forms {A : Type} {n : ℕ}
    {V : Fin n → Type} [Finite A] [∀ i, Fintype (V i)] (e f : Expr A V) :
    (R e = R f ↔ ⊢ e ≈ f) ∧ (R e ≤ R f → ⊢ e ≤ f) :=
  ⟨finite_header_equality_iff_derivable e f, finite_header_inequational_completeness A n V e f⟩

end Stackat.Fields
