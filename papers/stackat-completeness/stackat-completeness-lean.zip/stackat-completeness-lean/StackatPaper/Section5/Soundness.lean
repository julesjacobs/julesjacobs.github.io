import StackatPaper.Section5.Spec

/-!
Section 5: the field laws are sound in the concrete model (`Fields.finite_header_soundness`).
-/

namespace Stackat.Fields

private theorem closure_congr {R S : α → α → Prop} (h : ∀ x y, R x y ↔ S x y) :
    ∀ x y, Relation.ReflTransGen R x y ↔ Relation.ReflTransGen S x y := by
  intro x y
  exact ⟨Relation.ReflTransGen.mono (fun a b => (h a b).mp),
    Relation.ReflTransGen.mono (fun a b => (h a b).mpr)⟩

private theorem closure_induct_left {R S : α → α → Prop}
    (h : ∀ x z, (∃ y, R x y ∧ S y z) → S x z)
    {x y z} (hr : Relation.ReflTransGen R x y) (hs : S y z) : S x z := by
  induction hr using Relation.ReflTransGen.head_induction_on with
  | refl => exact hs
  | head hxy _ ih => exact h _ _ ⟨_, hxy, ih⟩

private theorem closure_induct_right {R S : α → α → Prop}
    (h : ∀ x z, (∃ y, S x y ∧ R y z) → S x z)
    {x y z} (hs : S x y) (hr : Relation.ReflTransGen R y z) : S x z := by
  induction hr with
  | refl => exact hs
  | tail _ hyz ih => exact h _ _ ⟨_, ih, hyz⟩

/-- Soundness, pointwise: a derivable equation relates the same configurations. -/
theorem finite_header_soundness_iff {A : Type} {n : Nat} {V : Fin n → Type}
    [∀ i, Fintype (V i)] {e f : Expr A V} (h : ⊢ e ≈ f) :
    ∀ s t, e.denote s t ↔ f.denote s t := by
  induction h with
  | refl => exact fun _ _ => Iff.rfl
  | symm _ ih => exact fun s t => (ih s t).symm
  | trans _ _ ih₁ ih₂ => exact fun s t => (ih₁ s t).trans (ih₂ s t)
  | add_congr _ _ ih₁ ih₂ =>
    exact fun s t => or_congr (ih₁ s t) (ih₂ s t)
  | mul_congr _ _ ih₁ ih₂ =>
    exact fun s t => exists_congr fun m => and_congr (ih₁ s m) (ih₂ m t)
  | star_congr _ ih => exact closure_congr ih
  | add_assoc => exact fun _ _ => or_assoc
  | add_comm => exact fun _ _ => or_comm
  | add_zero => exact fun _ _ => by simp [Expr.denote]
  | add_idem => exact fun _ _ => by simp [Expr.denote]
  | mul_assoc e f g =>
    intro s t
    change (∃ m, (∃ n, e.denote s n ∧ f.denote n m) ∧ g.denote m t) ↔
      (∃ n, e.denote s n ∧ ∃ m, f.denote n m ∧ g.denote m t)
    constructor
    · rintro ⟨m, ⟨n, he, hf⟩, hg⟩
      exact ⟨n, he, m, hf, hg⟩
    · rintro ⟨n, he, m, hf, hg⟩
      exact ⟨m, ⟨n, he, hf⟩, hg⟩
  | one_mul e => exact fun s t => by simp [Expr.denote]
  | mul_one e => exact fun s t => by simp [Expr.denote]
  | zero_mul e => exact fun s t => by simp [Expr.denote]
  | mul_zero e => exact fun s t => by simp [Expr.denote]
  | mul_add e f g =>
    intro s t
    change (∃ m, e.denote s m ∧ (f.denote m t ∨ g.denote m t)) ↔ _
    simp only [and_or_left, exists_or]
    rfl
  | add_mul e f g =>
    intro s t
    change (∃ m, (e.denote s m ∨ f.denote s m) ∧ g.denote m t) ↔ _
    simp only [or_and_right, exists_or]
    rfl
  | star_unfold_left e =>
    intro s t
    exact (Relation.ReflTransGen.cases_head_iff).symm
  | star_unfold_right e =>
    intro s t
    change (s = t ∨ ∃ m, Relation.ReflTransGen e.denote s m ∧ e.denote m t) ↔ _
    rw [eq_comm]
    exact (Relation.ReflTransGen.cases_tail_iff _ _ _).symm
  | star_induct_left h ih =>
    intro s t
    constructor
    · rintro (⟨m, hr, hf⟩ | hf)
      · exact closure_induct_left (fun x z h => (ih x z).mp (Or.inl h)) hr hf
      · exact hf
    · exact Or.inr
  | star_induct_right h ih =>
    intro s t
    constructor
    · rintro (⟨m, hf, hr⟩ | hf)
      · exact closure_induct_right (fun x z h => (ih x z).mp (Or.inl h)) hf hr
      · exact hf
    · exact Or.inr
  | push_pop a =>
    rintro ⟨i,s⟩ ⟨j,t⟩
    simp [Expr.denote, Prod.mk.injEq]
    aesop
  | push_pop_ne a b hab =>
    rintro ⟨i,s⟩ ⟨j,t⟩
    simp [Expr.denote, Ne.symm hab]
  | pop_push a =>
    rintro ⟨i,s⟩ ⟨j,t⟩
    simp [Expr.denote, Prod.mk.injEq]
    aesop
  | test_complete i =>
    intro s t
    have hs : ∀ xs : List (V i), ∀ f : V i → Expr A V, ∀ s t,
        (Expr.sum xs f).denote s t ↔ ∃ v ∈ xs, (f v).denote s t := by
      intro xs f s t
      induction xs with
      | nil => simp [Expr.sum, Expr.denote]
      | cons v xs ih => simpa [Expr.sum, Expr.denote] using or_congr Iff.rfl ih
    simp [hs, Expr.denote]
  | test_assign i v =>
    rintro ⟨h,s⟩ ⟨k,t⟩
    simp [Expr.denote, Prod.mk.injEq]
    aesop
  | assign_test i v =>
    rintro ⟨h,s⟩ ⟨k,t⟩
    simp [Expr.denote]
    rintro rfl rfl
    simp
  | assign_test_ne i v w hvw =>
    rintro ⟨h,s⟩ ⟨k,t⟩
    simp [Expr.denote]
    rintro rfl rfl
    simpa using hvw
  | assign_assign i v w =>
    rintro ⟨h,s⟩ ⟨k,t⟩
    simp [Expr.denote, and_comm]
  | test_comm i j v w =>
    intro s t
    simp [Expr.denote]
    aesop
  | assign_comm i j v w hij =>
    rintro ⟨h,s⟩ ⟨k,t⟩
    simp [Expr.denote, Function.update_comm hij]
  | assign_test_comm i j v w hij =>
    rintro ⟨h,s⟩ ⟨k,t⟩
    simp [Expr.denote, and_comm, and_left_comm]
    rintro rfl rfl
    simp [Function.update_of_ne hij.symm]
  | test_push i v a =>
    rintro ⟨h,s⟩ ⟨k,t⟩
    simp [Expr.denote, Prod.mk.injEq]
    aesop
  | test_pop i v a =>
    rintro ⟨h,s⟩ ⟨k,t⟩
    simp [Expr.denote, Prod.mk.injEq]
    aesop
  | assign_push i v a =>
    rintro ⟨h,s⟩ ⟨k,t⟩
    simp [Expr.denote, and_comm]
  | assign_pop i v a =>
    rintro ⟨h,s⟩ ⟨k,t⟩
    simp [Expr.denote, and_comm, eq_comm]

/-- **Soundness** of the field laws in the relational model. -/
theorem finite_header_soundness : Soundness :=
  fun h => funext fun s => funext fun t => propext (finite_header_soundness_iff h s t)

end Stackat.Fields
