import Mathlib.Logic.Relation
import Mathlib.Data.Fintype.Pi
import Mathlib.Order.Basic

/-!
Section 5: header expressions with finitely many finite-domain fields, their semantics on `H ×
A*`, the derivation system with the field laws (11), and the statements of soundness and
completeness.
-/

namespace Stackat.Fields

/-- Each of the finitely many fields has its own finite value domain. -/
abbrev Header {n : Nat} (V : Fin n → Type) := ∀ i, V i

inductive Expr (A : Type) {n : Nat} (V : Fin n → Type) where
  | zero
  | one
  | push (a : A)
  | pop (a : A)
  | test (i : Fin n) (v : V i)
  | assign (i : Fin n) (v : V i)
  | add (e f : Expr A V)
  | mul (e f : Expr A V)
  | star (e : Expr A V)

namespace Expr
instance : Zero (Expr A V) := ⟨zero⟩
instance : One (Expr A V) := ⟨one⟩
instance : Add (Expr A V) := ⟨add⟩
instance : Mul (Expr A V) := ⟨mul⟩

def sum (xs : List I) (f : I → Expr A V) : Expr A V :=
  xs.foldr (fun i e => f i + e) 0

def denote : Expr A V → (Header V × List A) → (Header V × List A) → Prop
  | .zero => fun _ _ => False
  | .one => Eq
  | .push a => fun s t => t.1 = s.1 ∧ t.2 = a :: s.2
  | .pop a => fun s t => t.1 = s.1 ∧ s.2 = a :: t.2
  | .test i v => fun s t => s.1 i = v ∧ s = t
  | .assign i v => fun s t => t.1 = Function.update s.1 i v ∧ t.2 = s.2
  | .add e f => fun s t => denote e s t ∨ denote f s t
  | .mul e f => fun s t => ∃ m, denote e s m ∧ denote f m t
  | .star e => Relation.ReflTransGen (denote e)
end Expr

/-- The relation of `e` on configurations `H × A*`. -/
abbrev R (e : Expr A V) : Header V × List A → Header V × List A → Prop :=
  e.denote

/-- Finite derivations from Kleene algebra, per-field laws, and stack laws.
Field indices are `Fin n`; value domains may differ between fields. -/
inductive Derives {A : Type} {n : Nat} {V : Fin n → Type} [∀ i, Fintype (V i)] :
    Expr A V → Expr A V → Prop where
  -- Equational reasoning.
  | refl (e) : Derives e e
  | symm : Derives e f → Derives f e
  | trans : Derives e f → Derives f g → Derives e g
  | add_congr : Derives e e' → Derives f f' → Derives (e + f) (e' + f')
  | mul_congr : Derives e e' → Derives f f' → Derives (e * f) (e' * f')
  | star_congr : Derives e f → Derives e.star f.star

  -- Idempotent semiring laws.
  | add_assoc (e f g) : Derives ((e + f) + g) (e + (f + g))
  | add_comm (e f) : Derives (e + f) (f + e)
  | add_zero (e) : Derives (e + 0) e
  | add_idem (e) : Derives (e + e) e
  | mul_assoc (e f g) : Derives ((e * f) * g) (e * (f * g))
  | one_mul (e) : Derives (1 * e) e
  | mul_one (e) : Derives (e * 1) e
  | zero_mul (e) : Derives (0 * e) 0
  | mul_zero (e) : Derives (e * 0) 0
  | mul_add (e f g) : Derives (e * (f + g)) (e * f + e * g)
  | add_mul (e f g) : Derives ((e + f) * g) (e * g + f * g)

  -- Kleene star laws.
  | star_unfold_left (e) : Derives (1 + e * e.star) e.star
  | star_unfold_right (e) : Derives (1 + e.star * e) e.star
  | star_induct_left : Derives (e * f + f) f → Derives (e.star * f + f) f
  | star_induct_right : Derives (f * e + f) f → Derives (f * e.star + f) f

  -- Stack laws.
  | push_pop (a : A) : Derives (.push a * .pop a) 1
  | push_pop_ne (a b : A) : a ≠ b → Derives (.push a * .pop b) 0
  | pop_push (a : A) : Derives (.pop a * .push a + 1) 1

  -- Per-field laws.
  | test_complete (i : Fin n) :
      Derives (Expr.sum Finset.univ.toList (.test i)) 1
  | test_assign (i : Fin n) (v : V i) :
      Derives (.test i v * .assign i v) (.test i v)
  | assign_test (i : Fin n) (v : V i) :
      Derives (.assign i v * .test i v) (.assign i v)
  | assign_test_ne (i : Fin n) (v w : V i) : v ≠ w →
      Derives (.assign i v * .test i w) 0
  | assign_assign (i : Fin n) (v w : V i) :
      Derives (.assign i v * .assign i w) (.assign i w)
  | test_comm (i j : Fin n) (v : V i) (w : V j) :
      Derives (.test i v * .test j w) (.test j w * .test i v)
  | assign_comm (i j : Fin n) (v : V i) (w : V j) : i ≠ j →
      Derives (.assign i v * .assign j w) (.assign j w * .assign i v)
  | assign_test_comm (i j : Fin n) (v : V i) (w : V j) : i ≠ j →
      Derives (.assign i v * .test j w) (.test j w * .assign i v)
  | test_push (i : Fin n) (v : V i) (a : A) :
      Derives (.test i v * .push a) (.push a * .test i v)
  | test_pop (i : Fin n) (v : V i) (a : A) :
      Derives (.test i v * .pop a) (.pop a * .test i v)
  | assign_push (i : Fin n) (v : V i) (a : A) :
      Derives (.assign i v * .push a) (.push a * .assign i v)
  | assign_pop (i : Fin n) (v : V i) (a : A) :
      Derives (.assign i v * .pop a) (.pop a * .assign i v)

/-- `⊢ e ≈ f`: the equation `e = f` is derivable with the field laws. -/
scoped notation:25 "⊢ " e:51 " ≈ " f:51 => Fields.Derives e f

/-- `⊢ e ≤ f`: the inequality `e ≤ f`, that is `e + f = f`, is derivable with the field laws. -/
scoped notation:25 "⊢ " e:51 " ≤ " f:51 => Fields.Derives (e + f) f

/-- Every derivable equation is valid in the relational semantics. -/
def Soundness : Prop :=
  ∀ {A : Type} {n : Nat} {V : Fin n → Type} [∀ i, Fintype (V i)]
    {e f : Expr A V}, (⊢ e ≈ f) → R e = R f

def Completeness : Prop :=
  ∀ (A : Type) (n : Nat) (V : Fin n → Type) [Finite A] [∀ i, Fintype (V i)]
    (e f : Expr A V), R e = R f → ⊢ e ≈ f

def InequationalCompleteness : Prop :=
  ∀ (A : Type) (n : Nat) (V : Fin n → Type) [Finite A] [∀ i, Fintype (V i)]
    (e f : Expr A V), R e ≤ R f → ⊢ e ≤ f

end Stackat.Fields
