import StackatPaper.RunningExample.Basic

/-!
# The running example: the tables `E`, `F`, `C`, `G`

Section 3 ("Running example: the shared table", "Running example: predecessor cells",
Figures 2(b) and 3) and Appendix D ("Verifying the Running Tables").

* `E = {s,β} × {s,β}`, `F = {(s,s), (s,β), (β,s)}`, `C = {(β,β), (α,α)}`, `G = F ∪ C`;
* `F` comes from the accepting sets `{s, β}` of `(ab)*` and `{s}` of `{ε}` (`F_iff_accepting`), and
  its cell relation is `R_f` (`accepted_F_iff`);
* `G` is the good table of the paper and of Lean (`good_iff : Good dfa F i j ↔ G i j`),
  and `C` is the residual table (`residual_iff : Residual dfa F i j ↔ C i j`);
* `(b, b)` is accepted through `F_ss` with unchanged suffix `b` (`accepted_b_b`), `(b, bb)` is not
  (`not_accepted_b_bb`), so `(⊥, ⊥)` is not good (`not_good_bot_bot`; with the witness,
  `bot_bot_cell`);
* `G` is a certificate (`certificate_G`), `F ∪ (E ∖ F)` is not (`not_certificate_E`); deleting
  `b` from `(β, β)` reaches `(α, α)`, outside `E` (`strip_b_ββ`); the four `a`-predecessors of
  `(α, α)` are the cells of `E` and must be good (`pred_a_αα_good`); and the predecessor cells of
  Figure 3(b) (`stripping`, from `pred_b_ββ`, `pred_a_ββ`, `pred_a_αα`, `pred_b_αα`).
-/

namespace Stackat.Example

open Letter St

/-- `E = {s,β} × {s,β}`. -/
def E (i j : St) : Prop := (i = .s ∨ i = .β) ∧ (j = .s ∨ j = .β)
/-- `F = {(s,s), (s,β), (β,s)}`. -/
def F (i j : St) : Prop :=
  (i = .s ∧ j = .s) ∨ (i = .s ∧ j = .β) ∨ (i = .β ∧ j = .s)
/-- `C = {(β,β), (α,α)}`. -/
def C (i j : St) : Prop := (i = .β ∧ j = .β) ∨ (i = .α ∧ j = .α)
/-- `G = F ∪ C`. -/
def G (i j : St) : Prop := F i j ∨ C i j

instance : DecidableRel E := fun _ _ => by unfold E; infer_instance
instance : DecidableRel F := fun _ _ => by unfold F; infer_instance
instance : DecidableRel C := fun _ _ => by unfold C; infer_instance
instance : DecidableRel G := fun _ _ => by unfold G; infer_instance

/-! ## Where `E` and `F` come from -/

/-- The accepting set `{s, β}` of `(ab)*`. -/
def accAB (i : St) : Prop := i = .s ∨ i = .β
/-- The accepting set `{s}` of `{ε}`. -/
def accEps (i : St) : Prop := i = .s

/-- `f = Q*·1 + 1·P* = q((ab)*) p(ε) + q(ε) p((ab)*)` selects `{s,β} × {s} ∪ {s} × {s,β}`. -/
theorem F_iff_accepting (i j : St) : F i j ↔ (accAB i ∧ accEps j) ∨ (accEps i ∧ accAB j) := by
  unfold F accAB accEps
  cases i <;> cases j <;> simp

/-- The cell relation of `F` (equation (6)) is `R_f`. -/
theorem accepted_F_iff (u v : List Letter) : Accepted dfa F u v ↔ R f u v := by
  rw [f_denote]
  constructor
  · rintro ⟨x, y, w, rfl, rfl, h⟩
    rw [F_iff_accepting] at h
    rcases h with ⟨hx, hy⟩ | ⟨hx, hy⟩
    · obtain ⟨k, rfl⟩ := (h_mem_sβ x).mp hx
      rw [accEps, h_eq_s] at hy; subst hy
      exact Or.inl ⟨k, by simp⟩
    · obtain ⟨k, rfl⟩ := (h_mem_sβ y).mp hy
      rw [accEps, h_eq_s] at hx; subst hx
      exact Or.inr ⟨k, by simp⟩
  · rintro (⟨k, rfl⟩ | ⟨k, rfl⟩)
    · refine ⟨abPow k, [], v, rfl, rfl, (F_iff_accepting _ _).mpr (Or.inl ⟨?_, rfl⟩)⟩
      exact (h_mem_sβ _).mpr ⟨k, rfl⟩
    · refine ⟨[], abPow k, u, rfl, rfl, (F_iff_accepting _ _).mpr (Or.inr ⟨rfl, ?_⟩)⟩
      exact (h_mem_sβ _).mpr ⟨k, rfl⟩

/-- Cell acceptance by `F` is acceptance by `f`, which is equality of remainders. -/
theorem accepted_F_iff_rem (u v : List Letter) : Accepted dfa F u v ↔ rem u = rem v :=
  (accepted_F_iff u v).trans (R_f_iff u v)

/-! ## The good table -/

/-- `G` satisfies the certificate conditions of Proposition 8 (checked cell by cell). -/
theorem certificate_G : CertificateConditions dfa F G :=
  CertificateConditions.of_step dfa F (by decide) (by decide) (by decide)

/-- `E ≤ G`. -/
theorem E_le_G (i j : St) : E i j → G i j := by
  revert i j; decide

/-- A cell holding a pair with different remainders is not good. -/
theorem not_good_of {i j : St} (u v : List Letter) (hu : dfa.h u = i) (hv : dfa.h v = j)
    (h : rem u ≠ rem v) : ¬ Good dfa F i j :=
  fun hg => h ((accepted_F_iff_rem u v).mp (hg u hu v hv))

/-- **The good table is `G = F ∪ C`.** -/
theorem good_iff (i j : St) : Good dfa F i j ↔ G i j := by
  constructor
  · intro hg
    by_contra hG
    have rep : ∀ k : St, ∃ u, dfa.h u = k ∧
        rem u = (match k with | .s => [] | .α => [.a] | .β => [] | .bot => [.b]) := by
      intro k; cases k
      · exact ⟨[], rfl, rfl⟩
      · exact ⟨[.a], rfl, rfl⟩
      · exact ⟨[.a, .b], rfl, rfl⟩
      · exact ⟨[.b], rfl, rfl⟩
    cases i <;> cases j <;> first
      | exact hG (by decide)
      | exact not_good_of [.b] [.b, .b] rfl rfl (by decide) hg
      | (obtain ⟨u, hu, hru⟩ := rep _
         obtain ⟨v, hv, hrv⟩ := rep _
         exact not_good_of u v hu hv (by rw [hru, hrv]; decide) hg)
  · exact fun h => le_good_of_certificate dfa F certificate_G i j h

/-- **The residual table is `C`.** -/
theorem residual_iff (i j : St) : Residual dfa F i j ↔ C i j := by
  rw [Stackat.residual_iff, good_iff]
  revert i j; decide

/-- The cell `(α, α)` lies outside `E` but is good: every pair `((ab)^m a, (ab)^n a)` is accepted
by `f`. -/
theorem αα_good : ¬ E .α .α ∧ Good dfa F .α .α ∧
    ∀ m n, R f (abPow m ++ [a]) (abPow n ++ [a]) := by
  refine ⟨by decide, (good_iff _ _).mpr (by decide), fun m n => ?_⟩
  rw [← accepted_F_iff]
  exact (good_iff _ _).mpr (by decide) _ ((h_eq_α _).mpr ⟨m, rfl⟩) _ ((h_eq_α _).mpr ⟨n, rfl⟩)

/-- `(b, b)` is accepted through `F_ss` with unchanged suffix `b`. -/
theorem accepted_b_b : Accepted dfa F [.b] [.b] := ⟨[], [], [.b], rfl, rfl, by decide⟩

/-- `(b, bb)` is not accepted. -/
theorem not_accepted_b_bb : ¬ Accepted dfa F [.b] [.b, .b] := by
  rw [accepted_F_iff_rem]; decide

theorem not_f_b_bb : ¬ R f [b] [b, b] := by
  rw [R_f_iff]; decide

/-- `(⊥, ⊥)` is not good, yet contains the accepted pair `(b, b)`. -/
theorem not_good_bot_bot : ¬ Good dfa F .bot .bot ∧ dfa.h [.b] = .bot ∧ Accepted dfa F [.b] [.b] :=
  ⟨fun hg => not_accepted_b_bb (hg _ rfl _ rfl), rfl, accepted_b_b⟩

/-- **Running example (Section 3.4, Appendix D).** `(⊥, ⊥)` is not good, since `b` and `bb` are
in `L_⊥` and `(b, bb) ∉ R_f`; yet `(b, b)` is accepted, through `F_ss` with unchanged suffix `b`:
the prefixes are `ε`, in `L_s`, and the suffix is `b`. -/
theorem bot_bot_cell :
    ¬ Good dfa F .bot .bot ∧ dfa.h [b] = .bot ∧ dfa.h [b, b] = .bot ∧
      ¬ R f [b] [b, b] ∧ Accepted dfa F [b] [b] ∧
      ([b] = [] ++ [b] ∧ dfa.h [] = .s ∧ F (dfa.h []) (dfa.h [])) :=
  ⟨not_good_bot_bot.1, rfl, rfl, not_f_b_bb, accepted_b_b, rfl, rfl, by decide⟩

/-! ## Remainders on the classes (Appendix D) -/

theorem rem_of_run_s {u : List Letter} (h : dfa.h u = .s) : rem u = [] := by
  rw [(h_eq_s u).mp h]; rfl

theorem rem_of_run_β {u : List Letter} (h : dfa.h u = .β) : rem u = [] := by
  obtain ⟨k, rfl⟩ := (h_eq_β u).mp h
  simpa using rem_abPow_append (k + 1) []

theorem rem_of_run_α {u : List Letter} (h : dfa.h u = .α) : rem u = [.a] := by
  obtain ⟨k, rfl⟩ := (h_eq_α u).mp h
  rw [rem_abPow_append]; rfl

/-- On `L_⊥` the remainder is neither `ε` nor `a`, and it varies (`b` and `bb`). -/
theorem rem_of_run_bot {u : List Letter} (h : dfa.h u = .bot) : rem u ≠ [] ∧ rem u ≠ [.a] := by
  obtain ⟨k, x, rfl | rfl⟩ := (h_eq_bot u).mp h <;> simp [rem]

theorem rem_varies_bot : dfa.h [.b] = .bot ∧ dfa.h [.b, .b] = .bot ∧
    rem [.b] ≠ rem [.b, .b] := by decide

/-- **The remainder on the classes**: `ε` on `L_s` and `L_β`, `a` on `L_α`. -/
theorem rem_on_classes :
    (∀ u ∈ dfa.L .s, rem u = []) ∧ (∀ u ∈ dfa.L .β, rem u = []) ∧
      ∀ u ∈ dfa.L .α, rem u = [a] :=
  ⟨fun _ h => rem_of_run_s h, fun _ h => rem_of_run_β h, fun _ h => rem_of_run_α h⟩

/-- **The remainder on `L_⊥`** is neither `ε` nor `a`, and it varies within the class: `b` and
`bb` are in `L_⊥` with different remainders. -/
theorem rem_on_bot :
    (∀ u ∈ dfa.L .bot, rem u ≠ [] ∧ rem u ≠ [a]) ∧
      [b] ∈ dfa.L .bot ∧ [b, b] ∈ dfa.L .bot ∧ rem [b] ≠ rem [b, b] :=
  ⟨fun _ h => rem_of_run_bot h, rem_varies_bot⟩

/-! ## Predecessor cells (Figure 3) -/

/-- Deleting a final `b` from a pair in `(β, β)` reaches only `(α, α)`. -/
theorem pred_b_ββ (i j : St) : (step i .b = .β ∧ step j .b = .β) ↔ (i = .α ∧ j = .α) := by
  revert i j; decide

/-- No pair in `(β, β)` ends in `a`. -/
theorem pred_a_ββ (i j : St) : ¬ (step i .a = .β ∧ step j .a = .β) := by
  revert i j; decide

/-- Deleting a final `a` from a pair in `(α, α)` reaches the four cells of `E`. -/
theorem pred_a_αα (i j : St) : (step i .a = .α ∧ step j .a = .α) ↔ E i j := by
  revert i j; decide

/-- No pair in `(α, α)` ends in `b`. -/
theorem pred_b_αα (i j : St) : ¬ (step i .b = .α ∧ step j .b = .α) := by
  revert i j; decide

/-- **Running example (Section 3.4).** Deleting the final `b` from a pair in `(β, β)` reaches
`(α, α)`, which lies outside `E`. -/
theorem strip_b_ββ :
    (∀ i j, (step i b = .β ∧ step j b = .β) ↔ (i = .α ∧ j = .α)) ∧ ¬ E .α .α :=
  ⟨pred_b_ββ, by decide⟩

/-- **Running example (Section 3.4).** The predecessor cells of `(α, α)` by the letter `a` are
the four cells of `E`, and all four must be good. -/
theorem pred_a_αα_good :
    (∀ i j, (step i a = .α ∧ step j a = .α) ↔ E i j) ∧
      ∀ i j, step i a = .α → step j a = .α → Good dfa F i j :=
  ⟨pred_a_αα, fun i j hi hj => residual_match dfa F (a := .a)
    (by rw [dfa_step, dfa_step, hi, hj]; exact (residual_iff _ _).mpr (by decide))⟩

/-- **Running example (Appendix D).** Stripping `b` from the residual cells `(β, β)` and
`(α, α)` reaches only `(α, α)`, and stripping `a` reaches the four cells of `E`. -/
theorem stripping :
    (∀ i j, (step i b = .β ∧ step j b = .β) ↔ (i = .α ∧ j = .α)) ∧
      (∀ i j, ¬ (step i a = .β ∧ step j a = .β)) ∧
      (∀ i j, (step i a = .α ∧ step j a = .α) ↔ E i j) ∧
      ∀ i j, ¬ (step i b = .α ∧ step j b = .α) :=
  ⟨pred_b_ββ, pred_a_ββ, pred_a_αα, pred_b_αα⟩

/-- Deleting the final `a` from a word in `L_α` leaves a word in `L_s` or `L_β`. -/
theorem pred_α (u : List Letter) :
    dfa.h (u ++ [a]) = .α ↔ (dfa.h u = .s ∨ dfa.h u = .β) := by
  rw [DFA.h_append_singleton, dfa_step]
  generalize dfa.h u = i
  cases i <;> decide

/-- `E ∖ F` alone does not satisfy the certificate conditions: `(β, β)` needs `(α, α)`. -/
theorem not_certificate_E :
    ¬ CertificateConditions dfa F (F ⊔ (E \ F)) := by
  intro h
  have := (h.step (i := .α) (j := .α) (a := .b) (b := .b)
    (show (F ⊔ (E \ F)) .β .β from Or.inr ⟨by decide, by decide⟩) (by decide)).2
  rcases this with h1 | ⟨h2, -⟩
  · exact absurd h1 (by decide)
  · exact absurd h2 (by decide)

end Stackat.Example
