import StackatPaper.RunningExample.Algebra
import StackatPaper.Section3.Words

/-!
# The running example: the worked example of Section 3.1

* `QP² = q_a q_b p_b p_a p_b p_a ≤ q_a p_a p_b p_a ≤ p_b p_a = P` (`QP2_le_mid_le_P`), the cut
  table (`cut_table`), the normalization `QPQP² = Q(PQ)P² = QP²` with `PQ = 1`
  (`QPQP2_normalization`), and `q_a q_b p_b p_a p_b p_a = q(ab)p(abab)` of Figure 1 (`QP2_eq_qp`);
* `Q^m P^n` sends `(ab)^m w` to `(ab)^n w` (`QmPn_R`); on `(ab)^m w`, `Q^{m-n}` has the same
  output when `m ≥ n`, and `P^{n-m}` when `n ≥ m` (`Qsub_Psub_R`); and `QP` restores only
  stacks beginning with `ab`, whereas `1` restores every stack (`QP_and_one_R`);
* the suffix-deletion example: `q_a p_a` accepts `(aa, aa)` and `(a, a)` but not `(ε, ε)`
  (`suffix_deletion_example`);
* every certificate for the example tables contains `G` (`certificate_contains_G`), in
  particular `(α, α)`, which is not in `E` (`αα_needed`).
-/

namespace Stackat

open FreeAlgebra

/-- `Expr` powers. -/
def Expr.npow (x : Expr A) : ℕ → Expr A
  | 0 => 1
  | n + 1 => x * Expr.npow x n

/-- `x ^ n` for expressions. -/
instance Expr.instPowNat : Pow (Expr A) ℕ := ⟨Expr.npow⟩


namespace Example

open Letter St

/-! ## The worked example of Section 3.1 -/

/-- `QP² ≤ q_a p_a p_b p_a`: one use of `q_b p_b ≤ 1`. -/
theorem QP2_le_mid : ⊢ Q * P ^ 2 ≤ .pop a * .push a * .push b * .push a := by
  apply of_eq_iff.mp
  rw [of_add]
  apply add_eq_right_iff_le.mpr
  show of (Q * (P * (P * 1))) ≤ _
  simp only [Q, P, of_mul, of_one, mul_one]
  calc of (.pop Letter.a) * of (.pop .b) * (of (.push .b) * of (.push .a) *
        (of (.push .b) * of (.push .a))) =
      of (.pop .a) * (of (.pop .b) * of (.push .b)) * of (.push .a) * of (.push .b) *
        of (.push .a) := by simp only [mul_assoc]
    _ ≤ of (.pop .a) * 1 * of (.push .a) * of (.push .b) * of (.push .a) :=
      mul_le_mul_left (mul_le_mul_left (mul_le_mul_left
        (mul_le_mul_right (FreeAlgebra.pop_push _) _) _) _) _
    _ = of (.pop .a) * of (.push .a) * of (.push .b) * of (.push .a) := by
      simp only [mul_one, mul_assoc]

/-- `q_a p_a p_b p_a ≤ p_b p_a = P`: one use of `q_a p_a ≤ 1`. -/
theorem mid_le_P : ⊢ .pop a * .push a * .push b * .push a ≤ P := by
  apply of_eq_iff.mp
  rw [of_add]
  apply add_eq_right_iff_le.mpr
  simp only [P, of_mul]
  calc of (.pop Letter.a) * of (.push .a) * of (.push .b) * of (.push .a) =
      of (.pop .a) * of (.push .a) * (of (.push .b) * of (.push .a)) := by simp only [mul_assoc]
    _ ≤ 1 * (of (.push .b) * of (.push .a)) := mul_le_mul_left (FreeAlgebra.pop_push _) _
    _ = _ := one_mul _

/-- Figure 1: `q_a q_b p_b p_a p_b p_a = q(ab) p(abab)`. -/
theorem QP2_eq_qp : ⊢ Q * P ^ 2 ≈ q [a, b] * p [a, b, a, b] := by
  apply of_eq_iff.mp
  show of (Q * (P * (P * 1))) = _
  simp only [Q, P, q, p, of_mul, of_one, one_mul, mul_one, mul_assoc]

/-- The cut of `QP²`: `ab | w ↦ abab | w`. -/
theorem cut_QP2 (u v : List Letter) :
    R (Q * P ^ 2) u v ↔ ∃ w, u = [a, b] ++ w ∧ v = [a, b, a, b] ++ w := by
  rw [← qp_R]
  exact soundness_iff QP2_eq_qp u v

/-- The cut of `q(a)p(aba)`: `a | bw ↦ aba | bw`. -/
theorem cut_mid (u v : List Letter) :
    R (q [a] * p [a, b, a]) u v ↔ ∃ w, u = [a] ++ w ∧ v = [a, b, a] ++ w :=
  qp_R _ _ _ _

/-- The cut of `P`: `ε | abw ↦ ab | abw`. -/
theorem cut_P (u v : List Letter) : R P u v ↔ ∃ w, u = [] ++ w ∧ v = [a, b] ++ w := by
  rw [P_denote]; simp

/-- `P = q(ε) p(ab)`. -/
theorem P_eq_qp : ⊢ P ≈ q [] * p [a, b] := by
  apply of_eq_iff.mp
  simp only [P, q, p, of_mul, of_one, one_mul]

/-- **The cut table.** On input `abw` all three programs produce `ababw`, each preserving a
different suffix: `w`, `bw`, `abw`. The three programs are `q(ab)p(abab)` (by normalization,
Figure 1), `q(a)p(aba)` and `q(ε)p(ab)`, which leave the suffix after the cut unchanged
(`qp_R`). -/
theorem cut_table (w : List Letter) :
    (⊢ Q * P ^ 2 ≈ q [a, b] * p [a, b, a, b]) ∧ (⊢ P ≈ q [] * p [a, b]) ∧
      R (Q * P ^ 2) ([a, b] ++ w) ([a, b, a, b] ++ w) ∧
      R (q [a] * p [a, b, a]) ([a] ++ b :: w) ([a, b, a] ++ b :: w) ∧
      R P ([] ++ a :: b :: w) ([a, b] ++ a :: b :: w) :=
  ⟨QP2_eq_qp, P_eq_qp, (cut_QP2 _ _).mpr ⟨w, rfl, rfl⟩, (cut_mid _ _).mpr ⟨_, rfl, rfl⟩,
    (cut_P _ _).mpr ⟨_, rfl, rfl⟩⟩

/-- `PQ = 1`. -/
theorem PQ_eq_one : ⊢ P * Q ≈ 1 := by
  apply of_eq_iff.mp
  simp only [P, Q, of_mul, of_one]
  calc of (.push Letter.b) * of (.push .a) * (of (.pop .a) * of (.pop .b)) =
      of (.push .b) * (of (.push .a) * of (.pop .a)) * of (.pop .b) := by simp only [mul_assoc]
    _ = 1 := by rw [FreeAlgebra.push_pop, mul_one, FreeAlgebra.push_pop]

theorem Qpow_denote (m : ℕ) (u v : List Letter) :
    R (Expr.npow Q m) u v ↔ u = abPow m ++ v := by
  induction m generalizing u with
  | zero => simp [Expr.npow, R, OfNat.ofNat, One.one]
  | succ m ih =>
    change (∃ x, R Q u x ∧ R (Expr.npow Q m) x v) ↔ _
    simp only [Q_denote, ih]
    constructor
    · rintro ⟨x, rfl, rfl⟩; rfl
    · intro h; exact ⟨_, h, rfl⟩

theorem Ppow_denote (n : ℕ) (u v : List Letter) :
    R (Expr.npow P n) u v ↔ v = abPow n ++ u := by
  induction n generalizing u v with
  | zero => simp [Expr.npow, R, OfNat.ofNat, One.one, eq_comm]
  | succ n ih =>
    change (∃ x, R P u x ∧ R (Expr.npow P n) x v) ↔ _
    simp only [P_denote, ih]
    constructor
    · rintro ⟨x, rfl, rfl⟩
      rw [abPow_succ', List.append_assoc]; rfl
    · intro h
      refine ⟨_, rfl, ?_⟩
      rw [h, abPow_succ', List.append_assoc]; rfl

/-- `Q^m P^n` sends `(ab)^m w` to `(ab)^n w`, and only such pairs. -/
theorem QmPn_R (m n : ℕ) (u v : List Letter) :
    R (Q ^ m * P ^ n) u v ↔ ∃ w, u = abPow m ++ w ∧ v = abPow n ++ w := by
  change (∃ x, R (Expr.npow Q m) u x ∧ R (Expr.npow P n) x v) ↔ _
  simp only [Qpow_denote, Ppow_denote]

/-- When `m ≥ n`, `Q^{m-n}` has the same output on `(ab)^m w`. -/
theorem Qsub_denote {m n : ℕ} (h : n ≤ m) (w : List Letter) :
    R (Expr.npow Q (m - n)) (abPow m ++ w) (abPow n ++ w) := by
  rw [Qpow_denote, ← List.append_assoc, ← abPow_add, Nat.sub_add_cancel h]

/-- When `n ≥ m`, `P^{n-m}` has the same output on `(ab)^m w`. -/
theorem Psub_denote {m n : ℕ} (h : m ≤ n) (w : List Letter) :
    R (Expr.npow P (n - m)) (abPow m ++ w) (abPow n ++ w) := by
  rw [Ppow_denote, ← List.append_assoc, ← abPow_add, Nat.sub_add_cancel h]

/-- `QP` restores only stacks beginning with `ab`, whereas `1` restores every stack. -/
theorem QP_denote (u v : List Letter) :
    R (Q * P) u v ↔ u = v ∧ ∃ w, u = .a :: .b :: w := by
  change (∃ x, R Q u x ∧ R P x v) ↔ _
  simp only [Q_denote, P_denote]
  constructor
  · rintro ⟨x, rfl, rfl⟩; exact ⟨rfl, x, rfl⟩
  · rintro ⟨rfl, w, rfl⟩; exact ⟨w, rfl, rfl⟩

/-- Suffix deletion requires exclusion of direct acceptance: `q_a p_a` accepts `(aa, aa)` with
unchanged suffix `a`; deleting it gives `(a, a)`, also accepted; deleting again gives `(ε, ε)`,
which is not. -/
theorem suffix_deletion_example :
    R (.pop a * .push a) ([a] ++ [a]) ([a] ++ [a]) ∧
      R (.pop a * .push a) [a] [a] ∧ ¬ R (.pop a * .push a) [] [] := by
  simp only [pop_push_ne_R]
  refine ⟨⟨[.a], rfl, rfl⟩, ⟨[], rfl, rfl⟩, ?_⟩
  rintro ⟨w, h, _⟩
  simp at h

/-- **Every certificate contains `G`.** Any table `G' ≥ E, F` satisfying the certificate
conditions contains `C`; in particular it contains `(α, α)`, which is not in `E`
(Section 3, "predecessor cells"; Appendix D). -/
theorem certificate_contains_G (G' : St → St → Prop) (hE : E ≤ G') (hF : F ≤ G')
    (h : CertificateConditions dfa F G') : G ≤ G' := by
  have hββ : G' .β .β := hE _ _ (by decide)
  have hαα : G' .α .α := (h.step (i := .α) (j := .α) (a := .b) (b := .b) hββ (by decide)).2
  rintro i j (hf | ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩)
  · exact hF _ _ hf
  · exact hββ
  · exact hαα

/-! ## The claims of the running example, one theorem each -/

/-- **Running example (Section 3.1).**
`QP² = q_a q_b p_b p_a p_b p_a ≤ q_a p_a p_b p_a ≤ p_b p_a = P`. -/
theorem QP2_le_mid_le_P :
    (⊢ Q * P ^ 2 ≤ .pop a * .push a * .push b * .push a) ∧
      (⊢ .pop a * .push a * .push b * .push a ≤ P) :=
  ⟨QP2_le_mid, mid_le_P⟩

/-- **Running example (Section 3.1).** Normalization (Figure 1) gives `QPQP² = Q(PQ)P² = QP²`,
using `PQ = 1`. -/
theorem QPQP2_normalization :
    (⊢ Q * P * Q * P ^ 2 ≈ Q * (P * Q) * P ^ 2) ∧
      (⊢ Q * (P * Q) * P ^ 2 ≈ Q * P ^ 2) ∧ (⊢ P * Q ≈ 1) := by
  refine ⟨?_, ?_, PQ_eq_one⟩
  · apply of_eq_iff.mp
    simp only [of_mul, mul_assoc]
  · apply of_eq_iff.mp
    have h := of_eq_iff.mpr PQ_eq_one
    rw [of_mul, of_one] at h
    simp only [of_mul]
    rw [h, mul_one]

/-- **Running example (Section 3.1).** On `(ab)^m w`, `Q^{m-n}` has the same output as `Q^m P^n`
when `m ≥ n`, and `P^{n-m}` does when `n ≥ m`. -/
theorem Qsub_Psub_R (m n : ℕ) (w : List Letter) :
    (n ≤ m → R (Q ^ (m - n)) (abPow m ++ w) (abPow n ++ w)) ∧
      (m ≤ n → R (P ^ (n - m)) (abPow m ++ w) (abPow n ++ w)) :=
  ⟨fun h => Qsub_denote h w, fun h => Psub_denote h w⟩

/-- **Running example (Section 3.1).** `QP` restores only stacks beginning with `ab`, whereas `1`
restores every stack. -/
theorem QP_and_one_R (u v : List Letter) :
    (R (Q * P) u v ↔ u = v ∧ ∃ w, u = a :: b :: w) ∧ (R 1 u v ↔ u = v) :=
  ⟨QP_denote u v, Iff.rfl⟩

/-- **Running example (Appendix D).** The cell `(α, α)` is needed to close the certificate under
predecessors: every table `G' ≥ E, F` satisfying the certificate conditions contains `G`, hence
`(α, α)`, which does not occur in `E`. -/
theorem αα_needed :
    (∀ G' : St → St → Prop,
        E ≤ G' → F ≤ G' → CertificateConditions dfa F G' → G ≤ G') ∧
      G .α .α ∧ ¬ E .α .α :=
  ⟨certificate_contains_G, by decide, by decide⟩

end Example

end Stackat
