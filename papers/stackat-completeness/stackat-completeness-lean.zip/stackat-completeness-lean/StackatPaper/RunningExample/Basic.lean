import StackatPaper.Section4.Derivation
import StackatPaper.Section3.TargetTable

/-!
# The running example: alphabet, shared DFA, classes, expressions, relations

The running example of the completeness paper (Section 3 and Appendix D, "Verifying the Running
Tables"). Alphabet `A = {a, b}`, `Q = q_a q_b`, `P = p_b p_a`, `e = Q*P*`, `f = Q* + P*`.

* `dfa`: the four-state shared DFA of Figure 2(a), states `s, α, β, ⊥` (`St.bot` is `⊥`);
* the classes `L_s = {ε}`, `L_β = (ab)⁺`, `L_α = (ab)*a`, `L_⊥ = (ab)*(b + aa)A*`
  (`h_eq_s`, `h_eq_β`, `h_eq_α`, `h_eq_bot`);
* the remainder `ρ` (`rem`), with `u = (ab)^k ρ(u)` and `k` maximal (`rem_eq_iff`);
* the relations of `Q*`, `P*`, `e`, `f`; the remainder characterization
  `(u, v) ∈ R_f ↔ ρ(u) = ρ(v)` (`R_f_iff`) and `R_e = R_f` (`R_e_eq_R_f`).
-/

namespace Stackat.Example

/-- The alphabet `{a, b}`. -/
inductive Letter
  | a
  | b
  deriving DecidableEq, Repr

instance : Fintype Letter := ⟨{.a, .b}, by intro x; cases x <;> simp⟩

theorem sum_letter {K : Type*} [AddCommMonoid K] (g : Letter → K) :
    ∑ c, g c = g .a + g .b := by
  change ({.a, .b} : Finset Letter).sum g = _
  rw [Finset.sum_insert (by decide), Finset.sum_singleton]

/-- The states of the shared DFA of Figure 2(a): `s`, `α`, `β`, `⊥`. -/
inductive St
  | s
  | α
  | β
  | bot
  deriving DecidableEq, Repr

instance : Fintype St := ⟨{.s, .α, .β, .bot}, by intro x; cases x <;> simp⟩

theorem sum_st {K : Type*} [AddCommMonoid K] (g : St → K) :
    ∑ i, g i = g .s + (g .α + (g .β + g .bot)) := by
  change ({.s, .α, .β, .bot} : Finset St).sum g = _
  rw [Finset.sum_insert (by decide), Finset.sum_insert (by decide), Finset.sum_insert (by decide),
    Finset.sum_singleton]

open Letter St

/-- The transitions of Figure 2(a). -/
def step : St → Letter → St
  | .s, .a => .α
  | .s, .b => .bot
  | .α, .a => .bot
  | .α, .b => .β
  | .β, .a => .α
  | .β, .b => .bot
  | .bot, _ => .bot

/-- The shared DFA of Figure 2(a); all four states are reachable. -/
def dfa : DFA Letter St where
  initial := .s
  step := step
  reachable
    | .s => ⟨[], rfl⟩
    | .α => ⟨[a], rfl⟩
    | .β => ⟨[a, b], rfl⟩
    | .bot => ⟨[b], rfl⟩

@[simp] theorem dfa_initial : dfa.initial = .s := rfl
@[simp] theorem dfa_step (i : St) (c : Letter) : dfa.step i c = step i c := rfl

/-! ## Words `(ab)^k` -/

/-- The word `(ab)^k`. -/
def abPow : ℕ → List Letter
  | 0 => []
  | k + 1 => a :: b :: abPow k

@[simp] theorem abPow_zero : abPow 0 = [] := rfl
@[simp] theorem abPow_succ (k : ℕ) : abPow (k + 1) = .a :: .b :: abPow k := rfl

theorem abPow_add (m n : ℕ) : abPow (m + n) = abPow m ++ abPow n := by
  induction m with
  | zero => simp
  | succ m ih => rw [Nat.succ_add, abPow_succ, abPow_succ, ih]; rfl

theorem abPow_succ' (k : ℕ) : abPow (k + 1) = abPow k ++ [.a, .b] := by
  rw [abPow_add]; rfl

theorem run_append (u w : List Letter) : dfa.h (u ++ w) = w.foldl step (dfa.h u) := by
  simp only [DFA.h, List.foldl_append]; rfl

theorem foldl_bot (w : List Letter) : w.foldl step .bot = .bot := by
  induction w with
  | nil => rfl
  | cons c w ih => cases c <;> exact ih

theorem foldl_β_abPow (k : ℕ) : (abPow k).foldl step .β = .β := by
  induction k with
  | zero => rfl
  | succ k ih => exact ih

theorem run_abPow (k : ℕ) : dfa.h (abPow (k + 1)) = .β := foldl_β_abPow k

/-! ## The classes -/

/-- The classes of the paper, as predicates on words: `L_s = {ε}`, `L_α = (ab)*a`,
`L_β = (ab)⁺`, `L_⊥ = (ab)*(b + aa)A*`. -/
def cls : St → List Letter → Prop
  | .s, u => u = []
  | .α, u => ∃ k, u = abPow k ++ [.a]
  | .β, u => ∃ k, u = abPow (k + 1)
  | .bot, u => ∃ k x, u = abPow k ++ .b :: x ∨ u = abPow k ++ .a :: .a :: x

theorem cls_run (u : List Letter) : cls (dfa.h u) u := by
  induction u using List.reverseRecOn with
  | nil => rfl
  | append_singleton u c ih =>
    rw [DFA.h_append_singleton, dfa_step]
    generalize hi : dfa.h u = i at ih
    cases i <;> cases c
    · -- s, a
      change u = [] at ih; subst ih; exact ⟨0, rfl⟩
    · change u = [] at ih; subst ih; exact ⟨0, [], Or.inl rfl⟩
    · obtain ⟨k, rfl⟩ := ih; exact ⟨k, [], Or.inr (by simp)⟩
    · obtain ⟨k, rfl⟩ := ih; exact ⟨k, by rw [abPow_succ']; simp⟩
    · obtain ⟨k, rfl⟩ := ih; exact ⟨k + 1, rfl⟩
    · obtain ⟨k, rfl⟩ := ih; exact ⟨k + 1, [], Or.inl rfl⟩
    · obtain ⟨k, x, rfl | rfl⟩ := ih
      · exact ⟨k, x ++ [.a], Or.inl (by simp)⟩
      · exact ⟨k, x ++ [.a], Or.inr (by simp)⟩
    · obtain ⟨k, x, rfl | rfl⟩ := ih
      · exact ⟨k, x ++ [.b], Or.inl (by simp)⟩
      · exact ⟨k, x ++ [.b], Or.inr (by simp)⟩

theorem run_abPow_append (k : ℕ) (w : List Letter) :
    dfa.h (abPow k ++ w) = w.foldl step (if k = 0 then .s else .β) := by
  rw [run_append]
  cases k with
  | zero => rfl
  | succ k => rw [run_abPow]; rfl

/-- `L_s = {ε}`. -/
theorem h_eq_s (u : List Letter) : dfa.h u = .s ↔ u = [] := by
  constructor
  · intro h; have := cls_run u; rwa [h] at this
  · rintro rfl; rfl

/-- `L_β = (ab)⁺`. -/
theorem h_eq_β (u : List Letter) : dfa.h u = .β ↔ ∃ k, u = abPow (k + 1) := by
  constructor
  · intro h; have := cls_run u; rwa [h] at this
  · rintro ⟨k, rfl⟩; exact run_abPow k

/-- `L_α = (ab)*a`. -/
theorem h_eq_α (u : List Letter) : dfa.h u = .α ↔ ∃ k, u = abPow k ++ [.a] := by
  constructor
  · intro h; have := cls_run u; rwa [h] at this
  · rintro ⟨k, rfl⟩
    rw [run_abPow_append]; split <;> rfl

/-- `L_⊥ = (ab)*(b + aa)A*`. -/
theorem h_eq_bot (u : List Letter) :
    dfa.h u = .bot ↔ ∃ k x, u = abPow k ++ .b :: x ∨ u = abPow k ++ .a :: .a :: x := by
  constructor
  · intro h; have := cls_run u; rwa [h] at this
  · rintro ⟨k, x, rfl | rfl⟩
    · rw [run_abPow_append]; split
      · exact foldl_bot x
      · exact foldl_bot x
    · rw [run_abPow_append]; split
      · exact foldl_bot x
      · exact foldl_bot x

/-- The accepting set `{s, β}` recognizes `(ab)*`. -/
theorem h_mem_sβ (u : List Letter) :
    (dfa.h u = .s ∨ dfa.h u = .β) ↔ ∃ k, u = abPow k := by
  rw [h_eq_s, h_eq_β]
  constructor
  · rintro (rfl | ⟨k, rfl⟩)
    · exact ⟨0, rfl⟩
    · exact ⟨k + 1, rfl⟩
  · rintro ⟨k, rfl⟩
    cases k with
    | zero => exact Or.inl rfl
    | succ k => exact Or.inr ⟨k, rfl⟩

/-- **The classes of the shared DFA**: `L_s = {ε}`, `L_β = (ab)⁺`, `L_α = (ab)*a`, and
`L_⊥ = (ab)*(b + aa)A*`. -/
theorem classes :
    dfa.L .s = {[]} ∧ dfa.L .β = {u | ∃ k, u = abPow (k + 1)} ∧
      dfa.L .α = {u | ∃ k, u = abPow k ++ [a]} ∧
      dfa.L .bot =
        {u | ∃ k x, u = abPow k ++ b :: x ∨ u = abPow k ++ a :: a :: x} :=
  ⟨Set.ext h_eq_s, Set.ext h_eq_β, Set.ext h_eq_α, Set.ext h_eq_bot⟩

/-- **The accepting sets**: `{s, β}` accepts `(ab)*` and `{s}` accepts `{ε}`. -/
theorem accepting_sets :
    dfa.L .s ∪ dfa.L .β = {u | ∃ k, u = abPow k} ∧ dfa.L .s = {[]} :=
  ⟨Set.ext h_mem_sβ, Set.ext h_eq_s⟩

/-! ## The remainder `ρ` -/

/-- The remainder: `u = (ab)^k ρ(u)` with `k` maximal. -/
def rem : List Letter → List Letter
  | [] => []
  | [.a] => [.a]
  | .a :: .a :: w => .a :: .a :: w
  | .a :: .b :: w => rem w
  | .b :: w => .b :: w

@[simp] theorem rem_abPow_append (k : ℕ) (w : List Letter) : rem (abPow k ++ w) = rem w := by
  induction k with
  | zero => rfl
  | succ k ih => exact ih

/-- A word not starting with `ab` is its own remainder. -/
theorem rem_of_not_ab {r : List Letter} (h : ¬ ∃ w, r = .a :: .b :: w) : rem r = r := by
  match r, h with
  | [], _ => rfl
  | [.a], _ => rfl
  | .a :: .a :: w, _ => rfl
  | .a :: .b :: w, h => exact (h ⟨w, rfl⟩).elim
  | .b :: w, _ => rfl

theorem rem_not_ab (u : List Letter) : ¬ ∃ w, rem u = .a :: .b :: w := by
  intro h
  induction u using rem.induct with
  | case1 => simp [rem] at h
  | case2 => simp [rem] at h
  | case3 w => simp [rem] at h
  | case4 w ih => exact ih h
  | case5 w => simp [rem] at h

theorem exists_abPow_rem (u : List Letter) : ∃ k, u = abPow k ++ rem u := by
  induction u using rem.induct with
  | case1 => exact ⟨0, rfl⟩
  | case2 => exact ⟨0, rfl⟩
  | case3 w => exact ⟨0, rfl⟩
  | case4 w ih =>
    obtain ⟨k, hk⟩ := ih
    exact ⟨k + 1, by rw [rem, abPow_succ, List.cons_append, List.cons_append, ← hk]⟩
  | case5 w => exact ⟨0, rfl⟩

/-- **The remainder.** `ρ(u) = r` exactly when `u = (ab)^k r` for some `k` and `r` does not start
with `ab` (that is, `k` is maximal). -/
theorem rem_eq_iff (u r : List Letter) :
    rem u = r ↔ (∃ k, u = abPow k ++ r) ∧ ¬ ∃ w, r = a :: b :: w := by
  constructor
  · rintro rfl
    exact ⟨exists_abPow_rem u, rem_not_ab u⟩
  · rintro ⟨⟨k, rfl⟩, h⟩
    rw [rem_abPow_append, rem_of_not_ab h]

/-! ## Expressions -/

/-- `Q = q_a q_b`: pop `a`, then pop `b`. -/
def Q : Expr Letter := .pop a * .pop b
/-- `P = p_b p_a`: push `b`, then push `a`. -/
def P : Expr Letter := .push b * .push a
/-- `e = Q*P*`. -/
def e : Expr Letter := Q.star * P.star
/-- `f = Q* + P*`. -/
def f : Expr Letter := Q.star + P.star

theorem Q_denote (u v : List Letter) : R Q u v ↔ u = .a :: .b :: v := by
  simp [Q, R, HMul.hMul, Mul.mul]

theorem P_denote (u v : List Letter) : R P u v ↔ v = .a :: .b :: u := by
  simp [P, R, HMul.hMul, Mul.mul]

/-- `Q*` pops a power of `ab`. -/
theorem Qstar_denote (u v : List Letter) : R Q.star u v ↔ ∃ k, u = abPow k ++ v := by
  rw [show R Q.star = _ from R_star Q]
  constructor
  · intro h
    induction h using Relation.ReflTransGen.head_induction_on with
    | refl => exact ⟨0, rfl⟩
    | head hxy _ ih =>
      obtain ⟨k, rfl⟩ := ih
      rw [Q_denote] at hxy
      exact ⟨k + 1, by rw [hxy]; rfl⟩
  · rintro ⟨k, rfl⟩
    induction k with
    | zero => exact .refl
    | succ k ih => exact .head ((Q_denote _ _).mpr rfl) ih

/-- `P*` pushes a power of `ab`. -/
theorem Pstar_denote (u v : List Letter) : R P.star u v ↔ ∃ k, v = abPow k ++ u := by
  rw [show R P.star = _ from R_star P]
  constructor
  · intro h
    induction h with
    | refl => exact ⟨0, rfl⟩
    | tail _ hyz ih =>
      obtain ⟨k, rfl⟩ := ih
      rw [P_denote] at hyz
      exact ⟨k + 1, by rw [hyz]; rfl⟩
  · rintro ⟨k, rfl⟩
    induction k with
    | zero => exact .refl
    | succ k ih => exact .tail ih ((P_denote _ _).mpr rfl)

theorem f_denote (u v : List Letter) :
    R f u v ↔ (∃ k, u = abPow k ++ v) ∨ ∃ k, v = abPow k ++ u := by
  change R Q.star u v ∨ R P.star u v ↔ _
  rw [Qstar_denote, Pstar_denote]

theorem e_denote (u v : List Letter) :
    R e u v ↔ ∃ m n w, u = abPow m ++ w ∧ v = abPow n ++ w := by
  change (∃ x, R Q.star u x ∧ R P.star x v) ↔ _
  simp only [Qstar_denote, Pstar_denote]
  constructor
  · rintro ⟨w, ⟨m, hm⟩, ⟨n, hn⟩⟩
    exact ⟨m, n, w, hm, hn⟩
  · rintro ⟨m, n, w, hm, hn⟩
    exact ⟨w, ⟨m, hm⟩, ⟨n, hn⟩⟩

/-- **The remainder characterization** (Appendix D): `(u, v) ∈ R_f ↔ ρ(u) = ρ(v)`. -/
theorem R_f_iff (u v : List Letter) : R f u v ↔ rem u = rem v := by
  rw [f_denote]
  constructor
  · rintro (⟨k, rfl⟩ | ⟨k, rfl⟩) <;> simp
  · intro h
    obtain ⟨m, hm⟩ := exists_abPow_rem u
    obtain ⟨n, hn⟩ := exists_abPow_rem v
    rcases le_total n m with hle | hle
    · left
      obtain ⟨d, rfl⟩ := Nat.exists_eq_add_of_le hle
      refine ⟨d, ?_⟩
      rw [hm, hn, h, add_comm, abPow_add, List.append_assoc]
    · right
      obtain ⟨d, rfl⟩ := Nat.exists_eq_add_of_le hle
      refine ⟨d, ?_⟩
      rw [hm, hn, h, add_comm, abPow_add, List.append_assoc]

/-- `R_e = R_f` (Section 3, end of the running example). -/
theorem R_e_eq_R_f : R e = R f := by
  funext u v
  apply propext
  rw [e_denote, R_f_iff]
  constructor
  · rintro ⟨m, n, w, rfl, rfl⟩; simp
  · intro h
    obtain ⟨m, hm⟩ := exists_abPow_rem u
    obtain ⟨n, hn⟩ := exists_abPow_rem v
    exact ⟨m, n, rem u, hm, h ▸ hn⟩

end Stackat.Example
