import StackatPaper.RunningExample.Tables
import StackatPaper.Section4.Derivation

/-!
# The running example: transition matrices and the local inequality

Section 4 and Appendix D.5 ("The Running Example's Derivation"), in every Kleene algebra `K`.

* `T c`: `(T_c)_{ij} = 1` exactly when `δ(i,c) = j`; `X = Σ_c q_c T_c` and `Y = Σ_c p_c T_cᵀ`
  are Lean's `popMatrix dfa q` and `pushMatrix dfa p`;
* `T_a C T_aᵀ = E`, `T_b C T_bᵀ = Δ_α`, `T_a C T_bᵀ = T_b C T_aᵀ = 0` (`T_products`);
* `XCY = q_a p_a E + q_b p_b Δ_α ≤ E + Δ_α = F + C` (`XCY_eq_le`; `XCY_le` is `XCY ≤ F + C`);
* the zero initial row and column of `C` (`C_row_col_s`);
* the reversed edges of Figure 4 (`bridge_edges`).
-/

namespace Stackat.Example

open Letter St

variable {K : Type*} [KleeneAlgebra K]

/-- `(T_c)_{ij} = 1` exactly when `δ(i,c) = j`. -/
noncomputable def T (c : Letter) : Matrix St St K :=
  boolMatrix (fun i j => step i c = j)

/-- `Δ_α`: the only nonzero entry is at `(α, α)`. -/
noncomputable def Δα : Matrix St St K := boolMatrix (fun i j => i = .α ∧ j = .α)

theorem TaCTa : T (K := K) .a * boolMatrix C * (T .a).transpose = boolMatrix E := by
  ext i j
  cases i <;> cases j <;>
    simp [Matrix.mul_apply, sum_st, T, boolMatrix, bit, step, C, E]

theorem TbCTb : T (K := K) .b * boolMatrix C * (T .b).transpose = Δα := by
  ext i j
  cases i <;> cases j <;>
    simp [Matrix.mul_apply, sum_st, T, Δα, boolMatrix, bit, step, C]

theorem TaCTb : T (K := K) .a * boolMatrix C * (T .b).transpose = 0 := by
  ext i j
  cases i <;> cases j <;>
    simp [Matrix.mul_apply, sum_st, T, boolMatrix, bit, step, C]

theorem TbCTa : T (K := K) .b * boolMatrix C * (T .a).transpose = 0 := by
  ext i j
  cases i <;> cases j <;>
    simp [Matrix.mul_apply, sum_st, T, boolMatrix, bit, step, C]

/-- **Running example (Appendix D).** `T_a C T_aᵀ = E`, `T_b C T_bᵀ = Δ_α`, and
`T_a C T_bᵀ = T_b C T_aᵀ = 0`. -/
theorem T_products :
    T (K := K) a * boolMatrix C * (T a).transpose = boolMatrix E ∧
      T (K := K) b * boolMatrix C * (T b).transpose = Δα ∧
      T (K := K) a * boolMatrix C * (T b).transpose = 0 ∧
      T (K := K) b * boolMatrix C * (T a).transpose = 0 :=
  ⟨TaCTa, TbCTb, TaCTb, TbCTa⟩

/-- `XCY = q_a p_a E + q_b p_b Δ_α` (Appendix D). -/
theorem XCY_eq (p q : Letter → K) :
    popMatrix dfa q * boolMatrix C * pushMatrix dfa p =
      fun i j => q .a * p .a * boolMatrix (K := K) E i j + q .b * p .b * Δα i j := by
  ext i j
  erw [mul_push]
  simp only [pop_mul, sum_letter, dfa_step]
  cases i <;> cases j <;> simp [boolMatrix, bit, step, C, E, Δα]

/-- `E + Δ_α = F + C`. -/
theorem E_add_Δα : boolMatrix (K := K) E + Δα = boolMatrix F + boolMatrix C := by
  ext i j
  cases i <;> cases j <;> simp [boolMatrix, bit, C, E, F, Δα]

/-- **The local inequality** (10) of the example: `XCY ≤ E + Δ_α = F + C`, using only
`q_c p_c ≤ 1`. -/
theorem XCY_le (p q : Letter → K) (hqp : ∀ c, q c * p c ≤ 1) :
    popMatrix dfa q * boolMatrix C * pushMatrix dfa p ≤ boolMatrix F + boolMatrix C := by
  intro i j
  have h := congrFun (congrFun (XCY_eq p q) i) j
  rw [← E_add_Δα]
  erw [h]
  change _ ≤ boolMatrix (K := K) E i j + Δα i j
  apply add_le_add
  · calc q .a * p .a * boolMatrix (K := K) E i j ≤ 1 * boolMatrix (K := K) E i j :=
          mul_le_mul_left (hqp .a) _
      _ = _ := one_mul _
  · calc q .b * p .b * Δα (K := K) i j ≤ 1 * Δα i j := mul_le_mul_left (hqp .b) _
      _ = _ := one_mul _

/-- **Running example (Appendix D).** `XCY = q_a p_a E + q_b p_b Δ_α ≤ E + Δ_α = F + C`, the
inequality assuming `q_c p_c ≤ 1`. -/
theorem XCY_eq_le (p q : Letter → K) :
    popMatrix dfa q * boolMatrix C * pushMatrix dfa p =
        (fun i j =>
          q a * p a * boolMatrix (K := K) E i j + q b * p b * Δα i j) ∧
      ((∀ c, q c * p c ≤ 1) →
        popMatrix dfa q * boolMatrix C * pushMatrix dfa p ≤ boolMatrix E + Δα) ∧
      boolMatrix (K := K) E + Δα = boolMatrix F + boolMatrix C :=
  ⟨XCY_eq p q, fun hqp => E_add_Δα (K := K) ▸ XCY_le p q hqp, E_add_Δα⟩

/-- The zero initial row of `C` (boundary condition (6)). -/
theorem C_row_s (j : St) : ¬ C .s j := by cases j <;> decide
/-- The zero initial column of `C` (boundary condition (6)). -/
theorem C_col_s (i : St) : ¬ C i .s := by cases i <;> decide

/-- **Running example (Appendix D).** The zero initial row and column of `C`, the boundary
conditions (6). -/
theorem C_row_col_s : (∀ j, ¬ C .s j) ∧ ∀ i, ¬ C i .s := ⟨C_row_s, C_col_s⟩

/-- Figure 4: the pop edge `s_L →q_a α_L` is `X_{sα} = q_a` (from `δ(s,a) = α`); the push edges
`α_R →p_a β_R`, `β_R →p_b α_R`, `α_R →p_a s_R` are `Y_{αβ} = p_a`, `Y_{βα} = p_b`, `Y_{αs} = p_a`,
reversing `β →a α`, `α →b β`, `s →a α`; the residual entry is `(α, α)`, and the outer endpoints of
the last step form the predecessor pair `(s, β) ∈ F` of `(α, α) = (δ(s,a), δ(β,a))`. -/
theorem bridge_edges (p q : Letter → K) :
    popMatrix dfa q .s .α = q a ∧ pushMatrix dfa p .α .β = p a ∧
      pushMatrix dfa p .β .α = p b ∧ pushMatrix dfa p .α .s = p a ∧
      C .α .α ∧ F .s .β ∧ step .s a = .α ∧ step .β a = .α := by
  refine ⟨?_, ?_, ?_, ?_, by decide, by decide, rfl, rfl⟩ <;>
    simp [popMatrix, pushMatrix, sum_letter, step]

end Stackat.Example
