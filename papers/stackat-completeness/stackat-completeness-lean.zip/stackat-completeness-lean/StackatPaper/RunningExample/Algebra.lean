import StackatPaper.RunningExample.Matrices
import Mathlib.Tactic.Abel

/-!
# The running example: star entries, the programs `Φ(D)`, and the derivations

Sections 3.2 and 4 (equations (2) and (9), the end of Section 4) and Appendix D ("The Running Example's
Derivation"), in every Kleene algebra `K` with letters `q, p : Letter → K`, and then in the
free algebra of derivations.

* the initial row of `X*` is `(1, Q*q_a, Q⁺, Q*(q_b + q_a q_a)(q_a + q_b)*)`, the pop expressions
  of `L_s, L_α, L_β, L_⊥` (`Xstar_row`, with `popRow`), and the initial column of `Y*` is
  `(1, p_a P*, P⁺, (p_a + p_b)*(p_b + p_a p_a)P*)` (`Ystar_col`, with `pushCol`);
* `e = Φ(E)` and `f = Φ(F)` (`PhiE`, `PhiF`), and `Φ(C) = Q⁺P⁺ + Q* q_a p_a P*` (`PhiC`,
  `PhiC_eq`);
* the derivation of the paper: `XCY ≤ F + C`, sandwich elimination and the zero boundary give
  `Φ(C) ≤ Φ(F)` (`PhiC_le_PhiF`), so `Φ(G) = Φ(F)` (`PhiG_eq_PhiF`) and `e ≤ f`;
* the example tables (`running_example_tables`): `e = Φ(E)`, `f = Φ(F)` modulo derivability,
  `G` the good table and `C` its residual cells;
* `Derives (e + f) f` (`e_le_f`) and `Derives (f + e) e` (`f_le_e`), together
  `e_le_f_and_f_le_e`; the shorter scalar proof in every Kleene algebra (`scalar_proof`).
-/

namespace Stackat.Example

open Letter St
open scoped Computability

section Star

variable {K : Type*} [KleeneAlgebra K] {S : Type*} [Fintype S] [DecidableEq S]

/-! ## Rows and columns of a matrix star -/

theorem star_one_le (N : Matrix S S K) (i : S) : 1 ≤ N∗ i i := by
  have h := (one_le_kstar (a := N)) i i
  simpa [Matrix.one_apply_eq] using h

theorem star_row_step (N : Matrix S S K) (i k j : S) : N∗ i k * N k j ≤ N∗ i j := by
  have h := (kstar_mul_le_kstar (a := N)) i j
  refine le_trans ?_ h
  change _ ≤ ∑ l, N∗ i l * N l j
  exact Finset.single_le_sum (f := fun l => N∗ i l * N l j) (fun _ _ => zero_le)
    (Finset.mem_univ k)

theorem star_col_step (N : Matrix S S K) (i k j : S) : N i k * N∗ k j ≤ N∗ i j := by
  have h := (mul_kstar_le_kstar (a := N)) i j
  refine le_trans ?_ h
  change _ ≤ ∑ l, N i l * N∗ l j
  exact Finset.single_le_sum (f := fun l => N i l * N∗ l j) (fun _ _ => zero_le)
    (Finset.mem_univ k)

/-- Star induction for one row: a row vector `c` with `1 ≤ c i₀` and `c N ≤ c` bounds row `i₀`
of `N*`. -/
theorem star_row_le (N : Matrix S S K) (i₀ : S) (c : S → K) (h1 : 1 ≤ c i₀)
    (h : ∀ i j, c i * N i j ≤ c j) (j : S) : N∗ i₀ j ≤ c j := by
  classical
  let Z : Matrix S S K := fun i j => if i = i₀ then c j else 0
  have hZ : Z * N ≤ Z := by
    intro i j
    change ∑ k, Z i k * N k j ≤ Z i j
    by_cases hi : i = i₀
    · simp only [Z, hi, if_true]
      exact idem_sum_le _ _ _ (fun k _ => h k j)
    · simp [Z, hi]
  have hs := (mul_kstar_le_self hZ) i₀ j
  calc N∗ i₀ j = 1 * N∗ i₀ j := (one_mul _).symm
    _ ≤ c i₀ * N∗ i₀ j := mul_le_mul_left h1 _
    _ ≤ ∑ k, Z i₀ k * N∗ k j := by
      simpa [Z] using Finset.single_le_sum (f := fun k => Z i₀ k * N∗ k j)
        (fun _ _ => zero_le) (Finset.mem_univ i₀)
    _ ≤ Z i₀ j := hs
    _ = c j := by simp [Z]

/-- Star induction for one column. -/
theorem star_col_le (N : Matrix S S K) (j₀ : S) (c : S → K) (h1 : 1 ≤ c j₀)
    (h : ∀ i j, N i j * c j ≤ c i) (i : S) : N∗ i j₀ ≤ c i := by
  classical
  let Z : Matrix S S K := fun i j => if j = j₀ then c i else 0
  have hZ : N * Z ≤ Z := by
    intro i j
    change ∑ k, N i k * Z k j ≤ Z i j
    by_cases hj : j = j₀
    · simp only [Z, hj, if_true]
      exact idem_sum_le _ _ _ (fun k _ => h i k)
    · simp [Z, hj]
  have hs := (kstar_mul_le_self hZ) i j₀
  calc N∗ i j₀ = N∗ i j₀ * 1 := (mul_one _).symm
    _ ≤ N∗ i j₀ * c j₀ := mul_le_mul_right h1 _
    _ ≤ ∑ k, N∗ i k * Z k j₀ := by
      simpa [Z] using Finset.single_le_sum (f := fun k => N∗ i k * Z k j₀)
        (fun _ _ => zero_le) (Finset.mem_univ j₀)
    _ ≤ Z i j₀ := hs
    _ = c i := by simp [Z]

end Star

/-! ## Scalar Kleene algebra lemmas -/

section Scalar

variable {K : Type*} [KleeneAlgebra K]

theorem kstar_mul_comm (x : K) : x∗ * x = x * x∗ := by
  apply le_antisymm
  · apply kstar_mul_le
    · simpa using mul_le_mul_right (one_le_kstar (a := x)) x
    · simpa [mul_assoc] using mul_le_mul_right (mul_kstar_le_kstar (a := x)) x
  · apply mul_kstar_le
    · simpa using mul_le_mul_left (one_le_kstar (a := x)) x
    · simpa [mul_assoc] using mul_le_mul_left (kstar_mul_le_kstar (a := x)) x

/-- Sliding: `(xy)* x = x (yx)*`. -/
theorem kstar_slide (x y : K) : (x * y)∗ * x = x * (y * x)∗ := by
  apply le_antisymm
  · apply kstar_mul_le
    · simpa using mul_le_mul_right (one_le_kstar (a := y * x)) x
    · calc x * y * (x * (y * x)∗) = x * ((y * x) * (y * x)∗) := by simp only [mul_assoc]
        _ ≤ x * (y * x)∗ := mul_le_mul_right mul_kstar_le_kstar _
  · apply mul_kstar_le
    · simpa using mul_le_mul_left (one_le_kstar (a := x * y)) x
    · calc (x * y)∗ * x * (y * x) = (x * y)∗ * (x * y) * x := by simp only [mul_assoc]
        _ ≤ (x * y)∗ * x := mul_le_mul_left kstar_mul_le_kstar _

theorem le_mul_kstar (x y : K) : x ≤ x * y∗ := by
  simpa using mul_le_mul_right (one_le_kstar (a := y)) x

theorem le_kstar_mul (x y : K) : x ≤ y∗ * x := by
  simpa using mul_le_mul_left (one_le_kstar (a := y)) x

end Scalar

/-! ## The star entries of the example -/

variable {K : Type*} [KleeneAlgebra K] (p q : Letter → K)

/-- `Q = q_a q_b` in `K`. -/
def Qk : K := q a * q b
/-- `P = p_b p_a` in `K`. -/
def Pk : K := p b * p a

theorem popMatrix_apply (i j : St) :
    popMatrix dfa q i j = (if step i .a = j then q .a else 0) + (if step i .b = j then q .b else 0) := by
  simp only [popMatrix, sum_letter, dfa_step]; rfl

theorem pushMatrix_apply (i j : St) :
    pushMatrix dfa p i j = (if step j .a = i then p .a else 0) + (if step j .b = i then p .b else 0) := by
  simp only [pushMatrix, sum_letter, dfa_step]; rfl

/-- Evaluates an entry of `X` or `Y`. -/
macro "xsimp" : tactic => `(tactic| simp only [popMatrix_apply, pushMatrix_apply, step,
  reduceCtorEq, if_true, if_false, ↓reduceIte, add_zero, zero_add, mul_zero, zero_mul] at *)

/-- The candidate initial row of `X*`: the pop expressions of the four classes. -/
def popRow : St → K
  | .s => 1
  | .α => (Qk q)∗ * q .a
  | .β => Qk q * (Qk q)∗
  | .bot => (Qk q)∗ * (q .b + q .a * q .a) * (q .a + q .b)∗

/-- The candidate initial column of `Y*`: the push expressions of the four classes. -/
def pushCol : St → K
  | .s => 1
  | .α => p .a * (Pk p)∗
  | .β => Pk p * (Pk p)∗
  | .bot => (p .a + p .b)∗ * (p .b + p .a * p .a) * (Pk p)∗

theorem popRow_upper : ∀ j, (popMatrix dfa q)∗ .s j ≤ popRow q j := by
  refine star_row_le (popMatrix dfa q) .s (popRow q) le_rfl ?_
  intro i j
  cases i <;> cases j <;> simp only [popRow] <;> xsimp <;> try exact zero_le
  · -- s → α
    rw [one_mul]; exact le_kstar_mul _ _
  · -- s → ⊥
    rw [one_mul]
    calc q .b ≤ q .b + q .a * q .a := le_add_right le_rfl
      _ ≤ (Qk q)∗ * (q .b + q .a * q .a) := le_kstar_mul _ _
      _ ≤ _ := le_mul_kstar _ _
  · -- α → β
    rw [mul_assoc, ← Qk, kstar_mul_comm]
  · -- α → ⊥
    calc (Qk q)∗ * q .a * q .a = (Qk q)∗ * (q .a * q .a) := mul_assoc _ _ _
      _ ≤ (Qk q)∗ * (q .b + q .a * q .a) := mul_le_mul_right (le_add_left le_rfl) _
      _ ≤ _ := le_mul_kstar _ _
  · -- β → α
    exact mul_le_mul_left mul_kstar_le_kstar _
  · -- β → ⊥
    calc Qk q * (Qk q)∗ * q .b ≤ (Qk q)∗ * q .b := mul_le_mul_left mul_kstar_le_kstar _
      _ ≤ (Qk q)∗ * (q .b + q .a * q .a) := mul_le_mul_right (le_add_right le_rfl) _
      _ ≤ _ := le_mul_kstar _ _
  · -- ⊥ → ⊥
    rw [mul_assoc]
    exact mul_le_mul_right kstar_mul_le_kstar _

theorem popRow_lower : ∀ j, popRow q j ≤ (popMatrix dfa q)∗ .s j := by
  set X := popMatrix dfa q with hX
  have hs : 1 ≤ X∗ .s .s := star_one_le X .s
  have e1 := star_row_step X .s .s .α
  have e2 := star_row_step X .s .α .β
  have e3 := star_row_step X .s .β .α
  have e4 := star_row_step X .s .s .bot
  have e5 := star_row_step X .s .α .bot
  have e6 := star_row_step X .s .β .bot
  have e7 := star_row_step X .s .bot .bot
  rw [hX] at e1 e2 e3 e4 e5 e6 e7
  xsimp
  rw [← hX] at e1 e2 e3 e4 e5 e6 e7
  have hsα : q .a ≤ X∗ .s .α :=
    (one_mul (q .a)).symm.le.trans ((mul_le_mul_left hs _).trans e1)
  have hα : (Qk q)∗ * q .a ≤ X∗ .s .α := by
    rw [Qk, kstar_slide]
    apply mul_kstar_le hsα
    calc X∗ .s .α * (q .b * q .a) = X∗ .s .α * q .b * q .a := (mul_assoc _ _ _).symm
      _ ≤ X∗ .s .β * q .a := mul_le_mul_left e2 _
      _ ≤ _ := e3
  have hβ' : (Qk q)∗ * Qk q ≤ X∗ .s .β := by
    rw [Qk, ← mul_assoc]
    exact (mul_le_mul_left hα _).trans e2
  have hβ : Qk q * (Qk q)∗ ≤ X∗ .s .β := by
    rw [← kstar_mul_comm]; exact hβ'
  have hbot : (Qk q)∗ * (q .b + q .a * q .a) * (q .a + q .b)∗ ≤ X∗ .s .bot := by
    apply mul_kstar_le _ e7
    have hb : (Qk q)∗ * q .b ≤ X∗ .s .bot := by
      rw [← one_add_mul_kstar (a := Qk q), add_mul, one_mul]
      exact add_le ((one_mul (q .b)).symm.le.trans ((mul_le_mul_left hs _).trans e4))
        ((mul_le_mul_left hβ _).trans e6)
    rw [mul_add]
    refine add_le hb ?_
    rw [← mul_assoc]
    exact (mul_le_mul_left hα _).trans e5
  intro j
  cases j
  · exact hs
  · exact hα
  · exact hβ
  · exact hbot

/-- The initial row of `X*` is the row of pop expressions of the classes. -/
theorem Xstar_row (j : St) : (popMatrix dfa q)∗ .s j = popRow q j :=
  le_antisymm (popRow_upper q j) (popRow_lower q j)

theorem pushCol_upper : ∀ i, (pushMatrix dfa p)∗ i .s ≤ pushCol p i := by
  refine star_col_le (pushMatrix dfa p) .s (pushCol p) le_rfl ?_
  intro i j
  cases i <;> cases j <;> simp only [pushCol] <;> xsimp <;> try exact zero_le
  · -- α ← s
    rw [mul_one]; exact le_mul_kstar _ _
  · -- α ← β
    calc p .a * (Pk p * (Pk p)∗) ≤ p .a * (Pk p)∗ := mul_le_mul_right mul_kstar_le_kstar _
      _ = _ := rfl
  · -- β ← α
    rw [← mul_assoc]; rfl
  · -- ⊥ ← s
    rw [mul_one]
    calc p .b ≤ p .b + p .a * p .a := le_add_right le_rfl
      _ ≤ (p .b + p .a * p .a) * (Pk p)∗ := le_mul_kstar _ _
      _ ≤ _ := by rw [mul_assoc]; exact le_kstar_mul _ _
  · -- ⊥ ← α
    calc p .a * (p .a * (Pk p)∗) = (p .a * p .a) * (Pk p)∗ := (mul_assoc _ _ _).symm
      _ ≤ (p .b + p .a * p .a) * (Pk p)∗ := mul_le_mul_left (le_add_left le_rfl) _
      _ ≤ _ := by rw [mul_assoc]; exact le_kstar_mul _ _
  · -- ⊥ ← β
    calc p .b * (Pk p * (Pk p)∗) ≤ p .b * (Pk p)∗ := mul_le_mul_right mul_kstar_le_kstar _
      _ ≤ (p .b + p .a * p .a) * (Pk p)∗ := mul_le_mul_left (le_add_right le_rfl) _
      _ ≤ _ := by rw [mul_assoc]; exact le_kstar_mul _ _
  · -- ⊥ ← ⊥
    rw [← mul_assoc, ← mul_assoc]
    exact mul_le_mul_left (mul_le_mul_left mul_kstar_le_kstar _) _

theorem pushCol_lower : ∀ i, pushCol p i ≤ (pushMatrix dfa p)∗ i .s := by
  set Y := pushMatrix dfa p with hY
  have hs : 1 ≤ Y∗ .s .s := star_one_le Y .s
  have e1 := star_col_step Y .α .s .s
  have e2 := star_col_step Y .α .β .s
  have e3 := star_col_step Y .β .α .s
  have e4 := star_col_step Y .bot .s .s
  have e5 := star_col_step Y .bot .α .s
  have e6 := star_col_step Y .bot .β .s
  have e7 := star_col_step Y .bot .bot .s
  rw [hY] at e1 e2 e3 e4 e5 e6 e7
  xsimp
  rw [← hY] at e1 e2 e3 e4 e5 e6 e7
  have hαs : p .a ≤ Y∗ .α .s :=
    (mul_one (p .a)).symm.le.trans ((mul_le_mul_right hs _).trans e1)
  have hα : p .a * (Pk p)∗ ≤ Y∗ .α .s := by
    rw [Pk, ← kstar_slide]
    apply kstar_mul_le hαs
    calc p .a * p .b * Y∗ .α .s = p .a * (p .b * Y∗ .α .s) := mul_assoc _ _ _
      _ ≤ p .a * Y∗ .β .s := mul_le_mul_right e3 _
      _ ≤ _ := e2
  have hβ : Pk p * (Pk p)∗ ≤ Y∗ .β .s := by
    rw [Pk, mul_assoc]
    exact (mul_le_mul_right hα _).trans e3
  have hbot : (p .a + p .b)∗ * (p .b + p .a * p .a) * (Pk p)∗ ≤ Y∗ .bot .s := by
    rw [mul_assoc]
    apply kstar_mul_le _ e7
    have hb : p .b * (Pk p)∗ ≤ Y∗ .bot .s := by
      rw [← one_add_mul_kstar (a := Pk p), mul_add, mul_one]
      exact add_le ((mul_one (p .b)).symm.le.trans ((mul_le_mul_right hs _).trans e4))
        ((mul_le_mul_right hβ _).trans e6)
    rw [add_mul]
    refine add_le hb ?_
    rw [mul_assoc]
    exact (mul_le_mul_right hα _).trans e5
  intro i
  cases i
  · exact hs
  · exact hα
  · exact hβ
  · exact hbot

/-- The initial column of `Y*` is the column of push expressions of the classes. -/
theorem Ystar_col (i : St) : (pushMatrix dfa p)∗ i .s = pushCol p i :=
  le_antisymm (pushCol_upper p i) (pushCol_lower p i)

/-! ## The programs `Φ(D) = ℓ X* D Y* r` -/

/-- `Φ(D) = Σ_{D_ij} q(L_i) p(L_j)` (the program of a table). -/
theorem tableProgram_eq (D : St → St → Prop) :
    tableProgram dfa p q D = ∑ i, ∑ j, popRow q i * bit (D i j) * pushCol p j := by
  simp only [tableProgram, Matrix.mul_apply, boolMatrix, Finset.sum_mul, dfa_initial, Xstar_row,
    Ystar_col]
  rw [Finset.sum_comm]

/-- `Φ(E) = Q*P*`. -/
theorem PhiE : tableProgram dfa p q E = (Qk q)∗ * (Pk p)∗ := by
  rw [tableProgram_eq]
  simp [sum_st, E, popRow, pushCol, -add_eq_sup]
  rw [show (Qk q)∗ * (Pk p)∗ = (1 + Qk q * (Qk q)∗) * (1 + Pk p * (Pk p)∗) by
    rw [one_add_mul_kstar, one_add_mul_kstar]]
  simp only [add_mul, mul_add, one_mul, mul_one]
  abel

/-- `Φ(F) = Q* + P*`. -/
theorem PhiF : tableProgram dfa p q F = (Qk q)∗ + (Pk p)∗ := by
  rw [tableProgram_eq]
  simp [sum_st, F, popRow, pushCol, -add_eq_sup]
  rw [show (Qk q)∗ + (Pk p)∗ = (1 + Qk q * (Qk q)∗) + (1 + Pk p * (Pk p)∗) by
    rw [one_add_mul_kstar, one_add_mul_kstar]]
  have : (1 : K) + 1 = 1 := add_idem 1
  calc 1 + Pk p * (Pk p)∗ + Qk q * (Qk q)∗ = (1 + 1) + (Qk q * (Qk q)∗ + Pk p * (Pk p)∗) := by
        rw [this]; abel
    _ = _ := by abel

/-- **`Φ(C) = Q⁺P⁺ + Q* q_a p_a P*`** (Appendix D): the cells `(β, β)` and `(α, α)`. -/
theorem PhiC : tableProgram dfa p q C =
    Qk q * (Qk q)∗ * (Pk p * (Pk p)∗) + (Qk q)∗ * q .a * (p .a * (Pk p)∗) := by
  rw [tableProgram_eq]
  simp [sum_st, C, popRow, pushCol, -add_eq_sup]
  abel

/-- **`Φ(C) = Q⁺P⁺ + Q* q_a p_a P*`** (Appendix D), in the paper's grouping. -/
theorem PhiC_eq : tableProgram dfa p q C =
    Qk q * (Qk q)∗ * (Pk p * (Pk p)∗) + (Qk q)∗ * (q a * p a) * (Pk p)∗ := by
  rw [PhiC]; simp only [mul_assoc]

/-! ## The derivation of `e ≤ f` in the paper -/

/-- `Φ(G) = Φ(F) + Φ(C)`. -/
theorem PhiG_split : tableProgram dfa p q G = tableProgram dfa p q F + tableProgram dfa p q C := by
  simp only [tableProgram_eq, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl; intro i _
  apply Finset.sum_congr rfl; intro j _
  rw [← add_mul, ← mul_add]
  congr 2
  by_cases hf : F i j <;> by_cases hc : C i j <;>
    simp [G, hf, hc, bit_true, bit_false]

/-- Sandwich elimination and the zero initial row and column of `C` give `Φ(C) ≤ Φ(F)`. -/
theorem PhiC_le_PhiF (hqp : ∀ c, q c * p c ≤ 1) :
    tableProgram dfa p q C ≤ tableProgram dfa p q F := by
  have hloc : popMatrix dfa q * boolMatrix C * pushMatrix dfa p ≤
      boolMatrix (K := K) C + boolMatrix F := by
    rw [add_comm]; exact XCY_le p q hqp
  have hs := Stackat.sandwich hloc .s .s
  have hl : ((popMatrix dfa q)∗ * boolMatrix (K := K) C) .s .s = 0 := by
    simp [Matrix.mul_apply, boolMatrix, bit_false (C_col_s _)]
  have hr : (boolMatrix (K := K) C * (pushMatrix dfa p)∗) .s .s = 0 := by
    simp [Matrix.mul_apply, boolMatrix, bit_false (C_row_s _)]
  simp only [Matrix.add_apply, hl, hr, zero_add] at hs
  exact hs

/-- **`Φ(G) = Φ(F)`** (Proposition 8, last sentence, for the example). -/
theorem PhiG_eq_PhiF (hqp : ∀ c, q c * p c ≤ 1) :
    tableProgram dfa p q G = tableProgram dfa p q F := by
  rw [PhiG_split]
  exact add_eq_left_iff_le.mpr (PhiC_le_PhiF p q hqp)

/-- `Φ(E) ≤ Φ(G)`. -/
theorem PhiE_le_PhiG : tableProgram dfa p q E ≤ tableProgram dfa p q G := by
  simp only [tableProgram_eq]
  apply Finset.sum_le_sum; intro i _
  apply Finset.sum_le_sum; intro j _
  apply mul_le_mul_left (mul_le_mul_right _ _) _
  by_cases he : E i j
  · rw [bit_true he, bit_true (E_le_G i j he)]
  · rw [bit_false he]; exact zero_le

/-- `e = Φ(E) ≤ Φ(G) = Φ(F) = f`, in every Kleene algebra with `q_c p_c ≤ 1`. -/
theorem e_le_f_KA (hqp : ∀ c, q c * p c ≤ 1) : (Qk q)∗ * (Pk p)∗ ≤ (Qk q)∗ + (Pk p)∗ := by
  rw [← PhiE, ← PhiF, ← PhiG_eq_PhiF p q hqp]
  exact PhiE_le_PhiG p q

/-! ## Derivations -/

open FreeAlgebra

/-- The letters of the free algebra. -/
abbrev pushF : Letter → FreeAlgebra Letter := fun c => of (.push c)
abbrev popF : Letter → FreeAlgebra Letter := fun c => of (.pop c)

theorem of_e : of e = (Qk popF)∗ * (Pk pushF)∗ := rfl
theorem of_f : of f = (Qk popF)∗ + (Pk pushF)∗ := rfl

/-- `e = Φ(E)` and `f = Φ(F)` as derivable equations (equation (2)). -/
theorem e_eq_PhiE : of e = Φ dfa E := (PhiE pushF popF).symm
theorem f_eq_PhiF : of f = Φ dfa F := (PhiF pushF popF).symm

/-- **Running example: the tables** (Section 3.2, Appendix D). `e = Φ(E)` and `f = Φ(F)`
modulo derivability, `G` is the good table of `F`, and `C` its residual cells. -/
theorem running_example_tables :
    FreeAlgebra.of e = Φ dfa E ∧ FreeAlgebra.of f = Φ dfa F ∧
      Good dfa F = G ∧ Residual dfa F = C :=
  ⟨e_eq_PhiE, f_eq_PhiF, funext fun i => funext fun j => propext (good_iff i j),
    funext fun i => funext fun j => propext (residual_iff i j)⟩

/-- **`e ≤ f`**, `Derives (e + f) f`, by the paper's derivation on the paper's tables. -/
theorem e_le_f : ⊢ e ≤ f := by
  apply of_eq_iff.mp
  rw [of_add, of_e, of_f]
  exact add_eq_right_iff_le.mpr (e_le_f_KA pushF popF FreeAlgebra.pop_push)

/-- **`f ≤ e`**, `Derives (f + e) e`, from `1 ≤ Q*` and `1 ≤ P*`. -/
theorem f_le_e : ⊢ f ≤ e := by
  apply of_eq_iff.mp
  rw [of_add, of_e, of_f]
  apply add_eq_right_iff_le.mpr
  apply add_le
  · exact le_mul_kstar _ _
  · exact le_kstar_mul _ _

/-- **Running example (Section 4).** `Q*P* ≤ Q* + P*`, by the derivation of Section 4 on the
example tables, and the reverse inequality, from `1 ≤ Q*, P*`. -/
theorem e_le_f_and_f_le_e : (⊢ e ≤ f) ∧ (⊢ f ≤ e) := ⟨e_le_f, f_le_e⟩

/-- The shorter scalar proof: `QP = q_a q_b p_b p_a ≤ q_a p_a ≤ 1`. -/
theorem QP_le_one_KA (hqp : ∀ c, q c * p c ≤ 1) : Qk q * Pk p ≤ 1 := by
  calc Qk q * Pk p = q .a * (q .b * p .b) * p .a := by simp only [Qk, Pk, mul_assoc]
    _ ≤ q .a * 1 * p .a := mul_le_mul_left (mul_le_mul_right (hqp .b) _) _
    _ = q .a * p .a := by rw [mul_one]
    _ ≤ 1 := hqp .a

/-- **Running example: the shorter scalar proof** (Section 4). In every Kleene algebra with
`q_c p_c ≤ 1`, `QP = q_a q_b p_b p_a ≤ q_a p_a ≤ 1`, so sandwich elimination applies with `X = Q`,
`Y = P`, `C = 1` and `F = 0`. -/
theorem scalar_proof (hqp : ∀ c, q c * p c ≤ 1) :
    Qk q * Pk p ≤ q a * p a ∧ q a * p a ≤ 1 ∧
      (Qk q)∗ * 1 * (Pk p)∗ ≤ (Qk q)∗ * 1 + 1 * (Pk p)∗ + (Qk q)∗ * 0 * (Pk p)∗ := by
  refine ⟨?_, hqp .a, Stackat.sandwich ?_⟩
  · calc Qk q * Pk p = q .a * (q .b * p .b) * p .a := by simp only [Qk, Pk, mul_assoc]
      _ ≤ q .a * 1 * p .a := mul_le_mul_left (mul_le_mul_right (hqp .b) _) _
      _ = q .a * p .a := by rw [mul_one]
  · rw [mul_one, add_zero]; exact QP_le_one_KA p q hqp

end Stackat.Example
