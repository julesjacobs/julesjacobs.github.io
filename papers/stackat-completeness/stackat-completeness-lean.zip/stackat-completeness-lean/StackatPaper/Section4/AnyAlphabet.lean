import StackatPaper.Section4.Derivation

/-!
# Theorem 1 over any alphabet

The proof of Theorem 1 works over a finite alphabet. The letters occurring in `e` and `f` form a
finite alphabet `B`, and both directions transfer along the inclusion `B → A`:

* `Expr.map g`: the expression with each letter `a` renamed to `g a`;
* `R_map`: for injective `g`, `R (e.map g)` relates `u.map g` to `v.map g` exactly when `R e`
  relates `u` to `v` (an execution from a stack of renamed letters only visits such stacks);
* `Derives.map`: derivations map along an injective `g` (`push_pop_ne` needs injectivity);
* `exists_map_val`: an expression whose letters satisfy `P` is the image of an expression over the
  subtype `{a // P a}`;
* `soundness_and_completeness_any_alphabet`: Theorem 1 for every alphabet, and the statement of
  `Spec.lean` (`soundness_and_completeness_spec`).
-/

namespace Stackat

variable {A B : Type}

/-- Rename the letters of an expression along `g`. -/
def Expr.map (g : A → B) : Expr A → Expr B
  | .zero => .zero
  | .one => .one
  | .push a => .push (g a)
  | .pop a => .pop (g a)
  | .add e f => .add (e.map g) (f.map g)
  | .mul e f => .mul (e.map g) (f.map g)
  | .star e => .star (e.map g)

/-- The letters occurring in an expression. -/
def Expr.letters : Expr A → List A
  | .zero => []
  | .one => []
  | .push a => [a]
  | .pop a => [a]
  | .add e f => e.letters ++ f.letters
  | .mul e f => e.letters ++ f.letters
  | .star e => e.letters

section Map

variable (g : A → B)

/-- An execution of `e.map g` from a stack of renamed letters only visits such stacks. -/
theorem R_map_range {e : Expr A} {s t : List B} (h : R (e.map g) s t)
    (hs : ∀ x ∈ s, x ∈ Set.range g) : ∀ x ∈ t, x ∈ Set.range g := by
  induction e generalizing s t with
  | zero => exact h.elim
  | one => cases h; exact hs
  | push a =>
    change t = g a :: s at h
    subst h
    intro x hx
    rcases List.mem_cons.mp hx with rfl | hx
    · exact ⟨a, rfl⟩
    · exact hs x hx
  | pop a =>
    change s = g a :: t at h
    subst h
    exact fun x hx => hs x (List.mem_cons_of_mem _ hx)
  | add e f he hf => exact h.elim (fun h => he h hs) (fun h => hf h hs)
  | mul e f he hf =>
    obtain ⟨m, h1, h2⟩ := h
    exact hf h2 (he h1 hs)
  | star e he =>
    change R (e.map g).star s t at h
    rw [R_star] at h
    induction h with
    | refl => exact hs
    | tail _ hbc ih => exact he hbc ih

/-- A list of letters in the range of `g` is the renaming of a list. -/
theorem exists_map_of_range {s : List B} (hs : ∀ x ∈ s, x ∈ Set.range g) :
    ∃ s' : List A, s'.map g = s := by
  induction s with
  | nil => exact ⟨[], rfl⟩
  | cons x s ih =>
    obtain ⟨a, rfl⟩ := hs x List.mem_cons_self
    obtain ⟨s', rfl⟩ := ih (fun y hy => hs y (List.mem_cons_of_mem _ hy))
    exact ⟨a :: s', rfl⟩

theorem map_mem_range (u : List A) : ∀ x ∈ u.map g, x ∈ Set.range g := by
  intro x hx
  obtain ⟨y, -, rfl⟩ := List.mem_map.mp hx
  exact ⟨y, rfl⟩

/-- **Renaming letters.** For injective `g`, `R (e.map g)` relates `u.map g` to `v.map g` exactly
when `R e` relates `u` to `v`. -/
theorem R_map {g : A → B} (hg : Function.Injective g) (e : Expr A) (u v : List A) :
    R (e.map g) (u.map g) (v.map g) ↔ R e u v := by
  induction e generalizing u v with
  | zero => exact Iff.rfl
  | one =>
    change u.map g = v.map g ↔ u = v
    exact (List.map_injective_iff.mpr hg).eq_iff
  | push a =>
    change v.map g = g a :: u.map g ↔ v = a :: u
    rw [← List.map_cons]
    exact (List.map_injective_iff.mpr hg).eq_iff
  | pop a =>
    change u.map g = g a :: v.map g ↔ u = a :: v
    rw [← List.map_cons]
    exact (List.map_injective_iff.mpr hg).eq_iff
  | add e f he hf => exact or_congr (he u v) (hf u v)
  | mul e f he hf =>
    constructor
    · rintro ⟨m, h1, h2⟩
      obtain ⟨m', rfl⟩ := exists_map_of_range g (R_map_range g h1 (map_mem_range g u))
      exact ⟨m', (he u m').mp h1, (hf m' v).mp h2⟩
    · rintro ⟨m, h1, h2⟩
      exact ⟨m.map g, (he u m).mpr h1, (hf m v).mpr h2⟩
  | star e he =>
    change R (e.map g).star (u.map g) (v.map g) ↔ R e.star u v
    rw [R_star, R_star]
    constructor
    · intro h
      suffices H : ∀ t, Relation.ReflTransGen (R (e.map g)) (u.map g) t →
          (∀ x ∈ t, x ∈ Set.range g) ∧
            ∀ v, t = v.map g → Relation.ReflTransGen (R e) u v from (H _ h).2 v rfl
      intro t ht
      induction ht with
      | refl =>
        refine ⟨map_mem_range g u, fun v hv => ?_⟩
        rw [(List.map_injective_iff.mpr hg) hv]
      | tail _ hbc ih =>
        obtain ⟨hb, ih⟩ := ih
        obtain ⟨b', rfl⟩ := exists_map_of_range g hb
        refine ⟨R_map_range g hbc hb, fun v hv => ?_⟩
        subst hv
        exact .tail (ih b' rfl) ((he b' v).mp hbc)
    · intro h
      induction h with
      | refl => exact .refl
      | tail _ hbc ih => exact .tail ih ((he _ _).mpr hbc)

/-- **Derivations map along an injective renaming.** -/
theorem Derives.map {g : A → B} (hg : Function.Injective g) {e f : Expr A} (h : ⊢ e ≈ f) :
    ⊢ e.map g ≈ f.map g := by
  induction h with
  | refl => exact .refl
  | symm _ ih => exact .symm ih
  | trans _ _ ih₁ ih₂ => exact .trans ih₁ ih₂
  | add_congr _ _ ih₁ ih₂ => exact .add_congr ih₁ ih₂
  | mul_congr _ _ ih₁ ih₂ => exact .mul_congr ih₁ ih₂
  | star_congr _ ih => exact .star_congr ih
  | add_assoc => exact .add_assoc
  | add_comm => exact .add_comm
  | add_zero => exact .add_zero
  | add_idem => exact .add_idem
  | mul_assoc => exact .mul_assoc
  | one_mul => exact .one_mul
  | mul_one => exact .mul_one
  | zero_mul => exact .zero_mul
  | mul_zero => exact .mul_zero
  | mul_add => exact .mul_add
  | add_mul => exact .add_mul
  | star_unfold_left => exact .star_unfold_left
  | star_unfold_right => exact .star_unfold_right
  | star_induct_left _ ih => exact .star_induct_left ih
  | star_induct_right _ ih => exact .star_induct_right ih
  | push_pop => exact .push_pop
  | push_pop_ne hab => exact .push_pop_ne (fun h => hab (hg h))
  | pop_push => exact .pop_push

end Map

/-- **Restriction to the occurring letters.** An expression whose letters all satisfy `P` is the
renaming of an expression over the subtype `{a // P a}`. -/
theorem exists_map_val (P : A → Prop) (e : Expr A) (h : ∀ a ∈ e.letters, P a) :
    ∃ e' : Expr {a // P a}, e'.map Subtype.val = e := by
  induction e with
  | zero => exact ⟨.zero, rfl⟩
  | one => exact ⟨.one, rfl⟩
  | push a => exact ⟨.push ⟨a, h a (by simp [Expr.letters])⟩, rfl⟩
  | pop a => exact ⟨.pop ⟨a, h a (by simp [Expr.letters])⟩, rfl⟩
  | add e f he hf =>
    obtain ⟨e', rfl⟩ := he (fun a ha => h a (by simp [Expr.letters, ha]))
    obtain ⟨f', rfl⟩ := hf (fun a ha => h a (by simp [Expr.letters, ha]))
    exact ⟨.add e' f', rfl⟩
  | mul e f he hf =>
    obtain ⟨e', rfl⟩ := he (fun a ha => h a (by simp [Expr.letters, ha]))
    obtain ⟨f', rfl⟩ := hf (fun a ha => h a (by simp [Expr.letters, ha]))
    exact ⟨.mul e' f', rfl⟩
  | star e he =>
    obtain ⟨e', rfl⟩ := he h
    exact ⟨.star e', rfl⟩

/-- Completeness over any alphabet, inclusion form: restrict to the finitely many letters of `e`
and `f`, apply Theorem 1 there, and map the derivation back. -/
theorem inclusion_derivable_any {A : Type} (e f : Expr A) (h : R e ≤ R f) : ⊢ e ≤ f := by
  let P : A → Prop := fun a => a ∈ e.letters ++ f.letters
  haveI : Finite {a // P a} := List.finite_toSet _ |>.to_subtype
  obtain ⟨e', he⟩ := exists_map_val P e (fun a ha => List.mem_append_left _ ha)
  obtain ⟨f', hf⟩ := exists_map_val P f (fun a ha => List.mem_append_right _ ha)
  have hinj : Function.Injective (Subtype.val : {a // P a} → A) := Subtype.val_injective
  have h' : R e' ≤ R f' := fun u v huv => by
    have hA := h _ _ (by rw [← he]; exact (R_map hinj e' u v).mpr huv)
    exact (R_map hinj f' u v).mp (by rw [hf]; exact hA)
  have hd : ⊢ (e' + f').map Subtype.val ≈ f'.map Subtype.val :=
    Derives.map hinj ((soundness_and_completeness e' f').1.mp h')
  rw [← he, ← hf]
  exact hd

/-- **Theorem 1, for every alphabet.** `R_e ⊆ R_f ⟺ ⊢ e + f = f`; consequently
`R_e = R_f ⟺ ⊢ e = f`. -/
theorem soundness_and_completeness_any_alphabet {A : Type} (e f : Expr A) :
    (R e ≤ R f ↔ ⊢ e ≤ f) ∧ (R e = R f ↔ ⊢ e ≈ f) := by
  refine ⟨⟨inclusion_derivable_any e f, fun h s t he => ?_⟩, ⟨fun h => ?_, soundness⟩⟩
  · exact (soundness_iff h s t).mp (Or.inl he)
  · have he := inclusion_derivable_any e f h.le
    have hf := inclusion_derivable_any f e h.ge
    exact .trans (.symm hf) (.trans .add_comm he)

/-- **Theorem 1, as stated in `Spec.lean`.** -/
theorem soundness_and_completeness_spec : SoundnessAndCompleteness :=
  fun _ e f => (soundness_and_completeness_any_alphabet e f).1

end Stackat
