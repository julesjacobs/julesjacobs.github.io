import StackatPaper.Section3.TargetTable
import StackatPaper.Section3.SharedDFA

/-!
# Section 4: Completeness: Turning Good Cells into a Derivation

Fix the shared reachable DFA `M`, a target table `F`, and a certificate `G ≥ F` with
`C = G ∖ F`. In any Kleene algebra in which `q_a p_a ≤ 1`:

* the matrix representation (9) `Φ(D) = ℓ X* D Y* r` (`tableProgram_eq_matrix`), with `ℓ`, `r`
  the row and column selecting `s` (`initialVec`);
* the local inequality (10) `X C Y ≤ C + F` (`local_inequality`);
* star induction on both sides, Lemma 7 (`sandwich`);
* `ℓ C = 0`, `C r = 0`, `ℓ X* C r = 0` and `ℓ C Y* r = 0` (`boundary_terms`);
* every certificate gives `Φ(G) = Φ(F)` (`tableProgram_certificate_eq`, and for `Φ`
  `certificate_yields_equality`); Proposition 8 (`finite_certificate`);
* inclusion between normal forms from KA and `q_a p_a ≤ 1` alone (`normal_form_inclusion`);
* Theorem 1: `inequational_completeness`, `completeness`, and the two equivalences
  `inclusion_iff_derivable`, `equality_iff_derivable`, together `soundness_and_completeness`.
-/

namespace Stackat

open scoped Computability Matrix

variable {A S K : Type*} [Fintype A] [Fintype S] [DecidableEq S] [KleeneAlgebra K]

omit [Fintype S] [DecidableEq S] in
private theorem boolMatrix_mono {F G : S → S → Prop} (h : F ≤ G) :
    boolMatrix (K := K) F ≤ boolMatrix (K := K) G := by
  classical
  intro i j
  by_cases hf : F i j
  · simp only [boolMatrix, bit_true hf, bit_true (h i j hf), le_refl]
  · simp only [boolMatrix, bit_false hf]
    exact zero_le

omit [Fintype S] [DecidableEq S] in
/-- `G = C + F` for `G ≥ F` and `C = G ∖ F`. -/
private theorem boolMatrix_split {F G : S → S → Prop} (hF : F ≤ G) :
    boolMatrix (K := K) G = boolMatrix (K := K) (G \ F) + boolMatrix (K := K) F := by
  classical
  ext i j
  by_cases hf : F i j
  · have hg := hF i j hf
    have hc : ¬ (G \ F) i j := fun h => h.2 hf
    simp only [Matrix.add_apply, boolMatrix, bit_true hf, bit_true hg, bit_false hc, zero_add]
  · by_cases hg : G i j
    · have hc : (G \ F) i j := ⟨hg, hf⟩
      simp only [Matrix.add_apply, boolMatrix, bit_true hg, bit_true hc, bit_false hf, add_zero]
    · have hc : ¬ (G \ F) i j := fun h => hg h.1
      simp only [Matrix.add_apply, boolMatrix, bit_false hg, bit_false hc, bit_false hf, add_zero]

omit [Fintype S] [DecidableEq S] in
/-- A larger table has a larger program. -/
theorem tableProgram_mono (M : DFA A S) (p q : A → K) {E G : S → S → Prop} (h : E ≤ G)
    [Fintype S] [DecidableEq S] : tableProgram M p q E ≤ tableProgram M p q G :=
  mul_le_mul_left (mul_le_mul_right (boolMatrix_mono h) _) _ M.initial M.initial

/-! ## The matrix representation -/

/-- `ℓ`, the vector selecting the initial state `s`; as a row it is `ℓ`, as a column `r = ℓᵀ`. -/
noncomputable def initialVec (M : DFA A S) : S → K :=
  fun i => if i = M.initial then 1 else 0

omit [Fintype A] in
private theorem initialVec_entry (M : DFA A S) (N : Matrix S S K) :
    (initialVec M ᵥ* N) ⬝ᵥ initialVec M = N M.initial M.initial := by
  simp [Matrix.vecMul, dotProduct, initialVec, ite_mul, mul_ite]

/-- **The matrix representation** (9): `Φ(D) = ℓ X* D Y* r`. -/
theorem tableProgram_eq_matrix (M : DFA A S) (p q : A → K) (D : S → S → Prop) :
    tableProgram M p q D =
      (initialVec M ᵥ* ((popMatrix M q)∗ * boolMatrix D * (pushMatrix M p)∗)) ⬝ᵥ
        initialVec M :=
  (initialVec_entry M _).symm

/-! ## The local inequality -/

/-- **The local inequality** (10): for a certificate `G` with residual cells `C = G ∖ F`,
`X C Y ≤ C + F`. -/
theorem local_inequality (M : DFA A S) (p q : A → K) (hqp : ∀ a, q a * p a ≤ 1)
    {F G : S → S → Prop} (hG : CertificateConditions M F G) :
    popMatrix M q * boolMatrix (G \ F) * pushMatrix M p ≤
      boolMatrix (K := K) (G \ F) + boolMatrix F := by
  classical
  intro i j
  rw [mul_push]
  simp only [pop_mul, Finset.sum_mul]
  apply idem_sum_le
  intro b _
  apply idem_sum_le
  intro a _
  by_cases hc : (G \ F) (M.step i a) (M.step j b)
  · have hab : a = b := by
      by_contra hab
      exact hG.mismatch i j a b hab hc
    subst b
    have hg := hG.matching i j a hc
    have h1 : (boolMatrix (K := K) (G \ F) + boolMatrix F : Matrix S S K) i j = 1 := by
      by_cases hf : F i j
      · have hc' : ¬ (G \ F) i j := fun h => h.2 hf
        simp only [Matrix.add_apply, boolMatrix, bit_true hf, bit_false hc', zero_add]
      · have hc' : (G \ F) i j := ⟨hg, hf⟩
        simp only [Matrix.add_apply, boolMatrix, bit_true hc', bit_false hf, add_zero]
    rw [h1]
    simpa only [boolMatrix, bit_true hc, mul_one] using hqp a
  · simp only [boolMatrix, bit_false hc, mul_zero, zero_mul]
    exact zero_le

/-! ## Sandwich elimination -/

/-- **Star induction on both sides** (Lemma 7). In any Kleene algebra, `XCY ≤ C + F` implies
`X* C Y* ≤ X* C + C Y* + X* F Y*`. -/
theorem sandwich {X Y C F : K} (h : X * C * Y ≤ C + F) :
    X∗ * C * Y∗ ≤ X∗ * C + C * Y∗ + X∗ * F * Y∗ := by
  let H := X∗ * C + C * Y∗ + X∗ * F * Y∗
  have hC : C * Y∗ ≤ H :=
    (le_add_left le_rfl).trans (le_add_right le_rfl)
  have hXC : X * C * Y∗ ≤ H := by
    calc
      X * C * Y∗ = X * C * (1 + Y * Y∗) := by rw [one_add_mul_kstar]
      _ = X * C + (X * C * Y) * Y∗ := by simp only [mul_add, mul_one, mul_assoc]
      _ ≤ X * C + (C + F) * Y∗ := add_le_add le_rfl (mul_le_mul_left h _)
      _ = X * C + C * Y∗ + F * Y∗ := by simp only [add_mul, add_assoc]
      _ ≤ H := by
        apply add_le_add
        · exact add_le_add (mul_le_mul_left le_kstar _) le_rfl
        · exact mul_le_mul_left (by simpa only [one_mul, mul_one] using
            (mul_le_mul_left (one_le_kstar (a := X)) F)) _
  have hXH : X * H ≤ H := by
    dsimp only [H]
    rw [mul_add, mul_add]
    apply add_le
    · apply add_le
      · apply le_trans _ ((le_add_right le_rfl).trans (le_add_right le_rfl))
        simpa only [mul_assoc] using mul_le_mul_left (mul_kstar_le_kstar (a := X)) C
      · simpa only [H, mul_assoc] using hXC
    · apply le_trans _ (le_add_left le_rfl)
      simpa only [mul_assoc] using
        mul_le_mul_left (mul_le_mul_left (mul_kstar_le_kstar (a := X)) F) Y∗
  simpa only [H, mul_assoc] using kstar_mul_le hC hXH

/-! ## The boundary terms -/

omit [Fintype A] in
/-- `ℓ C = 0` and `C r = 0` for the residual cells of a certificate, by the boundary
conditions (6). -/
theorem residual_row_col_zero (M : DFA A S) {F G : S → S → Prop}
    (hG : CertificateConditions M F G) :
    initialVec M ᵥ* boolMatrix (K := K) (G \ F) = 0 ∧ boolMatrix (K := K) (G \ F) *ᵥ initialVec M = 0 := by
  constructor
  · ext j
    have h : boolMatrix (K := K) (G \ F) M.initial j = 0 := bit_false (hG.boundary_left j)
    simp [Matrix.vecMul, dotProduct, initialVec, ite_mul, h]
  · ext i
    have h : boolMatrix (K := K) (G \ F) i M.initial = 0 := bit_false (hG.boundary_right i)
    simp [Matrix.mulVec, dotProduct, initialVec, mul_ite, h]

/-- **The boundary terms vanish**: `ℓ X* C r = 0` and `ℓ C Y* r = 0`. -/
theorem boundary_terms_vanish (M : DFA A S) (p q : A → K) {F G : S → S → Prop}
    (hG : CertificateConditions M F G) :
    (initialVec M ᵥ* ((popMatrix M q)∗ * boolMatrix (G \ F))) ⬝ᵥ initialVec M = 0 ∧
      (initialVec M ᵥ* (boolMatrix (G \ F) * (pushMatrix M p)∗)) ⬝ᵥ initialVec M = 0 := by
  obtain ⟨hl, hr⟩ := residual_row_col_zero (K := K) M hG
  constructor
  · rw [← Matrix.vecMul_vecMul, ← Matrix.dotProduct_mulVec, hr, dotProduct_zero]
  · rw [← Matrix.vecMul_vecMul, hl, Matrix.zero_vecMul, zero_dotProduct]

/-- **The boundary terms.** For the residual cells `C = G ∖ F` of a certificate, `ℓ C = 0` and
`C r = 0` by the boundary conditions (6), hence `ℓ X* C r = 0` and `ℓ C Y* r = 0`. -/
theorem boundary_terms (M : DFA A S) (p q : A → K) {F G : S → S → Prop}
    (hG : CertificateConditions M F G) :
    initialVec M ᵥ* boolMatrix (K := K) (G \ F) = 0 ∧
      boolMatrix (K := K) (G \ F) *ᵥ initialVec M = 0 ∧
      (initialVec M ᵥ* ((popMatrix M q)∗ * boolMatrix (G \ F))) ⬝ᵥ
          initialVec M = 0 ∧
      (initialVec M ᵥ* (boolMatrix (G \ F) * (pushMatrix M p)∗)) ⬝ᵥ
          initialVec M = 0 :=
  ⟨(residual_row_col_zero M hG).1, (residual_row_col_zero M hG).2, boundary_terms_vanish M p q hG⟩

/-! ## Every certificate gives `Φ(G) = Φ(F)` -/

/-- Every certificate `G ≥ F` gives `Φ(G) = Φ(F)`, in every Kleene algebra with
`q_a p_a ≤ 1`: the local inequality, sandwich elimination, and the vanishing boundary terms
give `Φ(C) ≤ Φ(F)`, and `G = F + C`. -/
theorem tableProgram_certificate_eq (M : DFA A S) (p q : A → K) (hqp : ∀ a, q a * p a ≤ 1)
    {F G : S → S → Prop} (hF : F ≤ G) (hG : CertificateConditions M F G) :
    tableProgram M p q G = tableProgram M p q F := by
  apply le_antisymm _ (tableProgram_mono M p q hF)
  let X := popMatrix M q
  let Y := pushMatrix M p
  let C := boolMatrix (K := K) (G \ F)
  let D := boolMatrix (K := K) F
  have hs := sandwich (local_inequality M p q hqp hG) M.initial M.initial
  have hl : (X∗ * C) M.initial M.initial = 0 := by
    have h : ∀ k, C k M.initial = 0 := fun k => bit_false (hG.boundary_right k)
    simp [Matrix.mul_apply, h]
  have hr : (C * Y∗) M.initial M.initial = 0 := by
    have h : ∀ k, C M.initial k = 0 := fun k => bit_false (hG.boundary_left k)
    simp [Matrix.mul_apply, h]
  change (X∗ * C * Y∗) M.initial M.initial ≤
    (X∗ * C) M.initial M.initial + (C * Y∗) M.initial M.initial +
      (X∗ * D * Y∗) M.initial M.initial at hs
  rw [hl, hr, zero_add, zero_add] at hs
  change (X∗ * boolMatrix (K := K) G * Y∗) M.initial M.initial ≤ (X∗ * D * Y∗) M.initial M.initial
  rw [boolMatrix_split hF, mul_add, add_mul]
  exact add_le hs le_rfl

/-- **Proposition 8, second sentence.** Every certificate yields the algebraic equality
`Φ(G) = Φ(F)`. -/
theorem certificate_yields_equality {A : Type} [Fintype A] (M : DFA A S)
    {F G : S → S → Prop} (hF : F ≤ G) (hG : CertificateConditions M F G) :
    Φ M G = Φ M F :=
  tableProgram_certificate_eq M _ _ FreeAlgebra.pop_push hF hG

/-- **Proposition 8 (finite certificate).** For tables `E`, `F` on the shared reachable DFA,
`𝓡_E ⊆ 𝓡_F` iff some table `G ≥ E, F` satisfies the certificate conditions (6)–(8); every such
certificate yields the algebraic equality `Φ(G) = Φ(F)`. -/
theorem finite_certificate {A : Type} [Fintype A] (M : DFA A S)
    (E F : S → S → Prop) :
    (Accepted M E ≤ Accepted M F ↔
        ∃ G, E ≤ G ∧ F ≤ G ∧ CertificateConditions M F G) ∧
      ∀ G, F ≤ G → CertificateConditions M F G → Φ M G = Φ M F :=
  ⟨certificate_iff M F E, fun _ hF hG => certificate_yields_equality M hF hG⟩

/-- **Inclusion between normal forms from KA and `q_a p_a ≤ 1` alone.** If `𝓡_E ⊆ 𝓡_F`, then
`Φ(E) ≤ Φ(F)` in every Kleene algebra in which `q_a p_a ≤ 1`. -/
theorem normal_form_inclusion (M : DFA A S) (p q : A → K)
    (hqp : ∀ a, q a * p a ≤ 1) (E F : S → S → Prop)
    (hEF : Accepted M E ≤ Accepted M F) :
    tableProgram M p q E ≤ tableProgram M p q F := by
  obtain ⟨G, hE, hF, hG⟩ := (certificate_iff M F E).mp hEF
  exact (tableProgram_mono M p q hE).trans (tableProgram_certificate_eq M p q hqp hF hG).le

/-! ## Theorem 1 -/

section Assembly

open FreeAlgebra

variable {A : Type}

/-- Semantic inclusion gives derivability of `e + f = f`: the shared normal forms (2) reduce it
to the inclusion between normal forms. -/
theorem derives_inclusion_of_shared_normal_forms [Fintype A] {e f : Expr A}
    (h : R e ≤ R f) : ⊢ e ≤ f := by
  obtain ⟨n, M, E, F, he, hf, hse, hsf⟩ := shared_normal_forms e f
  have hincl := normal_form_inclusion M (fun a => of (.push a))
    (fun a => of (.pop a)) FreeAlgebra.pop_push E F (by rw [← hse, ← hsf]; exact h)
  change Φ M E ≤ Φ M F at hincl
  rw [← he, ← hf] at hincl
  exact of_eq_iff.mp (by simpa using hincl.add_eq_right)

/-- **Completeness** (Theorem 1, inclusion form). -/
theorem inequational_completeness : InequationalCompleteness := by
  intro A _ e f h
  letI := Fintype.ofFinite A
  exact derives_inclusion_of_shared_normal_forms h

/-- **Completeness** (Theorem 1, equation form). -/
theorem completeness : Completeness :=
  completeness_of_inequational inequational_completeness

/-- **Theorem 1 (soundness and completeness).** For a finite alphabet,
`R_e ⊆ R_f ⟺ ⊢ e + f = f`. -/
theorem inclusion_iff_derivable [Finite A] (e f : Expr A) : R e ≤ R f ↔ ⊢ e ≤ f := by
  constructor
  · exact inequational_completeness A e f
  · intro h s t he
    exact (soundness_iff h s t).mp (Or.inl he)

/-- **Theorem 1, consequence.** For a finite alphabet, `R_e = R_f ⟺ ⊢ e = f`. -/
theorem equality_iff_derivable [Finite A] (e f : Expr A) : R e = R f ↔ ⊢ e ≈ f := by
  constructor
  · exact completeness A e f
  · exact soundness

/-- **Theorem 1 (soundness and completeness).** For a finite alphabet,
`R_e ⊆ R_f ⟺ ⊢ e + f = f`; consequently `R_e = R_f ⟺ ⊢ e = f`. -/
theorem soundness_and_completeness [Finite A] (e f : Expr A) :
    (R e ≤ R f ↔ ⊢ e ≤ f) ∧ (R e = R f ↔ ⊢ e ≈ f) :=
  ⟨inclusion_iff_derivable e f, equality_iff_derivable e f⟩

end Assembly

end Stackat
