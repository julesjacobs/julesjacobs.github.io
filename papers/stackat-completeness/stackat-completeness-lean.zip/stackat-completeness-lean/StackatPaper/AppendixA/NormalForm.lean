import StackatPaper.AppendixA.Automaton
import StackatPaper.AppendixA.Saturation

/-!
# Appendix A: reordering and the pop–push normal form

* the reordering identity (14): `ab ≤ a + b ⟹ (a + b)* = b* a*` (`reorder`);
* with `S = B`, `P = P̂`, `Q = Q̂`: `S² = S`, `PS = P`, `SQ = Q`, `PQ ≤ S` give `ab ≤ a + b` for
  `a = S + P`, `b = S + Q` (`saturated_mul_le`), hence `(S + P + Q)* = (S + Q)*(S + P)*`
  (`saturated_factorization`);
* equation (13), `M* = (B + P̂ + Q̂)*` (`StackGraph.saturated_star`);
* hence `M* = (B + Q̂)*(B + P̂)*` from the two push–pop equations alone
  (`StackGraph.factorization`);
* `e = λ(B + Q̂)*(B + P̂)*ρ` in the algebra of expressions (`StackAutomaton.normalized_ofExpr_with`);
* Lemma 2, the pop–push normal form (`pop_push_normal_form`), and both together
  (`StackAutomaton.expansion`).
-/

namespace Stackat

open scoped Computability

variable {K : Type*} [KleeneAlgebra K]

/-- **The reordering identity** (14): if `ab ≤ a + b`, then `(a + b)* = b* a*`. -/
theorem reorder {a b : K} (h : a * b ≤ a + b) : (a + b)∗ = b∗ * a∗ := by
  have hab : a * b∗ ≤ a + b∗ := by
    apply mul_kstar_le (le_add_right le_rfl)
    rw [add_mul]
    apply add_le
    · exact h.trans (add_le_add le_rfl le_kstar)
    · exact kstar_mul_le_kstar.trans (le_add_left le_rfl)
  apply le_antisymm
  · apply kstar_le_of_mul_le_right
    · simpa only [one_mul, mul_one] using mul_le_mul' (one_le_kstar (a := b)) (one_le_kstar (a := a))
    · rw [add_mul]
      apply add_le
      · calc
          a * (b∗ * a∗) = (a * b∗) * a∗ := (mul_assoc _ _ _).symm
          _ ≤ (a + b∗) * a∗ := mul_le_mul_left hab _
          _ = a * a∗ + b∗ * a∗ := add_mul _ _ _
          _ ≤ b∗ * a∗ := add_le
            (mul_kstar_le_kstar.trans (by simpa only [one_mul, mul_one] using
              (mul_le_mul_left (one_le_kstar (a := b)) a∗))) le_rfl
      · simpa only [mul_assoc] using mul_le_mul_left (mul_kstar_le_kstar (a := b)) a∗
  · calc
      b∗ * a∗ ≤ (a + b)∗ * (a + b)∗ :=
        mul_le_mul' (kstar_mono (le_add_left le_rfl)) (kstar_mono (le_add_right le_rfl))
      _ = (a + b)∗ := kstar_mul_kstar _

/-- **Appendix A.** With `S = B`, `P = P̂` and `Q = Q̂`: the identities `B² = B`, `P̂B = P̂` and
`BQ̂ = Q̂`, together with `P̂Q̂ ≤ B`, give `ab ≤ a + b` for `a = B + P̂` and `b = B + Q̂`. -/
theorem saturated_mul_le {S P Q : K}
    (hSS : S * S = S) (hPS : P * S = P)
    (hSQ : S * Q = Q) (hPQ : P * Q ≤ S) :
    (S + P) * (S + Q) ≤ (S + P) + (S + Q) := by
  rw [add_mul, mul_add, mul_add, hSS, hSQ, hPS]
  apply add_le
  · exact add_le (le_add_right (le_add_right le_rfl))
      (le_add_left (le_add_left le_rfl))
  · exact add_le (le_add_right (le_add_left le_rfl))
      (hPQ.trans (le_add_right (le_add_right le_rfl)))

theorem saturated_factorization {S P Q : K}
    (hSS : S * S = S) (hPS : P * S = P)
    (hSQ : S * Q = Q) (hPQ : P * Q ≤ S) :
    (S + P + Q)∗ = (S + Q)∗ * (S + P)∗ := by
  have h := saturated_mul_le hSS hPS hSQ hPQ
  have heq : (S + P) + (S + Q) = S + P + Q := by
    calc
      (S + P) + (S + Q) = (S + S) + P + Q := by
        simp only [add_left_comm, add_comm]
      _ = S + P + Q := by rw [add_idem]
  simpa only [heq] using reorder h

theorem normalization_of_saturation {M S P Q : K}
    (hlo : M ≤ S + P + Q) (hhi : S + P + Q ≤ M∗)
    (hSS : S * S = S) (hPS : P * S = P)
    (hSQ : S * Q = Q) (hPQ : P * Q ≤ S) :
    M∗ = (S + Q)∗ * (S + P)∗ := by
  have heq : M∗ = (S + P + Q)∗ := le_antisymm (kstar_mono hlo)
    (by simpa only [kstar_idem] using kstar_mono hhi)
  exact heq.trans (saturated_factorization hSS hPS hSQ hPQ)

theorem epsilon_star_left {S Q : K} (h1 : 1 ≤ S) (hSS : S * S = S) (hQS : Q * S = Q) :
    (S + Q)∗ = S * Q∗ := by
  apply le_antisymm
  · apply kstar_le_of_mul_le_right
    · simpa only [one_mul] using mul_le_mul' h1 (one_le_kstar (a := Q))
    · rw [add_mul, ← mul_assoc, ← mul_assoc, hSS, hQS]
      exact add_le le_rfl (mul_kstar_le_kstar.trans
        (by simpa only [one_mul] using mul_le_mul_left h1 Q∗))
  · calc
      S * Q∗ ≤ (S + Q)∗ * (S + Q)∗ :=
        mul_le_mul' ((le_add_right le_rfl).trans le_kstar) (kstar_mono (le_add_left le_rfl))
      _ = (S + Q)∗ := kstar_mul_kstar _

theorem epsilon_star_right {S Q : K} (h1 : 1 ≤ S) (hSS : S * S = S) (hSQ : S * Q = Q) :
    (S + Q)∗ = Q∗ * S := by
  apply le_antisymm
  · apply kstar_le_of_mul_le_left
    · simpa only [mul_one] using mul_le_mul' (one_le_kstar (a := Q)) h1
    · rw [mul_add, mul_assoc, mul_assoc, hSS, hSQ]
      exact add_le le_rfl (kstar_mul_le_kstar.trans
        (by simpa only [mul_one] using mul_le_mul_right h1 Q∗))
  · calc
      Q∗ * S ≤ (S + Q)∗ * (S + Q)∗ :=
        mul_le_mul' (kstar_mono (le_add_left le_rfl)) ((le_add_right le_rfl).trans le_kstar)
      _ = (S + Q)∗ := kstar_mul_kstar _

end Stackat

namespace Stackat.StackGraph

open scoped Computability

variable {A S K : Type*} [Fintype A] [Fintype S] [DecidableEq S] [KleeneAlgebra K]

/-- Balanced-path saturation separates every finite push–pop graph into a pop-only
and a push-only automaton using only the two push–pop equations. -/
theorem factorization (G : StackGraph A S) (p q : A → K)
    (hpq : ∀ a, p a * q a = 1) (hne : ∀ a b, a ≠ b → p a * q b = 0) :
    (G.transition p q)∗ =
      (G.saturation + G.saturatedPop q)∗ * (G.saturation + G.saturatedPush p)∗ :=
  normalization_of_saturation (transition_le_saturated G p q) (saturated_le_star G p q hpq)
    (saturation_idem G) (saturated_label_mul_saturation G G.push p)
    (saturation_mul_saturated_label G G.pop q) (saturated_push_pop G p q hpq hne)

/-- **Equation (13).** `M ≤ B + P̂ + Q̂ ≤ M*`, so `M* = (B + P̂ + Q̂)*`. -/
theorem saturated_star (G : StackGraph A S) (p q : A → K)
    (hpq : ∀ a, p a * q a = 1) :
    G.transition p q ≤ G.saturation + G.saturatedPush p + G.saturatedPop q ∧
      G.saturation + G.saturatedPush p + G.saturatedPop q ≤
        (G.transition p q)∗ ∧
      (G.transition p q)∗ =
        (G.saturation + G.saturatedPush p + G.saturatedPop q)∗ :=
  ⟨transition_le_saturated G p q, saturated_le_star G p q hpq,
    le_antisymm (kstar_mono (transition_le_saturated G p q))
      (by simpa only [kstar_idem] using kstar_mono (saturated_le_star G p q hpq))⟩

theorem saturated_pop_factor (G : StackGraph A S) (q : A → K) :
    (G.saturation + G.saturatedPop q)∗ = G.saturation * (G.saturatedPop q)∗ :=
  epsilon_star_left (one_le_saturation G) (saturation_idem G) (saturated_label_mul_saturation G G.pop q)

theorem saturated_push_factor (G : StackGraph A S) (p : A → K) :
    (G.saturation + G.saturatedPush p)∗ = (G.saturatedPush p)∗ * G.saturation :=
  epsilon_star_right (one_le_saturation G) (saturation_idem G) (saturation_mul_saturated_label G G.push p)

end Stackat.StackGraph

namespace Stackat.StackAutomaton

open scoped Computability

variable {A : Type} [Fintype A]

/-- `e = λ(B + Q̂)*(B + P̂)*ρ`, in expressions modulo any derivation system containing the two
push–pop equations. -/
theorem normalized_ofExpr_with {L : StackLaw → Prop} (h₁ : L .push_pop) (h₂ : L .push_pop_ne)
    (e : Expr A) :
    (FreeAlgebraWith.of e : FreeAlgebraWith L A) =
      (((ofExpr e).graph.saturation (K := FreeAlgebraWith L A) +
        (ofExpr e).graph.saturatedPop (fun a => FreeAlgebraWith.of (.pop a)))∗ *
       ((ofExpr e).graph.saturation (K := FreeAlgebraWith L A) +
        (ofExpr e).graph.saturatedPush (fun a => FreeAlgebraWith.of (.push a)))∗ :
          Matrix (ofExpr e).State (ofExpr e).State (FreeAlgebraWith L A))
          (ofExpr e).initial (ofExpr e).final := by
  rw [← eval_ofExpr_with e]
  exact congrArg (fun m => m (ofExpr e).initial (ofExpr e).final)
    ((ofExpr e).graph.factorization (fun a => FreeAlgebraWith.of (.push a))
      (fun a => FreeAlgebraWith.of (.pop a)) (FreeAlgebraWith.push_pop h₁)
      (fun _ _ h => FreeAlgebraWith.push_pop_ne h₂ h))

end Stackat.StackAutomaton

/-! ## Lemma 2 -/

namespace Stackat

open scoped Computability

variable {A : Type}

namespace Expr

/-- A pure-pop expression: built from pops, `0`, `1`, sum, product and star. -/
inductive PopOnly : Expr A → Prop
  | zero : PopOnly 0
  | one : PopOnly 1
  | pop (a : A) : PopOnly (.pop a)
  | add {e f : Expr A} : PopOnly e → PopOnly f → PopOnly (e + f)
  | mul {e f : Expr A} : PopOnly e → PopOnly f → PopOnly (e * f)
  | star {e : Expr A} : PopOnly e → PopOnly e.star

/-- A pure-push expression: built from pushes, `0`, `1`, sum, product and star. -/
inductive PushOnly : Expr A → Prop
  | zero : PushOnly 0
  | one : PushOnly 1
  | push (a : A) : PushOnly (.push a)
  | add {e f : Expr A} : PushOnly e → PushOnly f → PushOnly (e + f)
  | mul {e f : Expr A} : PushOnly e → PushOnly f → PushOnly (e * f)
  | star {e : Expr A} : PushOnly e → PushOnly e.star

/-- The finite sum of a list of expressions. -/
def sum : List (Expr A) → Expr A
  | [] => 0
  | e :: es => e + sum es

end Expr

section Closure

variable {K : Type*} [KleeneAlgebra K] (P : K → Prop) (h0 : P 0) (h1 : P 1)
  (hadd : ∀ x y, P x → P y → P (x + y)) (hmul : ∀ x y, P x → P y → P (x * y))
  (hstar : ∀ x, P x → P x∗)
include h0 h1 hadd hmul hstar

omit h1 hmul hstar in
private theorem sum_closed {I : Type*} (s : Finset I) (f : I → K) (hf : ∀ i ∈ s, P (f i)) :
    P (∑ i ∈ s, f i) :=
  Finset.sum_induction f P hadd h0 hf

/-- The entries of `M*` lie in every subset of a Kleene algebra that contains the entries of
`M` and is closed under the Kleene algebra operations (state elimination). -/
private theorem matrix_star_closed {S : Type*} [Fintype S] [DecidableEq S] (M : Matrix S S K)
    (hM : ∀ i j, P (M i j)) : ∀ i j, P (M∗ i j) := by
  have hclose : ∀ (ks : List S) (D : Matrix S S K), (∀ i j, P (D i j)) →
      ∀ i j, P (MatrixStar.close ks D i j) := by
    intro ks
    induction ks with
    | nil => exact fun D hD => hD
    | cons k ks ih =>
      intro D hD i j
      have h := ih D hD
      exact hadd _ _ (h i j) (hmul _ _ (hmul _ _ (h i k) (hstar _ (h k k))) (h k j))
  intro i j
  change P ((1 + MatrixStar.close Finset.univ.toList M) i j)
  rw [Matrix.add_apply, Matrix.one_apply]
  refine hadd _ _ ?_ (hclose _ M hM i j)
  split
  · exact h1
  · exact h0

end Closure

/-- **Lemma 2 (pop–push normal form).** Using only KA and the two push–pop equations, every
expression is provably equal to a finite sum `Σ_i q(U_i) p(V_i)` of pure-pop expressions
followed by pure-push expressions. -/
theorem pop_push_normal_form [Fintype A] (e : Expr A) :
    ∃ xs : List (Expr A × Expr A),
      (∀ x y, (x, y) ∈ xs → x.PopOnly ∧ y.PushOnly) ∧
        (⊢[(· ≠ .pop_push)] e ≈ Expr.sum (xs.map fun (x, y) => x * y)) := by
  classical
  let L : StackLaw → Prop := (· ≠ .pop_push)
  let K := FreeAlgebraWith L A
  let of : Expr A → K := FreeAlgebraWith.of
  let IsPop : K → Prop := fun z => ∃ x : Expr A, x.PopOnly ∧ of x = z
  let IsPush : K → Prop := fun z => ∃ x : Expr A, x.PushOnly ∧ of x = z
  have popClosed : ∀ (S : Type) [Fintype S] [DecidableEq S] (M : Matrix S S K),
      (∀ i j, IsPop (M i j)) → ∀ i j, IsPop (M∗ i j) :=
    fun S _ _ M hM => matrix_star_closed IsPop ⟨0, .zero, rfl⟩ ⟨1, .one, rfl⟩
      (fun _ _ ⟨x, hx, ex⟩ ⟨y, hy, ey⟩ => ⟨x + y, .add hx hy, by rw [← ex, ← ey]; rfl⟩)
      (fun _ _ ⟨x, hx, ex⟩ ⟨y, hy, ey⟩ => ⟨x * y, .mul hx hy, by rw [← ex, ← ey]; rfl⟩)
      (fun _ ⟨x, hx, ex⟩ => ⟨x.star, .star hx, by rw [← ex]; rfl⟩) M hM
  have pushClosed : ∀ (S : Type) [Fintype S] [DecidableEq S] (M : Matrix S S K),
      (∀ i j, IsPush (M i j)) → ∀ i j, IsPush (M∗ i j) :=
    fun S _ _ M hM => matrix_star_closed IsPush ⟨0, .zero, rfl⟩ ⟨1, .one, rfl⟩
      (fun _ _ ⟨x, hx, ex⟩ ⟨y, hy, ey⟩ => ⟨x + y, .add hx hy, by rw [← ex, ← ey]; rfl⟩)
      (fun _ _ ⟨x, hx, ex⟩ ⟨y, hy, ey⟩ => ⟨x * y, .mul hx hy, by rw [← ex, ← ey]; rfl⟩)
      (fun _ ⟨x, hx, ex⟩ => ⟨x.star, .star hx, by rw [← ex]; rfl⟩) M hM
  let G := (StackAutomaton.ofExpr e).graph
  have hbitPop : ∀ P : Prop, IsPop (bit (K := K) P) := fun P => by
    unfold bit; split
    · exact ⟨1, .one, rfl⟩
    · exact ⟨0, .zero, rfl⟩
  have hbitPush : ∀ P : Prop, IsPush (bit (K := K) P) := fun P => by
    unfold bit; split
    · exact ⟨1, .one, rfl⟩
    · exact ⟨0, .zero, rfl⟩
  have hX : ∀ i j, IsPop ((G.saturation (K := K) + G.saturatedPop (fun a => of (.pop a))) i j) := by
    intro i j
    rw [Matrix.add_apply]
    obtain ⟨x, hx, ex⟩ := hbitPop (G.Balanced i j)
    obtain ⟨y, hy, ey⟩ := sum_closed IsPop ⟨0, .zero, rfl⟩
      (fun _ _ ⟨x, hx, ex⟩ ⟨y, hy, ey⟩ => ⟨x + y, .add hx hy, by rw [← ex, ← ey]; rfl⟩)
      Finset.univ (fun a => if G.surround G.pop a i j then of (.pop a) else 0)
      (fun a _ => by dsimp only; split; exacts [⟨_, .pop a, rfl⟩, ⟨0, .zero, rfl⟩])
    refine ⟨x + y, .add hx hy, ?_⟩
    change of x + of y = _
    rw [ex, ey]
    rfl
  have hY : ∀ i j, IsPush ((G.saturation (K := K) + G.saturatedPush (fun a => of (.push a))) i j) := by
    intro i j
    rw [Matrix.add_apply]
    obtain ⟨x, hx, ex⟩ := hbitPush (G.Balanced i j)
    obtain ⟨y, hy, ey⟩ := sum_closed IsPush ⟨0, .zero, rfl⟩
      (fun _ _ ⟨x, hx, ex⟩ ⟨y, hy, ey⟩ => ⟨x + y, .add hx hy, by rw [← ex, ← ey]; rfl⟩)
      Finset.univ (fun a => if G.surround G.push a i j then of (.push a) else 0)
      (fun a _ => by dsimp only; split; exacts [⟨_, .push a, rfl⟩, ⟨0, .zero, rfl⟩])
    refine ⟨x + y, .add hx hy, ?_⟩
    change of x + of y = _
    rw [ex, ey]
    rfl
  have hXs := popClosed _ _ hX
  have hYs := pushClosed _ _ hY
  choose x hx ex using hXs (StackAutomaton.ofExpr e).initial
  choose y hy ey using fun k => hYs k (StackAutomaton.ofExpr e).final
  refine ⟨Finset.univ.toList.map fun k => (x k, y k), ?_, ?_⟩
  · intro x' y' hxy
    obtain ⟨k, -, hk⟩ := List.mem_map.mp hxy
    obtain ⟨rfl, rfl⟩ := Prod.mk.inj hk
    exact ⟨hx k, hy k⟩
  · apply FreeAlgebraWith.of_eq_iff.mp
    rw [StackAutomaton.normalized_ofExpr_with (L := L) (by decide) (by decide) e, Matrix.mul_apply]
    have hsum : ∀ l : List (StackAutomaton.ofExpr e).State,
        (FreeAlgebraWith.of
          (Expr.sum ((l.map fun k => (x k, y k)).map fun (x, y) => x * y)) : K)
          = (l.map fun k => of (x k) * of (y k)).sum := by
      intro l
      induction l with
      | nil => rfl
      | cons k l ih =>
        simp only [List.map_cons, List.sum_cons, ← ih]
        rfl
    rw [hsum, Finset.sum_map_toList]
    simp only [ex, ey]
    rfl

end Stackat

namespace Stackat.StackAutomaton

open scoped Computability

variable {A : Type} [Fintype A]

/-- **Appendix A.** In the algebra of expressions modulo KA and the two push–pop equations,
`e = λ(B + Q̂)*(B + P̂)*ρ`, and expanding the finite matrix product gives a finite sum of pure-pop
expressions followed by pure-push expressions. -/
theorem expansion (e : Expr A) :
    let K := FreeAlgebraWith (· ≠ .pop_push) A
    let G := (ofExpr e).graph
    let p := fun a => (FreeAlgebraWith.of (.push a) : K)
    let q := fun a => (FreeAlgebraWith.of (.pop a) : K)
    (FreeAlgebraWith.of e : K) =
        ((G.saturation + G.saturatedPop q)∗ *
            (G.saturation + G.saturatedPush p)∗ : Matrix _ _ K)
          (ofExpr e).initial (ofExpr e).final ∧
      ∃ xs : List (Expr A × Expr A),
        (∀ x y, (x, y) ∈ xs → x.PopOnly ∧ y.PushOnly) ∧
          (⊢[(· ≠ .pop_push)] e ≈ Expr.sum (xs.map fun (x, y) => x * y)) :=
  ⟨normalized_ofExpr_with (by decide) (by decide) e, pop_push_normal_form e⟩

end Stackat.StackAutomaton
