import StackatPaper.AppendixA.StackGraph
import StackatPaper.Background.FreeAlgebra

/-!
Appendix A: the algebraic automaton of an expression, `e = λ M* ρ` (`StackAutomaton.ofExpr`,
`StackAutomaton.eval_ofExpr`, `StackAutomaton.eval_ofExpr_free`), justified in every Kleene
algebra by finite star induction.
-/

namespace Stackat.StackGraph

open scoped Computability


variable {A S T K : Type*}

structure Map (G : StackGraph A S) (H : StackGraph A T) (f : S → T) : Prop where
  eps : ∀ i j, G.eps i j → H.eps (f i) (f j)
  push : ∀ a i j, G.push a i j → H.push a (f i) (f j)
  pop : ∀ a i j, G.pop a i j → H.pop a (f i) (f j)

variable [Fintype A] [Fintype S] [DecidableEq S] [KleeneAlgebra K]

noncomputable def paths (G : StackGraph A S) (p q : A → K) : Matrix S S K :=
  (G.transition p q)∗

omit [Fintype S] [DecidableEq S] in
theorem eps_le_transition (G : StackGraph A S) (p q : A → K) {i j} (h : G.eps i j) :
    1 ≤ G.transition p q i j := by
  have hb : boolMatrix (K := K) G.eps i j = 1 := bit_true h
  rw [← hb]
  exact (le_add_right le_rfl).trans (le_add_right le_rfl)

theorem eps_le_paths (G : StackGraph A S) (p q : A → K) {i j} (h : G.eps i j) :
    1 ≤ G.paths p q i j :=
  (eps_le_transition G p q h).trans (le_kstar (a := G.transition p q) i j)

theorem push_le_paths (G : StackGraph A S) (p q : A → K) {a i j} (h : G.push a i j) :
    p a ≤ G.paths p q i j :=
  (push_le_transition G p q h).trans (le_kstar (a := G.transition p q) i j)

theorem pop_le_paths (G : StackGraph A S) (p q : A → K) {a i j} (h : G.pop a i j) :
    q a ≤ G.paths p q i j :=
  (pop_le_transition G p q h).trans (le_kstar (a := G.transition p q) i j)

theorem paths_refl (G : StackGraph A S) (p q : A → K) (i : S) : 1 ≤ G.paths p q i i :=
  matrix_star_diagonal _ _

theorem paths_trans (G : StackGraph A S) (p q : A → K) (i j k : S) :
    G.paths p q i j * G.paths p q j k ≤ G.paths p q i k :=
  matrix_star_entry_mul_le _ _ _ _

theorem paths_between (G : StackGraph A S) (p q : A → K) {x : K} {i j k l : S}
    (hi : 1 ≤ G.paths p q i j) (hx : x ≤ G.paths p q j k) (hl : 1 ≤ G.paths p q k l) :
    x ≤ G.paths p q i l := by
  calc
    x = 1 * x * 1 := by simp only [one_mul, mul_one]
    _ ≤ G.paths p q i j * G.paths p q j k * G.paths p q k l :=
      mul_le_mul' (mul_le_mul' hi hx) hl
    _ ≤ G.paths p q i k * G.paths p q k l := mul_le_mul_left (G.paths_trans p q i j k) _
    _ ≤ G.paths p q i l := G.paths_trans p q i k l

structure Potential (G : StackGraph A S) (p q : A → K) (b : S → K) : Prop where
  eps : ∀ i j, G.eps i j → b j ≤ b i
  push : ∀ a i j, G.push a i j → p a * b j ≤ b i
  pop : ∀ a i j, G.pop a i j → q a * b j ≤ b i

omit [Fintype S] [DecidableEq S] in
theorem Potential.transition {G : StackGraph A S} {p q : A → K} {b : S → K}
    (h : G.Potential p q b) (i j : S) : G.transition p q i j * b j ≤ b i := by
  classical
  simp only [StackGraph.transition, Matrix.add_apply, labelMatrix, add_mul, Finset.sum_mul]
  apply add_le
  · apply add_le
    · by_cases he : G.eps i j
      · simpa only [boolMatrix, bit_true he, one_mul] using h.eps i j he
      · simp only [boolMatrix, bit_false he, zero_mul]; exact zero_le
    · apply idem_sum_le
      intro a _
      by_cases hp : G.push a i j
      · simpa only [if_pos hp] using h.push a i j hp
      · simp only [if_neg hp, zero_mul]; exact zero_le
  · apply idem_sum_le
    intro a _
    by_cases hq : G.pop a i j
    · simpa only [if_pos hq] using h.pop a i j hq
    · simp only [if_neg hq, zero_mul]; exact zero_le

theorem Potential.bound {G : StackGraph A S} {p q : A → K} {b : S → K}
    (h : G.Potential p q b) (i j : S) (hj : 1 ≤ b j) : G.paths p q i j ≤ b i :=
  matrix_star_le_potential _ _ h.transition i j hj

theorem paths_potential (G : StackGraph A S) (p q : A → K) (t : S) :
    G.Potential p q (fun i => G.paths p q i t) where
  eps i j h := by
    calc
      G.paths p q j t = 1 * G.paths p q j t := (one_mul _).symm
      _ ≤ G.paths p q i j * G.paths p q j t := mul_le_mul_left (G.eps_le_paths p q h) _
      _ ≤ G.paths p q i t := G.paths_trans p q i j t
  push a i j h := (mul_le_mul_left (G.push_le_paths p q h) _).trans (G.paths_trans p q i j t)
  pop a i j h := (mul_le_mul_left (G.pop_le_paths p q h) _).trans (G.paths_trans p q i j t)

omit [Fintype A] [Fintype S] [DecidableEq S] in
theorem Potential.mul_right {G : StackGraph A S} {p q : A → K} {b : S → K}
    (h : G.Potential p q b) (x : K) : G.Potential p q (fun i => b i * x) where
  eps i j he := mul_le_mul_left (h.eps i j he) x
  push a i j hp := by simpa only [mul_assoc] using mul_le_mul_left (h.push a i j hp) x
  pop a i j hq := by simpa only [mul_assoc] using mul_le_mul_left (h.pop a i j hq) x

variable [Fintype T] [DecidableEq T]

omit [Fintype S] [DecidableEq S] [Fintype T] [DecidableEq T] in
theorem Map.transition {G : StackGraph A S} {H : StackGraph A T} {f : S → T}
    (h : G.Map H f) (p q : A → K) (i j : S) : G.transition p q i j ≤ H.transition p q (f i) (f j) := by
  classical
  apply add_le
  · apply add_le
    · by_cases he : G.eps i j
      · simpa only [boolMatrix, bit_true he] using H.eps_le_transition p q (h.eps i j he)
      · simp only [boolMatrix, bit_false he]; exact zero_le
    · apply idem_sum_le
      intro a _
      by_cases hp : G.push a i j
      · simpa only [if_pos hp] using H.push_le_transition p q (h.push a i j hp)
      · simp only [if_neg hp]; exact zero_le
  · apply idem_sum_le
    intro a _
    by_cases hq : G.pop a i j
    · simpa only [if_pos hq] using H.pop_le_transition p q (h.pop a i j hq)
    · simp only [if_neg hq]; exact zero_le

theorem Map.paths {G : StackGraph A S} {H : StackGraph A T} {f : S → T}
    (h : G.Map H f) (p q : A → K) (i j : S) : G.paths p q i j ≤ H.paths p q (f i) (f j) :=
  matrix_star_map_le _ _ f (h.transition p q) i j

end Stackat.StackGraph

namespace Stackat.StackGraph

variable {A S T K : Type*}

def empty : StackGraph A S := ⟨fun _ _ => False, fun _ _ _ => False, fun _ _ _ => False⟩

def sum (G : StackGraph A S) (H : StackGraph A T)
    (bridge : S ⊕ T → S ⊕ T → Prop) : StackGraph A (S ⊕ T) where
  eps i j := (match i, j with
    | .inl i, .inl j => G.eps i j
    | .inr i, .inr j => H.eps i j
    | _, _ => False) ∨ bridge i j
  push a i j := match i, j with
    | .inl i, .inl j => G.push a i j
    | .inr i, .inr j => H.push a i j
    | _, _ => False
  pop a i j := match i, j with
    | .inl i, .inl j => G.pop a i j
    | .inr i, .inr j => H.pop a i j
    | _, _ => False

theorem map_sum_left (G : StackGraph A S) (H : StackGraph A T) (bridge) :
    G.Map (G.sum H bridge) Sum.inl where
  eps _ _ h := Or.inl h
  push _ _ _ h := h
  pop _ _ _ h := h

theorem map_sum_right (G : StackGraph A S) (H : StackGraph A T) (bridge) :
    H.Map (G.sum H bridge) Sum.inr where
  eps _ _ h := Or.inl h
  push _ _ _ h := h
  pop _ _ _ h := h

theorem Map.comp {U : Type*} {G : StackGraph A S} {H : StackGraph A T}
    {J : StackGraph A U} {f : S → T} {g : T → U} (h : G.Map H f) (k : H.Map J g) :
    G.Map J (g ∘ f) where
  eps i j he := k.eps _ _ (h.eps i j he)
  push a i j hp := k.push a _ _ (h.push a i j hp)
  pop a i j hq := k.pop a _ _ (h.pop a i j hq)

variable [KleeneAlgebra K]

theorem Potential.empty (p q : A → K) (b : S → K) : (empty : StackGraph A S).Potential p q b where
  eps _ _ h := h.elim
  push _ _ _ h := h.elim
  pop _ _ _ h := h.elim

theorem Potential.sum {G : StackGraph A S} {H : StackGraph A T} {bridge}
    {p q : A → K} {b : S → K} {c : T → K}
    (hb : G.Potential p q b) (hc : H.Potential p q c)
    (hbridge : ∀ i j, bridge i j → Sum.elim b c j ≤ Sum.elim b c i) :
    (G.sum H bridge).Potential p q (Sum.elim b c) where
  eps i j h := by
    rcases h with h | h
    · cases i <;> cases j
      · exact hb.eps _ _ h
      · exact h.elim
      · exact h.elim
      · exact hc.eps _ _ h
    · exact hbridge i j h
  push a i j h := by
    cases i <;> cases j
    · exact hb.push a _ _ h
    · exact h.elim
    · exact h.elim
    · exact hc.push a _ _ h
  pop a i j h := by
    cases i <;> cases j
    · exact hb.pop a _ _ h
    · exact h.elim
    · exact h.elim
    · exact hc.pop a _ _ h

end Stackat.StackGraph

namespace Stackat

open scoped Computability

structure StackAutomaton (A : Type) where
  State : Type
  [finiteState : Fintype State]
  [decEqState : DecidableEq State]
  graph : StackGraph A State
  initial : State
  final : State

attribute [instance] StackAutomaton.finiteState StackAutomaton.decEqState

namespace StackAutomaton

variable {A : Type} {K : Type*} [Fintype A] [KleeneAlgebra K]

noncomputable def eval (M : StackAutomaton A) (p q : A → K) : K :=
  M.graph.paths p q M.initial M.final

def single (eps : Prop) (push pop : A → Prop) : StackAutomaton A where
  State := Bool
  graph := {
    eps := fun i j => i = false ∧ j = true ∧ eps
    push := fun a i j => i = false ∧ j = true ∧ push a
    pop := fun a i j => i = false ∧ j = true ∧ pop a }
  initial := false
  final := true

theorem single_le (eps : Prop) (push pop : A → Prop) (p q : A → K) (x : K)
    (he : eps → 1 ≤ x) (hp : ∀ a, push a → p a ≤ x) (hq : ∀ a, pop a → q a ≤ x) :
    (single eps push pop).eval p q ≤ x := by
  let b : Bool → K := fun i => if i then 1 else x
  have h : (single eps push pop).graph.Potential p q b := {
    eps := by rintro i j ⟨rfl, rfl, h⟩; exact he h
    push := by rintro a i j ⟨rfl, rfl, h⟩; simpa only [b, Bool.false_eq_true, ↓reduceIte, mul_one] using hp a h
    pop := by rintro a i j ⟨rfl, rfl, h⟩; simpa only [b, Bool.false_eq_true, ↓reduceIte, mul_one] using hq a h }
  exact h.bound false true le_rfl

def zero : StackAutomaton A := single False (fun _ => False) (fun _ => False)
def one : StackAutomaton A := single True (fun _ => False) (fun _ => False)
def push (a : A) : StackAutomaton A := single False (· = a) (fun _ => False)
def pop (a : A) : StackAutomaton A := single False (fun _ => False) (· = a)

@[simp] theorem eval_zero (p q : A → K) : (zero : StackAutomaton A).eval p q = 0 := by
  apply le_antisymm _ zero_le
  exact single_le _ _ _ p q 0 False.elim (fun _ => False.elim) (fun _ => False.elim)

@[simp] theorem eval_one (p q : A → K) : (one : StackAutomaton A).eval p q = 1 := by
  apply le_antisymm
  · exact single_le _ _ _ p q 1 (fun _ => le_rfl) (fun _ => False.elim) (fun _ => False.elim)
  · exact (one : StackAutomaton A).graph.eps_le_paths p q ⟨rfl, rfl, trivial⟩

@[simp] theorem eval_push (p q : A → K) (a : A) : (push a).eval p q = p a := by
  apply le_antisymm
  · exact single_le _ _ _ p q (p a) False.elim (fun _ h => by subst h; exact le_rfl) (fun _ => False.elim)
  · exact (push a).graph.push_le_paths p q ⟨rfl, rfl, rfl⟩

@[simp] theorem eval_pop (p q : A → K) (a : A) : (pop a).eval p q = q a := by
  apply le_antisymm
  · exact single_le _ _ _ p q (q a) False.elim (fun _ => False.elim) (fun _ h => by subst h; exact le_rfl)
  · exact (pop a).graph.pop_le_paths p q ⟨rfl, rfl, rfl⟩

def mulBridge (M N : StackAutomaton A) : M.State ⊕ N.State → M.State ⊕ N.State → Prop
  | .inl i, .inr j => i = M.final ∧ j = N.initial
  | _, _ => False

def mul (M N : StackAutomaton A) : StackAutomaton A where
  State := M.State ⊕ N.State
  graph := M.graph.sum N.graph (mulBridge M N)
  initial := .inl M.initial
  final := .inr N.final

theorem eval_mul (M N : StackAutomaton A) (p q : A → K) :
    (mul M N).eval p q = M.eval p q * N.eval p q := by
  let x := M.graph.paths p q
  let y := N.graph.paths p q
  let z := (mul M N).graph.paths p q
  have hleft := M.graph.map_sum_left N.graph (mulBridge M N)
  have hright := M.graph.map_sum_right N.graph (mulBridge M N)
  have hbridge : 1 ≤ z (.inl M.final) (.inr N.initial) :=
    (mul M N).graph.eps_le_paths p q (Or.inr ⟨rfl, rfl⟩)
  apply le_antisymm
  · have h := ((M.graph.paths_potential p q M.final).mul_right (N.eval p q)).sum
      (N.graph.paths_potential p q N.final) (bridge := mulBridge M N)
    apply h _ |>.bound (.inl M.initial) (.inr N.final) (N.graph.paths_refl p q N.final)
    intro i j hij
    cases i <;> cases j <;> try exact hij.elim
    rcases hij with ⟨rfl, rfl⟩
    simpa only [Sum.elim_inl, Sum.elim_inr, one_mul] using
      mul_le_mul_left (M.graph.paths_refl p q M.final) (N.eval p q)
  · change x M.initial M.final * y N.initial N.final ≤ z (.inl M.initial) (.inr N.final)
    calc
      x M.initial M.final * y N.initial N.final =
          x M.initial M.final * 1 * y N.initial N.final := by rw [mul_one]
      _ ≤ z (.inl M.initial) (.inl M.final) * z (.inl M.final) (.inr N.initial) * z (.inr N.initial) (.inr N.final) :=
        mul_le_mul' (mul_le_mul' (hleft.paths p q _ _) hbridge) (hright.paths p q _ _)
      _ ≤ z (.inl M.initial) (.inr N.initial) * z (.inr N.initial) (.inr N.final) :=
        mul_le_mul_left ((mul M N).graph.paths_trans p q _ _ _) _
      _ ≤ z (.inl M.initial) (.inr N.final) := (mul M N).graph.paths_trans p q _ _ _

end StackAutomaton
end Stackat

namespace Stackat.StackAutomaton

open scoped Computability

variable {A : Type} {K : Type*} [Fintype A] [KleeneAlgebra K]

def addBridge (M N : StackAutomaton A) : Bool ⊕ (M.State ⊕ N.State) → Bool ⊕ (M.State ⊕ N.State) → Prop
  | .inl false, .inr (.inl i) => i = M.initial
  | .inl false, .inr (.inr i) => i = N.initial
  | .inr (.inl i), .inl true => i = M.final
  | .inr (.inr i), .inl true => i = N.final
  | _, _ => False

def add (M N : StackAutomaton A) : StackAutomaton A where
  State := Bool ⊕ (M.State ⊕ N.State)
  graph := StackGraph.empty.sum (M.graph.sum N.graph (fun _ _ => False)) (addBridge M N)
  initial := .inl false
  final := .inl true

theorem eval_add (M N : StackAutomaton A) (p q : A → K) :
    (add M N).eval p q = M.eval p q + N.eval p q := by
  let core := M.graph.sum N.graph (fun _ _ => False)
  have hcore := StackGraph.map_sum_right (StackGraph.empty : StackGraph A Bool) core (addBridge M N)
  have hm := (M.graph.map_sum_left N.graph (fun _ _ => False)).comp hcore
  have hn := (M.graph.map_sum_right N.graph (fun _ _ => False)).comp hcore
  apply le_antisymm
  · let b : Bool → K := fun i => if i then 1 else M.eval p q + N.eval p q
    have hpCore := (M.graph.paths_potential p q M.final).sum (N.graph.paths_potential p q N.final)
      (bridge := fun _ _ => False) (fun _ _ => False.elim)
    have hp := (StackGraph.Potential.empty p q b).sum hpCore (bridge := addBridge M N)
    apply hp _ |>.bound (.inl false) (.inl true) le_rfl
    intro i j hij
    rcases i with b | (i | i) <;> rcases j with c | (j | j)
    · cases b <;> cases c <;> exact hij.elim
    · cases b
      · cases hij
        exact le_add_right le_rfl
      · exact hij.elim
    · cases b
      · cases hij
        exact le_add_left le_rfl
      · exact hij.elim
    · cases c
      · exact hij.elim
      · cases hij
        exact M.graph.paths_refl p q M.final
    · exact hij.elim
    · exact hij.elim
    · cases c
      · exact hij.elim
      · cases hij
        exact N.graph.paths_refl p q N.final
    · exact hij.elim
    · exact hij.elim
  · apply add_le
    · exact (add M N).graph.paths_between p q
        ((add M N).graph.eps_le_paths p q (i := .inl false) (j := .inr (.inl M.initial)) (Or.inr rfl))
        (hm.paths p q M.initial M.final)
        ((add M N).graph.eps_le_paths p q (i := .inr (.inl M.final)) (j := .inl true) (Or.inr rfl))
    · exact (add M N).graph.paths_between p q
        ((add M N).graph.eps_le_paths p q (i := .inl false) (j := .inr (.inr N.initial)) (Or.inr rfl))
        (hn.paths p q N.initial N.final)
        ((add M N).graph.eps_le_paths p q (i := .inr (.inr N.final)) (j := .inl true) (Or.inr rfl))

def starBridge (M : StackAutomaton A) : Bool ⊕ M.State → Bool ⊕ M.State → Prop
  | .inl false, .inl true => True
  | .inl false, .inr i => i = M.initial
  | .inr i, .inl false => i = M.final
  | _, _ => False

def star (M : StackAutomaton A) : StackAutomaton A where
  State := Bool ⊕ M.State
  graph := StackGraph.empty.sum M.graph (starBridge M)
  initial := .inl false
  final := .inl true

theorem eval_star (M : StackAutomaton A) (p q : A → K) : (star M).eval p q = (M.eval p q)∗ := by
  let x := M.eval p q
  let z := (star M).graph.paths p q
  have hm := StackGraph.map_sum_right (StackGraph.empty : StackGraph A Bool) M.graph (starBridge M)
  have hentry : 1 ≤ z (.inl false) (.inr M.initial) :=
    (star M).graph.eps_le_paths p q (Or.inr rfl)
  have hexit : 1 ≤ z (.inr M.final) (.inl false) :=
    (star M).graph.eps_le_paths p q (Or.inr rfl)
  have hunit : 1 ≤ z (.inl false) (.inl true) :=
    (star M).graph.eps_le_paths p q (Or.inr trivial)
  apply le_antisymm
  · let b : Bool → K := fun i => if i then 1 else x∗
    have hp := (StackGraph.Potential.empty p q b).sum
      ((M.graph.paths_potential p q M.final).mul_right x∗) (bridge := starBridge M)
    apply hp _ |>.bound (.inl false) (.inl true) le_rfl
    intro i j hij
    rcases i with b | i <;> rcases j with c | j
    · cases b <;> cases c
      · exact hij.elim
      · exact one_le_kstar
      · exact hij.elim
      · exact hij.elim
    · cases b
      · cases hij
        exact mul_kstar_le_kstar
      · exact hij.elim
    · cases c
      · cases hij
        simpa only [one_mul] using mul_le_mul_left (M.graph.paths_refl p q M.final) x∗
      · exact hij.elim
    · exact hij.elim
  · apply kstar_le_of_mul_le_right hunit
    have hloop : x ≤ z (.inl false) (.inl false) :=
      (star M).graph.paths_between p q hentry (hm.paths p q M.initial M.final) hexit
    exact (mul_le_mul_left hloop _).trans ((star M).graph.paths_trans p q _ _ _)

/-- Thompson construction, justified in every Kleene algebra by finite star induction. -/
def ofExpr : Expr A → StackAutomaton A
  | .zero => zero
  | .one => one
  | .push a => push a
  | .pop a => pop a
  | .add e f => add (ofExpr e) (ofExpr f)
  | .mul e f => mul (ofExpr e) (ofExpr f)
  | .star e => star (ofExpr e)

theorem eval_ofExpr (e : Expr A) (p q : A → K) : (ofExpr e).eval p q = Expr.eval p q e := by
  induction e with
  | zero => exact eval_zero p q
  | one => exact eval_one p q
  | push a => exact eval_push p q a
  | pop a => exact eval_pop p q a
  | add e f he hf => simpa only [ofExpr, Expr.eval, he, hf] using eval_add (ofExpr e) (ofExpr f) p q
  | mul e f he hf => simpa only [ofExpr, Expr.eval, he, hf] using eval_mul (ofExpr e) (ofExpr f) p q
  | star e he => simpa only [ofExpr, Expr.eval, he] using eval_star (ofExpr e) p q

/-- Evaluating the automaton of `e` at the classes of the pushes and pops gives the class of
`e`, in expressions modulo any of the derivation systems `DerivesWith L`. -/
theorem eval_ofExpr_with {L : StackLaw → Prop} (e : Expr A) :
    (ofExpr e).eval (fun a => (FreeAlgebraWith.of (.push a) : FreeAlgebraWith L A))
      (fun a => FreeAlgebraWith.of (.pop a)) = FreeAlgebraWith.of e := by
  rw [eval_ofExpr]
  exact FreeAlgebraWith.eval_of e

/-- **The automaton representation** `e = λ M* ρ`, in the algebra of expressions modulo
derivability: `λ`, `ρ` select the initial and final state of the automaton of `e`. -/
theorem eval_ofExpr_free (e : Expr A) :
    (ofExpr e).eval (p := fun a => FreeAlgebra.of (.push a))
        (q := fun a => FreeAlgebra.of (.pop a)) =
      FreeAlgebra.of e :=
  eval_ofExpr_with e

end Stackat.StackAutomaton
