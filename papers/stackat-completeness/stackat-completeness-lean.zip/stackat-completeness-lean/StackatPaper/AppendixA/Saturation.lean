import StackatPaper.AppendixA.StackGraph

/-!
# Appendix A: balanced-path saturation

* a balanced path gives a unit-labelled edge (`StackGraph.balanced_le_star`);
* the balanced closure `B` (`StackGraph.saturation`, the Boolean matrix of the least relation
  `StackGraph.Balanced` containing `I + E_0` and closed under `B² ≤ B` and `B U_a B V_a B ≤ B`);
* `B² = B` (`StackGraph.saturation_idem`), `B ≤ M*` (`StackGraph.saturation_le_star`);
* `P̂ = B(Σ_a p_a U_a)B` and `Q̂ = B(Σ_a q_a V_a)B` (`StackGraph.saturatedPush`,
  `StackGraph.saturatedPop`), `P̂ Q̂ ≤ B` (`StackGraph.saturated_push_pop`);
* `M ≤ B + P̂ + Q̂ ≤ M*` (`StackGraph.transition_le_saturated`, `StackGraph.saturated_le_star`),
  which gives (13) `M* = (B + P̂ + Q̂)*`.
-/

namespace Stackat

open scoped Computability

namespace StackGraph

variable {A S K : Type*}

inductive Balanced (G : StackGraph A S) : S → S → Prop where
  | refl (i) : Balanced G i i
  | eps {i j} : G.eps i j → Balanced G i j
  | trans {i j k} : Balanced G i j → Balanced G j k → Balanced G i k
  | matchPair {a i j k l} :
      G.push a i j → Balanced G j k → G.pop a k l → Balanced G i l

def surround (G : StackGraph A S) (L : A → S → S → Prop) (a : A) (i j : S) :
    Prop :=
  ∃ u v, G.Balanced i u ∧ L a u v ∧ G.Balanced v j

theorem surround_edge (G : StackGraph A S) (L : A → S → S → Prop)
    {a i j} (h : L a i j) : G.surround L a i j :=
  ⟨i, j, .refl i, h, .refl j⟩

theorem surround_left (G : StackGraph A S) (L : A → S → S → Prop)
    {a i j k} (h : G.Balanced i j) (hL : G.surround L a j k) : G.surround L a i k := by
  obtain ⟨u, v, hju, huv, hvk⟩ := hL
  exact ⟨u, v, .trans h hju, huv, hvk⟩

theorem surround_right (G : StackGraph A S) (L : A → S → S → Prop)
    {a i j k} (hL : G.surround L a i j) (h : G.Balanced j k) : G.surround L a i k := by
  obtain ⟨u, v, hiu, huv, hvj⟩ := hL
  exact ⟨u, v, hiu, huv, .trans hvj h⟩

theorem surround_match (G : StackGraph A S) {a i j k}
    (hp : G.surround G.push a i j) (hq : G.surround G.pop a j k) : G.Balanced i k := by
  obtain ⟨u, v, hiu, huv, hvj⟩ := hp
  obtain ⟨x, y, hjx, hxy, hyk⟩ := hq
  exact .trans hiu (.trans (.matchPair huv (.trans hvj hjx) hxy) hyk)

variable [Fintype A] [KleeneAlgebra K]

noncomputable def saturation (G : StackGraph A S) : Matrix S S K :=
  boolMatrix G.Balanced

noncomputable def saturatedPush (G : StackGraph A S) (p : A → K) :
    Matrix S S K :=
  labelMatrix (G.surround G.push) p

noncomputable def saturatedPop (G : StackGraph A S) (q : A → K) :
    Matrix S S K :=
  labelMatrix (G.surround G.pop) q

variable [Fintype S] [DecidableEq S]

/-- **A balanced path gives a unit-labelled edge:** if `p_a q_a = 1`, a balanced connection from `i`
to `j` gives `1 ≤ (M*)_{ij}`. -/
theorem balanced_le_star (G : StackGraph A S) (p q : A → K)
    (hpq : ∀ a, p a * q a = 1) {i j} (h : G.Balanced i j) :
    1 ≤ (G.transition p q)∗ i j := by
  induction h with
  | refl i => exact matrix_star_diagonal _ i
  | @eps i j h =>
    have he : (1 : K) ≤ G.transition p q i j := by
      have hb : boolMatrix (K := K) G.eps i j = 1 := bit_true h
      rw [← hb]
      exact (le_add_right le_rfl).trans (le_add_right le_rfl)
    exact he.trans (le_kstar (a := G.transition p q) i j)
  | @trans i j k _ _ hij hjk =>
    calc
      1 = (1 : K) * 1 := (one_mul _).symm
      _ ≤ (G.transition p q)∗ i j * (G.transition p q)∗ j k := mul_le_mul' hij hjk
      _ ≤ (G.transition p q)∗ i k := matrix_star_entry_mul_le _ i k j
  | @matchPair a i j k l hij _ hkl hjk =>
    have hp : p a ≤ (G.transition p q)∗ i j :=
      (push_le_transition G p q hij).trans (le_kstar (a := G.transition p q) i j)
    have hq : q a ≤ (G.transition p q)∗ k l :=
      (pop_le_transition G p q hkl).trans (le_kstar (a := G.transition p q) k l)
    calc
      1 = p a * 1 * q a := by rw [mul_one, hpq]
      _ ≤ (G.transition p q)∗ i j * (G.transition p q)∗ j k * (G.transition p q)∗ k l :=
        mul_le_mul' (mul_le_mul' hp hjk) hq
      _ ≤ (G.transition p q)∗ i k * (G.transition p q)∗ k l :=
        mul_le_mul_left (matrix_star_entry_mul_le _ i k j) _
      _ ≤ (G.transition p q)∗ i l := matrix_star_entry_mul_le _ i l k

/-- **`B ≤ M*`**, if `p_a q_a = 1`. -/
theorem saturation_le_star (G : StackGraph A S) (p q : A → K)
    (hpq : ∀ a, p a * q a = 1) : G.saturation ≤ (G.transition p q)∗ := by
  classical
  intro i j
  by_cases h : G.Balanced i j
  · simpa only [saturation, boolMatrix, bit_true h] using balanced_le_star G p q hpq h
  · simp only [saturation, boolMatrix, bit_false h]; exact zero_le

theorem surround_le_star (G : StackGraph A S) (p q : A → K)
    (hpq : ∀ a, p a * q a = 1) (L : A → S → S → Prop) (w : A → K)
    (hL : ∀ a i j, L a i j → w a ≤ G.transition p q i j)
    {a i j} (h : G.surround L a i j) : w a ≤ (G.transition p q)∗ i j := by
  obtain ⟨u, v, hiu, huv, hvj⟩ := h
  calc
    w a = 1 * w a * 1 := by simp only [one_mul, mul_one]
    _ ≤ (G.transition p q)∗ i u * (G.transition p q)∗ u v * (G.transition p q)∗ v j :=
      mul_le_mul' (mul_le_mul' (balanced_le_star G p q hpq hiu)
        ((hL a u v huv).trans (le_kstar (a := G.transition p q) u v)))
        (balanced_le_star G p q hpq hvj)
    _ ≤ (G.transition p q)∗ i v * (G.transition p q)∗ v j :=
      mul_le_mul_left (matrix_star_entry_mul_le _ i v u) _
    _ ≤ (G.transition p q)∗ i j := matrix_star_entry_mul_le _ i j v

theorem saturated_label_le_star (G : StackGraph A S) (p q : A → K)
    (hpq : ∀ a, p a * q a = 1) (L : A → S → S → Prop) (w : A → K)
    (hL : ∀ a i j, L a i j → w a ≤ G.transition p q i j) :
    labelMatrix (G.surround L) w ≤ (G.transition p q)∗ := by
  classical
  intro i j
  apply idem_sum_le
  intro a _
  by_cases h : G.surround L a i j
  · simpa only [if_pos h] using surround_le_star G p q hpq L w hL h
  · simp only [if_neg h]; exact zero_le

end StackGraph
end Stackat


namespace Stackat.StackGraph

open scoped Computability


variable {A S K : Type*} [Fintype A] [Fintype S] [DecidableEq S] [KleeneAlgebra K]

omit [Fintype A] [Fintype S] in
theorem one_le_saturation (G : StackGraph A S) : (1 : Matrix S S K) ≤ G.saturation := by
  classical
  intro i j
  by_cases hij : i = j
  · subst j
    simp only [Matrix.one_apply_eq, saturation, boolMatrix, bit_true (Balanced.refl i), le_refl]
  · simp only [Matrix.one_apply_ne hij, saturation, boolMatrix]
    exact zero_le

omit [Fintype A] in
/-- **`B² = B`.** -/
theorem saturation_idem (G : StackGraph A S) :
    G.saturation * G.saturation = (G.saturation : Matrix S S K) := by
  classical
  apply le_antisymm
  · intro i j
    apply idem_sum_le
    intro k _
    by_cases hik : G.Balanced i k
    · by_cases hkj : G.Balanced k j
      · simp only [saturation, boolMatrix, bit_true hik, bit_true hkj,
          bit_true (Balanced.trans hik hkj), one_mul, le_refl]
      · simp only [saturation, boolMatrix, bit_false hkj, mul_zero]; exact zero_le
    · simp only [saturation, boolMatrix, bit_false hik, zero_mul]; exact zero_le
  · simpa only [mul_one] using mul_le_mul_right (one_le_saturation G) (G.saturation : Matrix S S K)

omit [DecidableEq S] in
theorem saturation_mul_label (G : StackGraph A S) (L : A → S → S → Prop) (w : A → K) :
    G.saturation * labelMatrix (G.surround L) w ≤ labelMatrix (G.surround L) w := by
  classical
  intro i j
  simp only [Matrix.mul_apply, labelMatrix, Finset.mul_sum]
  apply idem_sum_le
  intro k _
  apply idem_sum_le
  intro a _
  by_cases hik : G.Balanced i k
  · by_cases hL : G.surround L a k j
    · simp only [saturation, boolMatrix, bit_true hik, if_pos hL, one_mul]
      exact label_le _ w (surround_left G L hik hL)
    · simp only [if_neg hL, mul_zero]; exact zero_le
  · simp only [saturation, boolMatrix, bit_false hik, zero_mul]; exact zero_le

omit [DecidableEq S] in
theorem label_mul_saturation (G : StackGraph A S) (L : A → S → S → Prop) (w : A → K) :
    labelMatrix (G.surround L) w * G.saturation ≤ labelMatrix (G.surround L) w := by
  classical
  intro i j
  simp only [Matrix.mul_apply, labelMatrix, Finset.sum_mul]
  apply idem_sum_le
  intro k _
  apply idem_sum_le
  intro a _
  by_cases hkj : G.Balanced k j
  · by_cases hL : G.surround L a i k
    · simp only [saturation, boolMatrix, bit_true hkj, if_pos hL, mul_one]
      exact label_le _ w (surround_right G L hL hkj)
    · simp only [if_neg hL, zero_mul]; exact zero_le
  · simp only [saturation, boolMatrix, bit_false hkj, mul_zero]; exact zero_le

theorem saturated_label_mul_saturation (G : StackGraph A S) (L : A → S → S → Prop) (w : A → K) :
    labelMatrix (G.surround L) w * G.saturation = labelMatrix (G.surround L) w := by
  apply le_antisymm (label_mul_saturation G L w)
  simpa only [mul_one] using mul_le_mul_right (one_le_saturation G) (labelMatrix (G.surround L) w)

theorem saturation_mul_saturated_label (G : StackGraph A S) (L : A → S → S → Prop) (w : A → K) :
    G.saturation * labelMatrix (G.surround L) w = labelMatrix (G.surround L) w := by
  apply le_antisymm (saturation_mul_label G L w)
  simpa only [one_mul] using mul_le_mul_left (one_le_saturation G) (labelMatrix (G.surround L) w)

omit [DecidableEq S] in
/-- **`P̂ Q̂ ≤ B`**, if `p_a q_a = 1` and `p_a q_b = 0` for `a ≠ b`. -/
theorem saturated_push_pop (G : StackGraph A S) (p q : A → K)
    (hpq : ∀ a, p a * q a = 1) (hne : ∀ a b, a ≠ b → p a * q b = 0) :
    G.saturatedPush p * G.saturatedPop q ≤ G.saturation := by
  classical
  intro i j
  simp only [Matrix.mul_apply, saturatedPush, saturatedPop, labelMatrix,
    Finset.sum_mul, Finset.mul_sum]
  apply idem_sum_le
  intro k _
  apply idem_sum_le
  intro b _
  apply idem_sum_le
  intro a _
  by_cases hp : G.surround G.push a i k
  · by_cases hq : G.surround G.pop b k j
    · simp only [if_pos hp, if_pos hq]
      by_cases hab : a = b
      · subst b
        simp only [hpq, saturation, boolMatrix, bit_true (surround_match G hp hq), le_refl]
      · rw [hne a b hab]; exact zero_le
    · simp only [if_neg hq, mul_zero]; exact zero_le
  · simp only [if_neg hp, zero_mul]; exact zero_le

theorem transition_le_saturated (G : StackGraph A S) (p q : A → K) :
    G.transition p q ≤ G.saturation + G.saturatedPush p + G.saturatedPop q := by
  apply add_le_add
  · apply add_le_add
    · intro i j
      classical
      by_cases h : G.eps i j
      · simp only [boolMatrix, saturation, bit_true h, bit_true (Balanced.eps h), le_refl]
      · simp only [boolMatrix, bit_false h]; exact zero_le
    · exact labelMatrix_mono _ _ p (fun _ _ _ => surround_edge G G.push)
  · exact labelMatrix_mono _ _ q (fun _ _ _ => surround_edge G G.pop)

theorem saturated_le_star (G : StackGraph A S) (p q : A → K)
    (hpq : ∀ a, p a * q a = 1) :
    G.saturation + G.saturatedPush p + G.saturatedPop q ≤ (G.transition p q)∗ := by
  apply add_le
  · apply add_le (saturation_le_star G p q hpq)
    exact saturated_label_le_star G p q hpq G.push p (fun _ _ _ => push_le_transition G p q)
  · exact saturated_label_le_star G p q hpq G.pop q (fun _ _ _ => pop_le_transition G p q)

end Stackat.StackGraph
