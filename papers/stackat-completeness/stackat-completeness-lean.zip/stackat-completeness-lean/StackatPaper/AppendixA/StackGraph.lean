import StackatPaper.Background.MatrixLemmas
import StackatPaper.Background.BooleanMatrix

/-!
# Appendix A: graphs with push and pop edges

A finite control graph with epsilon, push and pop edges (`StackGraph`), and its transition
matrix `M = E_0 + Σ_a p_a U_a + Σ_a q_a V_a` (`StackGraph.transition`), in any Kleene algebra.
-/

namespace Stackat

open scoped Computability

/-- A finite control graph: epsilon edges, and push and pop edges labelled by letters. -/
structure StackGraph (A S : Type*) where
  eps : S → S → Prop
  push : A → S → S → Prop
  pop : A → S → S → Prop

namespace StackGraph

variable {A S K : Type*}

variable [Fintype A] [KleeneAlgebra K]

noncomputable def labelMatrix (L : A → S → S → Prop) (w : A → K) : Matrix S S K := by
  classical
  exact fun i j => ∑ a, if L a i j then w a else 0

noncomputable def transition (G : StackGraph A S) (p q : A → K) :
    Matrix S S K :=
  boolMatrix G.eps + labelMatrix G.push p + labelMatrix G.pop q

theorem label_le (L : A → S → S → Prop) (w : A → K) {a i j} (h : L a i j) :
    w a ≤ labelMatrix L w i j := by
  classical
  have hs := Finset.single_le_sum (f := fun b => if L b i j then w b else 0)
    (fun _ _ => zero_le) (Finset.mem_univ a)
  simpa only [if_pos h] using hs

theorem labelMatrix_mono (L T : A → S → S → Prop) (w : A → K)
    (h : ∀ a i j, L a i j → T a i j) : labelMatrix L w ≤ labelMatrix T w := by
  classical
  intro i j
  apply idem_sum_le
  intro a _
  by_cases ha : L a i j
  · simpa only [if_pos ha] using label_le T w (h a i j ha)
  · simp only [if_neg ha]; exact zero_le

theorem push_le_transition (G : StackGraph A S) (p q : A → K) {a i j} (h : G.push a i j) :
    p a ≤ G.transition p q i j :=
  (label_le G.push p h).trans ((le_add_left le_rfl).trans (le_add_right le_rfl))

theorem pop_le_transition (G : StackGraph A S) (p q : A → K) {a i j} (h : G.pop a i j) :
    q a ≤ G.transition p q i j :=
  (label_le G.pop q h).trans (le_add_left le_rfl)

end StackGraph
end Stackat
