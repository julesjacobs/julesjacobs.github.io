import Mathlib.Algebra.Order.Kleene
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Data.Matrix.Mul

/-!
Background (§3.3): square matrices over a Kleene algebra form a Kleene algebra
(`MatrixStar.matrixKleeneAlgebra`), with star by state elimination (`MatrixStar.matrixStar`).
-/

namespace Stackat

variable {K : Type*} [IdemSemiring K]

theorem idem_sum_le {I : Type*} (s : Finset I) (f : I → K) (b : K)
    (h : ∀ i ∈ s, f i ≤ b) : ∑ i ∈ s, f i ≤ b := by
  classical
  induction s using Finset.induction_on with
  | empty => simp only [Finset.sum_empty]; exact zero_le
  | @insert i s hi ih =>
    rw [Finset.sum_insert hi]
    exact add_le (h i (Finset.mem_insert_self _ _))
      (ih (fun j hj => h j (Finset.mem_insert_of_mem hj)))

end Stackat

namespace Stackat.MatrixStar

open scoped Computability

variable {S K : Type*} [KleeneAlgebra K]

instance {T : Type*} : SemilatticeSup (Matrix S T K) :=
  inferInstanceAs (SemilatticeSup (S → T → K))

instance {T : Type*} : OrderBot (Matrix S T K) :=
  inferInstanceAs (OrderBot (S → T → K))

abbrev Mat (S K : Type*) := Matrix S S K

def eliminate (k : S) (D : Mat S K) : Mat S K :=
  fun i j => D i j + D i k * (D k k)∗ * D k j

def ClosedAt (D : Mat S K) (k : S) : Prop :=
  ∀ i j, D i k * D k j ≤ D i j

theorem le_eliminate (D : Mat S K) (k : S) : D ≤ eliminate k D :=
  fun _ _ => le_add_right le_rfl

theorem eliminate_closed (D : Mat S K) (k : S) : ClosedAt (eliminate k D) k := by
  intro i j
  have hi : eliminate k D i k ≤ D i k * (D k k)∗ := by
    dsimp [eliminate]
    apply add_le
    · simpa only [mul_one] using mul_le_mul_right (one_le_kstar (a := D k k)) (D i k)
    · simpa only [mul_assoc] using mul_le_mul_right (kstar_mul_le_kstar (a := D k k)) (D i k)
  have hj : eliminate k D k j ≤ (D k k)∗ * D k j := by
    dsimp [eliminate]
    apply add_le
    · simpa only [one_mul] using mul_le_mul_left (one_le_kstar (a := D k k)) (D k j)
    · exact mul_le_mul_left mul_kstar_le_kstar _
  calc
    eliminate k D i k * eliminate k D k j ≤
        (D i k * (D k k)∗) * ((D k k)∗ * D k j) := mul_le_mul' hi hj
    _ = D i k * (D k k)∗ * D k j := by simp only [mul_assoc, ← mul_assoc (D k k)∗, kstar_mul_kstar]
    _ ≤ eliminate k D i j := le_add_left le_rfl

theorem eliminate_preserves {D : Mat S K} {l : S} (h : ClosedAt D l) (k : S) :
    ClosedAt (eliminate k D) l := by
  intro i j
  dsimp [eliminate]
  rw [add_mul, mul_add, mul_add]
  apply add_le
  · apply add_le
    · exact (h i j).trans (le_add_right le_rfl)
    · apply le_trans _ (le_add_left le_rfl)
      calc
        D i l * (D l k * (D k k)∗ * D k j) =
            (D i l * D l k) * (D k k)∗ * D k j := by simp only [mul_assoc]
        _ ≤ D i k * (D k k)∗ * D k j :=
          mul_le_mul_left (mul_le_mul_left (h i k) _) _
  · apply add_le
    · apply le_trans _ (le_add_left le_rfl)
      calc
        D i k * (D k k)∗ * D k l * D l j =
            D i k * (D k k)∗ * (D k l * D l j) := mul_assoc _ _ _
        _ ≤ D i k * (D k k)∗ * D k j := mul_le_mul_right (h k j) _
    · apply le_trans _ (le_add_left le_rfl)
      calc
        (D i k * (D k k)∗ * D k l) * (D l k * (D k k)∗ * D k j) =
            D i k * (D k k)∗ * (D k l * D l k) * (D k k)∗ * D k j := by
              simp only [mul_assoc]
        _ ≤ D i k * (D k k)∗ * D k k * (D k k)∗ * D k j :=
          mul_le_mul_left (mul_le_mul_left (mul_le_mul_right (h k k) _) _) _
        _ ≤ D i k * (D k k)∗ * (D k k)∗ * D k j := by
          apply mul_le_mul_left
          apply mul_le_mul_left
          simpa only [mul_assoc] using mul_le_mul_right (kstar_mul_le_kstar (a := D k k)) (D i k)
        _ = D i k * (D k k)∗ * D k j := by rw [mul_assoc (D i k), kstar_mul_kstar]

def close : List S → Mat S K → Mat S K
  | [], D => D
  | k :: ks, D => eliminate k (close ks D)

theorem le_close (ks : List S) (D : Mat S K) : D ≤ close ks D := by
  induction ks with
  | nil => exact le_rfl
  | cons k ks ih => exact ih.trans (le_eliminate _ k)

theorem close_closed (ks : List S) (D : Mat S K) {k : S} (hk : k ∈ ks) :
    ClosedAt (close ks D) k := by
  induction ks with
  | nil => simp at hk
  | cons l ks ih =>
    rcases List.mem_cons.mp hk with rfl | hk
    · exact eliminate_closed _ _
    · exact eliminate_preserves (ih hk) l

theorem eliminate_bound_left {D : Mat S K} {b : S → K}
    (h : ∀ i j, D i j * b j ≤ b i) (k : S) :
    ∀ i j, eliminate k D i j * b j ≤ b i := by
  intro i j
  dsimp [eliminate]
  rw [add_mul]
  apply add_le (h i j)
  calc
    D i k * (D k k)∗ * D k j * b j =
        D i k * ((D k k)∗ * (D k j * b j)) := by simp only [mul_assoc]
    _ ≤ D i k * b k := mul_le_mul_right (kstar_mul_le (h k j) (h k k)) _
    _ ≤ b i := h i k

theorem eliminate_bound_right {D : Mat S K} {b : S → K}
    (h : ∀ i j, b i * D i j ≤ b j) (k : S) :
    ∀ i j, b i * eliminate k D i j ≤ b j := by
  intro i j
  dsimp [eliminate]
  rw [mul_add]
  apply add_le (h i j)
  calc
    b i * (D i k * (D k k)∗ * D k j) =
        (b i * D i k) * (D k k)∗ * D k j := by simp only [mul_assoc]
    _ ≤ b k * D k j := mul_le_mul_left (mul_kstar_le (h i k) (h k k)) _
    _ ≤ b j := h k j

theorem close_bound_left {D : Mat S K} {b : S → K}
    (h : ∀ i j, D i j * b j ≤ b i) (ks : List S) :
    ∀ i j, close ks D i j * b j ≤ b i := by
  induction ks with
  | nil => exact h
  | cons k ks ih => exact eliminate_bound_left ih k

theorem close_bound_right {D : Mat S K} {b : S → K}
    (h : ∀ i j, b i * D i j ≤ b j) (ks : List S) :
    ∀ i j, b i * close ks D i j ≤ b j := by
  induction ks with
  | nil => exact h
  | cons k ks ih => exact eliminate_bound_right ih k

variable [Fintype S] [DecidableEq S]

instance : IdemSemiring (Matrix S S K) where
  toSemilatticeSup := inferInstanceAs (SemilatticeSup (S → S → K))
  toOrderBot := inferInstanceAs (OrderBot (S → S → K))
  add_eq_sup a b := by ext i j; exact add_eq_sup (a i j) (b i j)

noncomputable def matrixStar (M : Matrix S S K) : Matrix S S K :=
  1 + close Finset.univ.toList M

noncomputable instance : KStar (Matrix S S K) := ⟨matrixStar⟩

noncomputable instance matrixKleeneAlgebra : KleeneAlgebra (Matrix S S K) where
  one_le_kstar := by
    intro M
    exact le_add_right le_rfl
  mul_kstar_le_kstar := by
    intro M
    change M * (1 + close Finset.univ.toList M) ≤ 1 + close Finset.univ.toList M
    rw [mul_add, mul_one]
    apply add_le
    · exact (le_close _ _).trans (le_add_left le_rfl)
    · intro i j
      apply le_trans _ (le_add_left le_rfl)
      change (∑ k, M i k * close Finset.univ.toList M k j) ≤ _
      apply idem_sum_le
      intro k _
      exact (mul_le_mul_left (le_close Finset.univ.toList M i k) _).trans
        (close_closed Finset.univ.toList M (by simp) i j)
  kstar_mul_le_kstar := by
    intro M
    change (1 + close Finset.univ.toList M) * M ≤ 1 + close Finset.univ.toList M
    rw [add_mul, one_mul]
    apply add_le
    · exact (le_close _ _).trans (le_add_left le_rfl)
    · intro i j
      apply le_trans _ (le_add_left le_rfl)
      change (∑ k, close Finset.univ.toList M i k * M k j) ≤ _
      apply idem_sum_le
      intro k _
      exact (mul_le_mul_right (le_close Finset.univ.toList M k j) _).trans
        (close_closed Finset.univ.toList M (by simp) i j)
  kstar_mul_le_self := by
    intro M B h
    change (1 + close Finset.univ.toList M) * B ≤ B
    rw [add_mul, one_mul]
    apply add_le le_rfl
    intro i j
    change (∑ k, close Finset.univ.toList M i k * B k j) ≤ B i j
    apply idem_sum_le
    intro k _
    apply close_bound_left (b := fun i => B i j) _ _ i k
    intro a b
    apply le_trans _ (h a j)
    exact Finset.single_le_sum (f := fun c => M a c * B c j)
      (fun c _ => zero_le) (Finset.mem_univ b)
  mul_kstar_le_self := by
    intro M B h
    change B * (1 + close Finset.univ.toList M) ≤ B
    rw [mul_add, mul_one]
    apply add_le le_rfl
    intro i j
    change (∑ k, B i k * close Finset.univ.toList M k j) ≤ B i j
    apply idem_sum_le
    intro k _
    apply close_bound_right (b := fun j => B i j) _ _ k j
    intro a b
    apply le_trans _ (h i b)
    exact Finset.single_le_sum (f := fun c => B i c * M c b)
      (fun c _ => zero_le) (Finset.mem_univ a)

end Stackat.MatrixStar
