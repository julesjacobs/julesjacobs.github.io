import StackatPaper.Background.FreeAlgebra
import StackatPaper.Background.BooleanMatrix
import Mathlib.Logic.Relation

/-!
Background: binary relations form a Kleene algebra (`Rel`); the relational pushes and pops, and
`Expr.eval Rel.push Rel.pop e = R e` (`Rel.eval_denote`).
-/

namespace Stackat

/-- The specification's `Steps r` is Mathlib's reflexive transitive closure of `r`. -/
theorem steps_eq_reflTransGen {α : Type*} (r : α → α → Prop) :
    Steps r = Relation.ReflTransGen r := by
  funext s t
  apply propext
  constructor
  · intro h
    induction h with
    | refl => exact .refl
    | step h _ ih => exact .head h ih
  · intro h
    induction h using Relation.ReflTransGen.head_induction_on with
    | refl => exact .refl
    | head h _ ih => exact .step h ih

theorem R_star {A : Type} (e : Expr A) : R e⋆ = Relation.ReflTransGen (R e) := by
  rw [← steps_eq_reflTransGen]; rfl

/-- Binary relations, with multiplication executing the left relation first. -/
def Rel (α : Type*) := α → α → Prop

namespace Rel

variable {α : Type*}

instance : Zero (Rel α) := ⟨fun _ _ => False⟩
instance : One (Rel α) := ⟨Eq⟩
instance : Add (Rel α) := ⟨fun R S x y => R x y ∨ S x y⟩
instance : Mul (Rel α) := ⟨fun R S x z => ∃ y, R x y ∧ S y z⟩
instance : KStar (Rel α) := ⟨Relation.ReflTransGen⟩

@[ext] theorem ext {R S : Rel α} (h : ∀ x y, R x y ↔ S x y) : R = S :=
  funext fun x => funext fun y => propext (h x y)

@[simp] theorem zero_apply (x y : α) : (0 : Rel α) x y ↔ False := Iff.rfl
@[simp] theorem one_apply (x y : α) : (1 : Rel α) x y ↔ x = y := Iff.rfl
@[simp] theorem add_apply (R S : Rel α) (x y : α) : (R + S) x y ↔ R x y ∨ S x y := Iff.rfl
@[simp] theorem mul_apply (R S : Rel α) (x z : α) : (R * S) x z ↔ ∃ y, R x y ∧ S y z := Iff.rfl

instance : Semiring (Rel α) where
  add_assoc R S T := ext (fun _ _ => or_assoc)
  add_comm R S := ext (fun _ _ => or_comm)
  add_zero R := ext (fun _ _ => by simp)
  zero_add R := ext (fun _ _ => by simp)
  mul_assoc R S T := by
    apply ext
    intro x z
    constructor
    · rintro ⟨y, ⟨w, hr, hs⟩, ht⟩
      exact ⟨w, hr, y, hs, ht⟩
    · rintro ⟨w, hr, y, hs, ht⟩
      exact ⟨y, ⟨w, hr, hs⟩, ht⟩
  one_mul R := ext (fun _ _ => by simp)
  mul_one R := ext (fun _ _ => by simp)
  zero_mul R := ext (fun _ _ => by simp)
  mul_zero R := ext (fun _ _ => by simp)
  left_distrib R S T := ext (fun _ _ => by simp [and_or_left, exists_or])
  right_distrib R S T := ext (fun _ _ => by simp [or_and_right, exists_or])
  nsmul := nsmulRec
  natCast := Nat.unaryCast
  natCast_zero := rfl
  natCast_succ := fun _ => rfl

instance : PartialOrder (Rel α) where
  le R S := ∀ x y, R x y → S x y
  le_refl _ := fun _ _ h => h
  le_trans _ _ _ h₁ h₂ := fun x y h => h₂ x y (h₁ x y h)
  le_antisymm _ _ h₁ h₂ := ext (fun x y => ⟨h₁ x y, h₂ x y⟩)

instance : SemilatticeSup (Rel α) where
  sup := (· + ·)
  le_sup_left _ _ := fun _ _ => Or.inl
  le_sup_right _ _ := fun _ _ => Or.inr
  sup_le _ _ _ h₁ h₂ := fun x y h => h.elim (h₁ x y) (h₂ x y)

instance : OrderBot (Rel α) where
  bot := 0
  bot_le _ := fun _ _ => False.elim

instance : IdemSemiring (Rel α) where
  add_eq_sup _ _ := rfl

open scoped Computability

instance : KleeneAlgebra (Rel α) where
  one_le_kstar R := by rintro x y rfl; exact .refl
  mul_kstar_le_kstar R := by
    rintro x z ⟨y, hr, hs⟩
    exact hs.head hr
  kstar_mul_le_kstar R := by
    rintro x z ⟨y, hs, hr⟩
    exact hs.tail hr
  kstar_mul_le_self R S h := by
    rintro x z ⟨y, hr, hs⟩
    induction hr using Relation.ReflTransGen.head_induction_on with
    | refl => exact hs
    | head hxy _ ih => exact h _ _ ⟨_, hxy, ih⟩
  mul_kstar_le_self R S h := by
    rintro x z ⟨y, hs, hr⟩
    induction hr with
    | refl => exact hs
    | tail _ hyz ih => exact h _ _ ⟨_, ih, hyz⟩

theorem sum_apply {I : Type*} (s : Finset I) (R : I → Rel α) (x y : α) :
    (∑ i ∈ s, R i) x y ↔ ∃ i ∈ s, R i x y := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert i s hi ih => simp [Finset.sum_insert hi, ih]

theorem bit_apply (P : Prop) (x y : α) : bit (K := Rel α) P x y ↔ P ∧ x = y := by
  classical
  by_cases h : P <;> simp [bit, h]

variable {A : Type}

def push (a : A) : Rel (List A) := fun s t => t = a :: s
def pop (a : A) : Rel (List A) := fun s t => s = a :: t

@[simp] theorem push_pop (a : A) : push a * pop a = (1 : Rel (List A)) := by
  apply ext
  intro s t
  simp [mul_apply, push, pop]

theorem push_pop_ne {a b : A} (h : a ≠ b) : push a * pop b = (0 : Rel (List A)) := by
  apply ext
  intro s t
  simp [mul_apply, push, pop, h]

theorem eval_denote (e : Expr A) : Expr.eval push pop e = (R e : Rel (List A)) := by
  induction e with
  | zero => rfl
  | one => rfl
  | push a => rfl
  | pop a => rfl
  | add e f he hf =>
    change Expr.eval push pop e + Expr.eval push pop f = _
    rw [he, hf]
    rfl
  | mul e f he hf =>
    change Expr.eval push pop e * Expr.eval push pop f = _
    rw [he, hf]
    rfl
  | star e he =>
    change (Expr.eval push pop e)∗ = _
    rw [he, show (R e⋆ : Rel (List A)) = Relation.ReflTransGen (R e) from R_star e]
    rfl

end Rel
end Stackat
