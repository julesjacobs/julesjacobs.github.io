import StackatPaper.Background.MatrixLemmas

/-!
Background: matrix star induction for rectangular matrices and the simulation `M R = R N ⟹ M* R =
R N*` (`matrix_star_simulation`, used in Appendix B).
-/

namespace Stackat

open scoped Computability

variable {K S T U : Type*} [KleeneAlgebra K]

theorem matrix_mul_mono [Fintype T] {L L' : Matrix S T K} {R R' : Matrix T U K}
    (hL : L ≤ L') (hR : R ≤ R') : L * R ≤ L' * R' := by
  intro i j
  exact Finset.sum_le_sum (fun k _ => mul_le_mul' (hL i k) (hR k j))

variable [Fintype S] [DecidableEq S]

theorem matrix_star_mul_le {M : Matrix S S K} {R C : Matrix S T K}
    (hR : R ≤ C) (hM : M * C ≤ C) : M∗ * R ≤ C := by
  intro i j
  apply idem_sum_le
  intro k _
  have hb : ∀ a b, M a b * C b j ≤ C a j := fun a b =>
    (matrix_mul_term_le M C a j b).trans (hM a j)
  exact (mul_le_mul_right (hR k j) _).trans
    (matrix_star_mul_potential M (fun k => C k j) hb i k)

theorem matrix_mul_star_le {M : Matrix S S K} {R C : Matrix T S K}
    (hR : R ≤ C) (hM : C * M ≤ C) : R * M∗ ≤ C := by
  intro i j
  apply idem_sum_le
  intro k _
  have hb : ∀ a b, C i a * M a b ≤ C i b := fun a b =>
    (matrix_mul_term_le C M i b a).trans (hM i b)
  exact (mul_le_mul_left (hR i k) _).trans
    (matrix_star_right_potential M (fun k => C i k) hb k j)

variable [Fintype T] [DecidableEq T]

/-- Intertwining extends to finite-matrix star, including rectangular simulations. -/
theorem matrix_star_simulation (M : Matrix S S K) (N : Matrix T T K)
    (W : Matrix S T K) (h : M * W = W * N) : M∗ * W = W * N∗ := by
  apply le_antisymm
  · apply matrix_star_mul_le
    · simpa only [Matrix.mul_one] using matrix_mul_mono (le_refl W) (one_le_kstar (a := N))
    · calc
        M * (W * N∗) = (M * W) * N∗ := (Matrix.mul_assoc _ _ _).symm
        _ = (W * N) * N∗ := by rw [h]
        _ = W * (N * N∗) := Matrix.mul_assoc _ _ _
        _ ≤ W * N∗ := matrix_mul_mono le_rfl mul_kstar_le_kstar
  · apply matrix_mul_star_le
    · simpa only [Matrix.one_mul] using matrix_mul_mono (one_le_kstar (a := M)) (le_refl W)
    · calc
        (M∗ * W) * N = M∗ * (W * N) := Matrix.mul_assoc _ _ _
        _ = M∗ * (M * W) := by rw [h]
        _ = (M∗ * M) * W := (Matrix.mul_assoc _ _ _).symm
        _ ≤ M∗ * W := matrix_mul_mono kstar_mul_le_kstar le_rfl

end Stackat
