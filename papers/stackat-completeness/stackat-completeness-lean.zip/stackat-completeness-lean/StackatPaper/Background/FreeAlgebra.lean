import StackatPaper.Spec
import Mathlib.Algebra.Order.Kleene
import Mathlib.Algebra.BigOperators.Group.Finset.Basic

/-!
# Background: evaluation in a Kleene algebra and the algebra of expressions

Section 4 works in the KA of expressions modulo derivable equality. This file builds it, for
the full system `Derives` and for the systems with fewer stack laws that Appendix A ("using
only KA and the two push–pop equations") and Appendix C (the reduced systems) need:

* `Expr.eval p q e`: the value of `e` in a Kleene algebra in which `p a`, `q a` interpret `p_a`,
  `q_a`;
* `DerivesWith L`: derivability from KA and the stack schemes in `L` (`derives_iff` identifies
  `DerivesWith` with all three schemes and `Derives`), sound in every Kleene algebra satisfying
  the schemes in `L` (`DerivesWith.sound`);
* `FreeAlgebraWith L A`: expressions modulo `DerivesWith L`, a Kleene algebra;
  `FreeAlgebra A` is the case of all three schemes, with `of_eq_iff : of e = of f ↔ ⊢ e ≈ f`.
-/

namespace Stackat

open scoped Computability


variable {A : Type}

/-! ## Evaluation -/

/-- The value of an expression in a Kleene algebra, with `p a` for `p_a` and `q a` for `q_a`. -/
noncomputable def Expr.eval {K : Type*} [KleeneAlgebra K] (p q : A → K) :
    Expr A → K
  | .zero => 0
  | .one => 1
  | .push a => p a
  | .pop a => q a
  | .add e f => Expr.eval p q e + Expr.eval p q f
  | .mul e f => Expr.eval p q e * Expr.eval p q f
  | .star e => (Expr.eval p q e)∗

/-! ## Derivability from chosen stack schemes -/

/-- The three stack schemes of equation (1): `p_a q_a = 1`, `p_a q_b = 0` for `a ≠ b`, and
`q_a p_a ≤ 1`. -/
inductive StackLaw where
  | push_pop
  | push_pop_ne
  | pop_push
  deriving DecidableEq

/-- Derivability from the Kleene algebra laws and the stack schemes satisfying `L`. Each
constructor is the constructor of `Derives` with the same name; a stack scheme may be used only
if `L` holds for it. -/
inductive DerivesWith (L : StackLaw → Prop) : Expr A → Expr A → Prop where
  | refl (e) : DerivesWith L e e
  | symm : DerivesWith L e f → DerivesWith L f e
  | trans : DerivesWith L e f → DerivesWith L f g → DerivesWith L e g
  | add_congr : DerivesWith L e e' → DerivesWith L f f' → DerivesWith L (e + f) (e' + f')
  | mul_congr : DerivesWith L e e' → DerivesWith L f f' → DerivesWith L (e * f) (e' * f')
  | star_congr : DerivesWith L e f → DerivesWith L e.star f.star
  | add_assoc (e f g) : DerivesWith L ((e + f) + g) (e + (f + g))
  | add_comm (e f) : DerivesWith L (e + f) (f + e)
  | add_zero (e) : DerivesWith L (e + 0) e
  | add_idem (e) : DerivesWith L (e + e) e
  | mul_assoc (e f g) : DerivesWith L ((e * f) * g) (e * (f * g))
  | one_mul (e) : DerivesWith L (1 * e) e
  | mul_one (e) : DerivesWith L (e * 1) e
  | zero_mul (e) : DerivesWith L (0 * e) 0
  | mul_zero (e) : DerivesWith L (e * 0) 0
  | mul_add (e f g) : DerivesWith L (e * (f + g)) (e * f + e * g)
  | add_mul (e f g) : DerivesWith L ((e + f) * g) (e * g + f * g)
  | star_unfold_left (e) : DerivesWith L (1 + e * e.star) e.star
  | star_unfold_right (e) : DerivesWith L (1 + e.star * e) e.star
  | star_induct_left : DerivesWith L (e * f + f) f → DerivesWith L (e.star * f + f) f
  | star_induct_right : DerivesWith L (f * e + f) f → DerivesWith L (f * e.star + f) f
  | push_pop (h : L .push_pop) (a : A) : DerivesWith L (.push a * .pop a) 1
  | push_pop_ne (h : L .push_pop_ne) (a b : A) :
      a ≠ b → DerivesWith L (.push a * .pop b) 0
  | pop_push (h : L .pop_push) (a : A) : DerivesWith L (.pop a * .push a + 1) 1

/-- `⊢[L] e ≈ f`: `e = f` is derivable from KA and the stack schemes in `L`. -/
scoped notation:25 "⊢[" L "] " e:51 " ≈ " f:51 => DerivesWith L e f

/-- `⊢[L] e ≤ f`: `e + f = f` is derivable from KA and the stack schemes in `L`. -/
scoped notation:25 "⊢[" L "] " e:51 " ≤ " f:51 => DerivesWith L (e + f) f

/-- `⊬[L] e ≈ f`: `e = f` is not derivable from KA and the stack schemes in `L`. -/
scoped notation:25 "⊬[" L "] " e:51 " ≈ " f:51 => ¬ DerivesWith L e f

/-- `⊬ e ≈ f`: the equation `e = f` is not derivable. -/
scoped notation:25 "⊬ " e:51 " ≈ " f:51 => ¬ Derives e f

/-- `⊬ e ≤ f`: the inequality `e ≤ f` is not derivable. -/
scoped notation:25 "⊬ " e:51 " ≤ " f:51 => ¬ Derives (e + f) f

/-- All three stack schemes. -/
abbrev allLaws : StackLaw → Prop := fun _ => True

/-- With all three schemes, `DerivesWith` is the derivation system `Derives` of the paper. -/
theorem derives_iff {e f : Expr A} : Derives e f ↔ DerivesWith allLaws e f := by
  constructor
  · intro h
    induction h with
    | @refl e => exact .refl e
    | symm _ ih => exact .symm ih
    | trans _ _ ih₁ ih₂ => exact .trans ih₁ ih₂
    | add_congr _ _ ih₁ ih₂ => exact .add_congr ih₁ ih₂
    | mul_congr _ _ ih₁ ih₂ => exact .mul_congr ih₁ ih₂
    | star_congr _ ih => exact .star_congr ih
    | @add_assoc e f g => exact .add_assoc e f g
    | @add_comm e f => exact .add_comm e f
    | @add_zero e => exact .add_zero e
    | @add_idem e => exact .add_idem e
    | @mul_assoc e f g => exact .mul_assoc e f g
    | @one_mul e => exact .one_mul e
    | @mul_one e => exact .mul_one e
    | @zero_mul e => exact .zero_mul e
    | @mul_zero e => exact .mul_zero e
    | @mul_add e f g => exact .mul_add e f g
    | @add_mul e f g => exact .add_mul e f g
    | @star_unfold_left e => exact .star_unfold_left e
    | @star_unfold_right e => exact .star_unfold_right e
    | star_induct_left _ ih => exact .star_induct_left ih
    | star_induct_right _ ih => exact .star_induct_right ih
    | @push_pop a => exact .push_pop trivial a
    | @push_pop_ne a b hab => exact .push_pop_ne trivial a b hab
    | @pop_push a => exact .pop_push trivial a
  · intro h
    induction h with
    | refl e => exact .refl (e := e)
    | symm _ ih => exact .symm ih
    | trans _ _ ih₁ ih₂ => exact .trans ih₁ ih₂
    | add_congr _ _ ih₁ ih₂ => exact .add_congr ih₁ ih₂
    | mul_congr _ _ ih₁ ih₂ => exact .mul_congr ih₁ ih₂
    | star_congr _ ih => exact .star_congr ih
    | add_assoc e f g => exact .add_assoc (e := e) (f := f) (g := g)
    | add_comm e f => exact .add_comm (e := e) (f := f)
    | add_zero e => exact .add_zero (e := e)
    | add_idem e => exact .add_idem (e := e)
    | mul_assoc e f g => exact .mul_assoc (e := e) (f := f) (g := g)
    | one_mul e => exact .one_mul (e := e)
    | mul_one e => exact .mul_one (e := e)
    | zero_mul e => exact .zero_mul (e := e)
    | mul_zero e => exact .mul_zero (e := e)
    | mul_add e f g => exact .mul_add (e := e) (f := f) (g := g)
    | add_mul e f g => exact .add_mul (e := e) (f := f) (g := g)
    | star_unfold_left e => exact .star_unfold_left (e := e)
    | star_unfold_right e => exact .star_unfold_right (e := e)
    | star_induct_left _ ih => exact .star_induct_left ih
    | star_induct_right _ ih => exact .star_induct_right ih
    | push_pop _ a => exact .push_pop (a := a)
    | push_pop_ne _ a b hab => exact .push_pop_ne hab
    | pop_push _ a => exact .pop_push (a := a)

/-- A stack scheme holds for the interpretations `p a` of `p_a` and `q a` of `q_a`. -/
def StackLaw.Holds {K : Type*} [KleeneAlgebra K] (p q : A → K) : StackLaw → Prop
  | .push_pop => ∀ a, p a * q a = 1
  | .push_pop_ne => ∀ a b, a ≠ b → p a * q b = 0
  | .pop_push => ∀ a, q a * p a ≤ 1

/-- **Soundness in Kleene algebra models.** In a Kleene algebra whose pushes and pops satisfy
the schemes in `L`, every `DerivesWith L` derivation is an equation of values. -/
theorem DerivesWith.sound {L : StackLaw → Prop} {K : Type*} [KleeneAlgebra K] {p q : A → K}
    (hL : ∀ x, L x → x.Holds p q) {e f : Expr A} (h : DerivesWith L e f) :
    e.eval p q = f.eval p q := by
  induction h with
  | refl => rfl
  | symm _ ih => exact ih.symm
  | trans _ _ ih₁ ih₂ => exact ih₁.trans ih₂
  | add_congr _ _ ih₁ ih₂ =>
    change Expr.eval p q _ + Expr.eval p q _ = Expr.eval p q _ + Expr.eval p q _
    rw [ih₁, ih₂]
  | mul_congr _ _ ih₁ ih₂ =>
    change Expr.eval p q _ * Expr.eval p q _ = Expr.eval p q _ * Expr.eval p q _
    rw [ih₁, ih₂]
  | star_congr _ ih =>
    change (Expr.eval p q _)∗ = (Expr.eval p q _)∗
    rw [ih]
  | add_assoc => exact _root_.add_assoc _ _ _
  | add_comm => exact _root_.add_comm _ _
  | add_zero => exact _root_.add_zero _
  | add_idem => exact _root_.add_idem _
  | mul_assoc => exact _root_.mul_assoc _ _ _
  | one_mul => exact _root_.one_mul _
  | mul_one => exact _root_.mul_one _
  | zero_mul => exact MulZeroClass.zero_mul _
  | mul_zero => exact MulZeroClass.mul_zero _
  | mul_add => exact _root_.mul_add _ _ _
  | add_mul => exact _root_.add_mul _ _ _
  | star_unfold_left => exact one_add_mul_kstar
  | star_unfold_right => exact one_add_kstar_mul
  | star_induct_left _ ih => exact add_eq_right_iff_le.mpr (kstar_mul_le_self
      (add_eq_right_iff_le.mp ih))
  | star_induct_right _ ih => exact add_eq_right_iff_le.mpr (mul_kstar_le_self
      (add_eq_right_iff_le.mp ih))
  | push_pop h a => exact (hL _ h : ∀ a, p a * q a = 1) a
  | push_pop_ne h a b hab => exact (hL _ h : ∀ a b, a ≠ b → p a * q b = 0) a b hab
  | pop_push h a => exact add_eq_right_iff_le.mpr ((hL _ h : ∀ a, q a * p a ≤ 1) a)

/-! ## Expressions modulo derivability -/

instance derivesWithSetoid (L : StackLaw → Prop) (A : Type) : Setoid (Expr A) where
  r := DerivesWith L
  iseqv := ⟨DerivesWith.refl, DerivesWith.symm, DerivesWith.trans⟩

/-- Expressions modulo `DerivesWith L`. -/
abbrev FreeAlgebraWith (L : StackLaw → Prop) (A : Type) :=
  Quotient (derivesWithSetoid L A)

namespace FreeAlgebraWith

variable {L : StackLaw → Prop}

/-- The class of an expression. -/
def of (e : Expr A) : FreeAlgebraWith L A := Quotient.mk _ e

instance : Zero (FreeAlgebraWith L A) := ⟨of 0⟩
instance : One (FreeAlgebraWith L A) := ⟨of 1⟩
instance : Add (FreeAlgebraWith L A) := ⟨Quotient.map₂ (· + ·)
  (fun _ _ h₁ _ _ h₂ => DerivesWith.add_congr h₁ h₂)⟩
instance : Mul (FreeAlgebraWith L A) := ⟨Quotient.map₂ (· * ·)
  (fun _ _ h₁ _ _ h₂ => DerivesWith.mul_congr h₁ h₂)⟩
instance : KStar (FreeAlgebraWith L A) := ⟨Quotient.map Expr.star
  (fun _ _ h => DerivesWith.star_congr h)⟩


theorem of_eq_iff {e f : Expr A} : (of e : FreeAlgebraWith L A) = of f ↔ DerivesWith L e f :=
  ⟨Quotient.exact, fun h => Quotient.sound h⟩

instance : Semiring (FreeAlgebraWith L A) where
  add_assoc := fun a b c => Quotient.inductionOn₃ a b c
    (fun e f g => Quotient.sound (.add_assoc e f g))
  add_comm := fun a b => Quotient.inductionOn₂ a b
    (fun e f => Quotient.sound (.add_comm e f))
  zero_add := fun a => Quotient.inductionOn a
    (fun e => Quotient.sound (.trans (.add_comm 0 e) (.add_zero e)))
  add_zero := fun a => Quotient.inductionOn a (fun e => Quotient.sound (.add_zero e))
  nsmul := nsmulRec
  zero_mul := fun a => Quotient.inductionOn a (fun e => Quotient.sound (.zero_mul e))
  mul_zero := fun a => Quotient.inductionOn a (fun e => Quotient.sound (.mul_zero e))
  mul_assoc := fun a b c => Quotient.inductionOn₃ a b c
    (fun e f g => Quotient.sound (.mul_assoc e f g))
  one_mul := fun a => Quotient.inductionOn a (fun e => Quotient.sound (.one_mul e))
  mul_one := fun a => Quotient.inductionOn a (fun e => Quotient.sound (.mul_one e))
  left_distrib := fun a b c => Quotient.inductionOn₃ a b c
    (fun e f g => Quotient.sound (.mul_add e f g))
  right_distrib := fun a b c => Quotient.inductionOn₃ a b c
    (fun e f g => Quotient.sound (.add_mul e f g))
  natCast := Nat.unaryCast
  natCast_zero := rfl
  natCast_succ := fun _ => rfl

instance : IdemSemiring (FreeAlgebraWith L A) :=
  IdemSemiring.ofSemiring (fun a => Quotient.inductionOn a
    (fun e => Quotient.sound (.add_idem e)))

instance : KleeneAlgebra (FreeAlgebraWith L A) where
  one_le_kstar := by
    intro a
    induction a using Quotient.inductionOn with
    | _ e =>
      have h : (1 : FreeAlgebraWith L A) + of e * (of e)∗ = (of e)∗ :=
        Quotient.sound (.star_unfold_left e)
      exact le_trans (le_add_right le_rfl) (le_of_eq h)
  mul_kstar_le_kstar := by
    intro a
    induction a using Quotient.inductionOn with
    | _ e =>
      have h : (1 : FreeAlgebraWith L A) + of e * (of e)∗ = (of e)∗ :=
        Quotient.sound (.star_unfold_left e)
      exact le_trans (le_add_left le_rfl) (le_of_eq h)
  kstar_mul_le_kstar := by
    intro a
    induction a using Quotient.inductionOn with
    | _ e =>
      have h : (1 : FreeAlgebraWith L A) + (of e)∗ * of e = (of e)∗ :=
        Quotient.sound (.star_unfold_right e)
      exact le_trans (le_add_left le_rfl) (le_of_eq h)
  kstar_mul_le_self := by
    intro a b
    induction a, b using Quotient.inductionOn₂ with
    | _ e f =>
      intro h
      exact of_eq_iff.mp h |>.star_induct_left |> Quotient.sound
  mul_kstar_le_self := by
    intro a b
    induction a, b using Quotient.inductionOn₂ with
    | _ e f =>
      intro h
      exact of_eq_iff.mp h |>.star_induct_right |> Quotient.sound

/-- Evaluating an expression at the classes of the pushes and pops gives its class. -/
theorem eval_of (e : Expr A) :
    e.eval (fun a => (of (.push a) : FreeAlgebraWith L A)) (fun a => of (.pop a)) = of e := by
  induction e with
  | zero => rfl
  | one => rfl
  | push a => rfl
  | pop a => rfl
  | add e f he hf =>
    change Expr.eval _ _ e + Expr.eval _ _ f = of e + of f
    rw [he, hf]
  | mul e f he hf =>
    change Expr.eval _ _ e * Expr.eval _ _ f = of e * of f
    rw [he, hf]
  | star e he =>
    change (Expr.eval _ _ e)∗ = (of e)∗
    rw [he]

theorem push_pop (h : L .push_pop) (a : A) :
    (of (.push a) : FreeAlgebraWith L A) * of (.pop a) = 1 :=
  Quotient.sound (.push_pop h a)

theorem push_pop_ne (h : L .push_pop_ne) {a b : A} (hab : a ≠ b) :
    (of (.push a) : FreeAlgebraWith L A) * of (.pop b) = 0 :=
  Quotient.sound (.push_pop_ne h a b hab)

theorem pop_push (h : L .pop_push) (a : A) :
    (of (.pop a) : FreeAlgebraWith L A) * of (.push a) ≤ 1 :=
  Quotient.sound (.pop_push h a)

end FreeAlgebraWith

/-- The Kleene algebra of expressions modulo derivability (`Derives`, all three schemes). -/
abbrev FreeAlgebra (A : Type) := FreeAlgebraWith allLaws A

namespace FreeAlgebra

/-- The class of an expression modulo derivability. -/
abbrev of (e : Expr A) : FreeAlgebra A := FreeAlgebraWith.of e

@[simp] theorem of_one : of (1 : Expr A) = 1 := rfl
@[simp] theorem of_add (e f : Expr A) : of (e + f) = of e + of f := rfl
@[simp] theorem of_mul (e f : Expr A) : of (e * f) = of e * of f := rfl

/-- Equality in the algebra of expressions is derivable equality. -/
theorem of_eq_iff {e f : Expr A} : of e = of f ↔ ⊢ e ≈ f :=
  FreeAlgebraWith.of_eq_iff.trans derives_iff.symm

@[simp] theorem push_pop (a : A) : of (.push a) * of (.pop a) = 1 :=
  FreeAlgebraWith.push_pop trivial a

@[simp] theorem push_pop_ne {a b : A} (h : a ≠ b) : of (.push a) * of (.pop b) = 0 :=
  FreeAlgebraWith.push_pop_ne trivial h

theorem pop_push (a : A) : of (.pop a) * of (.push a) ≤ 1 :=
  FreeAlgebraWith.pop_push trivial a

end FreeAlgebra

end Stackat
