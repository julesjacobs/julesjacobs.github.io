import StackatPaper.Background.MatrixStar

/-!
Background: entries of matrix stars.
-/

namespace Stackat

open scoped Computability

variable {K : Type*} [KleeneAlgebra K]

variable {S : Type*} [Fintype S] [DecidableEq S]

omit [DecidableEq S] in
theorem matrix_mul_term_le {I J : Type*} (M : Matrix I S K) (N : Matrix S J K) (i : I) (j : J) (k : S) :
    M i k * N k j ≤ (M * N) i j :=
  Finset.single_le_sum (f := fun k => M i k * N k j)
    (fun _ _ => zero_le) (Finset.mem_univ k)

theorem matrix_star_entry_mul_le (M : Matrix S S K) (i j k : S) :
    M∗ i k * M∗ k j ≤ M∗ i j := by
  have h := matrix_mul_term_le M∗ M∗ i j k
  simpa only [kstar_mul_kstar] using h

theorem matrix_star_diagonal (M : Matrix S S K) (i : S) : 1 ≤ M∗ i i := by
  simpa only [Matrix.one_apply_eq] using (one_le_kstar (a := M) i i)

theorem matrix_star_mul_potential (M : Matrix S S K) (b : S → K)
    (h : ∀ i j, M i j * b j ≤ b i) (i j : S) : M∗ i j * b j ≤ b i := by
  classical
  change ((1 : Matrix S S K) i j + MatrixStar.close Finset.univ.toList M i j) * b j ≤ b i
  rw [add_mul]
  apply add_le
  · by_cases hij : i = j
    · subst j; simp only [Matrix.one_apply_eq, one_mul, le_refl]
    · simp only [Matrix.one_apply_ne hij, zero_mul]; exact zero_le
  · exact MatrixStar.close_bound_left h _ i j

theorem matrix_star_right_potential (M : Matrix S S K) (b : S → K)
    (h : ∀ i j, b i * M i j ≤ b j) (i j : S) : b i * M∗ i j ≤ b j := by
  classical
  change b i * ((1 : Matrix S S K) i j + MatrixStar.close Finset.univ.toList M i j) ≤ b j
  rw [mul_add]
  apply add_le
  · by_cases hij : i = j
    · subst j; simp only [Matrix.one_apply_eq, mul_one, le_refl]
    · simp only [Matrix.one_apply_ne hij, mul_zero]; exact zero_le
  · exact MatrixStar.close_bound_right h _ i j

theorem matrix_star_le_potential (M : Matrix S S K) (b : S → K)
    (h : ∀ i j, M i j * b j ≤ b i) (i j : S) (hj : 1 ≤ b j) : M∗ i j ≤ b i := by
  calc
    M∗ i j = M∗ i j * 1 := (mul_one _).symm
    _ ≤ M∗ i j * b j := mul_le_mul_right hj _
    _ ≤ b i := matrix_star_mul_potential M b h i j

theorem matrix_star_map_le {T : Type*} [Fintype T] [DecidableEq T]
    (M : Matrix S S K) (N : Matrix T T K) (f : S → T)
    (h : ∀ i j, M i j ≤ N (f i) (f j)) (i j : S) : M∗ i j ≤ N∗ (f i) (f j) := by
  apply matrix_star_le_potential M (fun k => N∗ (f k) (f j)) _ i j
    (matrix_star_diagonal _ _)
  intro a b
  exact (mul_le_mul_left ((h a b).trans (le_kstar (a := N) (f a) (f b))) _).trans
    (matrix_star_entry_mul_le _ _ _ _)

end Stackat
