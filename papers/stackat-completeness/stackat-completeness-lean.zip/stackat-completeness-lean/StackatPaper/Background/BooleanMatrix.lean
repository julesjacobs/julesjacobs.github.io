import StackatPaper.Background.MatrixLemmas

/-!
# Background: Boolean entries

A Boolean table entry denotes `0` or `1` in a Kleene algebra (`bit`), and a Boolean table a
matrix of such entries (`boolMatrix`). Boolean entries commute with every element.
-/

namespace Stackat

variable {K : Type*} [KleeneAlgebra K]

/-- The value `1` or `0` of a proposition. -/
noncomputable def bit (P : Prop) : K := by
  classical
  exact if P then 1 else 0

@[simp] theorem bit_true (h : P) : bit (K := K) P = 1 := by simp [bit, h]
@[simp] theorem bit_false (h : ¬ P) : bit (K := K) P = 0 := by simp [bit, h]

/-- The matrix of a Boolean table. -/
noncomputable def boolMatrix {S T : Type*} (F : S → T → Prop) : Matrix S T K :=
  fun i j => bit (F i j)

theorem bit_le_one (P : Prop) : bit (K := K) P ≤ 1 := by
  classical
  by_cases h : P
  · rw [bit_true h]
  · rw [bit_false h]; exact zero_le

theorem bit_and (P Q : Prop) : bit (K := K) (P ∧ Q) = bit P * bit Q := by
  classical
  by_cases hp : P <;> by_cases hq : Q <;> simp [bit, hp, hq]

theorem bit_exists {I : Type*} [Fintype I] (P : I → Prop) :
    bit (K := K) (∃ i, P i) = ∑ i, bit (P i) := by
  classical
  by_cases h : ∃ i, P i
  · rw [bit_true h]
    apply le_antisymm
    · obtain ⟨i, hi⟩ := h
      have hs := Finset.single_le_sum (f := fun j => bit (K := K) (P j))
        (fun _ _ => zero_le) (Finset.mem_univ i)
      simpa only [bit_true hi] using hs
    · exact idem_sum_le _ _ _ (fun i _ => bit_le_one (P i))
  · rw [bit_false h]
    symm
    apply Finset.sum_eq_zero
    intro i _
    exact bit_false (fun hi => h ⟨i, hi⟩)

end Stackat
