import StackatPaper.Spec
import StackatPaper.Section5.Spec

/-!
Section 6: the result types of the decision procedures. An inclusion answer carries
a derivation of `e + f = f` or a counterexample with its proof; an equivalence answer a derivation
of `e = f` or a distinguishing pair.
-/

namespace Stackat.Decision

inductive InclusionResult (e f : Expr A) where
  | included (proof : ⊢ e ≤ f)
  | counterexample (input output : List A)
      (proof : R e input output ∧ ¬ R f input output)

inductive EquivalenceResult (e f : Expr A) where
  | equivalent (proof : ⊢ e ≈ f)
  | different (input output : List A)
      (proof : (R e input output ∧ ¬ R f input output) ∨
        (R f input output ∧ ¬ R e input output))

end Stackat.Decision

namespace Stackat.Fields.Decision

inductive InclusionResult (e f : Expr A V) [∀ i, Fintype (V i)] where
  | included (proof : ⊢ e ≤ f)
  | counterexample (input output : Header V × List A)
      (proof : R e input output ∧ ¬ R f input output)

inductive EquivalenceResult (e f : Expr A V) [∀ i, Fintype (V i)] where
  | equivalent (proof : ⊢ e ≈ f)
  | different (input output : Header V × List A)
      (proof : (R e input output ∧ ¬ R f input output) ∨
        (R f input output ∧ ¬ R e input output))

end Stackat.Fields.Decision
