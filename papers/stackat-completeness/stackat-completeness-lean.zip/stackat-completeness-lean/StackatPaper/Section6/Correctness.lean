import StackatPaper.Section6.PureDecision
import StackatPaper.Section6.FieldDecision

/-!
Section 6: what the executable decision procedures decide. Each result carries a derivation or a
verified counterexample (the result types, `Section6/Results.lean`); this file states the
correctness of the four procedures in one theorem (`decision_procedures`): the inclusion
procedure returns a derivation exactly when the semantic inclusion holds, and the equivalence
procedure exactly when the relations are equal; otherwise they return a counterexample. The
certificate checkers are verified (`certificate_checkers`).
-/

namespace Stackat

/-- A pure inclusion result is a derivation exactly when `R_e ⊆ R_f`. -/
private theorem inclusion_result_iff {A : Type} {e f : Expr A} (r : Decision.InclusionResult e f) :
    (∃ d, r = .included d) ↔ R e ≤ R f := by
  cases r with
  | included d => exact ⟨fun _ s t he => (soundness_iff d s t).mp (Or.inl he), fun _ => ⟨d, rfl⟩⟩
  | counterexample s t h =>
    exact ⟨fun ⟨_, hd⟩ => (nomatch hd), fun hle => (h.2 (hle s t h.1)).elim⟩

/-- A pure equivalence result is a derivation exactly when `R_e = R_f`. -/
private theorem equivalence_result_iff {A : Type} {e f : Expr A}
    (r : Decision.EquivalenceResult e f) : (∃ d, r = .equivalent d) ↔ R e = R f := by
  cases r with
  | equivalent d =>
    exact ⟨fun _ => funext fun s => funext fun t => propext (soundness_iff d s t), fun _ => ⟨d, rfl⟩⟩
  | different s t h =>
    refine ⟨fun ⟨_, hd⟩ => (nomatch hd), fun hef => ?_⟩
    have h' : ∀ s t, R e s t ↔ R f s t := fun s t => by rw [hef]
    rcases h with h | h
    · exact (h.2 ((h' s t).mp h.1)).elim
    · exact (h.2 ((h' s t).mpr h.1)).elim

/-- An inclusion result with fields is a derivation exactly when the relations are included. -/
private theorem field_inclusion_result_iff {A : Type} {n : ℕ} {V : Fin n → Type}
    [∀ i, Fintype (V i)] {e f : Fields.Expr A V} (r : Fields.Decision.InclusionResult e f) :
    (∃ d, r = .included d) ↔ Fields.R e ≤ Fields.R f := by
  cases r with
  | included d =>
    exact ⟨fun _ s t he => (Fields.finite_header_soundness_iff d s t).mp (Or.inl he),
      fun _ => ⟨d, rfl⟩⟩
  | counterexample s t h =>
    exact ⟨fun ⟨_, hd⟩ => (nomatch hd), fun hle => (h.2 (hle s t h.1)).elim⟩

/-- An equivalence result with fields is a derivation exactly when the relations are equal. -/
private theorem field_equivalence_result_iff {A : Type} {n : ℕ} {V : Fin n → Type}
    [∀ i, Fintype (V i)] {e f : Fields.Expr A V} (r : Fields.Decision.EquivalenceResult e f) :
    (∃ d, r = .equivalent d) ↔ Fields.R e = Fields.R f := by
  cases r with
  | equivalent d => exact ⟨fun _ => Fields.finite_header_soundness d, fun _ => ⟨d, rfl⟩⟩
  | different s t h =>
    refine ⟨fun ⟨_, hd⟩ => (nomatch hd), fun hef' => ?_⟩
    have hef : ∀ s t, Fields.R e s t ↔ Fields.R f s t := fun s t => by rw [hef']
    rcases h with h | h
    · exact (h.2 ((hef s t).mp h.1)).elim
    · exact (h.2 ((hef s t).mpr h.1)).elim

/-- **The executable decision procedures** (Section 6). Given explicit finite enumerations of the
alphabet and of the field domains, the inclusion procedures return a derivation of `e + f = f`
exactly when `R_e ⊆ R_f`, and the equivalence procedures a derivation of `e = f` exactly when
`R_e = R_f`, for pure stack expressions and for expressions with header fields; otherwise they
return a counterexample. -/
theorem decision_procedures {A : Type} [FinEnum A] :
    (∀ e f : Expr A,
      ((∃ d, Executable.PureDecision.decide_inclusion e f = .included d) ↔
          R e ≤ R f) ∧
        ((∃ d, Executable.PureDecision.decide_equivalence e f = .equivalent d) ↔
          R e = R f)) ∧
      ∀ {n : ℕ} {V : Fin n → Type} [∀ i, FinEnum (V i)] (e f : Fields.Expr A V),
        ((∃ d, Fields.Executable.decide_inclusion e f = .included d) ↔
            Fields.R e ≤ Fields.R f) ∧
          ((∃ d, Fields.Executable.decide_equivalence e f = .equivalent d) ↔
            Fields.R e = Fields.R f) :=
  ⟨fun _ _ => ⟨inclusion_result_iff _, equivalence_result_iff _⟩,
    fun _ _ => ⟨field_inclusion_result_iff _, field_equivalence_result_iff _⟩⟩

/-- **The certificate checkers** (Section 6). The separate certificate-exporting interfaces of
the pure and the field procedures come with verified checkers: an answer that the checker accepts
is correct, that is, an inclusion certificate implies the semantic inclusion, and a counterexample
is related by the source and not by the target. -/
theorem certificate_checkers {A : Type} [FinEnum A] :
    (∀ (e f : Expr A)
        (answer : Decision.Answer (List A) Decision.CellCertificate),
      Executable.PureDecision.checkAnswer e f answer = true →
        Decision.Correct (R e) (R f) answer) ∧
      ∀ {n : ℕ} {V : Fin n → Type} [∀ i, FinEnum (V i)] (e f : Fields.Expr A V)
        (answer : Fields.Decision.Answer (A := A) V),
        Fields.Executable.checkAnswer e f answer = true →
          Fields.Decision.Correct e f answer :=
  ⟨Executable.PureDecision.checkAnswer_correct, Fields.Executable.checkAnswer_correct⟩

end Stackat
