import StackatPaper.Section6.Results
import StackatPaper.Section6.Executable.DecisionData
import StackatPaper.Section4.Derivation
import StackatPaper.Section6.Executable.AutomatonDecision
import StackatPaper.Section6.Executable.RowNormalForm
import StackatPaper.AppendixD.Counterexample

/-!
Section 6: the executable decision procedure for pure stack expressions
(`Executable.PureDecision.decide_inclusion`, `Executable.PureDecision.decide_equivalence`), and
the certificate checker (`Executable.PureDecision.checkAnswer_correct`).
-/

namespace Stackat.Executable.PureDecision
variable {A : Type} [FinEnum A]

def family (e f : Expr A) : Bool → StackAutomaton A
  | false => StackAutomaton.ofExpr e
  | true => StackAutomaton.ofExpr f
instance (e f : Expr A) : ∀ i, GraphDecisions ((family e f) i).graph
  | false => expressionGraphDecisions e
  | true => expressionGraphDecisions f

instance (e f : Expr A) : ∀ i, FinEnum (family e f i).State
  | false => expressionStateEnum e
  | true => expressionStateEnum f

def counterexample (e f : Expr A) : Option (List A × List A) :=
  AutomatonDecision.counterexample (family e f)

theorem counterexample_sound (e f : Expr A) {s t : List A}
    (h : counterexample e f = some (s,t)) : R e s t ∧ ¬ R f s t := by
  simpa only [family, StackAutomaton.eval_ofExpr, Rel.eval_denote] using
    AutomatonDecision.counterexample_sound (family e f) h

theorem counterexample_none_iff (e f : Expr A) :
    counterexample e f = none ↔ ∀ s t, R e s t → R f s t := by
  simpa only [family, StackAutomaton.eval_ofExpr, Rel.eval_denote] using
    AutomatonDecision.counterexample_none_iff (family e f)

def checkCertificate (e f : Expr A) (c : Decision.CellCertificate) : Bool :=
  AutomatonDecision.checkCertificate (family e f) c

theorem checkCertificate_sound (e f : Expr A) (c : Decision.CellCertificate)
    (h : checkCertificate e f c = true) : ∀ s t, R e s t → R f s t := by
  have hh := AutomatonDecision.checkCertificate_sound (family e f) c h
  simpa only [family, StackAutomaton.eval_ofExpr, Rel.eval_denote] using hh

@[irreducible] def decideRaw (e f : Expr A) : Decision.Answer (List A) Decision.CellCertificate :=
  match counterexample e f with
  | some (s,t) => .counterexample s t
  | none => .included (AutomatonDecision.certificate (family e f))

def decide_inclusion (e f : Expr A) : Decision.InclusionResult e f :=
  match h : counterexample e f with
  | some (s,t) => .counterexample s t (counterexample_sound e f h)
  | none => .included (inequational_completeness A e f
      ((counterexample_none_iff e f).mp h))

def member (e : Expr A) (s t : List A) : Bool :=
  AutomatonDecision.member (family e e) false s t

theorem member_correct (e : Expr A) (s t : List A) : member e s t = true ↔ R e s t := by
  have h := AutomatonDecision.member_correct (family e e) false s t
  simpa only [family, StackAutomaton.eval_ofExpr, Rel.eval_denote] using h

def checkAnswer (e f : Expr A) :
    Decision.Answer (List A) Decision.CellCertificate → Bool
  | .included c => checkCertificate e f c
  | .counterexample s t => member e s t && !member f s t

theorem checkAnswer_correct (e f : Expr A) (answer : Decision.Answer (List A) Decision.CellCertificate)
    (h : checkAnswer e f answer = true) : Decision.Correct (R e) (R f) answer := by
  cases answer with
  | included c => exact checkCertificate_sound e f c h
  | counterexample s t =>
    simpa only [checkAnswer, Bool.and_eq_true, Bool.not_eq_true', Bool.eq_false_iff,
      ne_eq, member_correct, Decision.Correct] using h

@[irreducible] def decideEquivalenceRaw (e f : Expr A) :
    Decision.EquivalenceAnswer (List A) Decision.CellCertificate :=
  match decideRaw e f with
  | .counterexample s t => .different true s t
  | .included c => match decideRaw f e with
    | .counterexample s t => .different false s t
    | .included d => .equivalent c d

def decide_equivalence (e f : Expr A) : Decision.EquivalenceResult e f :=
  match decide_inclusion e f with
  | .counterexample s t h => .different s t (Or.inl h)
  | .included h => match decide_inclusion f e with
    | .counterexample s t k => .different s t (Or.inr k)
    | .included k => .equivalent (completeness A e f (le_antisymm
        (fun s t he => (soundness_iff h s t).mp (Or.inl he))
        (fun s t hf => (soundness_iff k s t).mp (Or.inl hf))))

end Stackat.Executable.PureDecision
