import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Fintype.Card
import Mathlib.Data.Finset.Card
import Mathlib.Logic.Relation

/-!
Section 6, verified implementation support (`Reachability`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable

variable {Q : Type} [Finite Q] [DecidableEq Q]

/-- Each vertex is expanded once. The termination bound is proof-only. -/
def explore [Finite Q] (next : Q → List Q) (seen : Finset Q) (todo : List Q) : Finset Q :=
  match todo with
  | [] => seen
  | x :: xs =>
    if x ∈ seen then explore next seen xs
    else explore next (insert x seen) (next x ++ xs)
termination_by (@Fintype.card Q (Fintype.ofFinite Q) - seen.card, todo.length)
decreasing_by
  · apply Prod.Lex.right
    simp
  · letI : Fintype Q := Fintype.ofFinite Q
    simp_wf
    have hs : seen.card < Fintype.card Q :=
      lt_of_lt_of_le (Finset.card_lt_card (Finset.ssubset_insert ‹x ∉ seen›))
        (Finset.card_le_univ (insert x seen))
    simp [Finset.card_insert_of_notMem ‹x ∉ seen›]
    omega

/-- Reachable vertices, without enumerating the ambient finite state space. -/
def reachable (next : Q → List Q) (roots : List Q) : Finset Q :=
  explore next ∅ roots

theorem explore_preserves (next : Q → List Q) (P : Q → Prop)
    (closed : ∀ x, P x → ∀ y ∈ next x, P y)
    (seen : Finset Q) (todo : List Q)
    (hs : ∀ x ∈ seen, P x) (ht : ∀ x ∈ todo, P x) :
    ∀ x ∈ explore next seen todo, P x := by
  fun_induction explore next seen todo with
  | case1 seen => exact hs
  | case2 seen x xs hx ih =>
    exact ih hs (fun y hy => ht y (List.mem_cons_of_mem x hy))
  | case3 seen x xs hx ih =>
    apply ih
    · intro y hy
      rcases Finset.mem_insert.mp hy with rfl | hy
      · exact ht _ (by simp)
      · exact hs y hy
    · intro y hy
      rcases List.mem_append.mp hy with hy | hy
      · exact closed x (ht x (by simp)) y hy
      · exact ht y (List.mem_cons_of_mem x hy)

theorem explore_complete (next : Q → List Q) (seen : Finset Q) (todo : List Q)
    (pending : ∀ x ∈ seen, ∀ y ∈ next x, y ∈ seen ∨ y ∈ todo) :
    seen ⊆ explore next seen todo ∧
    (∀ x ∈ todo, x ∈ explore next seen todo) ∧
    (∀ x ∈ explore next seen todo, ∀ y ∈ next x, y ∈ explore next seen todo) := by
  fun_induction explore next seen todo with
  | case1 seen =>
    refine ⟨fun _ h => h, by simp, ?_⟩
    intro x hx y hy
    simpa using pending x hx y hy
  | case2 seen x xs hx ih =>
    have hp : ∀ z ∈ seen, ∀ y ∈ next z, y ∈ seen ∨ y ∈ xs := by
      intro z hz y hy
      rcases pending z hz y hy with h | h
      · exact Or.inl h
      · rcases List.mem_cons.mp h with rfl | h
        · exact Or.inl hx
        · exact Or.inr h
    obtain ⟨hs, ht, hc⟩ := ih hp
    refine ⟨hs, ?_, hc⟩
    intro y hy
    rcases List.mem_cons.mp hy with rfl | hy
    · exact hs hx
    · exact ht y hy
  | case3 seen x xs hx ih =>
    have hp : ∀ z ∈ insert x seen, ∀ y ∈ next z,
        y ∈ insert x seen ∨ y ∈ next x ++ xs := by
      intro z hz y hy
      rcases Finset.mem_insert.mp hz with rfl | hz
      · exact Or.inr (List.mem_append_left _ hy)
      · rcases pending z hz y hy with h | h
        · exact Or.inl (Finset.mem_insert_of_mem h)
        · rcases List.mem_cons.mp h with rfl | h
          · exact Or.inl (Finset.mem_insert_self ..)
          · exact Or.inr (List.mem_append_right _ h)
    obtain ⟨hs, ht, hc⟩ := ih hp
    refine ⟨fun _ h => hs (Finset.mem_insert_of_mem h), ?_, hc⟩
    intro y hy
    rcases List.mem_cons.mp hy with rfl | hy
    · exact hs (Finset.mem_insert_self ..)
    · exact ht y (List.mem_append_right _ hy)

theorem mem_reachable_iff (next : Q → List Q) (roots : List Q) (x : Q) :
    x ∈ reachable next roots ↔
      ∃ r ∈ roots, Relation.ReflTransGen (fun a b => b ∈ next a) r x := by
  constructor
  · apply explore_preserves next
      (fun x => ∃ r ∈ roots, Relation.ReflTransGen (fun a b => b ∈ next a) r x)
    · rintro y ⟨r, hr, h⟩ z hz
      exact ⟨r, hr, h.tail hz⟩
    · simp
    · intro r hr
      exact ⟨r, hr, .refl⟩
  · obtain ⟨_, ht, hc⟩ := explore_complete next ∅ roots (by simp)
    rintro ⟨r, hr, h⟩
    induction h with
    | refl => exact ht r hr
    | tail h hstep ih => exact hc _ ih _ hstep

end Stackat.Executable
