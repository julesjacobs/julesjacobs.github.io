import StackatPaper.Section5.Spec
import StackatPaper.Section6.Executable.DecisionData

/-!
Section 6, verified implementation support (`FieldDecisionData`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Fields.Decision

/-- One finite cell certificate for each input/output header pair. -/
abbrev InclusionCertificate {n : Nat} (V : Fin n → Type) :=
  List ((Header V × Header V) × Stackat.Decision.CellCertificate)

abbrev Answer {A : Type} {n : Nat} (V : Fin n → Type) :=
  Stackat.Decision.Answer (Header V × List A) (InclusionCertificate V)

def Correct (e f : Expr A V) (answer : Answer (A := A) V) : Prop :=
  Stackat.Decision.Correct (R e) (R f) answer

end Stackat.Fields.Decision
