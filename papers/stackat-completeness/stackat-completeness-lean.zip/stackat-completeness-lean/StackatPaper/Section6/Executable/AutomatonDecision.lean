import StackatPaper.Section6.Executable.IndexedGraph
import StackatPaper.Section6.Executable.RowNormalForm
import StackatPaper.AppendixD.SourceDirected
import StackatPaper.Section6.Executable.CellCertificate
import StackatPaper.Section6.Executable.Membership

/-!
Section 6, verified implementation support (`AutomatonDecision`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable.RowDecision
local instance : FinEnum Bool := FinEnum.ofList [false, true] (by intro b; cases b <;> simp)
variable {A : Type} [FinEnum A]
variable (F : Bool → StackAutomaton A) [∀ i, GraphDecisions (F i).graph] [∀ i, FinEnum (F i).State]

@[noinline, nospecialize] def counterexample : Option (List A × List A) :=
  letI := RowNormalForm.prepare F
  letI := RowNormalForm.stateEnum F
  letI := SourceDirected.prepare (RowNormalForm.automaton F)
  SourceDirected.counterexample (RowNormalForm.automaton F) (RowNormalForm.accepts F true)
    (RowNormalForm.accepts F false) (RowNormalForm.representative F)

theorem counterexample_sound {s t : List A} (h : counterexample F = some (s,t)) :
    (F false).eval Rel.push Rel.pop s t ∧ ¬ (F true).eval Rel.push Rel.pop s t := by
  letI := RowNormalForm.prepare F
  letI := RowNormalForm.stateEnum F
  letI := SourceDirected.prepare (RowNormalForm.automaton F)
  have hh := SourceDirected.counterexample_sound (RowNormalForm.automaton F)
    (RowNormalForm.accepts F true) (RowNormalForm.accepts F false)
    (RowNormalForm.representative F) (RowNormalForm.representative_ok F) h
  exact ⟨(RowNormalForm.semantics F false s t).mp hh.1,
    fun hf => hh.2 ((RowNormalForm.semantics F true s t).mpr hf)⟩

theorem counterexample_none_iff : counterexample F = none ↔
    ∀ s t, (F false).eval Rel.push Rel.pop s t → (F true).eval Rel.push Rel.pop s t := by
  letI := RowNormalForm.prepare F
  letI := RowNormalForm.stateEnum F
  letI := SourceDirected.prepare (RowNormalForm.automaton F)
  have h := SourceDirected.counterexample_none_iff (RowNormalForm.automaton F)
    (RowNormalForm.accepts F true) (RowNormalForm.accepts F false)
    (RowNormalForm.representative F) (RowNormalForm.representative_ok F)
  simpa only [BadCells.Direct, RowNormalForm.semantics] using h

@[noinline, nospecialize] def certificate : Decision.CellCertificate :=
  letI := RowNormalForm.prepare F
  letI := RowNormalForm.stateEnum F
  CellCertificate.produce (RowNormalForm.automaton F) (RowNormalForm.accepts F true)

@[noinline, nospecialize] def checkCertificate (c : Decision.CellCertificate) : Bool :=
  letI := RowNormalForm.prepare F
  letI := RowNormalForm.stateEnum F
  CellCertificate.check (RowNormalForm.automaton F)
    (RowNormalForm.accepts F false) (RowNormalForm.accepts F true) c

theorem checkCertificate_sound (c : Decision.CellCertificate) (h : checkCertificate F c = true) :
    ∀ s t, (F false).eval Rel.push Rel.pop s t → (F true).eval Rel.push Rel.pop s t := by
  letI := RowNormalForm.prepare F
  letI := RowNormalForm.stateEnum F
  have hh := CellCertificate.check_sound (RowNormalForm.automaton F)
    (RowNormalForm.accepts F false) (RowNormalForm.accepts F true) c h
  simpa only [BadCells.Direct, RowNormalForm.semantics] using hh

@[noinline, nospecialize] def member (i : Bool) (s t : List A) : Bool :=
  letI := RowNormalForm.prepare F
  Stackat.Executable.member (RowNormalForm.automaton F) (RowNormalForm.accepts F i) s t

theorem member_correct (i : Bool) (s t : List A) : member F i s t = true ↔
    (F i).eval Rel.push Rel.pop s t := by
  letI := RowNormalForm.prepare F
  exact (Stackat.Executable.member_correct (RowNormalForm.automaton F)
    (RowNormalForm.accepts F i) s t).trans (RowNormalForm.semantics F i s t)
end Stackat.Executable.RowDecision

namespace Stackat.Executable.AutomatonDecision
local instance : FinEnum Bool := FinEnum.ofList [false,true] (by intro b; cases b <;> simp)
variable {A : Type} [FinEnum A]
variable (F : Bool → StackAutomaton A) [∀ i, GraphDecisions (F i).graph] [∀ i, FinEnum (F i).State]

structure IndexedFamily where
  table : Table Bool (fun _ => StackAutomaton A)
  correct : ∀ i, table.get i = indexed (F i)
  enums : ∀ i, FinEnum (table.get i).State
  decisions : ∀ i, GraphDecisions (table.get i).graph

@[noinline, nospecialize] def makeFamily : IndexedFamily F :=
  let t := Table.ofFn fun i => indexed (F i)
  { table := t
    correct := by intro i; simp [t]
    enums := fun i => by rw [show t.get i = indexed (F i) from Table.get_ofFn _ _]; exact finIndex _
    decisions := fun i => by
      rw [show t.get i = indexed (F i) from Table.get_ofFn _ _]
      exact indexedDecisions (F i) }

namespace IndexedFamily
variable {F}
@[noinline, nospecialize] def family (c : IndexedFamily F) : Bool → StackAutomaton A := c.table.get
instance (c : IndexedFamily F) : ∀ i, FinEnum (c.family i).State := c.enums
instance (c : IndexedFamily F) : ∀ i, GraphDecisions (c.family i).graph := c.decisions
omit [∀ i, GraphDecisions (F i).graph] in
@[simp] theorem eval (c : IndexedFamily F) (i : Bool) :
    (c.family i).eval Rel.push Rel.pop = (F i).eval Rel.push Rel.pop := by
  rw [family, c.correct, indexed_eval]
end IndexedFamily

@[noinline, nospecialize] def counterexample := RowDecision.counterexample (makeFamily F).family
@[noinline, nospecialize] def certificate := RowDecision.certificate (makeFamily F).family
@[noinline, nospecialize] def checkCertificate := RowDecision.checkCertificate (makeFamily F).family
@[noinline, nospecialize] def member := RowDecision.member (makeFamily F).family

theorem counterexample_sound {s t : List A} (h : counterexample F = some (s,t)) :
    (F false).eval Rel.push Rel.pop s t ∧ ¬ (F true).eval Rel.push Rel.pop s t := by
  simpa only [IndexedFamily.eval] using
    RowDecision.counterexample_sound (makeFamily F).family h

theorem counterexample_none_iff : counterexample F = none ↔
    ∀ s t, (F false).eval Rel.push Rel.pop s t → (F true).eval Rel.push Rel.pop s t := by
  simpa only [IndexedFamily.eval] using RowDecision.counterexample_none_iff (makeFamily F).family

theorem checkCertificate_sound (c : Decision.CellCertificate) (h : checkCertificate F c = true) :
    ∀ s t, (F false).eval Rel.push Rel.pop s t → (F true).eval Rel.push Rel.pop s t := by
  simpa only [IndexedFamily.eval] using RowDecision.checkCertificate_sound (makeFamily F).family c h

theorem member_correct (i : Bool) (s t : List A) : member F i s t = true ↔
    (F i).eval Rel.push Rel.pop s t := by
  simpa only [IndexedFamily.eval] using RowDecision.member_correct (makeFamily F).family i s t
end Stackat.Executable.AutomatonDecision
