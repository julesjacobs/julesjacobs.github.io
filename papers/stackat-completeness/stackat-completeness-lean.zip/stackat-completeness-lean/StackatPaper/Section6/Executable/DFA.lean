import StackatPaper.Section6.Executable.Reachability
import StackatPaper.Section3.DFA

/-!
Section 6, verified implementation support (`DFA`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable.DFA

variable {A Q : Type} [Finite Q] [DecidableEq Q]

def successors (alphabet : List A) (δ : Q → A → Q) (q : Q) : List Q :=
  alphabet.map (δ q)

omit [Finite Q] [DecidableEq Q] in
@[simp] theorem mem_successors (alphabet : List A) (complete : ∀ a, a ∈ alphabet) (δ : Q → A → Q) (q r : Q) :
    r ∈ successors alphabet δ q ↔ ∃ a, δ q a = r := by
  simp [successors, complete]

def states (alphabet : List A) (initial : Q) (δ : Q → A → Q) : Finset Q :=
  reachable (successors alphabet δ) [initial]

theorem mem_states (alphabet : List A) (complete : ∀ a, a ∈ alphabet) (initial : Q) (δ : Q → A → Q) (q : Q) :
    q ∈ states alphabet initial δ ↔ ∃ w : List A, w.foldl δ initial = q := by
  rw [states, mem_reachable_iff]
  simp only [List.mem_singleton, exists_eq_left]
  constructor
  · intro h
    induction h with
    | refl => exact ⟨[], rfl⟩
    | @tail q r _ hstep ih =>
      obtain ⟨w, rfl⟩ := ih
      obtain ⟨a, rfl⟩ := (mem_successors alphabet complete δ _ _).mp hstep
      exact ⟨w ++ [a], by simp [List.foldl_append]⟩
  · rintro ⟨w, rfl⟩
    induction w using List.reverseRecOn with
    | nil => exact .refl
    | append_singleton w a ih =>
      simp only [List.foldl_append, List.foldl_cons, List.foldl_nil]
      exact ih.tail ((mem_successors alphabet complete δ _ _).mpr ⟨a, rfl⟩)

end Stackat.Executable.DFA
