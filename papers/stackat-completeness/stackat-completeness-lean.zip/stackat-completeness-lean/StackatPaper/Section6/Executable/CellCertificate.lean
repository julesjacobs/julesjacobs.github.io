import StackatPaper.Section6.Executable.DecisionData
import StackatPaper.AppendixD.BadCells

/-!
Section 6, verified implementation support (`CellCertificate`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable.CellCertificate
variable {A S : Type} [FinEnum A] [FinEnum S]
variable (M : DFA A S) (E F : S → S → Bool)

def table (c : Decision.CellCertificate) (i j : S) : Prop :=
  ((FinEnum.equiv i).val, (FinEnum.equiv j).val) ∈ c
instance (c : Decision.CellCertificate) (i j : S) : Decidable (table c i j) :=
  inferInstanceAs (Decidable (_ ∈ c))

def check (c : Decision.CellCertificate) : Bool :=
  decide ((∀ i j, F i j = true → table c i j) ∧
    (∀ j, table c M.initial j → F M.initial j = true) ∧
    (∀ i, table c i M.initial → F i M.initial = true) ∧
    (∀ i j a b, table c (M.step i a) (M.step j b) →
      F (M.step i a) (M.step j b) ≠ true → a = b ∧ table c i j) ∧
    (∀ i j, E i j = true → table c i j))

theorem check_iff (c : Decision.CellCertificate) : check M E F c = true ↔
    BadCells.Direct E ≤ table c ∧ BadCells.Direct F ≤ table c ∧
      CertificateConditions M (BadCells.Direct F) (table c) := by
  simp only [check, decide_eq_true_eq]
  constructor
  · rintro ⟨hd, hl, hr, hs, he⟩
    exact ⟨he, hd, CertificateConditions.of_step M _ hl hr hs⟩
  · rintro ⟨he, hd, hc⟩
    exact ⟨hd, fun j hg => by_contra fun hf => hc.boundary_left j ⟨hg, hf⟩,
      fun i hg => by_contra fun hf => hc.boundary_right i ⟨hg, hf⟩,
      fun i j a b hg hf => hc.step hg hf, he⟩

theorem check_sound (c : Decision.CellCertificate) (h : check M E F c = true) :
    ∀ s t, Accepted M (BadCells.Direct E) s t →
      Accepted M (BadCells.Direct F) s t := by
  obtain ⟨he, hd, hc⟩ := (check_iff M E F c).mp h
  exact (certificate_iff M (BadCells.Direct F) (BadCells.Direct E)).mpr ⟨table c, he, hd, hc⟩

def produce : Decision.CellCertificate :=
  let d := BadCells.bad M F
  ((FinEnum.toList (S × S)).filter fun p => p ∉ d).map fun (i,j) =>
    ((FinEnum.equiv i).val, (FinEnum.equiv j).val)

end Stackat.Executable.CellCertificate
