import StackatPaper.AppendixA.Automaton
import StackatPaper.Section6.Executable.Saturation
import StackatPaper.Section6.Executable.FiniteIndex

/-!
Section 6, verified implementation support (`ExpressionGraph`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable

variable {A S T : Type}

class GraphDecisions (G : StackGraph A S) where
  eps : DecidableRel G.eps
  push : ∀ a, DecidableRel (G.push a)
  pop : ∀ a, DecidableRel (G.pop a)

attribute [instance_reducible, instance] GraphDecisions.eps GraphDecisions.push GraphDecisions.pop

instance : GraphDecisions (StackGraph.empty : StackGraph A S) where
  eps := fun _ _ => inferInstanceAs (Decidable False)
  push := fun _ _ _ => inferInstanceAs (Decidable False)
  pop := fun _ _ _ => inferInstanceAs (Decidable False)

instance (G : StackGraph A S) (H : StackGraph A T) [GraphDecisions G] [GraphDecisions H]
    (bridge : S ⊕ T → S ⊕ T → Prop) [DecidableRel bridge] : GraphDecisions (G.sum H bridge) where
  eps := by
    intro i j
    cases i <;> cases j <;> dsimp [StackGraph.sum] <;> infer_instance
  push := by
    intro a i j
    cases i <;> cases j <;> dsimp [StackGraph.sum] <;> infer_instance
  pop := by
    intro a i j
    cases i <;> cases j <;> dsimp [StackGraph.sum] <;> infer_instance

instance (eps : Prop) (push pop : A → Prop) [Decidable eps]
    [DecidablePred push] [DecidablePred pop] : GraphDecisions (StackAutomaton.single eps push pop).graph where
  eps := fun _ _ => inferInstanceAs (Decidable (_ ∧ _ ∧ eps))
  push := fun a _ _ => inferInstanceAs (Decidable (_ ∧ _ ∧ push a))
  pop := fun a _ _ => inferInstanceAs (Decidable (_ ∧ _ ∧ pop a))

instance (M N : StackAutomaton A) : DecidableRel (StackAutomaton.mulBridge M N) := by
  intro i j
  cases i <;> cases j <;> dsimp [StackAutomaton.mulBridge] <;> infer_instance

instance (M N : StackAutomaton A) : DecidableRel (StackAutomaton.addBridge M N) := by
  intro i j
  rcases i with b | (i | i) <;> rcases j with c | (j | j)
  all_goals first
    | cases b <;> cases c <;> dsimp [StackAutomaton.addBridge] <;> infer_instance
    | cases b <;> dsimp [StackAutomaton.addBridge] <;> infer_instance
    | cases c <;> dsimp [StackAutomaton.addBridge] <;> infer_instance
    | dsimp [StackAutomaton.addBridge]; infer_instance

instance (M : StackAutomaton A) : DecidableRel (StackAutomaton.starBridge M) := by
  intro i j
  rcases i with b | i <;> rcases j with c | j
  all_goals first
    | cases b <;> cases c <;> dsimp [StackAutomaton.starBridge] <;> infer_instance
    | cases b <;> dsimp [StackAutomaton.starBridge] <;> infer_instance
    | cases c <;> dsimp [StackAutomaton.starBridge] <;> infer_instance
    | dsimp [StackAutomaton.starBridge]; infer_instance

@[implicit_reducible]
def expressionGraphDecisions [DecidableEq A] : (e : Expr A) →
    GraphDecisions (StackAutomaton.ofExpr e).graph
  | .zero => by dsimp [StackAutomaton.ofExpr, StackAutomaton.zero]; infer_instance
  | .one => by dsimp [StackAutomaton.ofExpr, StackAutomaton.one]; infer_instance
  | .push a => by dsimp [StackAutomaton.ofExpr, StackAutomaton.push]; infer_instance
  | .pop a => by dsimp [StackAutomaton.ofExpr, StackAutomaton.pop]; infer_instance
  | .add e f => by
    letI := expressionGraphDecisions e
    letI := expressionGraphDecisions f
    dsimp [StackAutomaton.ofExpr, StackAutomaton.add]
    infer_instance
  | .mul e f => by
    letI := expressionGraphDecisions e
    letI := expressionGraphDecisions f
    dsimp [StackAutomaton.ofExpr, StackAutomaton.mul]
    infer_instance
  | .star e => by
    letI := expressionGraphDecisions e
    dsimp [StackAutomaton.ofExpr, StackAutomaton.star]
    infer_instance


local instance : FinEnum Bool := FinEnum.ofList [false,true] (by intro b; cases b <;> simp)

@[implicit_reducible] def expressionStateEnum : (e : Expr A) → FinEnum (StackAutomaton.ofExpr e).State
  | .zero => by dsimp [StackAutomaton.ofExpr, StackAutomaton.zero, StackAutomaton.single]; infer_instance
  | .one => by dsimp [StackAutomaton.ofExpr, StackAutomaton.one, StackAutomaton.single]; infer_instance
  | .push a => by dsimp [StackAutomaton.ofExpr, StackAutomaton.push, StackAutomaton.single]; infer_instance
  | .pop a => by dsimp [StackAutomaton.ofExpr, StackAutomaton.pop, StackAutomaton.single]; infer_instance
  | .add e f => by
    letI := expressionStateEnum e
    letI := expressionStateEnum f
    dsimp [StackAutomaton.ofExpr, StackAutomaton.add]
    infer_instance
  | .mul e f => by
    letI := expressionStateEnum e
    letI := expressionStateEnum f
    dsimp [StackAutomaton.ofExpr, StackAutomaton.mul]
    infer_instance
  | .star e => by
    letI := expressionStateEnum e
    dsimp [StackAutomaton.ofExpr, StackAutomaton.star]
    infer_instance
end Stackat.Executable
