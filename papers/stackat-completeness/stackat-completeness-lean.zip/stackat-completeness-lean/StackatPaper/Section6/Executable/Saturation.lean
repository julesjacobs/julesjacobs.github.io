import StackatPaper.Section6.Executable.FixedPoint
import StackatPaper.AppendixA.Saturation

/-!
Section 6, verified implementation support (`Saturation`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable.Saturation

variable {A S : Type} [Fintype A] [Fintype S] [DecidableEq S]
variable (G : StackGraph A S) [DecidableRel G.eps]
  [∀ a, DecidableRel (G.push a)] [∀ a, DecidableRel (G.pop a)]

def step (d : Finset (S × S)) : Finset (S × S) :=
  Finset.univ.filter fun (i, j) =>
    (i, j) ∈ d ∨ i = j ∨ G.eps i j ∨
    (∃ k, (i, k) ∈ d ∧ (k, j) ∈ d) ∨
    ∃ a k l, G.push a i k ∧ (k, l) ∈ d ∧ G.pop a l j

@[simp] theorem mem_step (d : Finset (S × S)) (i j : S) :
    (i, j) ∈ step G d ↔
    (i, j) ∈ d ∨ i = j ∨ G.eps i j ∨
    (∃ k, (i, k) ∈ d ∧ (k, j) ∈ d) ∨
    ∃ a k l, G.push a i k ∧ (k, l) ∈ d ∧ G.pop a l j := by
  simp [step]

theorem grows (d : Finset (S × S)) : d ⊆ step G d := by
  rintro ⟨i, j⟩ h
  exact (mem_step G d i j).mpr (Or.inl h)

theorem preserves (d : Finset (S × S))
    (hd : ∀ p ∈ d, G.Balanced p.1 p.2) :
    ∀ p ∈ step G d, G.Balanced p.1 p.2 := by
  rintro ⟨i, j⟩ h
  rcases (mem_step G d i j).mp h with h | rfl | h | ⟨k, hik, hkj⟩ | ⟨a, k, l, hik, hkl, hlj⟩
  · exact hd _ h
  · exact .refl i
  · exact .eps h
  · exact .trans (hd (i, k) hik) (hd (k, j) hkj)
  · exact .matchPair hik (hd (k, l) hkl) hlj

/-- Reference finite closure; optimized producers can be checked against these rules. -/
def balanced : Finset (S × S) := fixedPoint (step G) (grows G) ∅

theorem balanced_iff (i j : S) : (i, j) ∈ balanced G ↔ G.Balanced i j := by
  constructor
  · exact fixedPoint_preserves (step G) (grows G)
      (fun p => G.Balanced p.1 p.2) (preserves G) ∅ (by simp) (i, j)
  · intro h
    have hc : step G (balanced G) = balanced G := fixedPoint_closed (step G) (grows G) ∅
    have add {i j} (h : (i, j) ∈ step G (balanced G)) : (i, j) ∈ balanced G := hc ▸ h
    induction h with
    | refl i => exact add ((mem_step G _ i i).mpr (Or.inr (Or.inl rfl)))
    | @eps i j h => exact add ((mem_step G _ i j).mpr (Or.inr (Or.inr (Or.inl h))))
    | @trans i j k _ _ ih ij =>
      exact add ((mem_step G _ i k).mpr (Or.inr (Or.inr (Or.inr (Or.inl ⟨j, ih, ij⟩)))))
    | @matchPair a i j k l hij _ hkl ih =>
      exact add ((mem_step G _ i l).mpr (Or.inr (Or.inr (Or.inr (Or.inr ⟨a, j, k, hij, ih, hkl⟩)))))

end Stackat.Executable.Saturation
