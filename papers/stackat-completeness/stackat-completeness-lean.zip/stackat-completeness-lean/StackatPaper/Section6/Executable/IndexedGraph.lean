import StackatPaper.Section6.Executable.ExpressionGraph
import StackatPaper.Section6.Executable.FiniteTable

/-!
Section 6, verified implementation support (`IndexedGraph`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable
open scoped Computability
variable {A : Type} [FinEnum A] (M : StackAutomaton A) [FinEnum M.State]

def indexed : StackAutomaton A where
  State := Fin (FinEnum.card M.State)
  graph := {
    eps := fun i j => M.graph.eps (FinEnum.equiv.symm i) (FinEnum.equiv.symm j)
    push := fun a i j => M.graph.push a (FinEnum.equiv.symm i) (FinEnum.equiv.symm j)
    pop := fun a i j => M.graph.pop a (FinEnum.equiv.symm i) (FinEnum.equiv.symm j) }
  initial := FinEnum.equiv M.initial
  final := FinEnum.equiv M.final

instance : FinEnum (indexed M).State := inferInstanceAs (FinEnum (Fin _))

structure EdgeTables [GraphDecisions M.graph] where
  eps : Table ((indexed M).State × (indexed M).State) (fun _ => Bool)
  push : Table A (fun _ => Table ((indexed M).State × (indexed M).State) (fun _ => Bool))
  pop : Table A (fun _ => Table ((indexed M).State × (indexed M).State) (fun _ => Bool))
  eps_ok : ∀ i j, eps.get (i,j) = true ↔ (indexed M).graph.eps i j
  push_ok : ∀ a i j, (push.get a).get (i,j) = true ↔ (indexed M).graph.push a i j
  pop_ok : ∀ a i j, (pop.get a).get (i,j) = true ↔ (indexed M).graph.pop a i j

@[noinline, nospecialize] def edgeTables [GraphDecisions M.graph] : EdgeTables M where
  eps := Table.ofFn fun (i,j) => decide (M.graph.eps (FinEnum.equiv.symm i) (FinEnum.equiv.symm j))
  push := Table.ofFn fun a => Table.ofFn fun (i,j) =>
    decide (M.graph.push a (FinEnum.equiv.symm i) (FinEnum.equiv.symm j))
  pop := Table.ofFn fun a => Table.ofFn fun (i,j) =>
    decide (M.graph.pop a (FinEnum.equiv.symm i) (FinEnum.equiv.symm j))
  eps_ok := by intros; simp [indexed]
  push_ok := by intros; simp [indexed]
  pop_ok := by intros; simp [indexed]

@[implicit_reducible, noinline, nospecialize] def EdgeTables.decisions [GraphDecisions M.graph] (t : EdgeTables M) :
    GraphDecisions (indexed M).graph where
  eps := fun i j => decidable_of_iff (t.eps.get (i,j) = true) (t.eps_ok i j)
  push := fun a i j => decidable_of_iff ((t.push.get a).get (i,j) = true) (t.push_ok a i j)
  pop := fun a i j => decidable_of_iff ((t.pop.get a).get (i,j) = true) (t.pop_ok a i j)

@[noinline, nospecialize] opaque indexedDecisions [GraphDecisions M.graph] : GraphDecisions (indexed M).graph :=
  (edgeTables M).decisions
attribute [instance] indexedDecisions

theorem indexed_eval {K : Type*} [KleeneAlgebra K] (p q : A → K) :
    (indexed M).eval p q = M.eval p q := by
  have back : (indexed M).graph.Map M.graph FinEnum.equiv.symm :=
    ⟨fun _ _ h => h, fun _ _ _ h => h, fun _ _ _ h => h⟩
  have forward : M.graph.Map (indexed M).graph FinEnum.equiv := {
    eps := by intro i j h; simpa [indexed] using h
    push := by intro a i j h; simpa [indexed] using h
    pop := by intro a i j h; simpa [indexed] using h }
  apply le_antisymm
  · simpa [StackAutomaton.eval, indexed] using back.paths p q (FinEnum.equiv M.initial) (FinEnum.equiv M.final)
  · exact forward.paths p q M.initial M.final
end Stackat.Executable
