import StackatPaper.Background.Relations
import StackatPaper.AppendixA.StackGraph

/-!
Section 6, verified implementation support (`ControlPaths`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable
open scoped Computability
variable {S X : Type} [Fintype S] [DecidableEq S]

def controlStep (M : Matrix S S (Rel X)) (s t : S × X) : Prop := M s.1 t.1 s.2 t.2

theorem matrix_star_paths (M : Matrix S S (Rel X)) (i j : S) (s t : X) :
    M∗ i j s t ↔ Relation.ReflTransGen (controlStep M) (i,s) (j,t) := by
  let R : Matrix S S (Rel X) := fun i j s t =>
    Relation.ReflTransGen (controlStep M) (i,s) (j,t)
  have upper : M∗ ≤ R := by
    apply kstar_le_of_mul_le_right
    · intro i j s t h
      by_cases hij : i = j
      · subst j
        have ht : s = t := by simpa only [Matrix.one_apply_eq, Rel.one_apply] using h
        subst t
        exact .refl
      · simp [Matrix.one_apply_ne hij] at h
    · intro i j s t h
      obtain ⟨k, _, m, hm, hr⟩ := (Rel.sum_apply _ _ s t).mp h
      change Relation.ReflTransGen (controlStep M) (k,m) (j,t) at hr
      exact Relation.ReflTransGen.head (b := (k,m)) hm hr
  constructor
  · exact upper i j s t
  · intro h
    have lower : ∀ {x y : S × X}, Relation.ReflTransGen (controlStep M) x y →
        M∗ x.1 y.1 x.2 y.2 := by
      intro x y h
      induction h with
      | refl => exact matrix_star_diagonal M x.1 x.2 x.2 rfl
      | @tail y z _ hyz ih =>
        exact matrix_star_entry_mul_le M x.1 z.1 y.1 x.2 z.2
          ⟨y.2, ih, le_kstar (a := M) y.1 z.1 y.2 z.2 hyz⟩
    exact lower h

omit [Fintype S] [DecidableEq S] in
theorem graph_transition_apply {A : Type} [Fintype A] (G : StackGraph A S)
    (p q : A → Rel X) (i j : S) (s t : X) :
    G.transition p q i j s t ↔
      (G.eps i j ∧ s = t) ∨ (∃ a, G.push a i j ∧ p a s t) ∨
        (∃ a, G.pop a i j ∧ q a s t) := by
  classical
  have cond (P : Prop) (r : Rel X) : (if P then r else 0) s t ↔ P ∧ r s t := by
    by_cases h : P <;> simp [h]
  simp only [StackGraph.transition, Matrix.add_apply, Rel.add_apply, boolMatrix,
    Rel.bit_apply, StackGraph.labelMatrix, Rel.sum_apply, Finset.mem_univ, true_and, cond,
    or_assoc]

end Stackat.Executable
