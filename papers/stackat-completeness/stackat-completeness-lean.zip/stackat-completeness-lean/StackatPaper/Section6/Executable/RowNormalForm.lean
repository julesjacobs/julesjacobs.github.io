import StackatPaper.Section6.Executable.ExpressionGraph
import StackatPaper.Section6.Executable.SaturationIndexed
import StackatPaper.Section6.Executable.FiniteTable
import StackatPaper.Section6.Executable.ReachableWords
import StackatPaper.Section3.SharedDFA
import StackatPaper.Section3.Tables

/-!
Section 6, verified implementation support (`RowNormalForm`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable.RowNormalForm
open scoped Computability

local instance : FinEnum Bool := FinEnum.ofList [false, true] (by intro b; cases b <;> simp)
variable {A I : Type} [FinEnum A] [FinEnum I]
variable (F : I → StackAutomaton A) [∀ i, GraphDecisions (F i).graph]

structure Rows where
  values : Table (I × Bool) (fun ib => Finset (F ib.1).State)
instance : CoeFun (Rows F) (fun _ => ∀ ib : I × Bool, Finset (F ib.1).State) :=
  ⟨fun r => r.values.get⟩
instance : Finite (Rows F) := Finite.of_injective
  (fun (r : Rows F) => r.values.get) (by
    intro r s h
    have hv : r.values = s.values := Table.ext (congrFun h)
    cases r; cases s; cases hv; rfl)
instance : DecidableEq (Rows F) := fun r s =>
  decidable_of_iff ((fun ib => r.values.get ib) = (fun ib => s.values.get ib)) (by
    constructor
    · intro h
      have hv : r.values = s.values := Table.ext (congrFun h)
      cases r; cases s; cases hv; rfl
    · intro h; cases h; rfl)


def letter (ib : I × Bool) (a : A) (i j : (F ib.1).State) : Prop :=
  let b := Saturation.balanced (F ib.1).graph
  if ib.2 then ∃ k l, (j, k) ∈ b ∧ (F ib.1).graph.push a k l ∧ (l, i) ∈ b
  else ∃ k l, (i, k) ∈ b ∧ (F ib.1).graph.pop a k l ∧ (l, j) ∈ b
instance (ib : I × Bool) (a : A) : DecidableRel (letter F ib a) := by
  unfold letter
  infer_instance

class Prepared [∀ i, FinEnum (F i).State] where
  starts : Table (I × Bool) (fun ib => Finset (F ib.1).State)
  letters : Table (I × Bool) (fun ib => Table A (fun _ => IndexedSet ((F ib.1).State × (F ib.1).State)))
  start_correct : ∀ ib j, j ∈ starts.get ib ↔
    if ib.2 then (F ib.1).graph.Balanced j (F ib.1).final
    else (F ib.1).graph.Balanced (F ib.1).initial j
  letter_correct : ∀ ib a i j, (i,j) ∈ ((letters.get ib).get a).entries ↔ letter F ib a i j

def compose {S : Type} [DecidableEq S] (r t : Finset (S × S)) : Finset (S × S) :=
  r.biUnion fun p => (t.filter fun q => p.2 = q.1).image fun q => (p.1,q.2)

@[simp] theorem mem_compose {S : Type} [DecidableEq S] (r t : Finset (S × S)) (i j : S) :
    (i,j) ∈ compose r t ↔ ∃ k, (i,k) ∈ r ∧ (k,j) ∈ t := by
  simp only [compose, Finset.mem_biUnion, Finset.mem_image, Finset.mem_filter, Prod.mk.injEq]
  constructor
  · rintro ⟨⟨x,k⟩, hp, ⟨⟨l,y⟩, ⟨hq, he⟩, hx, hy⟩⟩
    simp only at he hx hy
    subst x; subst y; subst l
    exact ⟨k,hp,hq⟩
  · rintro ⟨k,hp,hq⟩
    exact ⟨(i,k),hp,(k,j),⟨hq,rfl⟩,rfl,rfl⟩

@[noinline, nospecialize] opaque prepare [∀ i, FinEnum (F i).State] : Prepared F :=
  let decisions := Table.ofFn fun i => inferInstanceAs (GraphDecisions (F i).graph)
  let b := Table.ofFn fun i => @SaturationIndexed.balanced A (F i).State _ _ (F i).graph (decisions.get i)
  { starts := Table.ofFn fun ib => Finset.univ.filter fun j =>
      if ib.2 then (j,(F ib.1).final) ∈ b.get ib.1 else ((F ib.1).initial,j) ∈ b.get ib.1
    letters := Table.ofFn fun ib => Table.ofFn fun a =>
      let raw := if ib.2 then
        @Finset.filter _ (fun (i,j) => (F ib.1).graph.push a i j)
          (fun (i,j) => (decisions.get ib.1).push a i j) Finset.univ
        else @Finset.filter _ (fun (i,j) => (F ib.1).graph.pop a i j)
          (fun (i,j) => (decisions.get ib.1).pop a i j) Finset.univ
      let surrounded := compose (compose (b.get ib.1) raw) (b.get ib.1)
      IndexedSet.ofFinset (if ib.2 then surrounded.image Prod.swap else surrounded)
    start_correct := by intro ib j; simp [b, SaturationIndexed.balanced_iff]
    letter_correct := by
      intro ⟨idx,rev⟩ a i j
      cases rev <;> simp [b, letter, Saturation.balanced_iff, SaturationIndexed.balanced_iff,
        Finset.mem_image, Prod.swap_prod_mk, IndexedSet.ofFinset] <;> aesop }

variable [∀ i, FinEnum (F i).State] [data : Prepared F]

@[noinline, nospecialize] def initial : Rows F := ⟨data.starts⟩

@[noinline, nospecialize] def step (r : Rows F) (a : A) : Rows F :=
  let values := Table.ofFn fun ib =>
    Finset.univ.filter fun j => ∃ k ∈ r ib, ((data.letters.get ib).get a).contains (k,j) = true
  ⟨values⟩
abbrev State := DFA.WordState (initial F) (step F)
abbrev stateEnum : FinEnum (State F) := DFA.wordStateEnum (initial F) (step F)
@[noinline, nospecialize] def automaton : DFA A (State F) := DFA.wordAutomaton (initial F) (step F)
@[noinline, nospecialize] def representative : State F → List A := DFA.representative (initial F) (step F)
theorem representative_ok (d : State F) : (automaton F).h (representative F d) = d :=
  DFA.representative_ok (initial F) (step F) d
def row (d : State F) (ib : I × Bool) (j : (F ib.1).State) : Prop := j ∈ d.val ib
instance (d : State F) (ib : I × Bool) (j : (F ib.1).State) : Decidable (row F d ib j) :=
  inferInstanceAs (Decidable (j ∈ d.val ib))
theorem row_step (d : State F) (a : A) (ib : I × Bool) (j : (F ib.1).State) :
    row F ((automaton F).step d a) ib j ↔ ∃ k, row F d ib k ∧ letter F ib a k j := by
  simp [row, automaton, DFA.wordAutomaton, DFA.wordStep, step, IndexedSet.contains_iff, data.letter_correct]
omit [FinEnum I] [Prepared F] [∀ i, FinEnum (F i).State] in
theorem letter_pop (i : I) (a : A) (j k : (F i).State) :
    letter F (i, false) a j k ↔ (F i).graph.surround (F i).graph.pop a j k := by
  simp [letter, StackGraph.surround, Saturation.balanced_iff]
omit [FinEnum I] [Prepared F] [∀ i, FinEnum (F i).State] in
theorem letter_push (i : I) (a : A) (j k : (F i).State) :
    letter F (i, true) a j k ↔ (F i).graph.surround (F i).graph.push a k j := by
  simp [letter, StackGraph.surround, Saturation.balanced_iff]
def accepts (i : I) (d e : State F) : Bool :=
  decide (∃ k, row F d (i, false) k ∧ row F e (i, true) k)
variable {K : Type*} [KleeneAlgebra K]
set_option maxRecDepth 2000 in
theorem representation (p q : A → K) (hpq : ∀ a, p a * q a = 1)
    (hne : ∀ a b, a ≠ b → p a * q b = 0) (i : I) :
    letI := stateEnum F
    (F i).eval p q = tableProgram (automaton F) p q (fun d e => accepts F i d e = true) := by
  letI := stateEnum F
  classical
  have pop_component (k : (F i).State) :
      ((F i).graph.saturation (K := K) + (F i).graph.saturatedPop q)∗ (F i).initial k =
        ∑ d, (popMatrix (automaton F) q)∗ (automaton F).initial d * bit (row F d (i, false) k) := by
    rw [StackGraph.saturated_pop_factor]
    have h := deterministic_star_simulation (automaton F)
      ((F i).graph.surround (F i).graph.pop) (fun d j => row F d (i, false) j) q
      (fun d a j => (row_step F d a (i, false) j).trans (by simp only [letter_pop]))
    have he := congrArg (fun m => m (automaton F).initial k) h
    simpa [Matrix.mul_apply, boolMatrix, row, automaton, DFA.wordAutomaton,
      DFA.wordStart, initial, data.start_correct, StackGraph.saturation] using he.symm
  have push_component (k : (F i).State) :
      ((F i).graph.saturation (K := K) + (F i).graph.saturatedPush p)∗ k (F i).final =
        ∑ d, bit (row F d (i, true) k) * (pushMatrix (automaton F) p)∗ d (automaton F).initial := by
    rw [StackGraph.saturated_push_factor]
    have h := reverse_deterministic_star_simulation (automaton F)
      (fun a j k => (F i).graph.surround (F i).graph.push a k j)
      (fun d j => row F d (i, true) j) p
      (fun d a j => (row_step F d a (i, true) j).trans (by simp only [letter_push]))
    have he := congrArg (fun m => m k (automaton F).initial) h
    simpa [Matrix.mul_apply, boolMatrix, row, automaton, DFA.wordAutomaton,
      DFA.wordStart, initial, data.start_correct, StackGraph.saturation] using he
  change ((F i).graph.transition p q)∗ (F i).initial (F i).final = _
  rw [(F i).graph.factorization p q hpq hne]
  change (∑ k, ((F i).graph.saturation (K := K) + (F i).graph.saturatedPop q)∗ (F i).initial k *
    ((F i).graph.saturation (K := K) + (F i).graph.saturatedPush p)∗ k (F i).final) = _
  simp_rw [pop_component, push_component]
  simpa only [accepts, decide_eq_true_eq] using
    (tableProgram_product (automaton F) p q (fun d k => row F d (i, false) k)
      (fun d k => row F d (i, true) k)).symm
theorem semantics (i : I) (s t : List A) :
    Accepted (automaton F) (fun d e => accepts F i d e = true) s t ↔
      (F i).eval Rel.push Rel.pop s t := by
  letI := stateEnum F
  have h := representation F Rel.push Rel.pop Rel.push_pop (fun _ _ h => Rel.push_pop_ne h) i
  rw [← table_semantics]
  exact Iff.of_eq (congrArg (fun r : Rel (List A) => r s t) h.symm)

end Stackat.Executable.RowNormalForm
