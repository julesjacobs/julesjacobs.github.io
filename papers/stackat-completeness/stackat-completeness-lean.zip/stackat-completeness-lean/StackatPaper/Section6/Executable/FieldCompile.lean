import StackatPaper.Section5.Spec
import StackatPaper.Section6.Executable.ExpressionGraph
import StackatPaper.Section6.Executable.ControlPaths

/-!
Section 6, verified implementation support (`FieldCompile`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Fields.Executable
open Stackat.Executable
open scoped Computability
variable {A : Type} {n : Nat} {V : Fin n → Type}

abbrev Atom (A : Type) {n : Nat} (V : Fin n → Type) := A ⊕ (A ⊕ ((Σ i, V i) ⊕ (Σ i, V i)))

def atoms : Expr A V → Stackat.Expr (Atom A V)
  | .zero => .zero
  | .one => .one
  | .push a => .push (.inl a)
  | .pop a => .push (.inr (.inl a))
  | .test i v => .push (.inr (.inr (.inl ⟨i,v⟩)))
  | .assign i v => .push (.inr (.inr (.inr ⟨i,v⟩)))
  | .add e f => .add (atoms e) (atoms f)
  | .mul e f => .mul (atoms e) (atoms f)
  | .star e => .star (atoms e)

def atomRel : Atom A V → Rel (Header V × List A)
  | .inl a => (Expr.push a).denote
  | .inr (.inl a) => (Expr.pop a).denote
  | .inr (.inr (.inl ⟨i,v⟩)) => (Expr.test i v).denote
  | .inr (.inr (.inr ⟨i,v⟩)) => (Expr.assign i v).denote

theorem atoms_denote (e : Expr A V) :
    Expr.eval atomRel atomRel (atoms e) = (e.denote : Rel (Header V × List A)) := by
  induction e with
  | zero => rfl
  | one => rfl
  | push a => rfl
  | pop a => rfl
  | test i v => rfl
  | assign i v => rfl
  | add e f he hf => change _ + _ = _; rw [he, hf]; rfl
  | mul e f he hf => change _ * _ = _; rw [he, hf]; rfl
  | star e he => change _∗ = _; rw [he]; rfl

variable [Fintype A] [DecidableEq A] [∀ i, Fintype (V i)] [∀ i, DecidableEq (V i)]

def control (e : Expr A V) : StackAutomaton (Atom A V) := StackAutomaton.ofExpr (atoms e)
instance (e : Expr A V) : GraphDecisions (control e).graph := expressionGraphDecisions (atoms e)

def edge (e : Expr A V) (a : Atom A V) (i j : (control e).State) : Prop :=
  (control e).graph.push a i j ∨ (control e).graph.pop a i j
instance (e : Expr A V) (a : Atom A V) (i j : (control e).State) : Decidable (edge e a i j) :=
  inferInstanceAs (Decidable (_ ∨ _))

def silent (e : Expr A V) (s t : (control e).State × Header V) : Prop :=
  ((control e).graph.eps s.1 t.1 ∧ t.2 = s.2) ∨
  (∃ i v, edge e (.inr (.inr (.inl ⟨i,v⟩))) s.1 t.1 ∧ s.2 i = v ∧ t.2 = s.2) ∨
  (∃ i v, edge e (.inr (.inr (.inr ⟨i,v⟩))) s.1 t.1 ∧ t.2 = Function.update s.2 i v)

def graph (e : Expr A V) : StackGraph A ((control e).State × Header V) where
  eps := silent e
  push a s t := edge e (.inl a) s.1 t.1 ∧ t.2 = s.2
  pop a s t := edge e (.inr (.inl a)) s.1 t.1 ∧ t.2 = s.2

instance (e : Expr A V) : GraphDecisions (graph e) where
  eps := by intro i j; dsimp [graph, silent]; infer_instance
  push := by intro a i j; dsimp [graph]; infer_instance
  pop := by intro a i j; dsimp [graph]; infer_instance

def automaton (e : Expr A V) (h k : Header V) : StackAutomaton A where
  State := (control e).State × Header V
  graph := graph e
  initial := ((control e).initial, h)
  final := ((control e).final, k)
instance (e : Expr A V) (h k : Header V) : GraphDecisions (automaton e h k).graph :=
  inferInstanceAs (GraphDecisions (graph e))

omit [DecidableEq A] [∀ i, DecidableEq (V i)] in
theorem transition_correct (e : Expr A V) (i j : (control e).State)
    (h k : Header V) (s t : List A) :
    (graph e).transition Rel.push Rel.pop (i,h) (j,k) s t ↔
      (control e).graph.transition atomRel atomRel i j (h,s) (k,t) := by
  rw [graph_transition_apply, graph_transition_apply]
  simp only [graph, silent, edge, atomRel, Expr.denote, Rel.push, Rel.pop,
    Sum.exists, Sigma.exists, Prod.mk.injEq]
  aesop

omit [DecidableEq A] in
theorem eval_correct (e : Expr A V) (h k : Header V) (s t : List A) :
    (automaton e h k).eval Rel.push Rel.pop s t ↔ e.denote (h,s) (k,t) := by
  have he := StackAutomaton.eval_ofExpr (atoms e) atomRel atomRel
  rw [atoms_denote] at he
  change ((graph e).transition Rel.push Rel.pop)∗ _ _ s t ↔ _
  rw [matrix_star_paths]
  have hr : e.denote (h,s) (k,t) ↔
      Relation.ReflTransGen (controlStep ((control e).graph.transition atomRel atomRel))
        ((control e).initial,(h,s)) ((control e).final,(k,t)) := by
    rw [← he]
    exact matrix_star_paths _ _ _ _ _
  rw [hr]
  constructor
  · intro path
    have aux : ∀ {x y : ((control e).State × Header V) × List A},
        Relation.ReflTransGen (controlStep ((graph e).transition Rel.push Rel.pop)) x y →
        Relation.ReflTransGen (controlStep ((control e).graph.transition atomRel atomRel))
          (x.1.1,(x.1.2,x.2)) (y.1.1,(y.1.2,y.2)) := by
      intro x y path
      induction path with
      | refl => exact .refl
      | tail _ step ih => exact ih.tail ((transition_correct e _ _ _ _ _ _).mp step)
    exact aux path
  · intro path
    have aux : ∀ {x y : (control e).State × (Header V × List A)},
        Relation.ReflTransGen (controlStep ((control e).graph.transition atomRel atomRel)) x y →
        Relation.ReflTransGen (controlStep ((graph e).transition Rel.push Rel.pop))
          ((x.1,x.2.1),x.2.2) ((y.1,y.2.1),y.2.2) := by
      intro x y path
      induction path with
      | refl => exact .refl
      | tail _ step ih => exact ih.tail ((transition_correct e _ _ _ _ _ _).mpr step)
    exact aux path


instance (e : Expr A V) (h k : Header V) [∀ i, FinEnum (V i)] : FinEnum (automaton e h k).State := by
  letI := expressionStateEnum (atoms e)
  change FinEnum ((StackAutomaton.ofExpr (atoms e)).State × Header V)
  infer_instance
end Stackat.Fields.Executable
