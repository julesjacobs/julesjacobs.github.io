import StackatPaper.Section6.Executable.SaturationWorklist
import StackatPaper.Section6.Executable.IndexedSet

/-!
Section 6, verified implementation support (`SaturationIndexed`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable.SaturationIndexed
variable {A S : Type} [FinEnum A] [FinEnum S]
variable (G : StackGraph A S) [GraphDecisions G]

@[noinline, nospecialize] def next (d : IndexedSet (S × S)) (p : S × S) : List (S × S) :=
  ((FinEnum.toList S).filter fun i => d.contains (i,p.1)).map (fun i => (i,p.2)) ++
  ((FinEnum.toList S).filter fun j => d.contains (p.2,j)).map (fun j => (p.1,j)) ++
  (FinEnum.toList A).flatMap fun a =>
    let left := (FinEnum.toList S).filter fun i => G.push a i p.1
    let right := (FinEnum.toList S).filter fun j => G.pop a p.2 j
    left.flatMap fun i => right.map fun j => (i,j)

theorem next_eq (d : IndexedSet (S × S)) (p : S × S) :
    next G d p = SaturationWorklist.next G d.entries p := by
  simp [next, SaturationWorklist.next, ← IndexedSet.contains_iff]

@[noinline, nospecialize] def run (d : IndexedSet (S × S)) (todo : List (S × S)) : Finset (S × S) :=
  match todo with
  | [] => d.entries
  | p :: ps => if h : d.contains p = true then run d ps
    else let d' := d.add p h
         run d' (next G d' p ++ ps)
termination_by (Fintype.card (S × S) - d.entries.card, todo.length)
decreasing_by
  · apply Prod.Lex.right; simp
  · simp_wf
    have hn : p ∉ d.entries := by simpa using h
    have hs : d.entries.card < Fintype.card (S × S) :=
      lt_of_lt_of_le (Finset.card_lt_card (Finset.ssubset_insert hn))
        (Finset.card_le_univ (insert p d.entries))
    simp [Finset.card_insert_of_notMem hn]
    simp only [Fintype.card_prod] at hs
    omega

theorem run_eq (d : IndexedSet (S × S)) (todo : List (S × S)) :
    run G d todo = SaturationWorklist.run G d.entries todo := by
  fun_induction run G d todo with
  | case1 d => rw [SaturationWorklist.run]
  | case2 d p ps h ih =>
    rw [SaturationWorklist.run, if_pos ((d.contains_iff p).mp h)]
    exact ih
  | case3 d p ps h d' ih =>
    rw [SaturationWorklist.run, if_neg (by simpa using h)]
    simpa only [d', IndexedSet.add_entries, next_eq] using ih

@[noinline, nospecialize] def balanced : Finset (S × S) := run G IndexedSet.empty (SaturationWorklist.seeds G)
theorem balanced_iff (i j : S) : (i,j) ∈ balanced G ↔ G.Balanced i j := by
  rw [balanced, run_eq]
  exact SaturationWorklist.balanced_iff G i j
end Stackat.Executable.SaturationIndexed
