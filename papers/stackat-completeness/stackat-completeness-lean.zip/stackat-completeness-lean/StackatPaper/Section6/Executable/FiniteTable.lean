import StackatPaper.Section6.Executable.FiniteIndex

/-!
Section 6, verified implementation support (`FiniteTable`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable

private theorem transport_entry {I : Type*} {β : I → Type*} {i : I} (v : β i)
    (x : Σ j, β j) (h : x.1 = i) (hx : x = ⟨i,v⟩) : h ▸ x.2 = v := by
  cases hx
  rfl

structure Table (I : Type*) [FinEnum I] (β : I → Type*) where
  values : Array (Σ i, β i)
  size : values.size = FinEnum.card I
  key : ∀ (i : I), (values[(FinEnum.equiv i).val]'(by rw [size]; exact (FinEnum.equiv i).isLt)).1 = i

@[noinline, nospecialize] def Table.get {I : Type*} [FinEnum I] {β : I → Type*} (t : Table I β) (i : I) : β i :=
  t.key i ▸ (t.values[(FinEnum.equiv i).val]'(by rw [t.size]; exact (FinEnum.equiv i).isLt)).2

@[noinline, nospecialize] def Table.ofFn {I : Type*} [FinEnum I] {β : I → Type*} (f : ∀ i, β i) : Table I β where
  values := Array.ofFn fun j : Fin (FinEnum.card I) => ⟨FinEnum.equiv.symm j, f (FinEnum.equiv.symm j)⟩
  size := by simp
  key := by intro i; simp

@[simp] theorem Table.get_ofFn {I : Type*} [FinEnum I] {β : I → Type*} (f : ∀ i, β i) (i : I) :
    (Table.ofFn f).get i = f i := by
  unfold Table.get Table.ofFn
  apply transport_entry
  simp
  congr 1
  exact Equiv.symm_apply_apply FinEnum.equiv i
@[ext] theorem Table.ext {I : Type*} [FinEnum I] {β : I → Type*}
    {s t : Table I β} (h : ∀ i, s.get i = t.get i) : s = t := by
  have entry (u : Table I β) (j : Fin (FinEnum.card I)) :
      u.values[j.val]'(by rw [u.size]; exact j.isLt) =
        ⟨FinEnum.equiv.symm j, u.get (FinEnum.equiv.symm j)⟩ := by
    have pack {i : I} (x : Σ k, β k) (hx : x.1 = i) : ⟨i, hx ▸ x.2⟩ = x := by
      cases x with | mk k v => cases hx; rfl
    have hh := pack _ (u.key (FinEnum.equiv.symm j))
    change (⟨FinEnum.equiv.symm j, u.get (FinEnum.equiv.symm j)⟩ : Σ i, β i) = _ at hh
    simpa using hh.symm
  have hv : s.values = t.values := by
    apply Array.ext (s.size.trans t.size.symm)
    intro j hs ht
    have hj : j < FinEnum.card I := by simpa [s.size] using hs
    rw [entry s ⟨j,hj⟩, entry t ⟨j,hj⟩, h]
  cases s; cases t
  cases hv
  rfl

end Stackat.Executable
