import StackatPaper.Section6.Executable.DFA
import StackatPaper.Section6.Executable.Traces
import Mathlib.Data.FinEnum

/-!
Section 6, verified implementation support (`ReachableWords`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable.DFA

variable {A Q : Type} [FinEnum A] [Finite Q] [DecidableEq Q]

def labeledSuccessors (δ : Q → A → Q) (q : Q) : List (A × Q) :=
  (FinEnum.toList A).map fun a => (a, δ q a)

def wordTraces (initial : Q) (δ : Q → A → Q) : List (Q × List A) :=
  exploreTraces (labeledSuccessors δ) ∅ [(initial, [])]

theorem wordTraces_states (initial : Q) (δ : Q → A → Q) :
    ((wordTraces initial δ).map Prod.fst).toFinset = states (FinEnum.toList A) initial δ := by
  have h := exploreTraces_states (labeledSuccessors δ) ∅ [(initial, [])]
  simpa only [Finset.union_empty, wordTraces, states, reachable, labeledSuccessors,
    successors, List.map_map, Function.comp_def, List.map_cons, List.map_nil] using h

theorem wordTraces_valid (initial : Q) (δ : Q → A → Q) :
    ∀ p ∈ wordTraces initial δ, p.2.reverse.foldl δ initial = p.1 := by
  apply exploreTraces_preserves (labeledSuccessors δ)
    (fun p => p.2.reverse.foldl δ initial = p.1)
  · intro p hp q hq
    obtain ⟨⟨a, r⟩, har, rfl⟩ := List.mem_map.mp hq
    obtain ⟨b, _, hbr⟩ := List.mem_map.mp har
    cases hbr
    simpa [List.reverse_cons, List.foldl_append] using congrArg (fun s => δ s a) hp
  · intro p hp
    obtain rfl := List.mem_singleton.mp hp
    rfl

def stateList (initial : Q) (δ : Q → A → Q) : List Q :=
  (wordTraces initial δ).map Prod.fst

abbrev WordState (initial : Q) (δ : Q → A → Q) := {q // q ∈ stateList initial δ}

abbrev wordStateEnum (initial : Q) (δ : Q → A → Q) : FinEnum (WordState initial δ) :=
  FinEnum.ofList (stateList initial δ).attach (by simp)

theorem wordState_mem (initial : Q) (δ : Q → A → Q) (q : Q) :
    q ∈ stateList initial δ ↔ ∃ w : List A, w.foldl δ initial = q := by
  rw [← List.mem_toFinset, stateList, wordTraces_states]
  exact mem_states _ (FinEnum.mem_toList) initial δ q

def representative (initial : Q) (δ : Q → A → Q) (q : WordState initial δ) : List A :=
  (List.choose (fun p : Q × List A => p.1 = q.val) (wordTraces initial δ)
    (List.mem_map.mp q.property)).2.reverse

theorem representative_run (initial : Q) (δ : Q → A → Q) (q : WordState initial δ) :
    (representative initial δ q).foldl δ initial = q.val := by
  unfold representative
  obtain ⟨hm, he⟩ := List.choose_spec (fun p : Q × List A => p.1 = q.val)
    (wordTraces initial δ) (List.mem_map.mp q.property)
  exact (wordTraces_valid initial δ _ hm).trans he

def wordStart (initial : Q) (δ : Q → A → Q) : WordState initial δ :=
  ⟨initial, (wordState_mem initial δ initial).mpr ⟨[], rfl⟩⟩

def wordStep {initial : Q} {δ : Q → A → Q} (q : WordState initial δ) (a : A) :
    WordState initial δ :=
  ⟨δ q.val a, (wordState_mem initial δ _).mpr
    ⟨representative initial δ q ++ [a], by simp [List.foldl_append, representative_run]⟩⟩

theorem wordFold_val {initial : Q} {δ : Q → A → Q} (w : List A) (q : WordState initial δ) :
    (w.foldl wordStep q).val = w.foldl δ q.val := by
  induction w generalizing q with
  | nil => rfl
  | cons a w ih => exact ih (wordStep q a)

def wordAutomaton (initial : Q) (δ : Q → A → Q) :
    DFA A (WordState initial δ) where
  initial := wordStart initial δ
  step := fun q a => wordStep q a
  reachable := fun q => ⟨representative initial δ q,
    Subtype.ext ((wordFold_val _ (wordStart initial δ)).trans (representative_run initial δ q))⟩

@[simp] theorem wordRun_val (initial : Q) (δ : Q → A → Q) (w : List A) :
    ((wordAutomaton initial δ).h w).val = w.foldl δ initial :=
  wordFold_val w (wordStart initial δ)

theorem representative_ok (initial : Q) (δ : Q → A → Q) (q : WordState initial δ) :
    (wordAutomaton initial δ).h (representative initial δ q) = q :=
  Subtype.ext ((wordRun_val initial δ _).trans (representative_run initial δ q))

end Stackat.Executable.DFA
