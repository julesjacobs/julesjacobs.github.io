import StackatPaper.Section6.Executable.Reachability

/-!
Section 6, verified implementation support (`Traces`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable

variable {Q L W : Type} [Finite Q] [DecidableEq Q]

/-- Paths are reversed so that newly discovered paths share their existing suffix. -/
def traceChildren (next : Q → List (L × Q)) (p : Q × List L) : List (Q × List L) :=
  (next p.1).map fun (a, q) => (q, a :: p.2)

def exploreWith [Finite Q] (next : Q × W → List (Q × W))
    (seen : Finset Q) (todo : List (Q × W)) : List (Q × W) :=
  match todo with
  | [] => []
  | p :: ps =>
    if p.1 ∈ seen then exploreWith next seen ps
    else p :: exploreWith next (insert p.1 seen) (next p ++ ps)
termination_by (@Fintype.card Q (Fintype.ofFinite Q) - seen.card, todo.length)
decreasing_by
  · apply Prod.Lex.right
    simp
  · letI : Fintype Q := Fintype.ofFinite Q
    simp_wf
    have hs : seen.card < Fintype.card Q :=
      lt_of_lt_of_le (Finset.card_lt_card (Finset.ssubset_insert ‹p.1 ∉ seen›))
        (Finset.card_le_univ (insert p.1 seen))
    simp [Finset.card_insert_of_notMem ‹p.1 ∉ seen›]
    omega

theorem exploreWith_preserves (next : Q × W → List (Q × W)) (P : Q × W → Prop)
    (closed : ∀ p, P p → ∀ q ∈ next p, P q)
    (seen : Finset Q) (todo : List (Q × W))
    (ht : ∀ p ∈ todo, P p) : ∀ p ∈ exploreWith next seen todo, P p := by
  fun_induction exploreWith next seen todo with
  | case1 => simp
  | case2 seen p ps hp ih =>
    exact ih (fun q hq => ht q (List.mem_cons_of_mem p hq))
  | case3 seen p ps hp ih =>
    intro q hq
    rcases List.mem_cons.mp hq with rfl | hq
    · exact ht _ (by simp)
    · apply ih _ q hq
      intro r hr
      rcases List.mem_append.mp hr with hr | hr
      · exact closed p (ht p (by simp)) r hr
      · exact ht r (List.mem_cons_of_mem p hr)

theorem exploreWith_states (next : Q × W → List (Q × W))
    (edges : Q → List Q) (hnext : ∀ p, (next p).map Prod.fst = edges p.1)
    (seen : Finset Q) (todo : List (Q × W)) :
    ((exploreWith next seen todo).map Prod.fst).toFinset ∪ seen =
      explore edges seen (todo.map Prod.fst) := by
  fun_induction exploreWith next seen todo with
  | case1 => simp [explore]
  | case2 seen p ps hp ih =>
    simpa [explore, hp] using ih
  | case3 seen p ps hp ih =>
    simp only [List.map_append, hnext] at ih
    simp only [List.map_cons, List.toFinset_cons, explore, hp, ↓reduceIte]
    rw [← ih]
    ext q
    simp only [Finset.mem_insert, Finset.mem_union]
    tauto

abbrev exploreTraces (next : Q → List (L × Q)) := exploreWith (traceChildren next)

theorem exploreTraces_preserves (next : Q → List (L × Q)) (P : Q × List L → Prop)
    (closed : ∀ p, P p → ∀ q ∈ traceChildren next p, P q)
    (seen : Finset Q) (todo : List (Q × List L))
    (ht : ∀ p ∈ todo, P p) : ∀ p ∈ exploreTraces next seen todo, P p :=
  exploreWith_preserves _ P closed seen todo ht

theorem exploreTraces_states (next : Q → List (L × Q))
    (seen : Finset Q) (todo : List (Q × List L)) :
    ((exploreTraces next seen todo).map Prod.fst).toFinset ∪ seen =
      explore (fun q => (next q).map Prod.snd) seen (todo.map Prod.fst) :=
  exploreWith_states _ _ (fun _ => by simp [traceChildren, List.map_map, Function.comp_def]) seen todo

end Stackat.Executable
