import StackatPaper.Spec

/-!
Section 6, verified implementation support (`DecisionData`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Decision

/-- Pairs of state indices in the canonical reachable automaton. -/
abbrev CellCertificate := List (Nat × Nat)

inductive Answer (Cfg : Type) (Cert : Type) where
  | included (certificate : Cert)
  | counterexample (input output : Cfg)

def Correct (R S : Cfg → Cfg → Prop) : Answer Cfg Cert → Prop
  | .included _ => ∀ s t, R s t → S s t
  | .counterexample s t => R s t ∧ ¬ S s t

inductive EquivalenceAnswer (Cfg Cert : Type) where
  | equivalent (forward backward : Cert)
  | different (forward : Bool) (input output : Cfg)

end Stackat.Decision
