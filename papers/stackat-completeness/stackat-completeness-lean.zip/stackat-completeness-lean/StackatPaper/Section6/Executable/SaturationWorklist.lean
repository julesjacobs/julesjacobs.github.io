import StackatPaper.Section6.Executable.ExpressionGraph
import Mathlib.Data.FinEnum

/-!
Section 6, verified implementation support (`SaturationWorklist`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable.SaturationWorklist
variable {A S : Type} [FinEnum A] [FinEnum S]
variable (G : StackGraph A S) [GraphDecisions G]

def seeds : List (S × S) :=
  (FinEnum.toList (S × S)).filter fun (i,j) => i = j ∨ G.eps i j

def next (d : Finset (S × S)) (p : S × S) : List (S × S) :=
  ((FinEnum.toList S).filter fun i => (i,p.1) ∈ d).map (fun i => (i,p.2)) ++
  ((FinEnum.toList S).filter fun j => (p.2,j) ∈ d).map (fun j => (p.1,j)) ++
  (FinEnum.toList A).flatMap fun a =>
    let left := (FinEnum.toList S).filter fun i => G.push a i p.1
    let right := (FinEnum.toList S).filter fun j => G.pop a p.2 j
    left.flatMap fun i => right.map fun j => (i,j)

@[simp] theorem mem_next (d : Finset (S × S)) (p q : S × S) : q ∈ next G d p ↔
    ((q.1,p.1) ∈ d ∧ q.2 = p.2) ∨ ((p.2,q.2) ∈ d ∧ q.1 = p.1) ∨
      ∃ a, G.push a q.1 p.1 ∧ G.pop a p.2 q.2 := by
  simp [next, Prod.ext_iff, and_comm, and_assoc, eq_comm]

def run (seen : Finset (S × S)) (todo : List (S × S)) : Finset (S × S) :=
  match todo with
  | [] => seen
  | p :: ps => if p ∈ seen then run seen ps
    else run (insert p seen) (next G (insert p seen) p ++ ps)
termination_by (Fintype.card (S × S) - seen.card, todo.length)
decreasing_by
  · apply Prod.Lex.right; simp
  · simp_wf
    have hs : seen.card < Fintype.card (S × S) :=
      lt_of_lt_of_le (Finset.card_lt_card (Finset.ssubset_insert ‹p ∉ seen›))
        (Finset.card_le_univ (insert p seen))
    simp [Finset.card_insert_of_notMem ‹p ∉ seen›]
    simp only [Fintype.card_prod] at hs
    omega

def Pending (d : Finset (S × S)) (todo : List (S × S)) (i j : S) : Prop :=
  (i,j) ∈ d ∨ (i,j) ∈ todo

structure Invariant (d : Finset (S × S)) (todo : List (S × S)) : Prop where
  base : ∀ i j, i = j ∨ G.eps i j → Pending d todo i j
  trans : ∀ i j k, (i,j) ∈ d → (j,k) ∈ d → Pending d todo i k
  wrap : ∀ a i j k l, G.push a i j → (j,k) ∈ d → G.pop a k l → Pending d todo i l

theorem run_sound (d : Finset (S × S)) (todo : List (S × S))
    (hd : ∀ p ∈ d, G.Balanced p.1 p.2) (ht : ∀ p ∈ todo, G.Balanced p.1 p.2) :
    ∀ p ∈ run G d todo, G.Balanced p.1 p.2 := by
  fun_induction run G d todo with
  | case1 d => exact hd
  | case2 d p ps hp ih => exact ih hd (fun q hq => ht q (by simp [hq]))
  | case3 d p ps hp ih =>
    have hd' : ∀ q ∈ insert p d, G.Balanced q.1 q.2 := by
      intro q hq
      rcases Finset.mem_insert.mp hq with he | hq
      · simpa only [he] using ht p (by simp)
      · exact hd q hq
    apply ih hd'
    intro q hq
    rcases List.mem_append.mp hq with hq | hq
    · rcases (mem_next G _ p q).mp hq with ⟨hh,he⟩ | ⟨hh,he⟩ | ⟨a,hh,hk⟩
      · simpa only [he] using StackGraph.Balanced.trans (hd' (q.1,p.1) hh) (ht p (by simp))
      · simpa only [he] using StackGraph.Balanced.trans (ht p (by simp)) (hd' (p.2,q.2) hh)
      · exact .matchPair hh (ht p (by simp)) hk
    · exact ht q (by simp [hq])

theorem run_closed (d : Finset (S × S)) (todo : List (S × S)) (h : Invariant G d todo) :
    Invariant G (run G d todo) [] := by
  fun_induction run G d todo with
  | case1 d => exact h
  | case2 d p ps hp ih =>
    have lift : ∀ i j, Pending d (p::ps) i j → Pending d ps i j := by
      intro i j hh
      rcases hh with hh | hh
      · exact Or.inl hh
      · rcases List.mem_cons.mp hh with he | hh
        · exact Or.inl (he ▸ hp)
        · exact Or.inr hh
    exact ih ⟨fun i j hh => lift i j (h.base i j hh),
      fun i j k hi hj => lift i k (h.trans i j k hi hj),
      fun a i j k l hi hj hk => lift i l (h.wrap a i j k l hi hj hk)⟩
  | case3 d p ps hp ih =>
    have lift : ∀ i j, Pending d (p::ps) i j →
        Pending (insert p d) (next G (insert p d) p ++ ps) i j := by
      intro i j hh
      rcases hh with hh | hh
      · exact Or.inl (Finset.mem_insert_of_mem hh)
      · rcases List.mem_cons.mp hh with he | hh
        · exact Or.inl (Finset.mem_insert.mpr (Or.inl he))
        · exact Or.inr (List.mem_append_right _ hh)
    apply ih
    refine ⟨fun i j hh => lift i j (h.base i j hh), ?_, ?_⟩
    · intro i j k hi hj
      rcases Finset.mem_insert.mp hi with he | hi
      · apply Or.inr
        apply List.mem_append_left
        apply (mem_next G _ p (i,k)).mpr
        exact Or.inr (Or.inl ⟨by simpa [← he] using hj, by simp [← he]⟩)
      · rcases Finset.mem_insert.mp hj with he | hj
        · apply Or.inr
          apply List.mem_append_left
          apply (mem_next G _ p (i,k)).mpr
          exact Or.inl ⟨by simpa [← he] using (show (i,j) ∈ insert p d from Finset.mem_insert.mpr (Or.inr hi)), by simp [← he]⟩
        · exact lift i k (h.trans i j k hi hj)
    · intro a i j k l hi hj hk
      rcases Finset.mem_insert.mp hj with he | hj
      · apply Or.inr
        apply List.mem_append_left
        apply (mem_next G _ p (i,l)).mpr
        exact Or.inr (Or.inr ⟨a, by simpa [← he] using hi, by simpa [← he] using hk⟩)
      · exact lift i l (h.wrap a i j k l hi hj hk)

def balanced : Finset (S × S) := run G ∅ (seeds G)

theorem balanced_iff (i j : S) : (i,j) ∈ balanced G ↔ G.Balanced i j := by
  constructor
  · apply run_sound G ∅ (seeds G) (by simp)
    intro p hp
    have hh : p.1 = p.2 ∨ G.eps p.1 p.2 := by simpa [seeds] using hp
    rcases hh with hh | hh
    · rw [hh]; exact .refl _
    · exact .eps hh
  · intro hh
    have hc := run_closed G ∅ (seeds G) {
      base := by intro i j h; exact Or.inr (by simpa [seeds] using h)
      trans := by simp
      wrap := by simp }
    have base := hc.base
    have trans := hc.trans
    have wrap := hc.wrap
    simp only [Pending, List.not_mem_nil, or_false] at base trans wrap
    induction hh with
    | refl i => exact base i i (Or.inl rfl)
    | eps h => exact base _ _ (Or.inr h)
    | trans _ _ hi hj => exact trans _ _ _ hi hj
    | matchPair hi _ hk ih => exact wrap _ _ _ _ _ hi ih hk
end Stackat.Executable.SaturationWorklist
