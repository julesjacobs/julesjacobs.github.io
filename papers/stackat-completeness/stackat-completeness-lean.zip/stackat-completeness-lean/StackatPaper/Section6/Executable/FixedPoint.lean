import StackatPaper.Section6.Executable.Reachability

/-!
Section 6, verified implementation support (`FixedPoint`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable

variable {Q : Type} [Fintype Q] [DecidableEq Q]

/-- Iterate an inflationary operation until no new fact is produced. -/
def fixedPoint [Fintype Q] (step : Finset Q → Finset Q)
    (grows : ∀ s, s ⊆ step s) (s : Finset Q) : Finset Q :=
  if step s = s then s else fixedPoint step grows (step s)
termination_by Fintype.card Q - s.card
decreasing_by
  have hlt : s.card < (step s).card :=
    Finset.card_lt_card (lt_of_le_of_ne (grows s) (Ne.symm ‹step s ≠ s›))
  have hle := Finset.card_le_univ (step s)
  omega

theorem fixedPoint_closed (step : Finset Q → Finset Q)
    (grows : ∀ s, s ⊆ step s) (s : Finset Q) :
    step (fixedPoint step grows s) = fixedPoint step grows s := by
  fun_induction fixedPoint step grows s with
  | case1 s h => exact h
  | case2 s h ih => exact ih

theorem fixedPoint_preserves (step : Finset Q → Finset Q)
    (grows : ∀ s, s ⊆ step s) (P : Q → Prop)
    (stable : ∀ s, (∀ x ∈ s, P x) → ∀ x ∈ step s, P x)
    (s : Finset Q) (hs : ∀ x ∈ s, P x) :
    ∀ x ∈ fixedPoint step grows s, P x := by
  fun_induction fixedPoint step grows s with
  | case1 s h => exact hs
  | case2 s h ih => exact ih (stable s hs)

end Stackat.Executable
