import StackatPaper.Section3.TargetTable

/-!
Section 6, verified implementation support (`Membership`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable
variable {A S : Type} [DecidableEq A]
variable (M : DFA A S) (F : S → S → Bool)

def coverReverse : List A → List A → Bool
  | [], v => F (M.h []) (M.h v.reverse)
  | u, [] => F (M.h u.reverse) (M.h [])
  | a :: u, b :: v => F (M.h (a :: u).reverse) (M.h (b :: v).reverse) ||
      (a == b && coverReverse u v)

theorem coverReverse_correct (u v : List A) : coverReverse M F u v = true ↔
    Accepted M (fun i j => F i j = true) u.reverse v.reverse := by
  induction u generalizing v with
  | nil => simp [coverReverse, accepted_nil_left]
  | cons a u ih =>
    cases v with
    | nil => simp [coverReverse, accepted_nil_right]
    | cons b v =>
      simp only [coverReverse, Bool.or_eq_true, Bool.and_eq_true, beq_iff_eq, ih,
        List.reverse_cons, accepted_append_iff, DFA.h_append_singleton]

def member (u v : List A) : Bool := coverReverse M F u.reverse v.reverse

theorem member_correct (u v : List A) : member M F u v = true ↔
    Accepted M (fun i j => F i j = true) u v := by
  simpa [member] using coverReverse_correct M F u.reverse v.reverse
end Stackat.Executable
