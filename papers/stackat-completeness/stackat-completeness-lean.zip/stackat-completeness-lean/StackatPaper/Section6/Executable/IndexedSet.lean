import StackatPaper.Section6.Executable.FiniteIndex
import Mathlib.Data.Vector.Basic

/-!
Section 6, verified implementation support (`IndexedSet`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable
structure IndexedSet (Q : Type) [FinEnum Q] where
  entries : Finset Q
  bits : Vector Bool (FinEnum.card Q)
  correct : ∀ q, bits[(FinEnum.equiv q).val] = true ↔ q ∈ entries

namespace IndexedSet
variable {Q : Type} [FinEnum Q]
def contains (s : IndexedSet Q) (q : Q) : Bool := s.bits[(FinEnum.equiv q).val]
@[simp] theorem contains_iff (s : IndexedSet Q) (q : Q) : s.contains q = true ↔ q ∈ s.entries := s.correct q

def ofFinset (d : Finset Q) : IndexedSet Q where
  entries := d
  bits := Vector.ofFn fun i => decide (FinEnum.equiv.symm i ∈ d)
  correct := by intro q; simp

def empty : IndexedSet Q where
  entries := ∅
  bits := Vector.replicate _ false
  correct := by intro q; simp

def add (s : IndexedSet Q) (q : Q) (h : s.contains q ≠ true) : IndexedSet Q where
  entries := Finset.cons q s.entries (by simpa using h)
  bits := s.bits.set (FinEnum.equiv q).val true
  correct := by
    intro r
    by_cases hr : q = r
    · subst r; simp
    · have hn : (FinEnum.equiv q).val ≠ (FinEnum.equiv r).val := by
        intro hh; exact hr (FinEnum.equiv.injective (Fin.ext hh))
      simp [hn, s.correct, Ne.symm hr]
@[simp] theorem add_entries (s : IndexedSet Q) (q : Q) (h : s.contains q ≠ true) :
    (s.add q h).entries = insert q s.entries := Finset.cons_eq_insert _ _ (by simpa using h)
end IndexedSet
end Stackat.Executable
