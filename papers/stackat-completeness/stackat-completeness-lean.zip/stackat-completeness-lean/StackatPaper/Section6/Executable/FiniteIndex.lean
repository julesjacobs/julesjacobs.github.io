import Mathlib.Data.FinEnum
import Mathlib.Logic.Equiv.Fin.Basic

/-!
Section 6, verified implementation support (`FiniteIndex`): used by the executable decision
procedures; no paper claim is stated here.
-/

namespace Stackat.Executable
instance (priority := 1100) finIndex (n : Nat) : FinEnum (Fin n) where
  card := n
  equiv := Equiv.refl _
  decEq := inferInstance

instance (priority := 1100) prodIndex {S T : Type} [FinEnum S] [FinEnum T] : FinEnum (S × T) where
  card := FinEnum.card S * FinEnum.card T
  equiv := (Equiv.prodCongr FinEnum.equiv FinEnum.equiv).trans finProdFinEquiv
  decEq := inferInstance

instance (priority := 1100) sumIndex {S T : Type} [FinEnum S] [FinEnum T] : FinEnum (S ⊕ T) where
  card := FinEnum.card S + FinEnum.card T
  equiv := (Equiv.sumCongr FinEnum.equiv FinEnum.equiv).trans finSumFinEquiv
  decEq := inferInstance
end Stackat.Executable
