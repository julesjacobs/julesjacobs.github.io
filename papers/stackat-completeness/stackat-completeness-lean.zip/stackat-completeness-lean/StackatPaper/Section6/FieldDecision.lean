import StackatPaper.Section6.Results
import StackatPaper.Section6.Executable.FieldDecisionData
import StackatPaper.Section5.Completeness
import StackatPaper.Section5.Soundness
import StackatPaper.Section6.Executable.FieldCompile
import StackatPaper.Section6.Executable.AutomatonDecision
import Mathlib.Data.FinEnum

/-!
Section 6: the executable decision procedure with header fields: inclusion and equivalence, each
answer carrying a derivation or a verified counterexample (`Fields.Executable.decide_inclusion`,
`Fields.Executable.decide_equivalence`), and the certificate checker
(`Fields.Executable.checkAnswer_correct`).
-/

namespace Stackat.Fields.Executable
open Stackat.Executable
variable {A : Type} {n : Nat} {V : Fin n → Type}
variable [FinEnum A] [∀ i, FinEnum (V i)]

def family (e f : Expr A V) (h k : Header V) : Bool → StackAutomaton A
  | false => automaton e h k
  | true => automaton f h k
instance (e f : Expr A V) (h k : Header V) : ∀ i, GraphDecisions (family e f h k i).graph
  | false => inferInstanceAs (GraphDecisions (automaton e h k).graph)
  | true => inferInstanceAs (GraphDecisions (automaton f h k).graph)

instance (e f : Expr A V) (h k : Header V) : ∀ i, FinEnum (family e f h k i).State
  | false => inferInstanceAs (FinEnum (automaton e h k).State)
  | true => inferInstanceAs (FinEnum (automaton f h k).State)

def endpointCounterexample (e f : Expr A V) (h k : Header V) : Option (List A × List A) :=
  AutomatonDecision.counterexample (family e f h k)

theorem endpoint_sound (e f : Expr A V) (h k : Header V) {s t : List A}
    (hc : endpointCounterexample e f h k = some (s,t)) :
    e.denote (h,s) (k,t) ∧ ¬ f.denote (h,s) (k,t) := by
  have hh := AutomatonDecision.counterexample_sound (family e f h k) hc
  exact ⟨(eval_correct e h k s t).mp hh.1, fun hf => hh.2 ((eval_correct f h k s t).mpr hf)⟩

theorem endpoint_none_iff (e f : Expr A V) (h k : Header V) :
    endpointCounterexample e f h k = none ↔
      ∀ s t, e.denote (h,s) (k,t) → f.denote (h,s) (k,t) := by
  have hh := AutomatonDecision.counterexample_none_iff (family e f h k)
  simpa only [family, eval_correct] using hh

def counterexample (e f : Expr A V) : Option ((Header V × List A) × (Header V × List A)) :=
  (FinEnum.toList (Header V × Header V)).findSome? fun (h,k) =>
    (endpointCounterexample e f h k).map fun (s,t) => ((h,s),(k,t))

theorem counterexample_sound (e f : Expr A V) {s t : Header V × List A}
    (hc : counterexample e f = some (s,t)) : e.denote s t ∧ ¬ f.denote s t := by
  obtain ⟨⟨h,k⟩, _, hc⟩ := List.exists_of_findSome?_eq_some hc
  obtain ⟨⟨u,v⟩, he, hp⟩ := Option.map_eq_some_iff.mp hc
  cases hp
  exact endpoint_sound e f h k he

theorem counterexample_none_iff (e f : Expr A V) :
    counterexample e f = none ↔ ∀ s t, e.denote s t → f.denote s t := by
  simp only [counterexample, List.findSome?_eq_none_iff, Option.map_eq_none_iff]
  constructor
  · intro h ⟨hi,s⟩ ⟨ho,t⟩ hs
    exact (endpoint_none_iff e f hi ho).mp (h (hi,ho) (FinEnum.mem_toList _)) s t hs
  · intro h ⟨hi,ho⟩ _
    exact (endpoint_none_iff e f hi ho).mpr fun s t => h (hi,s) (ho,t)

def certificate (e f : Expr A V) : Decision.InclusionCertificate V :=
  (FinEnum.toList (Header V × Header V)).map fun (h,k) =>
    ((h,k), AutomatonDecision.certificate (family e f h k))

def checkCertificate (e f : Expr A V) (c : Decision.InclusionCertificate V) : Bool :=
  (FinEnum.toList (Header V × Header V)).all fun (h,k) =>
    c.any fun entry => decide (entry.1 = (h,k)) &&
      AutomatonDecision.checkCertificate (family e f h k) entry.2

theorem checkCertificate_sound (e f : Expr A V) (c : Decision.InclusionCertificate V)
    (hc : checkCertificate e f c = true) : ∀ s t, e.denote s t → f.denote s t := by
  simp only [checkCertificate, List.all_eq_true, FinEnum.mem_toList, true_implies,
    List.any_eq_true, Bool.and_eq_true, decide_eq_true_eq] at hc
  intro ⟨h,s⟩ ⟨k,t⟩ he
  obtain ⟨entry, _, _, hc⟩ := hc (h,k)
  have hh := AutomatonDecision.checkCertificate_sound (family e f h k) entry.2 hc
  exact (eval_correct f h k s t).mp (hh s t ((eval_correct e h k s t).mpr he))

@[irreducible] def decideRaw (e f : Expr A V) : Decision.Answer (A := A) V :=
  match counterexample e f with
  | some (s,t) => .counterexample s t
  | none => .included (certificate e f)

def decide_inclusion (e f : Expr A V) : Decision.InclusionResult e f :=
  match h : counterexample e f with
  | some (s,t) => .counterexample s t (counterexample_sound e f h)
  | none => .included (finite_header_inequational_completeness A n V e f
      ((counterexample_none_iff e f).mp h))

def member (e : Expr A V) (s t : Header V × List A) : Bool :=
  AutomatonDecision.member (family e e s.1 t.1) false s.2 t.2

theorem member_correct (e : Expr A V) (s t : Header V × List A) :
    member e s t = true ↔ e.denote s t :=
  (AutomatonDecision.member_correct (family e e s.1 t.1) false s.2 t.2).trans
    (eval_correct e s.1 t.1 s.2 t.2)

def checkAnswer (e f : Expr A V) : Decision.Answer (A := A) V → Bool
  | .included c => checkCertificate e f c
  | .counterexample s t => member e s t && !member f s t

theorem checkAnswer_correct (e f : Expr A V) (answer : Decision.Answer (A := A) V)
    (h : checkAnswer e f answer = true) : Decision.Correct e f answer := by
  cases answer with
  | included c => exact checkCertificate_sound e f c h
  | counterexample s t =>
    simpa only [checkAnswer, Bool.and_eq_true, Bool.not_eq_true', Bool.eq_false_iff,
      ne_eq, member_correct, Decision.Correct, Stackat.Decision.Correct] using h

@[irreducible] def decideEquivalenceRaw (e f : Expr A V) :
    Stackat.Decision.EquivalenceAnswer (Header V × List A) (Decision.InclusionCertificate V) :=
  match decideRaw e f with
  | .counterexample s t => .different true s t
  | .included c => match decideRaw f e with
    | .counterexample s t => .different false s t
    | .included d => .equivalent c d

def decide_equivalence (e f : Expr A V) : Decision.EquivalenceResult e f :=
  match decide_inclusion e f with
  | .counterexample s t h => .different s t (Or.inl h)
  | .included h => match decide_inclusion f e with
    | .counterexample s t k => .different s t (Or.inr k)
    | .included k => .equivalent (finite_header_completeness A n V e f (le_antisymm
        (fun s t he => (Fields.finite_header_soundness_iff h s t).mp (Or.inl he))
        (fun s t hf => (Fields.finite_header_soundness_iff k s t).mp (Or.inl hf))))

end Stackat.Fields.Executable
