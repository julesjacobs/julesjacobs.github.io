import StackatPaper
import Lean
open Lean
elab "#locations" : command => Elab.Command.liftTermElabM do
  let env ← getEnv
  let roots ← IO.FS.lines "checks/roots.txt"
  let mut out := ""
  for r in roots do
    if r == "" then continue
    let n := r.toName
    match env.getModuleIdxFor? n with
    | some idx => out := out ++ s!"{r}\t{env.header.moduleNames[idx.toNat]!}\n"
    | none => out := out ++ s!"{r}\t?\n"
  IO.FS.writeFile "checks/locations.txt" out
#locations
