# The paper's Lean map ("Where Each Result Is Mechanized"), in its order: first the definition
# entries of its Definitions part, then the entries of its Results part.
# CLAIMS: key, paper item, the headline declaration (two only for a pair of definitions), and the
# earlier names of the declarations. DEFINITIONS: the unmarked definitions of the Definitions part,
# in its order. The roots of the development are the headlines and the definitions.
S = 'Stackat.'
CLAIMS = [
 ('dexpr', '§2 syntax of expressions', ['Stackat.Expr'], ['Stackat.Expr']),
 ('ddenote', '§2 relational semantics R_e', ['Stackat.R'], ['Stackat.Expr.denote']),
 ('dderives', '§2 eq. (1), the derivation system ⊢', ['Stackat.Derives'], ['Stackat.Derives']),
 ('dphi', '§3.2 the program Φ(D) of a table', ['Stackat.Φ'], ['Stackat.normalForm']),
 ('dgood', '§3.3 eq. (4), good cells', ['Stackat.Good'], ['Stackat.Certificate.Good']),
 ('dmatrix', '§4 the matrices X and Y', ['Stackat.popMatrix', 'Stackat.pushMatrix'], ['Stackat.MatrixCertificate.popMatrix', 'Stackat.MatrixCertificate.pushMatrix']),
 ('matka', '§4 square matrices over a KA form a KA', ['Stackat.MatrixStar.matrixKleeneAlgebra'], ['Stackat.MatrixStar.instKleeneAlgebraMatrix_stackat', 'Stackat.MatrixStar.matrixStar']),
 ('dfields', '§5 eq. (11), expressions with fields and the field laws', ['Stackat.Fields.Derives'], ['Stackat.Fields.Derives']),
 ('dmat', 'App. B the matrix interpretation M_e', ['Stackat.Fields.Headers.matrices'], ['Stackat.Fields.Headers.matrices']),
 ('dsat', 'App. A the balanced closure B', ['Stackat.StackGraph.saturation'], ['Stackat.StackGraph.saturation']),
 ('dhat', 'App. A the matrices P̂ and Q̂', ['Stackat.StackGraph.saturatedPush', 'Stackat.StackGraph.saturatedPop'], ['Stackat.StackGraph.saturatedPush', 'Stackat.StackGraph.saturatedPop']),
 ('seeds', 'App. D.1 the initial marking', ['Stackat.InitiallyMarked'], ['Stackat.Executable.BadCells.mem_seeds']),
 ('dbad', 'App. D.1 eq. (18), the marking rule', ['Stackat.Marked'], ['Stackat.Executable.BadCells.propagate']),
 ('support', 'App. D.2 the least set C_min', ['Stackat.CMin'], ['Stackat.Executable.SourceDirected.support_source', 'Stackat.Executable.SourceDirected.support_closed', 'Stackat.Executable.SourceDirected.support_minimal']),
 ('lbaut', 'App. D.3 the automaton of the quadratic family', ['Stackat.LowerBound.step'], ['Stackat.Cyclic.LowerBound.step', 'Stackat.Cyclic.LowerBound.aut']),
 ('lbtab', 'App. D.3 the tables E and S² ∖ F of the family', ['Stackat.LowerBound.E', 'Stackat.LowerBound.Outside'], ['Stackat.Cyclic.LowerBound.E', 'Stackat.Cyclic.LowerBound.Outside', 'Stackat.Cyclic.LowerBound.F']),
 ('relpq', '§2 p_a q_a restores every stack, q_a p_a those beginning with a', ['Stackat.push_pop_and_pop_push_R'], ['Stackat.push_pop_denote', 'Stackat.pop_push_denote']),
 ('relqp', '§2 q_a p_b replaces a by b', ['Stackat.pop_push_ne_R'], ['Stackat.pop_push_ne_R']),
 ('thm', 'Theorem 1 (soundness and completeness)', ['Stackat.soundness_and_completeness_any_alphabet'], ['Stackat.inequationalCompleteness', 'Stackat.completeness', 'Stackat.derives_sound']),
 ('indep', 'Proposition 10 (independence of the stack laws)', ['Stackat.Independence.scheme_independence'], ['Stackat.Axioms.incomplete_without_push_pop', 'Stackat.Axioms.incomplete_without_pop_push', 'Stackat.Axioms.incomplete_without_push_pop_ne']),
 ('thmspec', 'App. E Theorem 1 as stated in Spec.lean', ['Stackat.soundness_and_completeness_spec'], ['Stackat.inequationalCompleteness', 'Stackat.completeness', 'Stackat.derives_sound']),
 ('equiv', 'App. E the two completeness formulations are equivalent', ['Stackat.completeness_iff_inequational'], ['Stackat.Example.Leftovers.completeness_iff_inequational']),
 ('qp', '§3.1 q(u)p(v) relates uw to vw', ['Stackat.qp_R'], ['Stackat.qWord_pWord_denote', 'Stackat.qWord', 'Stackat.pWord']),
 ('nf', 'Lemma 2 (pop–push normal form)', ['Stackat.pop_push_normal_form'], ['Stackat.StackGraph.factorization']),
 ('wordle', '§3.1 q(xw)p(yw) = q(x)q(w)p(w)p(y) ≤ q(x)p(y)', ['Stackat.qp_append_eq_le'], ['Stackat.qWord_pWord_append', 'Stackat.qWord_pWord_append_le']),
 ('wordone', '§3.1 q(w)p(w) ≤ 1', ['Stackat.qp_le_one'], ['Stackat.qWord_pWord_le_one']),
 ('dfa', '§3.2 one complete reachable DFA for all pop and push languages', ['Stackat.SharedDFA.representation'], ['Stackat.SharedNormalForm.dfa', 'Stackat.SharedNormalForm.accepts', 'Stackat.Certificate.Automaton', 'Stackat.Certificate.Automaton.run']),
 ('dfah', '§3.2 h(ua) = δ(h(u),a) and nonempty sets L_i', ['Stackat.DFA.h_append_singleton_and_L_nonempty'], ['Stackat.SharedNormalForm.dfa', 'Stackat.SharedNormalForm.accepts', 'Stackat.Certificate.Automaton', 'Stackat.Certificate.Automaton.run']),
 ('tables', '§3.2 eq. (2), e = Φ(E), f = Φ(F)', ['Stackat.shared_normal_forms'], ['Stackat.commonNormalForm', 'Stackat.CommonNormalForm']),
 ('sem', '§3.2 eq. (3), R_Φ(D) = 𝓡_D', ['Stackat.table_semantics'], ['Stackat.normalForm_semantics', 'Stackat.Certificate.Covers']),
 ('exqp', '§3.1 example: QP² ≤ q_a p_a p_b p_a ≤ P', ['Stackat.Example.QP2_le_mid_le_P'], ['Stackat.Example.QP2_le_mid', 'Stackat.Example.mid_le_P', 'Stackat.Example.QP2_le_P']),
 ('excut', '§3.1 example: the three cuts of (abw, ababw)', ['Stackat.Example.cut_table'], ['Stackat.Example.cut_table']),
 ('exnorm', '§3.1 example: QPQP² = Q(PQ)P² = QP², PQ = 1', ['Stackat.Example.QPQP2_normalization'], ['Stackat.Example.QPQP2_eq', 'Stackat.Example.PQ_eq_one']),
 ('expow', '§3.1 example: Q^m P^n sends (ab)^m w to (ab)^n w', ['Stackat.Example.QmPn_R'], ['Stackat.Example.QmPn_R']),
 ('exsub', '§3.1 example: on (ab)^m w, Q^{m-n} (m ≥ n) and P^{n-m} (n ≥ m) have the output of Q^m P^n', ['Stackat.Example.Qsub_Psub_R'], ['Stackat.Example.Qsub_denote', 'Stackat.Example.Psub_denote']),
 ('exqpden', '§3.1 example: QP restores only stacks beginning with ab, 1 every stack', ['Stackat.Example.QP_and_one_R'], ['Stackat.Example.QP_denote']),
 ('exeq', '§3.1 example: R_e = R_f', ['Stackat.Example.R_e_eq_R_f'], ['Stackat.Example.e_denote_iff_f']),
 ('good', '§3.3 F ≤ G, and 𝓡_E ⊆ 𝓡_F iff E ≤ G', ['Stackat.target_and_source_le_good'], ['Stackat.Certificate.direct_good', 'Stackat.Certificate.inclusion_good', 'Stackat.Certificate.Residual']),
 ('suffix', '§3.3 Lemma 3, eq. (5), the suffix alternative', ['Stackat.suffix_alternative'], ['Stackat.Executable.covers_append_iff', 'Stackat.Executable.covers_nil_left', 'Stackat.Executable.covers_nil_right']),
 ('bnd', '§3.3 empty-prefix boundaries', ['Stackat.residual_boundaries'], ['Stackat.Certificate.boundary_left', 'Stackat.Certificate.boundary_right']),
 ('mis', '§3.3 mismatched final symbols', ['Stackat.residual_mismatch'], ['Stackat.Certificate.mismatched']),
 ('mat', '§3.3 fact 3: good iff all predecessors good', ['Stackat.good_iff_predecessors_good'], ['Stackat.Certificate.matching']),
 ('cert', 'Proposition 8 (finite certificate)', ['Stackat.finite_certificate'], ['Stackat.Certificate.inclusion_iff_certificate', 'Stackat.Certificate.Invariant', 'Stackat.Example.Leftovers.certificate_eq', 'Stackat.Cyclic.certificate_inclusion']),
 ('exdfa', '§3.3 example: the sets L_i of the shared DFA', ['Stackat.Example.classes'], ['Stackat.Example.dfa', 'Stackat.Example.run_eq_s', 'Stackat.Example.run_eq_β', 'Stackat.Example.run_eq_α', 'Stackat.Example.run_eq_bot']),
 ('exacc', '§3.3 example: accepting sets {s,β} and {s}', ['Stackat.Example.accepting_sets'], ['Stackat.Example.run_mem_sβ', 'Stackat.Example.run_eq_s']),
 ('extab', '§3.3 example: the tables E, F, C, G', ['Stackat.Example.running_example_tables'], ['Stackat.Example.e_eq_PhiE', 'Stackat.Example.f_eq_PhiF', 'Stackat.Example.good_iff', 'Stackat.Example.residual_iff']),
 ('exaa', '§3.3 example: (α,α) outside E but good', ['Stackat.Example.αα_good'], ['Stackat.Example.αα_good']),
 ('exbot', '§3.3 example: (⊥,⊥) not good, contains accepted (b,b)', ['Stackat.Example.bot_bot_cell'], ['Stackat.Example.not_good_bot_bot', 'Stackat.Example.not_f_b_bb', 'Stackat.Example.covers_b_b']),
 ('exdel', '§3.3 suffix deletion needs exclusion of direct acceptance', ['Stackat.Example.suffix_deletion_example'], ['Stackat.Example.suffix_deletion_example']),
 ('expredb', '§3.3 example: deleting b from (β,β) reaches (α,α), outside E', ['Stackat.Example.strip_b_ββ'], ['Stackat.Example.pred_b_ββ']),
 ('exnotinv', '§3.3 example: E ∖ F alone is no certificate', ['Stackat.Example.not_certificate_E'], ['Stackat.Example.not_invariant_E']),
 ('expreda', '§3.3 example: deleting a from L_α leaves L_s or L_β', ['Stackat.Example.pred_α'], ['Stackat.Example.pred_α']),
 ('expredaa', '§3.3 example: the four predecessor cells of (α,α) must be good', ['Stackat.Example.pred_a_αα_good'], ['Stackat.Example.pred_a_αα']),
 ('matrix', '§4 eq. (9), Φ(D) = ℓ X* D Y* r', ['Stackat.tableProgram_eq_matrix'], ['Stackat.normalForm']),
 ('local', '§4 eq. (10), X C Y ≤ C + F', ['Stackat.local_inequality'], ['Stackat.MatrixCertificate.local_inequality', 'Stackat.Cyclic.certificate_inclusion']),
 ('sandwich', 'Lemma 7 (star induction on both sides)', ['Stackat.sandwich'], ['Stackat.sandwich']),
 ('zero', '§4 ℓ X* C r = 0, ℓ C Y* r = 0', ['Stackat.boundary_terms'], ['Stackat.MatrixCertificate.boundary_left', 'Stackat.MatrixCertificate.boundary_right']),
 ('final', '§4 inclusion between normal forms from KA and q_a p_a ≤ 1 alone', ['Stackat.normal_form_inclusion'], ['Stackat.normal_form_inclusion']),
 ('bounds', '§4 the two length bounds are Lean-verified', ['Stackat.length_bounds'], ['Stackat.Cyclic.short_counterexample_sq', 'Stackat.Cyclic.LowerBound.quadratic_lower_bound']),
 ('exle', '§4 example: Q*P* ≤ Q* + P* and the reverse', ['Stackat.Example.e_le_f_and_f_le_e'], ['Stackat.Example.e_le_f', 'Stackat.Example.f_le_e']),
 ('exscalar', '§4 example: the shorter scalar proof', ['Stackat.Example.scalar_proof'], ['Stackat.Example.QP_le_one', 'Stackat.Example.e_le_f_scalar']),
 ('fields', 'Corollary 9 (completeness with fields)', ['Stackat.Fields.finite_header_completeness_both_forms'], ['Stackat.Fields.completeness', 'Stackat.Fields.inequationalCompleteness', 'Stackat.Fields.derives_sound']),
 ('whole', '§5 eq. (15), the whole-header laws', ['Stackat.Fields.whole_model'], ['Stackat.Fields.whole_model']),
 ('hsim', '§5 eq. (17), the simulation M_e U = U e', ['Stackat.Fields.Headers.simulation'], ['Stackat.Fields.Headers.simulation']),
 ('starsim', '§5 simulation through matrix star', ['Stackat.matrix_star_simulation'], ['Stackat.matrix_star_simulation']),
 ('recon', '§5 eq. (12), reconstruction', ['Stackat.Fields.Headers.reconstruction'], ['Stackat.Fields.Headers.reconstruction']),
 ('exec', '§6 the executable decision procedure', ['Stackat.decision_procedures'], ['Stackat.Executable.PureDecision.decideInclusion', 'Stackat.Executable.PureDecision.decideEquivalence', 'Stackat.Fields.Executable.decideInclusion', 'Stackat.Fields.Executable.decideEquivalence']),
 ('checker', 'App. E the certificate checkers are verified', ['Stackat.certificate_checkers'], ['Stackat.Executable.PureDecision.checkAnswer_correct', 'Stackat.Fields.Executable.checkAnswer_correct']),
 ('netkat', '§7 bb ≤ b and a ≤ 1 fail for pushes and pops', ['Stackat.netkat_hypotheses_fail'], ['Stackat.Example.Leftovers.push_not_idem', 'Stackat.Example.Leftovers.pop_not_idem', 'Stackat.Example.Leftovers.push_not_le_one', 'Stackat.Example.Leftovers.pop_not_le_one']),
 ('closure', '§7 the closure of 1 meets q_a* p_a* in {q_a^n p_a^n}', ['Stackat.Closure.closure_inter_not_regular'], ['Stackat.Example.Closure.closure_inter']),
 ('aut', 'App. A the automaton representation e = λ M* ρ', ['Stackat.StackAutomaton.eval_ofExpr_free'], ['Stackat.Automaton.eval_ofExpr_free']),
 ('balanced', 'App. A a balanced path gives a unit-labelled edge', ['Stackat.StackGraph.balanced_le_star'], ['Stackat.StackGraph.balanced_le_star']),
 ('idem', 'App. A B² = B', ['Stackat.StackGraph.saturation_idem'], ['Stackat.StackGraph.saturation_idem']),
 ('satle', 'App. A B ≤ M*', ['Stackat.StackGraph.saturation_le_star'], ['Stackat.StackGraph.saturation_le_star']),
 ('hatpq', 'App. A P̂ Q̂ ≤ B', ['Stackat.StackGraph.saturated_push_pop'], ['Stackat.StackGraph.saturated_push_pop']),
 ('satstar', 'App. A eq. (13), M ≤ B + P̂ + Q̂ ≤ M*', ['Stackat.StackGraph.saturated_star'], ['Stackat.StackGraph.transition_le_saturated', 'Stackat.StackGraph.saturated_le_star']),
 ('reorder', 'App. A eq. (14), the reordering identity', ['Stackat.reorder'], ['Stackat.reorder']),
 ('sfact', 'App. A the identities give ab ≤ a + b', ['Stackat.saturated_mul_le'], ['Stackat.saturated_factorization']),
 ('fact', 'App. A M* = (B+Q̂)*(B+P̂)*', ['Stackat.StackGraph.factorization'], ['Stackat.StackGraph.factorization']),
 ('expand', 'App. A e = λ(B+Q̂)*(B+P̂)*ρ, a finite sum of pure-pop times pure-push', ['Stackat.StackAutomaton.expansion'], ['Stackat.Automaton.normalized_ofExpr']),
 ('fexp', 'App. B eq. (16), the field expansions', ['Stackat.Fields.field_expansions'], ['Stackat.Fields.expand_test', 'Stackat.Fields.expand_assign']),
 ('hfield', 'App. B whole-header assignments followed by field operations', ['Stackat.Fields.whole_assign_field_operations'], ['Stackat.Fields.whole_assign_fieldTest', 'Stackat.Fields.whole_assign_field']),
 ('hmap', 'App. B the map into the algebra with fields', ['Stackat.Fields.Headers.stackHom_preserves'], ['Stackat.Fields.Headers.stackHom', 'Stackat.Fields.Headers.stackHom_star', 'Stackat.Fields.Headers.map_matrix_star']),
 ('hsem', 'App. B entries of M_e in the relational model', ['Stackat.Fields.Headers.semantic_entries'], ['Stackat.Fields.Headers.semantic_entries']),
 ('hcomp', 'App. B completeness for whole-header expressions', ['Stackat.Fields.Headers.whole_header_completeness'], ['Stackat.Fields.Headers.completeness']),
 ('fderiv', 'App. B the derivation in the per-field system', ['Stackat.Fields.finite_header_completeness'], ['Stackat.Fields.completeness', 'Stackat.Fields.inequationalCompleteness', 'Stackat.Fields.derives_sound']),
 ('empty', 'App. B an empty field domain', ['Stackat.Fields.empty_domain'], ['Stackat.Example.Leftovers.empty_domain_derives', 'Stackat.Example.Leftovers.empty_domain_denote']),
 ('indpp', 'App. C countermodel for matching cancellation', ['Stackat.Independence.push_pop_countermodel'], ['Stackat.Independence.pushPop_independent']),
 ('indmm', 'App. C countermodel for mismatch', ['Stackat.Independence.mismatch_countermodel'], ['Stackat.Independence.mismatch_independent']),
 ('indpi', 'App. C countermodel for partial identity', ['Stackat.Independence.pop_push_countermodel'], ['Stackat.Independence.popPush_independent']),
 ('indcm', 'App. C each omitted law fails in a model of KA and the others', ['Stackat.Independence.scheme_countermodels'], ['Stackat.Independence.pushPop_independent', 'Stackat.Independence.mismatch_independent', 'Stackat.Independence.popPush_independent']),
 ('indsound', 'App. C soundness in these models gives nonderivability', ['Stackat.Independence.not_derivable_of_countermodel'], ['Stackat.Axioms.Model.sound', 'Stackat.Axioms.incomplete_of_model']),
 ('cost', 'App. D.1 at most |S|² insertions', ['Stackat.marking_runs'], ['Stackat.Example.Cost.Run.length_le_sq', 'Stackat.Example.Cost.bad_insertions_le_sq']),
 ('badng', 'App. D.1 every marked cell contains a pair outside 𝓡_F', ['Stackat.marked_not_good'], ['Stackat.Executable.BadCells.bad_not_good']),
 ('bad', 'App. D.1 B is the complement of G; inclusion iff E ∩ B = ∅', ['Stackat.marked_complement_and_inclusion'], ['Stackat.Executable.BadCells.good_iff', 'Stackat.Executable.BadCells.includes_iff']),
 ('badexec', 'App. D.1 the executable marking computes the complement of G', ['Stackat.Executable.BadCells.good_iff'], ['Stackat.Executable.BadCells.good_iff', 'Stackat.Executable.BadCells.includes_iff']),
 ('counterexample', 'App. D.1 witness recovery', ['Stackat.Executable.BadCells.counterexample_correct'], ['Stackat.Executable.BadCells.counterexample_sound']),
 ('srcprop', 'Proposition 11 (the least certificate)', ['Stackat.source_directed_search'], ['Stackat.Example.Leftovers.source_directed', 'Stackat.Example.Leftovers.source_directed_certificate', 'Stackat.Example.Leftovers.certificate_contains_cmin']),
 ('source', 'App. D.2 witness soundness and completeness of the inclusion test', ['Stackat.Executable.SourceDirected.counterexample_correct'], ['Stackat.Executable.SourceDirected.counterexample_sound', 'Stackat.Executable.SourceDirected.counterexample_none_iff']),
 ('short', 'Proposition 12 (short counterexamples)', ['Stackat.short_counterexamples'], ['Stackat.Cyclic.short_counterexample', 'Stackat.Cyclic.short_counterexample_sq']),
 ('shortsuf', 'App. D.3 acceptance is closed under a common suffix', ['Stackat.accepted_suffix'], ['Stackat.Certificate.covers_suffix']),
 ('shortbad', 'App. D.3 a rejected pair lies in a marked cell', ['Stackat.marked_of_not_accepted'], ['Stackat.Cyclic.marked_of_not_covers']),
 ('shortpath', 'App. D.3 at most b − 1 propagation steps', ['Stackat.markedWithin_bound'], ['Stackat.Cyclic.markedWithin_bound']),
 ('shortrep', 'App. D.3 representatives of length at most n − 1', ['Stackat.exists_short_representative'], ['Stackat.Cyclic.exists_run_eq_length_le']),
 ('shortwit', 'App. D.3 the witness grows by one letter per step', ['Stackat.MarkedWithin.exists_short'], ['Stackat.Cyclic.MarkedWithin.exists_short']),
 ('lbcard', 'App. D.3 n = r + s + 3 reachable states', ['Stackat.LowerBound.card_state_reachable'], ['Stackat.Cyclic.LowerBound.card_state']),
 ('lbclass', 'App. D.3 the sets L_i that make up U_i and V_j', ['Stackat.LowerBound.classes'], ['Stackat.Cyclic.LowerBound.eq_of_run_eq_U', 'Stackat.Cyclic.LowerBound.eq_of_run_eq_V', 'Stackat.Cyclic.LowerBound.run_b_aw', 'Stackat.Cyclic.LowerBound.run_aw']),
 ('lbrej', 'App. D.3 the target rejects exactly (ba^t, a^t)', ['Stackat.LowerBound.not_accepted_iff'], ['Stackat.Cyclic.LowerBound.not_covers_iff']),
 ('lower', 'App. D.3 the shortest counterexample has maximum length rs', ['Stackat.LowerBound.quadratic_lower_bound'], ['Stackat.Cyclic.LowerBound.quadratic_lower_bound']),
 ('consec', 'App. D.3 consecutive r, s give rs = Ω(n²)', ['Stackat.LowerBound.consecutive_and_two_three'], ['Stackat.Cyclic.LowerBound.consecutive_lower_bound']),
 ('exrem', 'App. D.4 the remainder ρ(u), u = (ab)^k ρ(u) with k maximal', ['Stackat.Example.rem_eq_iff'], ['Stackat.Example.rem', 'Stackat.Example.rem_eq_iff']),
 ('exrf', 'App. D.4 (u,v) ∈ R_f iff ρ(u) = ρ(v)', ['Stackat.Example.R_f_iff'], ['Stackat.Example.R_f_iff']),
 ('exremcls', 'App. D.4 the remainder on L_s, L_β, L_α', ['Stackat.Example.rem_on_classes'], ['Stackat.Example.rem_of_run_s', 'Stackat.Example.rem_of_run_β', 'Stackat.Example.rem_of_run_α']),
 ('exrembot', 'App. D.4 the remainder on L_⊥', ['Stackat.Example.rem_on_bot'], ['Stackat.Example.rem_of_run_bot', 'Stackat.Example.rem_varies_bot']),
 ('exT', 'App. D.5 the products T_c C T_dᵀ', ['Stackat.Example.T_products'], ['Stackat.Example.TaCTa', 'Stackat.Example.TbCTb', 'Stackat.Example.TaCTb', 'Stackat.Example.TbCTa']),
 ('exstrip', 'App. D.5 stripping b reaches (α,α), stripping a the cells of E', ['Stackat.Example.stripping'], ['Stackat.Example.pred_b_ββ', 'Stackat.Example.pred_a_ββ', 'Stackat.Example.pred_a_αα', 'Stackat.Example.pred_b_αα']),
 ('exxcy', 'App. D.5 XCY = q_a p_a E + q_b p_b Δ_α ≤ F + C', ['Stackat.Example.XCY_eq_le'], ['Stackat.Example.XCY_eq', 'Stackat.Example.XCY_le', 'Stackat.Example.E_add_Δα']),
 ('exzero', 'App. D.5 the zero initial row and column of C', ['Stackat.Example.C_row_col_s'], ['Stackat.Example.C_row_s', 'Stackat.Example.C_col_s']),
 ('exbridge', 'App. D.5 the edges of Figure 4', ['Stackat.Example.bridge_edges'], ['Stackat.Example.bridge_edges']),
 ('exphic', 'App. D.5 Φ(C) = Q⁺P⁺ + Q* q_a p_a P*', ['Stackat.Example.PhiC_eq'], ["Stackat.Example.PhiC'"]),
 ('excontains', 'App. D.5 (α,α) is needed to close the certificate', ['Stackat.Example.αα_needed'], ['Stackat.Example.certificate_contains_G']),
]

DEFINITIONS = [
 'Stackat.SoundnessAndCompleteness',
 'Stackat.Soundness',
 'Stackat.Completeness',
 'Stackat.InequationalCompleteness',
 'Stackat.StackLaw',
 'Stackat.DerivesWith',
 'Stackat.q',
 'Stackat.p',
 'Stackat.Expr.PopOnly',
 'Stackat.Expr.PushOnly',
 'Stackat.Expr.sum',
 'Stackat.Expr.npow',
 'Stackat.Expr.instPowNat',
 'Stackat.DFA',
 'Stackat.DFA.h',
 'Stackat.DFA.L',
 'Stackat.StackAutomaton',
 'Stackat.StackGraph.paths',
 'Stackat.StackAutomaton.eval',
 'Stackat.StackGraph',
 'Stackat.StackGraph.transition',
 'Stackat.SharedDFA.State',
 'Stackat.SharedDFA.dfa',
 'Stackat.SharedDFA.accepts',
 'Stackat.tableProgram',
 'Stackat.boolMatrix',
 'Stackat.FreeAlgebraWith',
 'Stackat.FreeAlgebraWith.of',
 'Stackat.FreeAlgebra',
 'Stackat.FreeAlgebra.of',
 'Stackat.Accepted',
 'Stackat.Rel',
 'Stackat.Rel.push',
 'Stackat.Rel.pop',
 'Stackat.Example.Letter',
 'Stackat.Example.Q',
 'Stackat.Example.P',
 'Stackat.Example.e',
 'Stackat.Example.f',
 'Stackat.Example.abPow',
 'Stackat.Residual',
 'Stackat.CertificateConditions',
 'Stackat.Example.St',
 'Stackat.Example.step',
 'Stackat.Example.dfa',
 'Stackat.Example.E',
 'Stackat.Example.F',
 'Stackat.Example.C',
 'Stackat.Example.G',
 'Stackat.MatrixStar.matrixStar',
 'Stackat.initialVec',
 'Stackat.Example.Qk',
 'Stackat.Example.Pk',
 'Stackat.Fields.Header',
 'Stackat.Fields.Expr',
 'Stackat.Fields.Expr.sum',
 'Stackat.Fields.Expr.denote',
 'Stackat.Fields.R',
 'Stackat.Fields.Soundness',
 'Stackat.Fields.Completeness',
 'Stackat.Fields.InequationalCompleteness',
 'Stackat.Fields.FieldModel',
 'Stackat.Fields.wholeTest',
 'Stackat.Fields.wholeAssign',
 'Stackat.Fields.Headers.HeaderModel',
 'Stackat.Fields.Headers.Expr',
 'Stackat.Fields.Headers.Expr.sum',
 'Stackat.Fields.Headers.eval',
 'Stackat.Decision.InclusionResult',
 'Stackat.Decision.EquivalenceResult',
 'Stackat.Executable.PureDecision.decide_inclusion',
 'Stackat.Executable.PureDecision.decide_equivalence',
 'Stackat.Fields.Decision.InclusionResult',
 'Stackat.Fields.Decision.EquivalenceResult',
 'Stackat.Fields.Executable.decide_inclusion',
 'Stackat.Fields.Executable.decide_equivalence',
 'Stackat.Decision.CellCertificate',
 'Stackat.Decision.Answer',
 'Stackat.Decision.Correct',
 'Stackat.Executable.PureDecision.checkAnswer',
 'Stackat.Fields.Decision.Answer',
 'Stackat.Fields.Decision.Correct',
 'Stackat.Fields.Executable.checkAnswer',
 'Stackat.Closure.Op',
 'Stackat.Closure.InClosure',
 'Stackat.Closure.pops',
 'Stackat.Closure.pushes',
 'Stackat.Closure.diagonal',
 'Stackat.StackAutomaton.ofExpr',
 'Stackat.StackGraph.Balanced',
 'Stackat.StackGraph.surround',
 'Stackat.Fields.Headers.FreeAlgebra',
 'Stackat.Fields.Headers.stackHom',
 'Stackat.Fields.Headers.Expr.denote',
 'Stackat.Fields.Headers.R',
 'Stackat.Fields.Headers.Derives',
 'Stackat.StackLaw.Holds',
 'Stackat.Independence.zeroOp',
 'Stackat.Independence.oneOp',
 'Stackat.Independence.bitPush',
 'Stackat.Independence.bitPop',
 'Stackat.Expr.eval',
 'Stackat.CanInsert',
 'Stackat.MarkingRun',
 'Stackat.Stuck',
 'Stackat.Executable.BadCells.Direct',
 'Stackat.Executable.BadCells.bad',
 'Stackat.Executable.BadCells.counterexample',
 'Stackat.Executable.SourceDirected.Prepared',
 'Stackat.Executable.SourceDirected.counterexample',
 'Stackat.MarkedWithin',
 'Stackat.LowerBound.Letter',
 'Stackat.LowerBound.State',
 'Stackat.LowerBound.aut',
 'Stackat.LowerBound.aw',
 'Stackat.LowerBound.F',
 'Stackat.Example.rem',
 'Stackat.Example.T',
 'Stackat.Example.Δα',
]


def check_shape():
    """One headline per key; two only for a pair of definitions (keys starting with d or lb)."""
    for key, item, decls, _ in CLAIMS:
        assert len(decls) == 1 or (len(decls) == 2 and key in PAIRS), (key, decls)
    names = [d for _, _, ds, _ in CLAIMS for d in ds] + DEFINITIONS
    assert len(names) == len(set(names)), 'a declaration listed twice'


# the definition entries that list a pair of definitions
PAIRS = {'dmatrix', 'dhat', 'lbtab'}


if __name__ == '__main__':
    import sys, re, os
    check_shape()
    root = os.path.dirname(os.path.abspath(__file__))
    # Coverage.lean: #check every declaration, in the order of the map
    with open(os.path.join(root, 'Coverage.lean'), 'w') as f:
        f.write('import StackatPaper\n\n/-! Every declaration of the paper\'s Lean map, in its order. Generated by\n`checks/claims.py`. -/\n\n')
        for key, item, decls, _ in CLAIMS:
            f.write(f'-- {key}: {item}\n')
            for d in decls:
                f.write(f'#check @{d}\n')
            f.write('\n')
        f.write('-- the unmarked definitions of the Definitions part\n')
        for d in DEFINITIONS:
            f.write(f'#check @{d}\n')
    # Audit.lean: #print axioms for every declaration
    roots = []
    for key, item, decls, _ in CLAIMS:
        for d in decls:
            if d not in roots: roots.append(d)
    for d in DEFINITIONS:
        if d not in roots: roots.append(d)
    with open(os.path.join(root, 'Audit.lean'), 'w') as f:
        f.write('import StackatPaper\n\n/-! The axioms of every declaration of the map. Generated by `checks/claims.py`. -/\n\n')
        for d in roots:
            f.write(f'#print axioms {d}\n')
    with open(os.path.join(root, 'roots.txt'), 'w') as f:
        f.write('\n'.join(roots) + '\n')
    print(len(CLAIMS), 'claims,', len(DEFINITIONS), 'further definitions,', len(roots), 'declarations')


def tables(root):
    """The naming table (DESIGN.md) and the paper-to-declaration tables (README.md)."""
    import os
    loc = {}
    p = os.path.join(root, 'locations.txt')
    for line in open(p):
        if '\t' in line:
            n, m = line.rstrip('\n').split('\t')
            loc[n] = m.replace('.', '/') + '.lean'
    def short(d):
        return d[len('Stackat.'):] if d.startswith('Stackat.') else d
    def cell(t):
        return t.replace('|', '\\|')
    def file(d):
        assert d in loc and loc[d] != '?/lean', f'no location for {d}: run checks/Locations.lean'
        return loc[d]
    naming = ['| key | paper item | headline here | earlier name |', '|---|---|---|---|']
    readme = ['| paper item | key | headline | file |', '|---|---|---|---|']
    for key, item, decls, old in CLAIMS:
        naming.append(f"| `{key}` | {cell(item)} | {', '.join('`' + short(d) + '`' for d in decls)} | "
                      f"{', '.join('`' + short(d) + '`' for d in old)} |")
        files = []
        for d in decls:
            if file(d) not in files: files.append(file(d))
        readme.append(f"| {cell(item)} | `{key}` | {', '.join('`' + short(d) + '`' for d in decls)} | "
                      f"{', '.join('`' + f + '`' for f in files)} |")
    readme += ['', 'The further definitions listed in the Definitions part of the map, in its order:', '',
               '| definition | file |', '|---|---|']
    for d in DEFINITIONS:
        readme.append(f'| `{short(d)}` | `{file(d)}` |')
    return '\n'.join(naming) + '\n', '\n'.join(readme) + '\n'


def splice(path, marker, text):
    s = open(path).read()
    a, b = f'<!-- {marker} -->', f'<!-- /{marker} -->'
    i, j = s.index(a) + len(a), s.index(b)
    open(path, 'w').write(s[:i] + '\n' + text + s[j:])


if __name__ == '__main__' and '--docs' in __import__('sys').argv:
    import os
    root = os.path.dirname(os.path.abspath(__file__))
    naming, readme = tables(root)
    if os.path.exists(os.path.join(root, '..', 'DESIGN.md')):
        splice(os.path.join(root, '..', 'DESIGN.md'), 'naming', naming)
    splice(os.path.join(root, '..', 'README.md'), 'claims', readme)
    print('docs updated')
