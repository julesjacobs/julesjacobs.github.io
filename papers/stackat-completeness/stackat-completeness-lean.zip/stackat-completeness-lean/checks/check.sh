#!/usr/bin/env bash
# Builds the development, runs the executable tests, and checks coverage, axioms and minimality.
# Usage: checks/check.sh [path/to/stackat-completeness.tex]
set -euo pipefail
cd -- "$(dirname -- "$0")/.."
PAPER=${1:-$HOME/git/stackat/icalp/worktrees/paper-lean/paper/stackat-completeness.tex}

python3 checks/claims.py
lake build
lake env lean checks/Locations.lean
python3 checks/claims.py --docs
tests="decisionTests decisionResultTests sourceDirectedTests executableTests decisionOracleTests"
lake build $tests
for t in $tests; do
  echo "== $t"
  ".lake/build/bin/$t"
done

# Coverage: the claims table lists exactly the paper's keys, in the order of the map, each with one
# headline (two for a pair of definitions); the map lists exactly the declarations of the table.
python3 - "$PAPER" <<'PY'
import re, sys
sys.path.insert(0, 'checks')
from claims import CLAIMS, DEFINITIONS, check_shape
check_shape()
paper = open(sys.argv[1]).read()
keys = re.findall(r'\\leanentry\{([A-Za-z]+)\}', paper)
mine = [k for k, _, _, _ in CLAIMS]
assert keys == mine, f'paper keys and claims table differ: {set(keys) ^ set(mine)}'
ms = paper.index('\\section{Where Each Result Is Mechanized}')
me = paper.index('\\end{document}')
# each entry of the map is preceded by a comment line "%lean <declarations> | <files>"
listed = [n for line in re.findall(r'^%lean ([^|\n]*)', paper[ms:me], re.M) for n in line.split()]
table = [d for _, _, ds, _ in CLAIMS for d in ds] + DEFINITIONS
assert sorted(listed) == sorted(table), f'map and table differ: {set(listed) ^ set(table)}'
print(f'coverage: {len(keys)} paper keys and {len(DEFINITIONS)} further definitions, as in the map')
PY
lake env lean -DwarningAsError=true checks/Coverage.lean > /dev/null
echo "coverage: every declaration exists"

# Axioms: every claim declaration uses at most propext, Classical.choice, Quot.sound.
lake env lean checks/Audit.lean | python3 -c '
import re, sys
ok = {"propext", "Classical.choice", "Quot.sound"}
n = 0
for line in sys.stdin:
    m = re.search(r"depends on axioms: \[(.*)\]", line)
    if m:
        n += 1
        ax = {a.strip() for a in m.group(1).split(",")}
        assert ax <= ok, line
    elif "does not depend on any axioms" in line:
        n += 1
print(f"audit: {n} declarations, axioms within propext, Classical.choice, Quot.sound")'
if grep -rnE '\bsorry\b|native_decide|ofReduceBool|ofReduceNat|implemented_by|extern' StackatPaper checks/tests; then
  echo "forbidden construct found"; exit 1
fi
echo "audit: no sorry, native_decide, ofReduceBool, implemented_by or extern"

# Minimality: no declaration outside the dependency closure of the claims and the tests.
out=$(lake env lean checks/Minimality.lean)
echo "$out" | grep -q '0 declarations outside the closure' || { echo "$out"; exit 1; }
echo "minimality: every declaration is in the closure of a claim or of the tests"
