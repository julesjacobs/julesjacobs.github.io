import StackatPaper

open Stackat Stackat.Executable

private def lastLetter : Stackat.DFA (Fin 2) (Fin 2) where
  initial := 0
  step := fun _ a => a
  reachable := fun q => ⟨[q], rfl⟩

private def graph (matching : Bool) : StackGraph (Fin 2) (Fin 4) where
  eps := fun i j => i = 1 ∧ j = 2
  push := fun a i j => a = 0 ∧ i = 0 ∧ j = 1
  pop := fun a i j => a = (if matching then 0 else 1) ∧ i = 2 ∧ j = 3

private def saturation (matching : Bool) : Finset (Fin 4 × Fin 4) :=
  letI : DecidableRel (graph matching).eps := fun _ _ => inferInstanceAs (Decidable (_ ∧ _))
  letI : ∀ a, DecidableRel ((graph matching).push a) := fun _ _ _ => inferInstanceAs (Decidable (_ ∧ _ ∧ _))
  letI : ∀ a, DecidableRel ((graph matching).pop a) := fun _ _ _ => inferInstanceAs (Decidable (_ ∧ _ ∧ _))
  Saturation.balanced (graph matching)

private def check (name : String) (ok : Bool) : IO Unit :=
  if ok then IO.println s!"PASS {name}" else throw (IO.userError s!"FAIL {name}")

def main : IO Unit := do
  check "cycle reachability" ((reachable (fun (q : Fin 3) => [q + 1]) [0]).card == 3)
  check "no roots" ((reachable (fun (q : Fin 3) => [q + 1]) []).card == 0)
  check "DFA visits only reachable states" ((DFA.states [()] (0 : Fin 1000) (fun _ _ => 1)).card == 2)
  check "empty alphabet DFA" ((DFA.states ([] : List Empty) (0 : Fin 1000) (fun q _ => q)).card == 1)
  check "balanced push epsilon pop" ((0, 3) ∈ saturation true)
  check "mismatched push pop" ((0, 3) ∉ saturation false)
  check "reflexive saturation" ((0, 0) ∈ saturation false)
  check "inclusion in universal target" (BadCells.includes lastLetter (fun _ _ => true) (fun _ _ => true))
  check "inclusion in empty target fails" (!BadCells.includes lastLetter (fun _ _ => false) (fun _ _ => true))
  check "empty source" (BadCells.includes lastLetter (fun _ _ => false) (fun _ _ => false))
  check "residual cycle inclusion" (BadCells.includes lastLetter
    (fun i j => !(i == 1 && j == 1)) (fun _ _ => true))
  check "boundary counterexample" (!BadCells.includes lastLetter
    (fun i j => !(i == 0 && j == 0)) (fun _ _ => true))
  let paths := exploreTraces (fun (q : Fin 3) => [((), q + 1)]) ∅ [(0, [])]
  check "traces visit once" (paths.length == 3)
  check "traces retain path length" ((paths.map fun p => p.2.length) == [0, 1, 2])
  check "counterexample absent on residual cycle" ((BadCells.counterexample lastLetter
    (fun i j => !(i == 1 && j == 1)) (fun i => [i]) (fun _ _ => true)).isNone)
  check "boundary witness words" (BadCells.counterexample lastLetter
    (fun _ _ => false) (fun i => [i]) (fun _ _ => true) == some ([], [0]))
  check "propagated witness words" (BadCells.counterexample lastLetter
    (fun i j => i != j) (fun i => [i]) (fun i j => i == 1 && j == 1) == some ([1], [0, 1]))
