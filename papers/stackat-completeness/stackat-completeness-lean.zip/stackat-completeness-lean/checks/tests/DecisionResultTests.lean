import StackatPaper

open Stackat

private def ensure (name : String) (b : Bool) : IO Unit :=
  unless b do throw (IO.userError name)

private def pure (name : String) (e f : Expr (Fin 2)) (expected : Bool) : IO Unit := do
  match Executable.PureDecision.decide_inclusion e f with
  | .included _ =>
    ensure name expected
    IO.println s!"{name}: included (proof of Derives (e + f) f)"
  | .counterexample s t _ =>
    ensure name (!expected)
    ensure (name ++ " witness") (Executable.PureDecision.member e s t && !Executable.PureDecision.member f s t)
    IO.println s!"{name}: counterexample {repr s} -> {repr t}"

private def fields {n : Nat} {V : Fin n → Type} [∀ i, FinEnum (V i)]
    [∀ i, Repr (V i)] (name : String) (e f : Fields.Expr (Fin 2) V) (expected : Bool) : IO Unit := do
  match Fields.Executable.decide_inclusion e f with
  | .included _ =>
    ensure name expected
    IO.println s!"{name}: included (proof of Fields.Derives (e + f) f)"
  | .counterexample (h,s) (k,t) _ =>
    ensure name (!expected)
    ensure (name ++ " witness") (Fields.Executable.member e (h,s) (k,t) && !Fields.Executable.member f (h,s) (k,t))
    let showHeader := fun h : Fields.Header V => (List.finRange n).map fun i => reprStr (h i)
    IO.println s!"{name}: counterexample header {showHeader h}, stack {repr s} -> header {showHeader k}, stack {repr t}"

abbrev F := Fields.Expr (Fin 2) (fun _ : Fin 1 => Fin 2)

def main : IO Unit := do
  pure "push-pop = identity" (.push 0 * .pop 0) 1 true
  pure "pop-push <= identity" (.pop 0 * .push 0) 1 true
  pure "identity <= pop-push" 1 (.pop 0 * .push 0) false
  pure "different pushes" (.push 0) (.push 1) false
  pure "nested star" ((Expr.push (A := Fin 2) 0).star.star) ((Expr.push 0).star) true
  let q : Expr (Fin 2) := .pop 0 * .pop 1
  let p : Expr (Fin 2) := .push 1 * .push 0
  pure "running example" (q.star * p.star) (q.star + p.star) true
  fields "assignment then test" (.assign 0 1 * .test 0 1 : F) (.assign 0 1) true
  fields "assignment changes header" (.assign 0 1 : F) 1 false
  fields "test restricts header" (1 : F) (.test 0 0) false
  fields "empty header domain" (1 : Fields.Expr (Fin 2) (fun _ : Fin 1 => Fin 0)) 0 true
  fields "zero fields" (1 : Fields.Expr (Fin 2) (fun _ : Fin 0 => Fin 0)) 0 false
  fields "heterogeneous fields" (.assign 0 1 : Fields.Expr (Fin 2) (fun i : Fin 2 => Fin (if i = 0 then 2 else 3))) 1 false
  for (e,f,expected) in [(1,1,true), (1,0,false), (0,1,false)] do
    match Executable.PureDecision.decide_equivalence (e : Expr (Fin 2)) f with
    | .equivalent _ =>
      ensure "pure equivalence" expected
      IO.println "pure equivalence: equivalent (proof of Derives e f)"
    | .different s t _ =>
      ensure "pure inequivalence" (!expected)
      ensure "pure distinguishing witness" (Executable.PureDecision.member e s t != Executable.PureDecision.member f s t)
      IO.println s!"pure equivalence: different at {repr s} -> {repr t}"
  for (e,f,expected) in [(1,1,true), (1,0,false), (0,1,false)] do
    match Fields.Executable.decide_equivalence (e : F) f with
    | .equivalent _ =>
      ensure "field equivalence" expected
      IO.println "field equivalence: equivalent (proof of Fields.Derives e f)"
    | .different s t _ =>
      ensure "field inequivalence" (!expected)
      ensure "field distinguishing witness" (Fields.Executable.member e s t != Fields.Executable.member f s t)
      IO.println s!"field equivalence: different at header {s.1 0}, stack {repr s.2} -> header {t.1 0}, stack {repr t.2}"
