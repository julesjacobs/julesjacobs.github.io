import StackatPaper

open Stackat

def ensure (name : String) (b : Bool) : IO Unit :=
  unless b do throw (IO.userError name)

def pureCase {A : Type} [FinEnum A] (name : String) (e f : Expr A) (included : Bool) : IO Unit := do
  let t ← IO.monoMsNow
  let answer := Executable.PureDecision.decideRaw e f
  let yes := match answer with | .included _ => true | _ => false
  ensure (name ++ " result") (yes == included)
  ensure (name ++ " checker") (Executable.PureDecision.checkAnswer e f answer)
  IO.println s!"PASS {name} ({(← IO.monoMsNow) - t} ms)"

def fieldCase {A : Type} {n : Nat} {V : Fin n → Type} [FinEnum A] [∀ i, FinEnum (V i)]
    (name : String) (e f : Fields.Expr A V) (included : Bool) : IO Unit := do
  let t ← IO.monoMsNow
  let answer := Fields.Executable.decideRaw e f
  let yes := match answer with | .included _ => true | _ => false
  ensure (name ++ " result") (yes == included)
  ensure (name ++ " checker") (Fields.Executable.checkAnswer e f answer)
  IO.println s!"PASS {name} ({(← IO.monoMsNow) - t} ms)"

abbrev E := Expr (Fin 2)
abbrev F := Fields.Expr (Fin 1) (fun _ : Fin 1 => Fin 2)
def fieldSource : F := .test 0 0 * .pop 0 * .assign 0 1 * .push 0
def fieldTarget : F := .test 0 0 * .push 0 * .assign 0 1 * .pop 0
abbrev Values (i : Fin 2) := Fin (if i = 0 then 2 else 3)
abbrev G := Fields.Expr (Fin 2) Values

def main : IO Unit := do
  pureCase "zero inclusion" (0 : E) 1 true
  pureCase "identity counterexample" (1 : E) 0 false
  pureCase "push-pop cancellation" (.push 0 * .pop 0 : E) 1 true
  pureCase "identity below push-pop" (1 : E) (.push 0 * .pop 0) true
  pureCase "mismatched push-pop" (.push 0 * .pop 1 : E) 0 true
  pureCase "pop-push below identity" (.pop 0 * .push 0 : E) 1 true
  pureCase "pop-push needs input" (1 : E) (.pop 0 * .push 0) false
  pureCase "different output letters" (.push 0 : E) (.push 1) false
  pureCase "choice" (.push 0 : E) (.push 0 + .push 1) true
  pureCase "star unfold" ((.push 0 : E).star) (1 + .push 0 * (.push 0 : E).star) true
  pureCase "nested star" ((.push 0 : E).star.star) ((.push 0 : E).star) true
  let q : E := .pop 0 * .pop 1
  let p : E := .push 1 * .push 0
  pureCase "block residual inclusion" (q.star * p.star) (q.star + p.star) true
  pureCase "block residual reverse" (q.star + p.star) (q.star * p.star) true
  pureCase "empty alphabet" ((1 : Expr (Fin 0)).star) 1 true
  fieldCase "zero fields" (1 : Fields.Expr (Fin 1) (fun _ : Fin 0 => Fin 0)) 0 false
  fieldCase "empty header domain" (1 : Fields.Expr (Fin 1) (fun _ : Fin 1 => Fin 0)) 0 true
  fieldCase "field test restricts" (.test 0 0 : F) 1 true
  fieldCase "field test rejects" (1 : F) (.test 0 0) false
  fieldCase "assignment changes header" (.assign 0 1 : F) 1 false
  fieldCase "assignment then test" (.assign 0 1 * .test 0 1 : F) (.assign 0 1) true
  fieldCase "assignment then wrong test" (.assign 0 1 * .test 0 0 : F) 0 true
  fieldCase "field running example" fieldSource fieldTarget true
  fieldCase "field running example reverse" fieldTarget fieldSource false
  let cycle : F := .assign 0 1 * .assign 0 0
  fieldCase "field star" (cycle.star) (1 + cycle) true
  fieldCase "field nested star" (cycle.star.star) (cycle.star) true
  let mixed : F := .push 0 * .assign 0 1
  let mixedNF : F := 1 + (.push 0 * (Fields.Expr.push 0).star * .assign 0 1)
  fieldCase "mixed stack-field star" mixed.star mixedNF true
  fieldCase "mixed stack-field star reverse" mixedNF mixed.star true
  fieldCase "empty alphabet with assignments"
    (.assign 0 1 * .test 0 1 : Fields.Expr (Fin 0) (fun _ : Fin 1 => Fin 2)) (.assign 0 1) true
  fieldCase "heterogeneous assignments commute"
    (.assign 0 1 * .assign 1 2 : G) (.assign 1 2 * .assign 0 1) true
  fieldCase "heterogeneous tests restrict"
    (.test 1 2 * .push 0 : G) (.push 0) true
  ensure "reject missing certificate" (!Fields.Executable.checkCertificate (1 : F) 1 [])
  ensure "reject invalid pure certificate" (!Executable.PureDecision.checkCertificate (1 : E) 1 [(100000,100000)])
  ensure "reject false counterexample" (!Executable.PureDecision.checkAnswer (1 : E) 1 (.counterexample [] []))
  ensure "reject reversed stack witness" (!Executable.PureDecision.checkAnswer (.push 1 * .push 0 : E) 0 (.counterexample [] [1,0]))
  ensure "accept ordered stack witness" (Executable.PureDecision.checkAnswer (.push 1 * .push 0 : E) 0 (.counterexample [] [0,1]))
  match Executable.PureDecision.decideRaw (1 : E) 1 with
  | .included c =>
    ensure "reject certificate for different claim"
      (!Executable.PureDecision.checkCertificate (1 : E) 0 c)
  | _ => throw (IO.userError "identity certificate")
  ensure "reject incorrect output header"
    (!Fields.Executable.checkAnswer (.assign 0 1 : F) 0
      (.counterexample ((fun _ => 0), []) ((fun _ => 0), [])))
  match Executable.PureDecision.decideEquivalenceRaw (1 : E) 0 with
  | .different true s t =>
    ensure "forward equivalence witness"
      (s.isEmpty && t.isEmpty && Executable.PureDecision.checkAnswer (1 : E) 0 (.counterexample s t))
  | _ => throw (IO.userError "forward inequivalence")
  match Executable.PureDecision.decideEquivalenceRaw (.push 0 * .pop 0 : E) 1 with
  | .equivalent c d =>
    ensure "equivalence forward certificate" (Executable.PureDecision.checkCertificate (.push 0 * .pop 0 : E) 1 c)
    ensure "equivalence backward certificate" (Executable.PureDecision.checkCertificate (1 : E) (.push 0 * .pop 0) d)
  | _ => throw (IO.userError "pure equivalence")
  match Fields.Executable.decideEquivalenceRaw fieldSource fieldTarget with
  | .different false (h,s) (k,t) =>
    ensure "equivalence witness" (h 0 == 0 && k 0 == 1 && s.isEmpty && t.isEmpty)
  | _ => throw (IO.userError "field inequivalence")
  match Fields.Executable.decideEquivalenceRaw (.assign 0 1 * .test 0 1 : F) (.assign 0 1) with
  | .equivalent c d =>
    ensure "field equivalence forward certificate"
      (Fields.Executable.checkCertificate (.assign 0 1 * .test 0 1 : F) (.assign 0 1) c)
    ensure "field equivalence backward certificate"
      (Fields.Executable.checkCertificate (.assign 0 1 : F) (.assign 0 1 * .test 0 1) d)
  | _ => throw (IO.userError "field equivalence")
  IO.println "All decision tests passed."
