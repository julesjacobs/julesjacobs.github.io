import StackatPaper
open Stackat Stackat.Executable

private def machine (x y : Fin 2) : Stackat.DFA (Fin 2) (Fin 2) where
  initial := 0
  step i a := if i = 0 then a else if a = 0 then x else y
  reachable i := ⟨[i], by simp⟩

private def table (mask : Nat) (i j : Fin 2) : Bool :=
  mask.testBit (2 * i.val + j.val)

private def accepts (M : Stackat.DFA (Fin 2) (Fin 2))
    (F : Fin 2 → Fin 2 → Bool) (u v : List (Fin 2)) : Bool :=
  ((List.range (min u.length v.length + 1)).any fun k =>
    u.drop (u.length-k) == v.drop (v.length-k) &&
      F (M.h (u.take (u.length-k))) (M.h (v.take (v.length-k))))

def main : IO Unit := do
  let mut count := 0
  for x in FinEnum.toList (Fin 2) do
    for y in FinEnum.toList (Fin 2) do
      let M := machine x y
      let _ : SourceDirected.Prepared M := SourceDirected.prepare M
      for e in List.range 16 do
        for f in List.range 16 do
          let E := table e
          let F := table f
          let answer := SourceDirected.counterexample M F E (fun i => [i])
          let old := BadCells.counterexample M F (fun i => [i]) E
          unless answer.isNone == old.isNone do
            throw (IO.userError s!"verdict disagreement: {x},{y},{e},{f}")
          if let some (u,v) := answer then
            unless accepts M E u v && !accepts M F u v do
              throw (IO.userError s!"invalid witness: {x},{y},{e},{f}: {repr u} -> {repr v}")
          count := count + 1
  IO.println s!"{count} source-directed table comparisons and independent witness checks passed"
