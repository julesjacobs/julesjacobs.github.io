import StackatPaper

open Stackat

namespace DecisionOracle

inductive Program where
  | zero
  | one
  | push (a : Fin 2)
  | pop (a : Fin 2)
  | choice (e f : Program)
  | sequence (e f : Program)

def expression : Program → Expr (Fin 2)
  | .zero => 0
  | .one => 1
  | .push a => .push a
  | .pop a => .pop a
  | .choice e f => expression e + expression f
  | .sequence e f => expression e * expression f

def run : Program → List (Fin 2) → List (List (Fin 2))
  | .zero, _ => []
  | .one, s => [s]
  | .push a, s => [a :: s]
  | .pop a, b :: s => if a == b then [s] else []
  | .pop _, [] => []
  | .choice e f, s => run e s ++ run f s
  | .sequence e f, s => (run e s).flatMap (run f)

def primitives : List Program := [.zero, .one, .push 0, .push 1, .pop 0, .pop 1]

def programs : List Program := primitives ++ primitives.flatMap fun e =>
  primitives.flatMap fun f => [.choice e f, .sequence e f]

def inputs : List (List (Fin 2)) := [[], [0], [1], [0,0], [0,1], [1,0], [1,1]]

def check : IO Unit := do
  let mut checks := 0
  for (p, i) in programs.zipIdx do
    for s in inputs do
      let outputs := run p s
      for t in (inputs ++ outputs).eraseDups do
        let expected := outputs.contains t
        let actual := Executable.PureDecision.member (expression p) s t
        unless actual == expected do
          throw (IO.userError s!"Interpreter disagreement: program {i}, {s} -> {t}")
        checks := checks + 1
  IO.println s!"PASS independent stack interpreter: {programs.length} programs, {checks} membership comparisons"

end DecisionOracle

def main : IO Unit := DecisionOracle.check
