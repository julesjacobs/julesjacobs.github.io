# StacKAT completeness: the paper's claims in Lean

A Lean 4 + Mathlib development of exactly the claims of *Kleene Algebra with Stacks Is Complete*
(`stackat-completeness.tex`), and the definitions and lemmas needed to prove them. Every Lean mark
of the paper (the 121 keys of its appendix "Where Each Result Is Mechanized") has one headline
declaration here, a theorem whose statement is the marked claim or, for a marked definition, the
definition (two for a pair of definitions); the table below maps paper items to headlines, and
lists the further definitions that the appendix shows once in its Definitions part.

* Lean `v4.30.0`, Mathlib `v4.30.0`, warnings are errors.
* Build: `lake build`. Full check (build, executable tests, coverage, axioms, minimality):
  `checks/check.sh [path/to/stackat-completeness.tex]`.
* Every headline depends only on `propext`, `Classical.choice` and `Quot.sound`; there is no `sorry`,
  `native_decide` or `Lean.ofReduceBool` (`checks/Audit.lean`).

## Reading the development

Files follow the sections of the revised paper: `StackatPaper/Spec.lean` (§2: syntax, semantics, `⊢`, the statement of
Theorem 1), `Section2.lean`, `AppendixA/` (normalization, imported by §3), `Section3/`,
`Section4/`, `Section5/`, `AppendixB/`, `Section6/`, `Section7.lean`, `AppendixC.lean`, `AppendixD/` and
`RunningExample/`, with general Kleene algebra in `Background/`.

`StackatPaper/Spec.lean` (syntax, semantics, derivation rules, and Theorem 1 as one proposition,
`SoundnessAndCompleteness`) imports nothing, so it depends only on the Lean core library. It is listed in full, on one page, in the paper's appendix "Where Each Result Is Mechanized". Notation that makes statements read like the paper: `R e` for `R_e`, `⊢ e ≈ f` and
`⊢ e ≤ f` for derivability of `e = f` and `e + f = f`, `⊬` for non-derivability, `⊢[L] e ≈ f` for
derivability from KA and the stack laws in `L` (so `⊢[(· ≠ .pop_push)]` omits `q_a p_a ≤ 1`),
`e⋆` for the star of an expression, `x ^ n` for powers of expressions, `Fields.R` and the `⊢` of `Fields.Derives` for expressions with
header fields, `Fields.Headers.R` and the `⊢` of `Fields.Headers.Derives` for whole-header
expressions, `q u` and `p u` for words, `Φ M D` for the program of a table, `M.h u` and `M.L i` for the state reached and
the classes, `Good M F` and `Residual M F` for `G` and `C`, `Accepted M D` for `𝓡_D`. Tables are
`S → S → Prop`, so `E ≤ G`, `Accepted M E ≤ Accepted M F` (that is `𝓡_E ⊆ 𝓡_F`) and
`E ⊓ Marked M F = ⊥` (that is `E ∩ B = ∅`) are read as in the paper.

`Spec.lean` states Theorem 1, `SoundnessAndCompleteness`, for every alphabet, as the paper does,
proved as `soundness_and_completeness_spec` (`Section4/AnyAlphabet.lean`, which
restricts to the finitely many letters of `e` and `f` and applies the finite theorem). The parts used elsewhere are stated
in `Section2.lean` and proved as `soundness : Soundness` (any alphabet), `completeness : Completeness`
and `inequational_completeness : InequationalCompleteness` (`Section2.lean`,
`Section4/Derivation.lean`).

## Where each paper item is

<!-- claims -->
| paper item | key | headline | file |
|---|---|---|---|
| §2 syntax of expressions | `dexpr` | `Expr` | `StackatPaper/Spec.lean` |
| §2 relational semantics R_e | `ddenote` | `R` | `StackatPaper/Spec.lean` |
| §2 eq. (1), the derivation system ⊢ | `dderives` | `Derives` | `StackatPaper/Spec.lean` |
| §3.2 the program Φ(D) of a table | `dphi` | `Φ` | `StackatPaper/Section3/Tables.lean` |
| §3.3 eq. (4), good cells | `dgood` | `Good` | `StackatPaper/Section3/TargetTable.lean` |
| §4 the matrices X and Y | `dmatrix` | `popMatrix`, `pushMatrix` | `StackatPaper/Section3/Tables.lean` |
| §4 square matrices over a KA form a KA | `matka` | `MatrixStar.matrixKleeneAlgebra` | `StackatPaper/Background/MatrixStar.lean` |
| §5 eq. (11), expressions with fields and the field laws | `dfields` | `Fields.Derives` | `StackatPaper/Section5/Spec.lean` |
| App. B the matrix interpretation M_e | `dmat` | `Fields.Headers.matrices` | `StackatPaper/AppendixB/Translation.lean` |
| App. A the balanced closure B | `dsat` | `StackGraph.saturation` | `StackatPaper/AppendixA/Saturation.lean` |
| App. A the matrices P̂ and Q̂ | `dhat` | `StackGraph.saturatedPush`, `StackGraph.saturatedPop` | `StackatPaper/AppendixA/Saturation.lean` |
| App. D.1 the initial marking | `seeds` | `InitiallyMarked` | `StackatPaper/AppendixD/Marking.lean` |
| App. D.1 eq. (18), the marking rule | `dbad` | `Marked` | `StackatPaper/AppendixD/Marking.lean` |
| App. D.2 the least set C_min | `support` | `CMin` | `StackatPaper/AppendixD/SourceDirected.lean` |
| App. D.3 the automaton of the quadratic family | `lbaut` | `LowerBound.step` | `StackatPaper/AppendixD/LowerBound.lean` |
| App. D.3 the tables E and S² ∖ F of the family | `lbtab` | `LowerBound.E`, `LowerBound.Outside` | `StackatPaper/AppendixD/LowerBound.lean` |
| §2 p_a q_a restores every stack, q_a p_a those beginning with a | `relpq` | `push_pop_and_pop_push_R` | `StackatPaper/Section2.lean` |
| §2 q_a p_b replaces a by b | `relqp` | `pop_push_ne_R` | `StackatPaper/Section2.lean` |
| Theorem 1 (soundness and completeness) | `thm` | `soundness_and_completeness_any_alphabet` | `StackatPaper/Section4/AnyAlphabet.lean` |
| Proposition 10 (independence of the stack laws) | `indep` | `Independence.scheme_independence` | `StackatPaper/AppendixC.lean` |
| App. E Theorem 1 as stated in Spec.lean | `thmspec` | `soundness_and_completeness_spec` | `StackatPaper/Section4/AnyAlphabet.lean` |
| App. E the two completeness formulations are equivalent | `equiv` | `completeness_iff_inequational` | `StackatPaper/Section2.lean` |
| §3.1 q(u)p(v) relates uw to vw | `qp` | `qp_R` | `StackatPaper/Section3/Words.lean` |
| Lemma 2 (pop–push normal form) | `nf` | `pop_push_normal_form` | `StackatPaper/AppendixA/NormalForm.lean` |
| §3.1 q(xw)p(yw) = q(x)q(w)p(w)p(y) ≤ q(x)p(y) | `wordle` | `qp_append_eq_le` | `StackatPaper/Section3/Words.lean` |
| §3.1 q(w)p(w) ≤ 1 | `wordone` | `qp_le_one` | `StackatPaper/Section3/Words.lean` |
| §3.2 one complete reachable DFA for all pop and push languages | `dfa` | `SharedDFA.representation` | `StackatPaper/Section3/SharedDFA.lean` |
| §3.2 h(ua) = δ(h(u),a) and nonempty sets L_i | `dfah` | `DFA.h_append_singleton_and_L_nonempty` | `StackatPaper/Section3/DFA.lean` |
| §3.2 eq. (2), e = Φ(E), f = Φ(F) | `tables` | `shared_normal_forms` | `StackatPaper/Section3/SharedDFA.lean` |
| §3.2 eq. (3), R_Φ(D) = 𝓡_D | `sem` | `table_semantics` | `StackatPaper/Section3/Tables.lean` |
| §3.1 example: QP² ≤ q_a p_a p_b p_a ≤ P | `exqp` | `Example.QP2_le_mid_le_P` | `StackatPaper/RunningExample/Words.lean` |
| §3.1 example: the three cuts of (abw, ababw) | `excut` | `Example.cut_table` | `StackatPaper/RunningExample/Words.lean` |
| §3.1 example: QPQP² = Q(PQ)P² = QP², PQ = 1 | `exnorm` | `Example.QPQP2_normalization` | `StackatPaper/RunningExample/Words.lean` |
| §3.1 example: Q^m P^n sends (ab)^m w to (ab)^n w | `expow` | `Example.QmPn_R` | `StackatPaper/RunningExample/Words.lean` |
| §3.1 example: on (ab)^m w, Q^{m-n} (m ≥ n) and P^{n-m} (n ≥ m) have the output of Q^m P^n | `exsub` | `Example.Qsub_Psub_R` | `StackatPaper/RunningExample/Words.lean` |
| §3.1 example: QP restores only stacks beginning with ab, 1 every stack | `exqpden` | `Example.QP_and_one_R` | `StackatPaper/RunningExample/Words.lean` |
| §3.1 example: R_e = R_f | `exeq` | `Example.R_e_eq_R_f` | `StackatPaper/RunningExample/Basic.lean` |
| §3.3 F ≤ G, and 𝓡_E ⊆ 𝓡_F iff E ≤ G | `good` | `target_and_source_le_good` | `StackatPaper/Section3/TargetTable.lean` |
| §3.3 Lemma 3, eq. (5), the suffix alternative | `suffix` | `suffix_alternative` | `StackatPaper/Section3/TargetTable.lean` |
| §3.3 empty-prefix boundaries | `bnd` | `residual_boundaries` | `StackatPaper/Section3/TargetTable.lean` |
| §3.3 mismatched final symbols | `mis` | `residual_mismatch` | `StackatPaper/Section3/TargetTable.lean` |
| §3.3 fact 3: good iff all predecessors good | `mat` | `good_iff_predecessors_good` | `StackatPaper/Section3/TargetTable.lean` |
| Proposition 8 (finite certificate) | `cert` | `finite_certificate` | `StackatPaper/Section4/Derivation.lean` |
| §3.3 example: the sets L_i of the shared DFA | `exdfa` | `Example.classes` | `StackatPaper/RunningExample/Basic.lean` |
| §3.3 example: accepting sets {s,β} and {s} | `exacc` | `Example.accepting_sets` | `StackatPaper/RunningExample/Basic.lean` |
| §3.3 example: the tables E, F, C, G | `extab` | `Example.running_example_tables` | `StackatPaper/RunningExample/Algebra.lean` |
| §3.3 example: (α,α) outside E but good | `exaa` | `Example.αα_good` | `StackatPaper/RunningExample/Tables.lean` |
| §3.3 example: (⊥,⊥) not good, contains accepted (b,b) | `exbot` | `Example.bot_bot_cell` | `StackatPaper/RunningExample/Tables.lean` |
| §3.3 suffix deletion needs exclusion of direct acceptance | `exdel` | `Example.suffix_deletion_example` | `StackatPaper/RunningExample/Words.lean` |
| §3.3 example: deleting b from (β,β) reaches (α,α), outside E | `expredb` | `Example.strip_b_ββ` | `StackatPaper/RunningExample/Tables.lean` |
| §3.3 example: E ∖ F alone is no certificate | `exnotinv` | `Example.not_certificate_E` | `StackatPaper/RunningExample/Tables.lean` |
| §3.3 example: deleting a from L_α leaves L_s or L_β | `expreda` | `Example.pred_α` | `StackatPaper/RunningExample/Tables.lean` |
| §3.3 example: the four predecessor cells of (α,α) must be good | `expredaa` | `Example.pred_a_αα_good` | `StackatPaper/RunningExample/Tables.lean` |
| §4 eq. (9), Φ(D) = ℓ X* D Y* r | `matrix` | `tableProgram_eq_matrix` | `StackatPaper/Section4/Derivation.lean` |
| §4 eq. (10), X C Y ≤ C + F | `local` | `local_inequality` | `StackatPaper/Section4/Derivation.lean` |
| Lemma 7 (star induction on both sides) | `sandwich` | `sandwich` | `StackatPaper/Section4/Derivation.lean` |
| §4 ℓ X* C r = 0, ℓ C Y* r = 0 | `zero` | `boundary_terms` | `StackatPaper/Section4/Derivation.lean` |
| §4 inclusion between normal forms from KA and q_a p_a ≤ 1 alone | `final` | `normal_form_inclusion` | `StackatPaper/Section4/Derivation.lean` |
| §4 the two length bounds are Lean-verified | `bounds` | `length_bounds` | `StackatPaper/AppendixD/LowerBound.lean` |
| §4 example: Q*P* ≤ Q* + P* and the reverse | `exle` | `Example.e_le_f_and_f_le_e` | `StackatPaper/RunningExample/Algebra.lean` |
| §4 example: the shorter scalar proof | `exscalar` | `Example.scalar_proof` | `StackatPaper/RunningExample/Algebra.lean` |
| Corollary 9 (completeness with fields) | `fields` | `Fields.finite_header_completeness_both_forms` | `StackatPaper/Section5/Completeness.lean` |
| §5 eq. (15), the whole-header laws | `whole` | `Fields.whole_model` | `StackatPaper/AppendixB/WholeHeaderLaws.lean` |
| §5 eq. (17), the simulation M_e U = U e | `hsim` | `Fields.Headers.simulation` | `StackatPaper/AppendixB/Translation.lean` |
| §5 simulation through matrix star | `starsim` | `matrix_star_simulation` | `StackatPaper/Background/MatrixSimulation.lean` |
| §5 eq. (12), reconstruction | `recon` | `Fields.Headers.reconstruction` | `StackatPaper/AppendixB/Translation.lean` |
| §6 the executable decision procedure | `exec` | `decision_procedures` | `StackatPaper/Section6/Correctness.lean` |
| App. E the certificate checkers are verified | `checker` | `certificate_checkers` | `StackatPaper/Section6/Correctness.lean` |
| §7 bb ≤ b and a ≤ 1 fail for pushes and pops | `netkat` | `netkat_hypotheses_fail` | `StackatPaper/Section7.lean` |
| §7 the closure of 1 meets q_a* p_a* in {q_a^n p_a^n} | `closure` | `Closure.closure_inter_not_regular` | `StackatPaper/Section7.lean` |
| App. A the automaton representation e = λ M* ρ | `aut` | `StackAutomaton.eval_ofExpr_free` | `StackatPaper/AppendixA/Automaton.lean` |
| App. A a balanced path gives a unit-labelled edge | `balanced` | `StackGraph.balanced_le_star` | `StackatPaper/AppendixA/Saturation.lean` |
| App. A B² = B | `idem` | `StackGraph.saturation_idem` | `StackatPaper/AppendixA/Saturation.lean` |
| App. A B ≤ M* | `satle` | `StackGraph.saturation_le_star` | `StackatPaper/AppendixA/Saturation.lean` |
| App. A P̂ Q̂ ≤ B | `hatpq` | `StackGraph.saturated_push_pop` | `StackatPaper/AppendixA/Saturation.lean` |
| App. A eq. (13), M ≤ B + P̂ + Q̂ ≤ M* | `satstar` | `StackGraph.saturated_star` | `StackatPaper/AppendixA/NormalForm.lean` |
| App. A eq. (14), the reordering identity | `reorder` | `reorder` | `StackatPaper/AppendixA/NormalForm.lean` |
| App. A the identities give ab ≤ a + b | `sfact` | `saturated_mul_le` | `StackatPaper/AppendixA/NormalForm.lean` |
| App. A M* = (B+Q̂)*(B+P̂)* | `fact` | `StackGraph.factorization` | `StackatPaper/AppendixA/NormalForm.lean` |
| App. A e = λ(B+Q̂)*(B+P̂)*ρ, a finite sum of pure-pop times pure-push | `expand` | `StackAutomaton.expansion` | `StackatPaper/AppendixA/NormalForm.lean` |
| App. B eq. (16), the field expansions | `fexp` | `Fields.field_expansions` | `StackatPaper/AppendixB/WholeHeaderLaws.lean` |
| App. B whole-header assignments followed by field operations | `hfield` | `Fields.whole_assign_field_operations` | `StackatPaper/AppendixB/WholeHeaderLaws.lean` |
| App. B the map into the algebra with fields | `hmap` | `Fields.Headers.stackHom_preserves` | `StackatPaper/AppendixB/Maps.lean` |
| App. B entries of M_e in the relational model | `hsem` | `Fields.Headers.semantic_entries` | `StackatPaper/AppendixB/Semantics.lean` |
| App. B completeness for whole-header expressions | `hcomp` | `Fields.Headers.whole_header_completeness` | `StackatPaper/AppendixB/HeaderCompleteness.lean` |
| App. B the derivation in the per-field system | `fderiv` | `Fields.finite_header_completeness` | `StackatPaper/Section5/Completeness.lean` |
| App. B an empty field domain | `empty` | `Fields.empty_domain` | `StackatPaper/AppendixB/EmptyDomain.lean` |
| App. C countermodel for matching cancellation | `indpp` | `Independence.push_pop_countermodel` | `StackatPaper/AppendixC.lean` |
| App. C countermodel for mismatch | `indmm` | `Independence.mismatch_countermodel` | `StackatPaper/AppendixC.lean` |
| App. C countermodel for partial identity | `indpi` | `Independence.pop_push_countermodel` | `StackatPaper/AppendixC.lean` |
| App. C each omitted law fails in a model of KA and the others | `indcm` | `Independence.scheme_countermodels` | `StackatPaper/AppendixC.lean` |
| App. C soundness in these models gives nonderivability | `indsound` | `Independence.not_derivable_of_countermodel` | `StackatPaper/AppendixC.lean` |
| App. D.1 at most \|S\|² insertions | `cost` | `marking_runs` | `StackatPaper/AppendixD/Marking.lean` |
| App. D.1 every marked cell contains a pair outside 𝓡_F | `badng` | `marked_not_good` | `StackatPaper/AppendixD/Marking.lean` |
| App. D.1 B is the complement of G; inclusion iff E ∩ B = ∅ | `bad` | `marked_complement_and_inclusion` | `StackatPaper/AppendixD/Marking.lean` |
| App. D.1 the executable marking computes the complement of G | `badexec` | `Executable.BadCells.good_iff` | `StackatPaper/AppendixD/BadCells.lean` |
| App. D.1 witness recovery | `counterexample` | `Executable.BadCells.counterexample_correct` | `StackatPaper/AppendixD/Counterexample.lean` |
| Proposition 11 (the least certificate) | `srcprop` | `source_directed_search` | `StackatPaper/AppendixD/SourceDirected.lean` |
| App. D.2 witness soundness and completeness of the inclusion test | `source` | `Executable.SourceDirected.counterexample_correct` | `StackatPaper/AppendixD/SourceDirected.lean` |
| Proposition 12 (short counterexamples) | `short` | `short_counterexamples` | `StackatPaper/AppendixD/LengthBounds.lean` |
| App. D.3 acceptance is closed under a common suffix | `shortsuf` | `accepted_suffix` | `StackatPaper/Section3/DFA.lean` |
| App. D.3 a rejected pair lies in a marked cell | `shortbad` | `marked_of_not_accepted` | `StackatPaper/AppendixD/Marking.lean` |
| App. D.3 at most b − 1 propagation steps | `shortpath` | `markedWithin_bound` | `StackatPaper/AppendixD/LengthBounds.lean` |
| App. D.3 representatives of length at most n − 1 | `shortrep` | `exists_short_representative` | `StackatPaper/AppendixD/LengthBounds.lean` |
| App. D.3 the witness grows by one letter per step | `shortwit` | `MarkedWithin.exists_short` | `StackatPaper/AppendixD/LengthBounds.lean` |
| App. D.3 n = r + s + 3 reachable states | `lbcard` | `LowerBound.card_state_reachable` | `StackatPaper/AppendixD/LowerBound.lean` |
| App. D.3 the sets L_i that make up U_i and V_j | `lbclass` | `LowerBound.classes` | `StackatPaper/AppendixD/LowerBound.lean` |
| App. D.3 the target rejects exactly (ba^t, a^t) | `lbrej` | `LowerBound.not_accepted_iff` | `StackatPaper/AppendixD/LowerBound.lean` |
| App. D.3 the shortest counterexample has maximum length rs | `lower` | `LowerBound.quadratic_lower_bound` | `StackatPaper/AppendixD/LowerBound.lean` |
| App. D.3 consecutive r, s give rs = Ω(n²) | `consec` | `LowerBound.consecutive_and_two_three` | `StackatPaper/AppendixD/LowerBound.lean` |
| App. D.4 the remainder ρ(u), u = (ab)^k ρ(u) with k maximal | `exrem` | `Example.rem_eq_iff` | `StackatPaper/RunningExample/Basic.lean` |
| App. D.4 (u,v) ∈ R_f iff ρ(u) = ρ(v) | `exrf` | `Example.R_f_iff` | `StackatPaper/RunningExample/Basic.lean` |
| App. D.4 the remainder on L_s, L_β, L_α | `exremcls` | `Example.rem_on_classes` | `StackatPaper/RunningExample/Tables.lean` |
| App. D.4 the remainder on L_⊥ | `exrembot` | `Example.rem_on_bot` | `StackatPaper/RunningExample/Tables.lean` |
| App. D.5 the products T_c C T_dᵀ | `exT` | `Example.T_products` | `StackatPaper/RunningExample/Matrices.lean` |
| App. D.5 stripping b reaches (α,α), stripping a the cells of E | `exstrip` | `Example.stripping` | `StackatPaper/RunningExample/Tables.lean` |
| App. D.5 XCY = q_a p_a E + q_b p_b Δ_α ≤ F + C | `exxcy` | `Example.XCY_eq_le` | `StackatPaper/RunningExample/Matrices.lean` |
| App. D.5 the zero initial row and column of C | `exzero` | `Example.C_row_col_s` | `StackatPaper/RunningExample/Matrices.lean` |
| App. D.5 the edges of Figure 4 | `exbridge` | `Example.bridge_edges` | `StackatPaper/RunningExample/Matrices.lean` |
| App. D.5 Φ(C) = Q⁺P⁺ + Q* q_a p_a P* | `exphic` | `Example.PhiC_eq` | `StackatPaper/RunningExample/Algebra.lean` |
| App. D.5 (α,α) is needed to close the certificate | `excontains` | `Example.αα_needed` | `StackatPaper/RunningExample/Words.lean` |

The further definitions listed in the Definitions part of the map, in its order:

| definition | file |
|---|---|
| `SoundnessAndCompleteness` | `StackatPaper/Spec.lean` |
| `Soundness` | `StackatPaper/Section2.lean` |
| `Completeness` | `StackatPaper/Section2.lean` |
| `InequationalCompleteness` | `StackatPaper/Section2.lean` |
| `StackLaw` | `StackatPaper/Background/FreeAlgebra.lean` |
| `DerivesWith` | `StackatPaper/Background/FreeAlgebra.lean` |
| `q` | `StackatPaper/Section3/Words.lean` |
| `p` | `StackatPaper/Section3/Words.lean` |
| `Expr.PopOnly` | `StackatPaper/AppendixA/NormalForm.lean` |
| `Expr.PushOnly` | `StackatPaper/AppendixA/NormalForm.lean` |
| `Expr.sum` | `StackatPaper/AppendixA/NormalForm.lean` |
| `Expr.npow` | `StackatPaper/RunningExample/Words.lean` |
| `Expr.instPowNat` | `StackatPaper/RunningExample/Words.lean` |
| `DFA` | `StackatPaper/Section3/DFA.lean` |
| `DFA.h` | `StackatPaper/Section3/DFA.lean` |
| `DFA.L` | `StackatPaper/Section3/DFA.lean` |
| `StackAutomaton` | `StackatPaper/AppendixA/Automaton.lean` |
| `StackGraph.paths` | `StackatPaper/AppendixA/Automaton.lean` |
| `StackAutomaton.eval` | `StackatPaper/AppendixA/Automaton.lean` |
| `StackGraph` | `StackatPaper/AppendixA/StackGraph.lean` |
| `StackGraph.transition` | `StackatPaper/AppendixA/StackGraph.lean` |
| `SharedDFA.State` | `StackatPaper/Section3/SharedDFA.lean` |
| `SharedDFA.dfa` | `StackatPaper/Section3/SharedDFA.lean` |
| `SharedDFA.accepts` | `StackatPaper/Section3/SharedDFA.lean` |
| `tableProgram` | `StackatPaper/Section3/Tables.lean` |
| `boolMatrix` | `StackatPaper/Background/BooleanMatrix.lean` |
| `FreeAlgebraWith` | `StackatPaper/Background/FreeAlgebra.lean` |
| `FreeAlgebraWith.of` | `StackatPaper/Background/FreeAlgebra.lean` |
| `FreeAlgebra` | `StackatPaper/Background/FreeAlgebra.lean` |
| `FreeAlgebra.of` | `StackatPaper/Background/FreeAlgebra.lean` |
| `Accepted` | `StackatPaper/Section3/DFA.lean` |
| `Rel` | `StackatPaper/Background/Relations.lean` |
| `Rel.push` | `StackatPaper/Background/Relations.lean` |
| `Rel.pop` | `StackatPaper/Background/Relations.lean` |
| `Example.Letter` | `StackatPaper/RunningExample/Basic.lean` |
| `Example.Q` | `StackatPaper/RunningExample/Basic.lean` |
| `Example.P` | `StackatPaper/RunningExample/Basic.lean` |
| `Example.e` | `StackatPaper/RunningExample/Basic.lean` |
| `Example.f` | `StackatPaper/RunningExample/Basic.lean` |
| `Example.abPow` | `StackatPaper/RunningExample/Basic.lean` |
| `Residual` | `StackatPaper/Section3/TargetTable.lean` |
| `CertificateConditions` | `StackatPaper/Section3/TargetTable.lean` |
| `Example.St` | `StackatPaper/RunningExample/Basic.lean` |
| `Example.step` | `StackatPaper/RunningExample/Basic.lean` |
| `Example.dfa` | `StackatPaper/RunningExample/Basic.lean` |
| `Example.E` | `StackatPaper/RunningExample/Tables.lean` |
| `Example.F` | `StackatPaper/RunningExample/Tables.lean` |
| `Example.C` | `StackatPaper/RunningExample/Tables.lean` |
| `Example.G` | `StackatPaper/RunningExample/Tables.lean` |
| `MatrixStar.matrixStar` | `StackatPaper/Background/MatrixStar.lean` |
| `initialVec` | `StackatPaper/Section4/Derivation.lean` |
| `Example.Qk` | `StackatPaper/RunningExample/Algebra.lean` |
| `Example.Pk` | `StackatPaper/RunningExample/Algebra.lean` |
| `Fields.Header` | `StackatPaper/Section5/Spec.lean` |
| `Fields.Expr` | `StackatPaper/Section5/Spec.lean` |
| `Fields.Expr.sum` | `StackatPaper/Section5/Spec.lean` |
| `Fields.Expr.denote` | `StackatPaper/Section5/Spec.lean` |
| `Fields.R` | `StackatPaper/Section5/Spec.lean` |
| `Fields.Soundness` | `StackatPaper/Section5/Spec.lean` |
| `Fields.Completeness` | `StackatPaper/Section5/Spec.lean` |
| `Fields.InequationalCompleteness` | `StackatPaper/Section5/Spec.lean` |
| `Fields.FieldModel` | `StackatPaper/AppendixB/WholeHeaderLaws.lean` |
| `Fields.wholeTest` | `StackatPaper/AppendixB/WholeHeaderLaws.lean` |
| `Fields.wholeAssign` | `StackatPaper/AppendixB/WholeHeaderLaws.lean` |
| `Fields.Headers.HeaderModel` | `StackatPaper/AppendixB/Translation.lean` |
| `Fields.Headers.Expr` | `StackatPaper/AppendixB/HeaderSpec.lean` |
| `Fields.Headers.Expr.sum` | `StackatPaper/AppendixB/HeaderSpec.lean` |
| `Fields.Headers.eval` | `StackatPaper/AppendixB/Translation.lean` |
| `Decision.InclusionResult` | `StackatPaper/Section6/Results.lean` |
| `Decision.EquivalenceResult` | `StackatPaper/Section6/Results.lean` |
| `Executable.PureDecision.decide_inclusion` | `StackatPaper/Section6/PureDecision.lean` |
| `Executable.PureDecision.decide_equivalence` | `StackatPaper/Section6/PureDecision.lean` |
| `Fields.Decision.InclusionResult` | `StackatPaper/Section6/Results.lean` |
| `Fields.Decision.EquivalenceResult` | `StackatPaper/Section6/Results.lean` |
| `Fields.Executable.decide_inclusion` | `StackatPaper/Section6/FieldDecision.lean` |
| `Fields.Executable.decide_equivalence` | `StackatPaper/Section6/FieldDecision.lean` |
| `Decision.CellCertificate` | `StackatPaper/Section6/Executable/DecisionData.lean` |
| `Decision.Answer` | `StackatPaper/Section6/Executable/DecisionData.lean` |
| `Decision.Correct` | `StackatPaper/Section6/Executable/DecisionData.lean` |
| `Executable.PureDecision.checkAnswer` | `StackatPaper/Section6/PureDecision.lean` |
| `Fields.Decision.Answer` | `StackatPaper/Section6/Executable/FieldDecisionData.lean` |
| `Fields.Decision.Correct` | `StackatPaper/Section6/Executable/FieldDecisionData.lean` |
| `Fields.Executable.checkAnswer` | `StackatPaper/Section6/FieldDecision.lean` |
| `Closure.Op` | `StackatPaper/Section7.lean` |
| `Closure.InClosure` | `StackatPaper/Section7.lean` |
| `Closure.pops` | `StackatPaper/Section7.lean` |
| `Closure.pushes` | `StackatPaper/Section7.lean` |
| `Closure.diagonal` | `StackatPaper/Section7.lean` |
| `StackAutomaton.ofExpr` | `StackatPaper/AppendixA/Automaton.lean` |
| `StackGraph.Balanced` | `StackatPaper/AppendixA/Saturation.lean` |
| `StackGraph.surround` | `StackatPaper/AppendixA/Saturation.lean` |
| `Fields.Headers.FreeAlgebra` | `StackatPaper/AppendixB/HeaderAlgebra.lean` |
| `Fields.Headers.stackHom` | `StackatPaper/AppendixB/Maps.lean` |
| `Fields.Headers.Expr.denote` | `StackatPaper/AppendixB/HeaderSpec.lean` |
| `Fields.Headers.R` | `StackatPaper/AppendixB/HeaderSpec.lean` |
| `Fields.Headers.Derives` | `StackatPaper/AppendixB/HeaderSpec.lean` |
| `StackLaw.Holds` | `StackatPaper/Background/FreeAlgebra.lean` |
| `Independence.zeroOp` | `StackatPaper/AppendixC.lean` |
| `Independence.oneOp` | `StackatPaper/AppendixC.lean` |
| `Independence.bitPush` | `StackatPaper/AppendixC.lean` |
| `Independence.bitPop` | `StackatPaper/AppendixC.lean` |
| `Expr.eval` | `StackatPaper/Background/FreeAlgebra.lean` |
| `CanInsert` | `StackatPaper/AppendixD/Marking.lean` |
| `MarkingRun` | `StackatPaper/AppendixD/Marking.lean` |
| `Stuck` | `StackatPaper/AppendixD/Marking.lean` |
| `Executable.BadCells.Direct` | `StackatPaper/AppendixD/BadCells.lean` |
| `Executable.BadCells.bad` | `StackatPaper/AppendixD/BadCells.lean` |
| `Executable.BadCells.counterexample` | `StackatPaper/AppendixD/Counterexample.lean` |
| `Executable.SourceDirected.Prepared` | `StackatPaper/AppendixD/SourceDirected.lean` |
| `Executable.SourceDirected.counterexample` | `StackatPaper/AppendixD/SourceDirected.lean` |
| `MarkedWithin` | `StackatPaper/AppendixD/LengthBounds.lean` |
| `LowerBound.Letter` | `StackatPaper/AppendixD/LowerBound.lean` |
| `LowerBound.State` | `StackatPaper/AppendixD/LowerBound.lean` |
| `LowerBound.aut` | `StackatPaper/AppendixD/LowerBound.lean` |
| `LowerBound.aw` | `StackatPaper/AppendixD/LowerBound.lean` |
| `LowerBound.F` | `StackatPaper/AppendixD/LowerBound.lean` |
| `Example.rem` | `StackatPaper/RunningExample/Basic.lean` |
| `Example.T` | `StackatPaper/RunningExample/Matrices.lean` |
| `Example.Δα` | `StackatPaper/RunningExample/Matrices.lean` |
<!-- /claims -->

## Checks

* `checks/claims.py`: the claims table (key, paper item, headline) and
  the further definitions of the map; it generates `checks/Coverage.lean` (`#check` of every
  declaration, in the order of the map), `checks/Audit.lean` (`#print axioms`), `checks/roots.txt`,
  and, with `checks/locations.txt` from `checks/Locations.lean`, the tables of this file (`python3 checks/claims.py --docs`); `checks/check.sh` regenerates all of them.
* `checks/Minimality.lean`: lists every declaration of `StackatPaper` outside the dependency
  closure of the claims and of the executable tests. It reports none. Instances and `rfl` simp
  lemmas leave no trace in proof terms; the ones it lists separately were each checked to be
  needed (removing them breaks the build).
* `checks/tests/`: the executable and decision tests of §5 (`lake build decisionTests …`).
